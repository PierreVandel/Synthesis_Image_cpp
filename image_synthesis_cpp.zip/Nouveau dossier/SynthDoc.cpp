// SynthDoc.cpp : implementation of the CSynthDoc class
//

#include "stdafx.h"
#include "Synth.h"

#include "SynthDoc.h"

#include "Spline2D.h"

#include "Spline2DView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define NB_MAX_SPLINE2D 500

#define ID_BITMAP_WINDOW 56789

/////////////////////////////////////////////////////////////////////////////
// CSynthDoc

IMPLEMENT_DYNCREATE(CSynthDoc, CDocument)

BEGIN_MESSAGE_MAP(CSynthDoc, CDocument)
	//{{AFX_MSG_MAP(CSynthDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSynthDoc construction/destruction

CSynthDoc::CSynthDoc()
{
	// TODO: add one-time construction code here

	// Initialisation des donnees membres
	nbmaxSpline2D = NB_MAX_SPLINE2D;
	nbSpline2D = 0;
	p_Splines2D = new Spline2D*[nbmaxSpline2D];
	vue_active = VUE3D;

	hauteur_effective = 100;

	besoinupdateobjetseditables=false;
	fenetreSpline3DViewouverte=false;

	surfaceobj=NULL;
	objetedite=NULL;

	icone_sphere = AfxGetApp()->LoadIcon(IDI_ICON_SPHERE);

	hasaname = false;
	filename[0] = '\0';

	p_mywindow=NULL;

}

CSynthDoc::~CSynthDoc()
{

	for (int i = 0 ; i < nbSpline2D ; i++)
		delete p_Splines2D[i];
	if (nbmaxSpline2D>0)
		delete [] p_Splines2D;
}

BOOL CSynthDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	SetTitle(CString("untitled"));
	
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CSynthDoc serialization

void CSynthDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSynthDoc diagnostics

#ifdef _DEBUG
void CSynthDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSynthDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSynthDoc commands

BOOL CSynthDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{



	hasaname = true;
	CString lePathName(lpszPathName);

	int i=0;
	int longueur = lePathName.GetLength();
	for (i = 0 ; i < longueur ; i++){
		filename[i] = lpszPathName[i];
	}
	filename[i] = '\0';


	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	
	// TODO: Add your specialized creation code here
	
	return TRUE;
}
