


#include <fstream>
using namespace std;

#include "objet3D.h"

class CSynthDoc;

#define INFINI 1.2e38


class Spline2D;
class DiscreteSceneGeometry;
class Tableaufloats;
class OaktreeNode;

//////////////////////////////////////////////////////////////////////
// Classe Celluleobj : cellule pour liste chainnee de pointeurs sur Objets3D
//////////////////////////////////////////////////////////////////////

class Celluleobj{
	friend class Listeobj;
	friend class Scene3D;
	friend class Scene3DRay;
	friend class Scene3DRadio;
	Objet3D *pobjet;    // pointeur sur un Objet3D
	Celluleobj * suiv;  // pointeur sur la cellule suivante

public:
	Celluleobj(void){suiv = NULL; pobjet = NULL;}
	Celluleobj(Objet3D * pobj);
	~Celluleobj(void){};
};


// Classe Listeobj : liste chainee d'Objet3D

class Listeobj{
	friend class Scene3D;
	friend class Scene3DRay;
	friend class Scene3DRadio;

public: // a enlever...

	Celluleobj *L;  // pointeur sur la tete de liste

public:

	// construction et destruction :
	Listeobj(){L = NULL;}
	~Listeobj();
	Listeobj(Listeobj &);
	Listeobj & operator=(Listeobj &);
	void destruction(void);

	// insertion en tete de liste :
	void inseretete(Objet3D * pobj);       // pobj doit etre alloue precedament 

};


//////////////////////////////////////////////////////////////////////
// Classe Scene3D : Contient toutes les donnees de la scene :
// objets 3D, cameras, sources lumineuses
// plus des donnees necessaires a l'algorithme du z-buffer
//////////////////////////////////////////////////////////////////////

class Arete;  // defini dans CelluleTA.h

class Scene3D{

	// donnees necessaires au stockage de la scene :

protected:

	Objet3D* objetselect; // pointer to the selected object
	Listeobj objets;  	// Liste des objets 3D de la scene
	int nogroupe[10000];

	Sourcelum * tablum;  // tableau des sources lumineuses
	int nblum;  // nombre de sources lumineuses ins�r�es par l'utilisateur
	int nblummax;  // nombre maximum de sources lumineuses

	double lumambiantR, lumambiantG, lumambiantB;  // ambiant light
	double fondR, fondG, fondB;  // background color

	Camera **tabcam;  // tableau de pointeurs sur des cam�ras
	int nbcam;  // nombre de cam�ras
	int nocamselect;  // numero de la camera selectionnee 


	int dimfenetrex, dimfenetrey;  //  dimensions de la fenetre graphique (nombre de pixels)

	double minix, maxix, miniy, maxiy, miniz, maxiz; // dimensions approximatives de la scene



	// Donnees necessaires a l'algorithme du z-buffer :

	char etatzbuffer;  // niveau d'antialiassage : simple z-buffer -> 1, double -> 2, triple -> 3
	int dim2Dx, dim2Dy;  // dimension de l'image calculee :
						 // dim2Dx = etatzbuffer*dimfenetrex et dim2Dy = etatzbuffer*dimfenetrey

	float ** minz;  // z-buffer contenant le min de la profondeur z en chaque pixel
	unsigned char **bufferR, **bufferG, **bufferB; // matrices pour stockage des couleurs en chaque pixel
	unsigned short** numobjets;  // stockage du numero de l'objet en chaque pixel (pour selection d'objets par click de souris)

	
	Arete * tabaretes; // edges of a polygone 2D for z-buffer (voir classe Polygone2D dans CelluleTA.h)
					   // pour remplissage (necessaire a l'algorithme du z-buffer)
	int nbmaxaretes;  // dimension maximale du tableau tabaretes

	double *inclipx, *inclipy, *outclipx, *outclipy;  // used for clipping (fenetrage)

	// boolean disply style parameters:
	bool voiraxes;
	bool enableambiante;
	bool enablephong;
	bool enabledifuse;
	bool enablespecular;
	bool enabletexture;
	bool enablebumpmap;
	bool enablegouraud;



public:

	// constructeur par defaut
	Scene3D(void){etatzbuffer=1; dimfenetrex = dimfenetrey = dim2Dx = dim2Dy = 0; minz = NULL; 
	              numobjets=NULL; bufferR=bufferG=bufferB=NULL; tabaretes = NULL; nblum=0; tablum=NULL; nbcam=0; 
				  tabcam=NULL;nbcam=0;nbmaxaretes=0;
				  fondB=fondG=fondB=0.0;
					inclipx = inclipy = outclipx = outclipy = NULL;voiraxes=true;
				objetselect=NULL;}

	// initialisation de la scene et initialisation des cameras :
	Scene3D(int dimx, int dimy, 
			double xmin, double xmax, double ymin, double ymax, double zmin, double zmax,
			int nbcamera, double hautcam, int nblumiere,
			double lumambR, double lumambG, double lumambB,
			double fR, double fG, double fB){Construction(dimx, dimy, 
												xmin, xmax, ymin, ymax, zmin, zmax,
												nbcamera, hautcam, nblumiere,
												lumambR, lumambG, lumambB,
												fR, fG, fB);}
	void Construction(int dimx, int dimy, 
			double xmin, double xmax, double ymin, double ymax, double zmin, double zmax,
			int nbcamera, double hautcam, int nblumiere,
			double lumambR, double lumambG, double lumambB,
			double fR, double fG, double fB);

	
	//			int nbmaxsp2D, int nbsp2D, Spline2D **psp2D
			

	// allocation et liberation de matrices de floats et unsigned char
	float ** allouerfloats2D(int dimx, int dimy);
	unsigned char ** alloueruchar2D(int dimx, int dimy);
	unsigned short ** allouerushort2D(int dimx, int dimy);
	void liberer(float **t, int dimx);
	void liberer(unsigned char **t, int dimx);
	void liberer(unsigned short **t, int dimx);


	// destruction de la scene :
	virtual void destruction(void);
	// destruction uniquement des matrices
	void detruitmatrices(void);
	bool restorematrices(void);
	// accesseurs :
	double getmaxx(){return maxix;} 
	double getmaxy(){return maxiy;} 
	double getmaxz(){return maxiz;} 
	int nocameraselect(){return nocamselect;}
	double nbcameras(){return nbcam;}
	Camera *getcamselect(void){return tabcam[nocamselect];}


	void updateobjetselect(Objet3D*& nouveauobjetselect);

	unsigned short selectionneobjet(CPoint pixel, CDC & cdc, unsigned short * numobjetselect, int& nbobjetselect, bool ctrlpressed);
	int editeobjet(unsigned short numobjetselect, int nbsplines2D, Spline2D** pSplines2D, Objet3D *&pobjetselect);
	int supprimeobjet(unsigned short* numobjetselect, int nbobjetselect);
	int editsourcelum(int nosource);
	int supprimesourcelum(int nosource);
	int getnblum(void){return nblum;}
	Objet3D * getobjetselect(void){return objetselect;}
	void groupeobjets(unsigned short *numobjetselect, int nbobjetselect);
	void ungroupobjets(unsigned short *numobjetselect, int nbobjetselect);
	Point3D GetCenterSelectedObjects(unsigned short * numobjetselect, int & nbobjetselect);
	void transform(Point3D translat, Point3D orig, double sca, Point3D diraxe, double angle, unsigned short * numobjetselect, int & nbobjetselect);
	unsigned short GetNumHead(void){return objets.L == NULL ? 0 : objets.L->pobjet->numero;}

	// insertion d'un objet 3D dans la scene
	void inseretete(Objet3D *pobj);  // l'Objet3D doit etre alloue et est recopie
									 // il faut donc eventuellement le detruire apres insertion

	// changes of coordinate system
	void MettreDansRepereCamera(Objet3D * pobj);
	void MettreDansRepereScene(Objet3D * pobj);
	void MettreTousObjetsDansRepereScene(void);
	void MettreTousObjetsDansRepereCamera(void);

	// insertion d'une source lumineuse ponctuelle non directionnelle
	void inserelum(double posx, double posy, double posz, 
					double coulR, double coulG, double coulB,
					bool direct, double dx, double dy, double dz, int expo,
					bool att, double coefc1, double coefc2, double coefc3); 

	// changement des dimensions de la fenetre graphique :
	virtual bool setdim2D(int dimx, int dimy); // retourne true si echec

	// changement du mode d'antialiassage (simple, double, triple z-buffer) :
	void setsamplebuffer(char etat);

	// Fonction de fenetrage (clipping) : intersection d'un polygone 2D avec une fenetre rectangulaire
	void clip(int nbsomm, double *tabx, double *taby,
				int* outcount, double *taboutx, double * tabouty, 
				double xmin, double ymin, double xmax, double ymax);

	// Fonctions annexes a l'algorithme du z-buffer :
	Point3D calculpoint3d(const Facette & face, int x, int y, double d);
	Point3D calculnormale(Objet3D & objet, const Facette &face, Point3D p3d, bool phong);
	Couleur calculcouleur(Couleur couleurobjet, Point3D p3d, Point3D  normale, Objet3D & objet, bool ambiante, bool difuse, bool specular);
	Couleur calculcouleur(Objet3D & objet, const Facette & face, 
							Point3D p3d, Point3D normale,  
							bool ambiante, bool difuse, bool specular,
							bool phong, bool gouraud, bool texture);
	Couleur calculcouleurgouraud(Intensitesgouraud intens, Couleur couleurobjet);
	Intensitesgouraud calculsommetgouraud(Point3D p3d, Point3D  normale, 
													const Objet3D & objet, 
													bool ambiante, bool difuse, bool specular);
	void calculeinetnsitesommetsgouraud(void);

	// necessaire pour les fonctionalites de radiosite discrete du zbuffer
	virtual void calcultermedifus(Point3D p3d, double &R, double &G, double &B, Objet3D &objet){};



	// fonction z-buffer qui appelle z-bufferperspect ou z-bufferparal selon le type de camera
	void zbuffer(imcouleur& bitmap_dib){
								if (nocamselect >= 0 && nocamselect < nbcam)
									if (tabcam[nocamselect]->type == PARAL) zbufferparal(bitmap_dib);
									else zbufferperspect(bitmap_dib);}
	
	// z-buffer dans le cas d'une projection parallele (non implemente)
	void zbufferparal(imcouleur& bitmap_dib);
	void parcourspolyparal(Facette face, Objet3D &objet, float **minz);

	// z-buffer dans le cas d'une projection en perspective
	void zbufferperspect(imcouleur& bitmap_dib);
	void parcourspolyperspect(Facette& face,  Objet3D &objet, bool phong,double d);


	virtual bool getenableradiosite(void){return false;}


	// Fonctions relatives a la navigation :
	int selectcam(int nocam);  // selection d'une camera par son numero
	void translatecam(double dx, double dy, double dz);  // translation d'une camera
	void translatecamcentral(double dx, double dy, double dz);
	void rotatecamcentral(double teta, char noaxe);
	void rotatecam(double teta, char noaxe);  // rotation d'une camera
	void rotatetranslatecam(double teta, double steptransl, char noaxe);
	void redrescam(void);  // redressement d'une camera (l'axe des z devient vertical
    void changecam(double px, double py, double pz,
		           double cx, double cy, double cz, double ax); // changement des parametres d'une camera

	// fonctions d'exportation 3D :
	void ecrit_polytext(char *nomfichier);
	void ecrit_scene(ofstream &fich, int nbmaxsp2d, int nbsp2d, Spline2D **ppSpline2D);
	void ecritobjetselect(ofstream &fich, unsigned short *numobjetselect, int nbobjetselect);


	// fonctions d'importation 3D :
	void charge_polytext(ifstream * fich);
	virtual void charge_scene(ifstream& fich, Spline2D **& ppSpline2D, int& nbmaxsp2d, int& nbsp2d, int dimx, int dimy);
	void litobj(ifstream &fich, bool translation, Spline2D** ppSpline2D, int noversion,
				Point3D translat, Point3D orig, double sca, Point3D diraxe, double angle);
	// accesseur :
	Camera * & cameraselectionnee(void);


	void setetatvoiraxes(bool etat){voiraxes = etat;}
	void setenableambiante(bool etat){enableambiante = etat;}
	void setenabledifuse(bool etat){enabledifuse = etat;}
	void setenablespecular(bool etat){enablespecular = etat;}
	void setenabletexture(bool etat){enabletexture = etat;}
	void setenablebumpmap(bool etat){enablebumpmap = etat;}
	void setenablephong(bool etat){enablephong = etat;}
	void setenablegouraud(bool etat){enablegouraud = etat;}

	bool getetatvoiraxes(void){return voiraxes;}
	bool getenableambiante(void){return enableambiante;}
	bool getenabledifuse(void){return enabledifuse;}
	bool getenablespecular(void){return enablespecular;}
	bool getenabletexture(void){return enabletexture;}
	bool getenablebumpmap(void){return enablebumpmap;}
	bool getenablephong(void){return enablephong;}
	bool getenablegouraud(void){return enablegouraud;}


	char getetatzbuffer(void){return etatzbuffer;}



};





