#include "stdafx.h"
#include "Synth.h"
#include "Camera.h"
#include "SurfaceSpline.h"
#include <fstream>
#include "math.h"
using namespace std;

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif



Surface * SurfaceBSplineCubiqueCylindre::copie(void){
	SurfaceBSplineCubiqueCylindre *surf=new SurfaceBSplineCubiqueCylindre;

	surf->nbpatches=3;
	for (int i = 0 ; i < nbpatches ; i ++){
		surf->patches[i] = patches[i]->copie();
		surf->nbctrlpatch[i] = nbctrlpatch[i];
	}

	return surf;
}





void SurfaceBSplineCubiqueCylindre::deplaceeffectctrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, Camera*cam){

	if (i < nbctrlpatch[0]){
		patches[0]->deplaceeffectctrlpoint(i,j,v,rayondeform_i, rayondeform_j,cam);
		patches[1]->deplaceeffectctrlpoint(patches[1]->GetNbRaws()-3-i,patches[1]->GetNbCols()-3+patches[0]->GetNbCols()-3-j,v,rayondeform_i, rayondeform_j,cam);
		patches[2]->deplaceeffectctrlpoint(i,patches[2]->GetNbCols()-3+j-2,v,rayondeform_i, rayondeform_j,cam);

		return;
	}

	if (i < nbctrlpatch[0] + nbctrlpatch[1]){
		i = i-nbctrlpatch[0];
		patches[0]->deplaceeffectctrlpoint(patches[1]->GetNbRaws()-3-i,patches[1]->GetNbCols()-3-j+patches[0]->GetNbCols()-3,v,rayondeform_i, rayondeform_j,cam);
		patches[1]->deplaceeffectctrlpoint(i,j,v,rayondeform_i, rayondeform_j,cam);
		patches[2]->deplaceeffectctrlpoint(patches[1]->GetNbRaws()-3-i,patches[2]->GetNbCols()-3+patches[1]->GetNbCols()-3-j+patches[0]->GetNbCols()-5,v,rayondeform_i, rayondeform_j,cam);

		return;
	}

	i = i-nbctrlpatch[0]-nbctrlpatch[1];
	patches[0]->deplaceeffectctrlpoint(i,-(patches[2]->GetNbCols()-3-j)+2,v,rayondeform_i, rayondeform_j,cam);
	patches[1]->deplaceeffectctrlpoint(patches[1]->GetNbRaws()-3-i,patches[1]->GetNbCols()-3+(patches[2]->GetNbCols()-3-j)+patches[0]->GetNbCols()-5,v,rayondeform_i, rayondeform_j,cam);
	patches[2]->deplaceeffectctrlpoint(i,j,v,rayondeform_i, rayondeform_j,cam);


}



SurfaceBSplineCubiqueCylindre::SurfaceBSplineCubiqueCylindre(istream &fich){

	nbpatches = 3;

	patches[0] = new SurfaceBSplineCubiqueCyl(fich);
	nbctrlpatch[0] = patches[0]->GetNbCtrl();

	patches[1] = new SurfaceBSplineCubiqueDisk(fich);
	nbctrlpatch[1] = patches[1]->GetNbCtrl();

	patches[2] = new SurfaceBSplineCubiqueDisk(fich);
	nbctrlpatch[2] = patches[2]->GetNbCtrl();
}




SurfaceBSplineCubiqueCylindre::SurfaceBSplineCubiqueCylindre(Point3D**ctrlbody, int nblbody, int nbcbody,
									Point3D**ctrltop, int nbltop, int nbctop,
									Point3D**ctrlbottom, int nblbottom, int nbcbottom){


	nbpatches = 3;
	nbctrlpatch[0] = nblbody*nbcbody;
	nbctrlpatch[1] = nbltop*nbctop;
	nbctrlpatch[2] = nblbottom*nbcbottom;

	patches[0] = new SurfaceBSplineCubiqueCyl(ctrlbody,nblbody,nbcbody);
	patches[1] = new SurfaceBSplineCubiqueDisk(ctrltop,nbltop,nbctop);
	patches[2] = new SurfaceBSplineCubiqueDisk(ctrlbottom,nblbottom,nbcbottom);
}



void SurfaceBSplineCubiqueCylindre::lisser(double amplitude, int i0, int j0, int ri, int rj){
	
	int i=i0, j=j0;

	if (i < nbctrlpatch[0]){
		patches[0]->lisser(amplitude, i,j, ri, rj);
		patches[1]->lisser(amplitude, patches[1]->GetNbRaws()-3-i,patches[1]->GetNbCols()-3+patches[0]->GetNbCols()-3-j, ri, rj);
		patches[2]->lisser(amplitude, i,patches[2]->GetNbCols()-3+j-2, ri, rj);

		return;
	}

	if (i < nbctrlpatch[0] + nbctrlpatch[1]){
		i = i-nbctrlpatch[0];
		patches[0]->lisser(amplitude, patches[1]->GetNbRaws()-3-i,patches[1]->GetNbCols()-3-j+patches[0]->GetNbCols()-3, ri, rj);
		patches[1]->lisser(amplitude, i,j, ri, rj);
		patches[2]->lisser(amplitude, patches[1]->GetNbRaws()-3-i,patches[2]->GetNbCols()-3+patches[1]->GetNbCols()-3-j+patches[0]->GetNbCols()-5, ri, rj);

		return;
	}

	i = i-nbctrlpatch[0]-nbctrlpatch[1];
	patches[0]->lisser(amplitude, i,-(patches[2]->GetNbCols()-3-j)+2, ri, rj);
	patches[1]->lisser(amplitude, patches[1]->GetNbRaws()-3-i,patches[1]->GetNbCols()-3+(patches[2]->GetNbCols()-3-j)+patches[0]->GetNbCols()-5, ri, rj);
	patches[2]->lisser(amplitude, i,j, ri, rj);

}

