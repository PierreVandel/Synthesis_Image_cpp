#include <stdlib.h>

#include "stdafx.h"
#include "Synth.h"

#include "SynthDoc.h"
#include "SynthView.h"
#include "NouvSceDilog.h"
#include "ObjetsDialog.h"

#include "Objet3D.h"
#include "imcouleur.h"

#include <fstream>
using namespace std;



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



void CSynthView::OnFileNouvsce() 
{
	// TODO: Add your command handler code here

	CNouvSceDilog dlg;

	dlg.m_xmin = -100;
	dlg.m_xmax = +100;
	dlg.m_ymin = -100;
	dlg.m_ymax = +100;
	dlg.m_zmin = -100;
	dlg.m_zmax = +100;
	dlg.m_nbcam = 20;
	dlg.m_hautcam = +40;
	dlg.m_nblum = 20;
	dlg.m_lumambiantR = 0.5;
	dlg.m_lumambiantG = 0.5;
	dlg.m_lumambiantB = 0.5;
	dlg.m_fondR = 0.0;
	dlg.m_fondG = 0.0;
	dlg.m_fondB = 0.0;

	CSynthDoc * pdoc = (CSynthDoc*)GetDocument();	

	int ret = dlg.DoModal();
	if (ret != IDCANCEL){
		steptrans = (float)0.05*(dlg.m_xmax - dlg.m_xmin);
		steprot = 10;
		steprotnavigat = 5;
		steptransnavigat = (float)0.1*(dlg.m_xmax - dlg.m_xmin);
		scene = Scene3DRay(dimx, dimy, 
						dlg.m_xmin, dlg.m_xmax, 
						dlg.m_ymin, dlg.m_ymax,
						dlg.m_zmin, dlg.m_zmax,
						dlg.m_nbcam, dlg.m_hautcam,
						dlg.m_nblum,
						dlg.m_lumambiantR, dlg.m_lumambiantG, dlg.m_lumambiantB,
						dlg.m_fondR, dlg.m_fondG, dlg.m_fondB);
//						pdoc->nbmaxSpline2D, pdoc->nbSpline2D, pdoc->p_Splines2D);



		activinsere = 1;
		scene.selectcam((int)(1*(dlg.m_nbcam / 10)));


		CClientDC cdc(this);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}
}


void CSynthView::OnUpdateFileNouvsce(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(enableuseinterface);
}



void CSynthView::OnFileSortiebmp() 
{
	// TODO: Add your command handler code here
	
	char nomfichier[150];
	

//	CExportBMP dlg;
//	dlg.m_nomfich = "noname.bmp";

	CFileDialog dlg(FALSE, CString("bmp"), CString("*.bmp"));

		int ret = dlg.DoModal();

	if (ret != IDCANCEL){
//		int longueur = dlg.m_nomfich.GetLength();
//		for (int i = 0 ; i < longueur ; i++){
//			nomfichier[i] = dlg.m_nomfich.GetAt(i);
//		}
		int longueur = dlg.GetPathName().GetLength();
    int i;
		for (i = 0 ; i < longueur ; i++){
			nomfichier[i] = dlg.GetPathName().GetAt(i);
		}
		nomfichier[i] = '\0';
		if (longueur < 4 ||
			(nomfichier[longueur-1] != 'p' && nomfichier[longueur-1] != 'P') ||
			(nomfichier[longueur-2] != 'm' && nomfichier[longueur-1] != 'M') ||
			(nomfichier[longueur-3] != 'b' && nomfichier[longueur-1] != 'B') ||
			nomfichier[longueur-4] != '.'){
			nomfichier[longueur] = '.';
			nomfichier[longueur+1] = 'b';
			nomfichier[longueur+2] = 'm';
			nomfichier[longueur+3] = 'p';
			nomfichier[longueur+4] = '\0';
		}


		bitmap_dib.ecritbmp(nomfichier);
		
	}
}

void CSynthView::OnUpdateFileSortiebmp(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);
}



void CSynthView::OnFileExportPolytext() 
{
	// TODO: Add your command handler code here

	char nomfichier[150];

	CFileDialog dlg(FALSE, CString("plt"), CString("*.plt"));

		int ret = dlg.DoModal();

	if (ret != IDCANCEL){
		int longueur = dlg.GetPathName().GetLength();
    int i;
		for (i = 0 ; i < longueur ; i++){
			nomfichier[i] = dlg.GetPathName().GetAt(i);
		}
		nomfichier[i] = '\0';
		if (longueur < 4 ||
			(nomfichier[longueur-1] != 't' && nomfichier[longueur-1] != 't') ||
			(nomfichier[longueur-2] != 'l' && nomfichier[longueur-1] != 'l') ||
			(nomfichier[longueur-3] != 'p' && nomfichier[longueur-1] != 'p') ||
			nomfichier[longueur-4] != '.'){
			nomfichier[longueur] = '.';
			nomfichier[longueur+1] = 'p';
			nomfichier[longueur+2] = 'l';
			nomfichier[longueur+3] = 't';
			nomfichier[longueur+4] = '\0';
		}


		scene.ecrit_polytext(nomfichier);
		
	}
	
}

void CSynthView::OnUpdateFileExportPolytext(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);
}

void CSynthView::OnFichierImportPolytext() 
{
	// TODO: Add your command handler code here

	char nomfichier[150];

	CFileDialog dlg(TRUE, CString("plt"), CString("*.plt"));

	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
		int longueur = dlg.GetPathName().GetLength();
    int i;
		for (i = 0 ; i < longueur ; i++){
			nomfichier[i] = dlg.GetPathName().GetAt(i);
		}
		nomfichier[i] = '\0';


		ifstream fich(nomfichier);

		if (fich.bad()){
			AfxMessageBox(CString("Probleme ouverture fichier !"));
			return;
		}


		steptrans = 10;
		steprot = 10;
		steprotnavigat = 5;
		steptransnavigat = 5;


		scene.charge_polytext(&fich);


		CClientDC cdc(this);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

}




void CSynthView::OnUpdateFichierImportPolytext(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);
}



void CSynthView::OnFileOpen() 
{
	// TODO: Add your command handler code here

	CFileDialog dlg(TRUE, CString("s3d"), CString("*.s3d"));


	CSynthDoc* pdoc = (CSynthDoc*)GetDocument();
	int ret = dlg.DoModal();

	int i = 0;
	if (ret != IDCANCEL){
		int longueur = dlg.GetPathName().GetLength();
		for (i = 0 ; i < longueur ; i++){
			pdoc->filename[i] = dlg.GetPathName().GetAt(i);
		}
		pdoc->filename[i] = '\0';


		ifstream fich(pdoc->filename);

		if (fich.bad()){
			AfxMessageBox(CString("Probleme ouverture fichier !"));
			return;
		}

		pdoc->hasaname=true;


		if (activinsere)
			scene.destruction();

		
		pdoc->SetTitle(CString(pdoc->filename));


		activinsere = 1;

		scene.charge_scene(fich, pdoc->p_Splines2D, pdoc->nbmaxSpline2D, pdoc->nbSpline2D, dimx, dimy);

		CClientDC cdc(this);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}


}

void CSynthView::OnFileSave() 
{
	// TODO: Add your command handler code here
		// TODO: Add your command handler code here

		CSynthDoc* pdoc = (CSynthDoc*)GetDocument();
		ofstream fich(pdoc->filename);

		if (fich.bad()){
			OnFileSaveAs();
			return;
		}
	

		scene.ecrit_scene(fich, pdoc->nbmaxSpline2D, pdoc->nbSpline2D, pdoc->p_Splines2D);
		

	

}

void CSynthView::OnUpdateFileSave(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
		CSynthDoc* pdoc = (CSynthDoc*)GetDocument();
	pCmdUI->Enable(activinsere && pdoc->hasaname);

}

void CSynthView::OnFileSaveAs() 
{
	// TODO: Add your command handler code here
		// TODO: Add your command handler code here
	char nomfichier[150];

	CFileDialog dlg(FALSE, CString("s3d"), CString("*.s3d"));

		int ret = dlg.DoModal();

	if (ret != IDCANCEL){
		int longueur = dlg.GetPathName().GetLength();
    int i;
		for (i = 0 ; i < longueur ; i++){
			nomfichier[i] = dlg.GetPathName().GetAt(i);
		}
		nomfichier[i] = '\0';
		if (longueur < 4 ||
			(nomfichier[longueur-1] != 'd' && nomfichier[longueur-1] != 'D') ||
			(nomfichier[longueur-2] != '3' && nomfichier[longueur-1] != '3') ||
			(nomfichier[longueur-3] != 's' && nomfichier[longueur-1] != 'S') ||
			nomfichier[longueur-4] != '.'){
			nomfichier[longueur] = '.';
			nomfichier[longueur+1] = 's';
			nomfichier[longueur+2] = '3';
			nomfichier[longueur+3] = 'd';
			nomfichier[longueur+4] = '\0';
		}

		ofstream fich(nomfichier);


		CSynthDoc * pdoc = (CSynthDoc*)GetDocument();	

		pdoc->hasaname=true;
		strcpy(pdoc->filename, nomfichier);
		pdoc->SetTitle(CString(nomfichier));

		scene.ecrit_scene(fich, pdoc->nbmaxSpline2D, pdoc->nbSpline2D, pdoc->p_Splines2D);
		
	}

	

}

void CSynthView::OnUpdateFileSaveAs(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(activinsere);

}






void CSynthView::OnImportObjet3d() 
{
	// TODO: Add your command handler code here
	
	char nomfichier[150];

	CFileDialog dlg(TRUE, CString("o3d"), CString("*.o3d"));

	int ret = dlg.DoModal();

	int i = 0;
	if (ret != IDCANCEL){
		int longueur = dlg.GetPathName().GetLength();
		for (i = 0 ; i < longueur ; i++){
			nomfichier[i] = dlg.GetPathName().GetAt(i);
		}
		nomfichier[i] = '\0';


		ifstream fich(nomfichier);

		if (fich.bad()){
			AfxMessageBox(CString("Probleme ouverture fichier !"));
			return;
		}


			CTransformDialog dlg;
		dlg.m_angle = 0;
		dlg.m_axisx = 0;
		dlg.m_axisy = 0;
		dlg.m_axisz = 1;
		dlg.m_origx = 0;
		dlg.m_origy = 0;
		dlg.m_origz = 0;
		dlg.m_scale = 1;

		int ret = dlg.DoModal();

		if (ret != IDCANCEL){

			int noversion;
			fich >> noversion;
			int nbobj;
			if (noversion >= 5)
				fich >> nbobj;
			else
				nbobj = 1;
			CSynthDoc *pdoc = (CSynthDoc *)GetDocument();

			nbobjetselect = 0;

			for (i=0 ; i < nbobj ; i++){
				scene.litobj(fich, true, pdoc->p_Splines2D, noversion,
							Point3D(dlg.m_translatx, dlg.m_translaty, dlg.m_translatz),
							Point3D(dlg.m_origx, dlg.m_origy, dlg.m_origz),
								dlg.m_scale, Point3D(dlg.m_axisx, dlg.m_axisy, dlg.m_axisz),
								dlg.m_angle);
				numobjetselect[nbobjetselect++] = scene.GetNumHead();
			}
			scene.groupeobjets(numobjetselect, nbobjetselect);

			nbobjetselect = 0;
			CClientDC cdc(this);
			scene.zbuffer(bitmap_dib);
			OnDraw(&cdc);

		}

	}
}

void CSynthView::OnUpdateImportObjet3d(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);
}

void CSynthView::OnExportObjet3d() 
{
	// TODO: Add your command handler code here
	
	char nomfichier[150];

	CFileDialog dlg(FALSE, CString("o3d"), CString("*.o3d"));

	int ret = dlg.DoModal();

	int i = 0;
	if (ret != IDCANCEL){
		int longueur = dlg.GetPathName().GetLength();
		for (i = 0 ; i < longueur ; i++){
			nomfichier[i] = dlg.GetPathName().GetAt(i);
		}
		nomfichier[i] = '\0';


		ofstream fich(nomfichier);

		if (fich.bad()){
			AfxMessageBox(CString("Probleme ouverture fichier !"));
			return;
		}

		scene.ecritobjetselect(fich, numobjetselect, nbobjetselect);
	}
}

void CSynthView::OnUpdateExportObjet3d(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere && nbobjetselect != 0);
}
