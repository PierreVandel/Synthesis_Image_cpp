#include "stdafx.h"
#include "Synth.h"
#include "Scene3DRay.h"
#include "imcouleur.h"
#include "Rayon.h"
#include "Objetderiv.h"




#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


#define EPSILON1 5e-3;


void Scene3DRay::computePointLight(Objet3D* objetintersecte, Couleur couleur, bool transparent, bool reflexiontotale, 
								Point3D p3d, 
							  Point3D V, Point3D normale, Point3D R, Point3D T, Couleur & I){

	Point3D Vlum;
	// variables pour l'�clairement
	double costeta, cosalpha, cosalphan, costetat;
	Point3D moinsN = -normale;

	// Calculs de r�flexion, transmission, diffuse, specullaire :
	// rayons vers les sources lumineuses :
	for (int il = 0 ; il < nblum ; il++){

		if (getenableradiosite())
			break;
		// vecteur unitaire dirig� vers la source lumineuse et distance � la source lumineuse
		Vlum = tablum[il].pos - p3d;  // vecteur dirige vers la source
		double distlum = (tablum[il].pos - p3d).norme();
		Vlum = Vlum*(1/distlum);
									// cosinus de l'angle entre vecteur normal et vecteur dirige vers la source

		// d�tection de la pr�sence d'un objet sur le rayon vers la source lumineuse
		Rayon raylum;
		raylum.origine = p3d;
		raylum.vectdirect = Vlum;
	
		// cosinus pour r�flexion difuse
		costeta = normale*Vlum;

		if (costeta <= 0 && !transparent)
			continue;

		double attenuation = 1; // si la lumi�re traverse des objets partiellement transparents :
		bool alombre = false;
		if (renduenableombres) {
			if (!usebsp)
				alombre=testshadow(raylum, distlum, attenuation);
			else{
				int rubish1;
				ResultIntersect rubish2;
				double rubish3;
				Objet3D *rubish4;
				alombre=calculintersectprocheBSP(raylum, rubish1, 
											rubish2, rubish3, rubish4,
											true, attenuation, distlum,
											false);

			}



		}

		
		// si on est � l'ombre pour cette source lumineuse, on passe � la source suivante
		if (alombre)
			continue;

		if (tablum[il].directionnel){
			double coslum = -Vlum*tablum[il].directionnorme;
			if (coslum < 0) coslum = 0;
			coslum = pow(coslum, tablum[il].exponentdirect);
			attenuation *= coslum;
		}

		if (tablum[il].attenuationdist){
			double distlum2 = distlum*distlum;
			double denominateur = tablum[il].c1 + 
									tablum[il].c2*distlum + 
									tablum[il].c3*distlum*distlum;
			if (denominateur < 1)
				denominateur = 1;
			attenuation *= (1/denominateur);

		}


		// calcul de r�flexion difuse :
		if (costeta > 0 && renduenabledifuse){
									// ajout du terme de reflexion difuse
			I.R += attenuation*tablum[il].intensiteR*objetintersecte->material.coef_rd*couleur.R*costeta;
			I.G += attenuation*tablum[il].intensiteG*objetintersecte->material.coef_rd*couleur.G*costeta;
			I.B += attenuation*tablum[il].intensiteB*objetintersecte->material.coef_rd*couleur.B*costeta;
		}

		// calcul de r�flexion sp�culaire :
		if (costeta > 0 && renduenablespecular){
			// calcul de l'angle alpha pour reflexion speculaire :
			cosalpha = Vlum*R; // angle entre le vecteur vers la source et la direction de r�flexion R
			if (cosalpha > 0){
				// cosalpha = (double)cos(alpha);
				cosalphan = pow(cosalpha, objetintersecte->material.exp_rs);
			}else
				cosalphan = 0;
			if (cosalphan > 0){
				// ajout du terme de reflexion speculaire
				I.R += attenuation*tablum[il].intensiteR*objetintersecte->material.coef_rs*cosalphan;
				I.G += attenuation*tablum[il].intensiteG*objetintersecte->material.coef_rs*cosalphan;
				I.B += attenuation*tablum[il].intensiteB*objetintersecte->material.coef_rs*cosalphan;
			}
		}

		// transmissions difuse et speculaire :

		// cosinus de l'angle entre vecteur normal et vecteur dirige vers la source
		costetat = moinsN*Vlum;

		// transmission difuse :
		if (costetat > 0 && renduenabletransmdifuse){
									// ajout du terme de reflexion difuse
			I.R += attenuation*tablum[il].intensiteR*objetintersecte->material.coef_td*couleur.R*costetat;
			I.G += attenuation*tablum[il].intensiteG*objetintersecte->material.coef_td*couleur.G*costetat;
			I.B += attenuation*tablum[il].intensiteB*objetintersecte->material.coef_td*couleur.B*costetat;
		}

		// transmission speculaire
		if (costetat > 0 && renduenabletransmspecular && !reflexiontotale){
			// calcul de l'angle alpha pour reflexion speculaire :

			double cosalphat = Vlum*T;
			if (cosalphat > 0){
				// cosalpha = (double)cos(alpha);
				cosalphan = pow(cosalphat, objetintersecte->material.exp_rs);

			}else
				cosalphan = 0;
			if (cosalphat > 0){
				// ajout du terme de transmission speculaire
				I.R += attenuation*tablum[il].intensiteR*objetintersecte->material.coef_ts*cosalphan;
				I.G += attenuation*tablum[il].intensiteG*objetintersecte->material.coef_ts*cosalphan;
				I.B += attenuation*tablum[il].intensiteB*objetintersecte->material.coef_ts*cosalphan;
			}
		}

	}  // fin du parcours du tableau des sources lumineuses
}





double Sphere::computesolidangle(Point3D p3d, double & cosphimax){
	
	
	double d2 = (origine-p3d).normecarre();
	if (d2 <= rayon*rayon){
		cosphimax = -1;
		return 4;
	}
	return 2*(1-(cosphimax=sqrt(1-rayon*rayon/d2)));
}



void Scene3DRay::computeExtendedLight(Objet3D* objetintersecte, Couleur couleur, bool transparent, bool reflexiontotale, 
								Point3D p3d, 
							  Point3D V, Point3D normale, Point3D R, Point3D T, Couleur & Iglobal){



	Point3D Vlum;
	// variables pour l'�clairement
	double costeta, cosalpha, cosalphan, costetat;
	Point3D moinsN = -normale;

	if (getenableradiosite())
		return;
	// Calculs de r�flexion, transmission, diffuse, specullaire :
	// rayons vers les sources lumineuses :

	for (int il = 0 ; il < nbextendedsources ; il++){

		Couleur I(0,0,0);
		double cosphimax;
		Objet3D*source = extendedsources[il];
		double solidangle= source->computesolidangle(p3d, cosphimax);

		Point3D veck = source->origine-p3d;
		veck.normer();
		Point3D veci = veck^Point3D(1, pi, pi*pi);
		veci.normer();
		Point3D vecj = veck^veci;

		int nbrayintersect = 0;
		int nbombre=0;
		bool penumbra=false;
		for (int compt = 0 ; compt < nbrayslights || (penumbra && compt < 2*nbrayslights) ; compt++){


			// vecteur unitaire dirig� vers la source lumineuse et distance � la source lumineuse
			double cosphiray = 1+(rand()/(double)RAND_MAX)*(cosphimax-1);
			if (nbrayslights==1)
				cosphiray=1;
			double sinphiray = sqrt(1-cosphiray*cosphiray);
			double thetaray = 2*pi*(rand()/(double)RAND_MAX);
			Vlum = cos(thetaray)*sinphiray*veci + sin(thetaray)*sinphiray *vecj + cosphiray*veck;  // vecteur dirige vers la source

			Rayon raylum;
			raylum.origine = p3d;
			raylum.vectdirect = Vlum;

			ResultIntersect resinter;
			double rubish;

			if (!source->calculintersect(raylum ,resinter,
												false, rubish, 0,
												false, false)){
				continue;
			}


			nbrayintersect++;

			double distlum = resinter.t_inter - EPSILON1;
										// cosinus de l'angle entre vecteur normal et vecteur dirige vers la source

			// d�tection de la pr�sence d'un objet sur le rayon vers la source lumineuse
		
			// cosinus pour r�flexion difuse
			costeta = normale*Vlum;

			if (costeta <= 0 && !transparent)
				continue;

			double attenuation = 1; // si la lumi�re traverse des objets partiellement transparents :
			bool alombre = false;
			if (renduenableombres) {
				if (!usebsp)
					alombre=testshadow(raylum, distlum, attenuation);
				else{
					int rubish1;
					ResultIntersect rubish2;
					double rubish3;
					Objet3D *rubish4;
					alombre=calculintersectprocheBSP(raylum, rubish1, 
												rubish2, rubish3, rubish4,
												true, attenuation, distlum,
												false);

				}



			}

			if (alombre || attenuation < 1)
				nbombre++;
			// si on est � l'ombre pour cette source lumineuse, on passe � la source suivante
			if (alombre)
				continue;

//			if (tablum[il].directionnel){
//				double coslum = -Vlum*tablum[il].directionnorme;
//				if (coslum < 0) coslum = 0;
//				coslum = pow(coslum, tablum[il].exponentdirect);
//				attenuation *= coslum;
//			}



			// calcul de r�flexion difuse :
			if (costeta > 0 && renduenabledifuse){
										// ajout du terme de reflexion difuse
				I.R += attenuation*objetintersecte->material.coef_rd*couleur.R*costeta;
				I.G += attenuation*objetintersecte->material.coef_rd*couleur.G*costeta;
				I.B += attenuation*objetintersecte->material.coef_rd*couleur.B*costeta;
			}

			// calcul de r�flexion sp�culaire :
			if (costeta > 0 && renduenablespecular){
				// calcul de l'angle alpha pour reflexion speculaire :
				cosalpha = Vlum*R; // angle entre le vecteur vers la source et la direction de r�flexion R
				if (cosalpha > 0){
					// cosalpha = (double)cos(alpha);
					cosalphan = pow(cosalpha, objetintersecte->material.exp_rs);
				}else
					cosalphan = 0;
				if (cosalphan > 0){
					// ajout du terme de reflexion speculaire
					I.R += attenuation*objetintersecte->material.coef_rs*cosalphan;
					I.G += attenuation*objetintersecte->material.coef_rs*cosalphan;
					I.B += attenuation*objetintersecte->material.coef_rs*cosalphan;
				}
			}

			// transmissions difuse et speculaire :

			// cosinus de l'angle entre vecteur normal et vecteur dirige vers la source
			costetat = moinsN*Vlum;

			// transmission difuse :
			if (costetat > 0 && renduenabletransmdifuse){
										// ajout du terme de reflexion difuse
				I.R += attenuation*objetintersecte->material.coef_td*couleur.R*costetat;
				I.G += attenuation*objetintersecte->material.coef_td*couleur.G*costetat;
				I.B += attenuation*objetintersecte->material.coef_td*couleur.B*costetat;
			}

			// transmission speculaire
			if (costetat > 0 && renduenabletransmspecular && !reflexiontotale){
				// calcul de l'angle alpha pour reflexion speculaire :

				double cosalphat = Vlum*T;
				if (cosalphat > 0){
					// cosalpha = (double)cos(alpha);
					cosalphan = pow(cosalphat, objetintersecte->material.exp_rs);

				}else
					cosalphan = 0;
				if (cosalphat > 0){
					// ajout du terme de transmission speculaire
					I.R += attenuation*objetintersecte->material.coef_ts*cosalphan;
					I.G += attenuation*objetintersecte->material.coef_ts*cosalphan;
					I.B += attenuation*objetintersecte->material.coef_ts*cosalphan;
				}
			}

			if (compt == nbrayslights-1 && (nbombre != 0 && nbombre != nbrayintersect))
				penumbra=true;
		}
		double factor = solidangle / (double)nbrayintersect * source->material.emitance/pi;
		Iglobal.R += I.R*factor;
		Iglobal.G += I.G*factor;
		Iglobal.B += I.B*factor;
	}  // fin du parcours du tableau des sources lumineuses

}


