// Rayon.h: interface for the Rayon class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RAYON_H__1A49068E_3336_425A_88CA_E0BC2C3585DC__INCLUDED_)
#define AFX_RAYON_H__1A49068E_3336_425A_88CA_E0BC2C3585DC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Point3D.h"
#include "Couleur.h"

#define EPSILON 1e-3


class Objet3D;

class Rayon  
{

public:

	Point3D origine;
	Point3D vectdirect;

	Objet3D * objetscontenant[20];
	int nbobjetscontenant;

	int initx, inity, initz, stepx, stepy, stepz, endx, endy, endz;

	Rayon();
	Rayon (Point3D or, Point3D vd){origine=or;vectdirect=vd;
									}
	virtual ~Rayon();

};

class ResultIntersect{


	
public:
	double t_inter;
	Point3D normale;
	Couleur couleur;  // coefficients RGB de la couleur (entre 0 et 1)
	Intensitesgouraud intens;
};


class Boiteenglobante{

public :
	double xmin, xmax, ymin, ymax, zmin, zmax;


	Boiteenglobante(void){xmin = xmax = ymin = ymax = zmin = zmax = 0;}
	Boiteenglobante(double xmini, double xmaxi, double ymini, double ymaxi, double zmini, double zmaxi){
		xmin = xmini; xmax = xmaxi;
		ymin = ymini; ymax = ymaxi;
		zmin = zmini; zmax = zmaxi;
	}

	bool testintersect(const Rayon &ray);
	bool appartient(Point3D p){
		return (p.x < xmax && p.x >= xmin && 
				p.y < ymax && p.y >= ymin &&
				p.z < zmax && p.z >= zmin);
	}
	bool testintersect2boites(Boiteenglobante &boite);

	Boiteenglobante enlarge(double r){return Boiteenglobante(xmin-r, xmax+r, ymin-r, ymax+r, zmin-r, zmax+r);}
};

#endif // !defined(AFX_RAYON_H__1A49068E_3336_425A_88CA_E0BC2C3585DC__INCLUDED_)
