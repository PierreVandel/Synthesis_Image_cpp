#include "stdafx.h"
#include "Synth.h"
#include "Camera.h"

#include <math.h>
// #include <limits.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


//#define NBMAXCAM 10
//#define INFINI 1.5e38



//////////////////////////////////////////////////////////////////////
// Fonctions des classes Camera et Cameraperspect
//////////////////////////////////////////////////////////////////////

// constructeur de camera
// x, y, z donnent la position
// dirx, diry, dirz donnent la direction de visee

Camera::Camera(double x, double y, double z, 
			   double dirx, double diry, double dirz)
{

	double norme;
	Point3D vect1;
	Point3D vect2;
	Point3D vect3;

	pos.x = x;  // origine du repere lie a la camera (position de la camera)
	pos.y = y;
	pos.z = z;
	M = Matrice(3,3);


	norme = (double) sqrt(dirx*dirx + diry*diry + dirz*dirz);
	if (norme > 0.001){
		vect1.x = dirx/norme;  // vect1 vecteur unitaire dirige dans la direction de visee
		vect1.y = diry/norme;  // correspond a l'axe Oz du repere lie a la camera
		vect1.z = dirz/norme; 
	}else{
		M[0][0] = M[1][1] = M[2][2] = 1;  // cas degenere
		return;
	}
	
	if (abs(vect1.x) > 0.001 || abs(vect1.y) > 0.001)
	{
		vect2.x = vect1.y;   // vect2 orthogonal a vect1 dans le plan
		vect2.y = -vect1.x;  // et perpendiculaire a l'axe Oz du repere de la scene
		vect2.z = 0;	     // donne le vecteur de l'axe Ox du repere de la camera
	}else
	{
		vect2.x = -vect1.z;  // cas degenere
		vect2.y = 0;
		vect2.z = vect1.x;
	}

	// normalisation du vecteur vect2 :
	norme = (double) sqrt(vect2.x*vect2.x + vect2.y*vect2.y + vect2.z*vect2.z);
	if (norme > 0.001){
		vect2.x /= norme;
		vect2.y /= norme;
		vect2.z /= norme; 
	}else{
		M[0][0] = M[1][1] = M[2][2] = 1;  // cas degenere
		return;
	}
	
	vect3 = vect1^vect2;  // vect3 vecteur unitaire orthogonal a vect1 et vect2
							// donne le vecteur de l'axe Oy du repere de la camera

	// construction de la matrice de passage du repere de la scene 
	// au repere de la camera :

/*	M[0][0] = vect2.x; M[0][1] = vect2.y; M[0][2] = vect2.z;
	M[1][0] = vect3.x; M[1][1] = vect3.y; M[1][2] = vect3.z;
	M[2][0] = vect1.x; M[2][1] = vect1.y; M[2][2] = vect1.z;

	M=M.t();	// vraie matrice de passage (2006)
*/

	M[0][0] = vect2.x; M[0][1] = vect3.x; M[0][2] = vect1.x;
	M[1][0] = vect2.y; M[1][1] = vect3.y; M[1][2] = vect1.y;
	M[2][0] = vect2.z; M[2][1] = vect3.z; M[2][2] = vect1.z;

}


// constructeur specifique pour camera en perspective
// (fait appel au constructeur de Camera)

Cameraperspect::Cameraperspect(double x, double y, double z, 
			       double cx, double cy, double cz,
				   double angx):Camera(x, y, z, cx-x, cy-y, cz-z)
{
	anglex = (double)(angx*pi/(double)180); 
	type = PERSPECT;

	centre.x = cx;
	centre.y = cy;
	centre.z = cz;
}

	
Camera* Cameraperspect::copie(void){
	return new Cameraperspect(pos.x,pos.y,pos.z,centre.x,centre.y,centre.z,anglex*180.0/pi);
}




