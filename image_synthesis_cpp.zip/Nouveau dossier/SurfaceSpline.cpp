// Surface.cpp: implementation of the Surface class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Synth.h"
#include "Camera.h"
#include "SurfaceSpline.h"
#include "Spline2D.h"
#include <fstream>
#include "math.h"
using namespace std;

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif




//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


Point3D **allouerPoints3D(int n, int m){
	Point3D ** res = new Point3D*[n];
	
	for (int i = 0 ; i < n ; i++)
		res[i] = new Point3D[m];
	return res;
}

void libererPoints3D(Point3D** t,int n){

	for (int i = 0 ; i < n ; i++)
		delete [] t[i];
	if (n > 0)
		delete [] t;
}


Surface::Surface()
{

}

Surface::~Surface()
{

}


void SurfaceBSplineCubique::affiche(CDC &cdc, Camera *cam, int dim2Dx, int dim2Dy){
	double D = (double)((((double)dim2Dx)/2.0)/tan(cam->accesanglex()/2));
	for (int i = 0 ; i <= NB_POINTS_SURFACE ; i++)
		for (int j = 0 ; j <= NB_POINTS_SURFACE ; j++){
			double xpos, ypos, zpos;
			getpoint(((double)i)/((double)NB_POINTS_SURFACE), ((double)j)/((double)NB_POINTS_SURFACE), 
				       xpos, ypos, zpos);
			Point3D n;
			getnormale(((double)i)/((double)NB_POINTS_SURFACE), ((double)j)/((double)NB_POINTS_SURFACE), n.x, n.y, n.z);
			if (n*Point3D(xpos,ypos,zpos)>0)
				continue;
			if (i < NB_POINTS_SURFACE){
				double xpos1, ypos1, zpos1;
				getpoint(((double)i+1)/((double)NB_POINTS_SURFACE), ((double)j)/((double)NB_POINTS_SURFACE), 
					       xpos1, ypos1, zpos1);
				cdc.MoveTo(((int)(xpos*D/zpos+dim2Dx/2.0)), ((int)(ypos*D/zpos+dim2Dy/2.0)));
				cdc.LineTo(((int)(xpos1*D/zpos1+dim2Dx/2.0)), ((int)(ypos1*D/zpos1+dim2Dy/2.0)));
				
			}
			if (j < NB_POINTS_SURFACE){
				double xpos2, ypos2, zpos2;
				getpoint(((double)i)/((double)NB_POINTS_SURFACE), ((double)j+1)/((double)NB_POINTS_SURFACE), 
					       xpos2, ypos2, zpos2);
				cdc.MoveTo(((int)(xpos*D/zpos+dim2Dx/2.0)), ((int)(ypos*D/zpos+dim2Dy/2.0)));
				cdc.LineTo(((int)(xpos2*D/zpos2+dim2Dx/2.0)), ((int)(ypos2*D/zpos2+dim2Dy/2.0)));
				
			}
		}
	affichectrlpoints(cdc, cam, dim2Dx, dim2Dy);
}


void SurfaceBSplineCubique::affichectrlpoints(CDC& cdc, Camera *cam, int dim2Dx, int dim2Dy){
	double D = (double)((((double)dim2Dx)/2.0)/tan(cam->accesanglex()/2));

	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			Point3D vecteur1 = ctrlpoints[(i+1)%nblignes][j]-ctrlpoints[(i-1)<0 ? nblignes-1 : i-1][j];
			Point3D vecteur2 = ctrlpoints[i][(j+1)%nbcols]-ctrlpoints[i][(j-1)<0 ? nbcols-1 : j-1];
			if (ctrlpoints[i][j]*(vecteur1^vecteur2) > 0 && (j!=0 && j!=nbcols-1))
				continue;
			double x=ctrlpoints[i][j].x*D/ctrlpoints[i][j].z+dim2Dx/2.0;
			double y=ctrlpoints[i][j].y*D/ctrlpoints[i][j].z+dim2Dy/2.0;
			cdc.Ellipse((int)x-3,(int)y-3,(int)x+3,(int)y+3);
		}
}

void SurfaceBSplineCubique::GetCtrlpointSelect(CPoint pos, int & iproche, int & jproche, Camera *cam, int dim2Dx, int dim2Dy){

	double D = (double)((((double)dim2Dx)/2.0)/tan(cam->accesanglex()/2));
	iproche = 0;
	jproche = 0;
	double min = 1e10;

	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			Point3D vecteur1 = ctrlpoints[(i+1)%nblignes][j]-ctrlpoints[(i-1)<0 ? nblignes-1 : i-1][j];
			Point3D vecteur2 = ctrlpoints[i][(j+1)%nbcols]-ctrlpoints[i][(j-1)<0 ? nbcols-1 : j-1];
			if (ctrlpoints[i][j]*(vecteur1^vecteur2) > 0 && (j!=0 && j!=nbcols-1))
				continue;
			double x=ctrlpoints[i][j].x*D/ctrlpoints[i][j].z+dim2Dx/2.0;
			double y=ctrlpoints[i][j].y*D/ctrlpoints[i][j].z+dim2Dy/2.0;
			if (sqrt((x-pos.x)*(x-pos.x) + (y-pos.y)*(y-pos.y)) < min){
				min = sqrt((x-pos.x)*(x-pos.x) + (y-pos.y)*(y-pos.y));
				iproche=i;
				jproche=j;
			}
		}
}


Point3D SurfaceBSplineCubique::GetProjectionCtrlPoint(int i, int j, double D,int dim2Dx, int dim2Dy){
	return Point3D(ctrlpoints[i][j].x*D/ctrlpoints[i][j].z+dim2Dx/2.0,ctrlpoints[i][j].y*D/ctrlpoints[i][j].z+dim2Dy/2.0,0);
}


void SurfaceBSplineCubique::DeplaceCtrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, CDC &cdc, Camera *cam, int dim2Dx, int dim2Dy){

	CPen penblanc(1, PS_SOLID, RGB(255,255,255));
	cdc.SelectObject(penblanc);
	affiche(cdc, cam, dim2Dx, dim2Dy);
	affichectrlpoints(cdc, cam, dim2Dx, dim2Dy);

	deplaceeffectctrlpoint(i,j,v, rayondeform_i, rayondeform_j, cam);
	

	CPen pennoir(1, PS_SOLID, RGB(0,0,0));
	cdc.SelectObject(pennoir);
	affiche(cdc, cam, dim2Dx, dim2Dy);
	affichectrlpoints(cdc, cam, dim2Dx, dim2Dy);

}


void SurfaceBSplineCubique::ecritctrlpoints(ostream & fich){

	fich << nblignes << " " << nbcols << "\n";

for (int i = 0 ; i < nblignes ; i++)
	for (int j = 0 ; j < nbcols ; j++)
		fich << ctrlpoints[i][j].x << " " << ctrlpoints[i][j].y << " " << ctrlpoints[i][j].z << "\n";


}




double **allouerdouble2D(int n, int m){
	double ** res = new double*[n];
	
	for (int i = 0 ; i < n ; i++)
		res[i] = new double[m];

	return res;

}

void liberedouble2D(double**t, int nl){
	for (int i = 0 ; i < nl ; i++)
		delete [] t[i];
	delete [] t;

}



Matrice **allouermatrices(int n, int m){
	Matrice ** res = new Matrice*[n];
	
	for (int i = 0 ; i < n ; i++)
		res[i] = new Matrice[m];

	return res;

}

void liberematrice(Matrice**t, int nl){
	for (int i = 0 ; i < nl ; i++)
		delete [] t[i];
	delete [] t;

}


SurfaceBSplineCubique::~SurfaceBSplineCubique(){
	if (ctrlpoints!=NULL){
		for (int i = 0 ; i < nblignes ; i++)
			delete ctrlpoints[i]; 
		delete [] ctrlpoints;
	}

	liberematrice(coeffs_x, nblignes-3);
	liberematrice(coeffs_y, nblignes-3);
	liberematrice(coeffs_z, nblignes-3);
}



SurfaceBSplineCubique::SurfaceBSplineCubique(istream &fich){
	fich >> nblignes;
	fich >> nbcols;

	ctrlpoints=allouerPoints3D(nblignes,nbcols);
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			fich >> ctrlpoints[i][j].x;
			fich >> ctrlpoints[i][j].y;
			fich >> ctrlpoints[i][j].z;
		}
//	for (i = 0 ; i < nblignes ; i++)
//		for (int j = 0 ; j < nbcols/2 ; j++){
//			Point3D interm = ctrlpoints[i][nbcols-1-j];
//			ctrlpoints[i][nbcols-1-j] = ctrlpoints[i][j];
//			ctrlpoints[i][j] = interm;
//		
//		}


	Matrice MBS(4,4);

	MBS[0][0] = -1; MBS[0][1] = 3 ; MBS[0][2] = -3; MBS[0][3] = 1;
	MBS[1][0] = 3 ; MBS[1][1] = -6; MBS[1][2] = 3 ; MBS[1][3] = 0;
	MBS[2][0] = -3; MBS[2][1] = 0 ; MBS[2][2] = 3 ; MBS[2][3] = 0;
	MBS[3][0] = 1 ; MBS[3][1] = 4 ; MBS[3][2] = 1 ; MBS[3][3] = 0;

	coeffs_x = allouermatrices(nblignes-3, nbcols-3);
	coeffs_y = allouermatrices(nblignes-3, nbcols-3);
	coeffs_z = allouermatrices(nblignes-3, nbcols-3);
	for (int i = 0 ; i < nblignes - 3 ; i++)
		for (int j = 0 ; j < nbcols - 3 ; j++){
			Matrice G_x(4,4);
			for (int k = 0 ; k < 4 ; k++)
				for (int l = 0 ; l < 4 ; l++)
					G_x[k][l] = ctrlpoints[i+k][j+l].x;
			coeffs_x[i][j] = MBS*G_x*MBS.t();
			Matrice G_y(4,4);
			for (int k = 0 ; k < 4 ; k++)
				for (int l = 0 ; l < 4 ; l++)
					G_y[k][l] = ctrlpoints[i+k][j+l].y;
			coeffs_y[i][j] = MBS*G_y*MBS.t();
			Matrice G_z(4,4);
			for (int k = 0 ; k < 4 ; k++)
				for (int l = 0 ; l < 4 ; l++)
					G_z[k][l] = ctrlpoints[i+k][j+l].z;
			coeffs_z[i][j] = MBS*G_z*MBS.t();
		}

}



void SurfaceBSplineCubique::precalculmatrices(bool allouer){

	Matrice MBS(4,4);

	MBS[0][0] = -1; MBS[0][1] = 3 ; MBS[0][2] = -3; MBS[0][3] = 1;
	MBS[1][0] = 3 ; MBS[1][1] = -6; MBS[1][2] = 3 ; MBS[1][3] = 0;
	MBS[2][0] = -3; MBS[2][1] = 0 ; MBS[2][2] = 3 ; MBS[2][3] = 0;
	MBS[3][0] = 1 ; MBS[3][1] = 4 ; MBS[3][2] = 1 ; MBS[3][3] = 0;

	if (allouer){
		coeffs_x = allouermatrices(nblignes-3, nbcols-3);
		coeffs_y = allouermatrices(nblignes-3, nbcols-3);
		coeffs_z = allouermatrices(nblignes-3, nbcols-3);
	}
	for (int i = 0 ; i < nblignes - 3 ; i++)
		for (int j = 0 ; j < nbcols - 3 ; j++){
			Matrice G_x(4,4);
			for (int k = 0 ; k < 4 ; k++)
				for (int l = 0 ; l < 4 ; l++)
					G_x[k][l] = ctrlpoints[i+k][j+l].x;
			coeffs_x[i][j] = MBS*G_x*MBS.t();
			Matrice G_y(4,4);
			for (int k = 0 ; k < 4 ; k++)
				for (int l = 0 ; l < 4 ; l++)
					G_y[k][l] = ctrlpoints[i+k][j+l].y;
			coeffs_y[i][j] = MBS*G_y*MBS.t();
			Matrice G_z(4,4);
			for (int k = 0 ; k < 4 ; k++)
				for (int l = 0 ; l < 4 ; l++)
					G_z[k][l] = ctrlpoints[i+k][j+l].z;
			coeffs_z[i][j] = MBS*G_z*MBS.t();
		}

}

SurfaceBSplineCubique::SurfaceBSplineCubique(Point3D**ctrl, int nbl, int nbc){
	nblignes=nbl;
	nbcols=nbc;

	ctrlpoints=allouerPoints3D(nblignes,nbcols);
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			ctrlpoints[i][j] = ctrl[i][j];
		}

	precalculmatrices(true);
}



void SurfaceBSplineCubique::mettredansreperecam(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine){
	
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			ctrlpoints[i][j].x *=scax;
			ctrlpoints[i][j].y *=scay;
			ctrlpoints[i][j].z *=scaz;
			ctrlpoints[i][j] = rot*ctrlpoints[i][j];
			ctrlpoints[i][j] = ctrlpoints[i][j] + origine;
		}

	Matrice Minv = cam->M;

	Point3D O =  Minv * cam->pos;


	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			ctrlpoints[i][j] = Minv *ctrlpoints[i][j] - O;
		}

	precalculmatrices(false);

/*	Matrice MBS(4,4);

	MBS[0][0] = -1; MBS[0][1] = 3 ; MBS[0][2] = -3; MBS[0][3] = 1;
	MBS[1][0] = 3 ; MBS[1][1] = -6; MBS[1][2] = 3 ; MBS[1][3] = 0;
	MBS[2][0] = -3; MBS[2][1] = 0 ; MBS[2][2] = 3 ; MBS[2][3] = 0;
	MBS[3][0] = 1 ; MBS[3][1] = 4 ; MBS[3][2] = 1 ; MBS[3][3] = 0;

	for (i = 0 ; i < nblignes - 3 ; i++)
		for (int j = 0 ; j < nbcols - 3 ; j++){
			Matrice G_x(4,4);
			for (int k = 0 ; k < 4 ; k++)
				for (int l = 0 ; l < 4 ; l++)
					G_x[k][l] = ctrlpoints[i+k][j+l].x;
			coeffs_x[i][j] = MBS*G_x*MBS.t();
			Matrice G_y(4,4);
			for (k = 0 ; k < 4 ; k++)
				for (int l = 0 ; l < 4 ; l++)
					G_y[k][l] = ctrlpoints[i+k][j+l].y;
			coeffs_y[i][j] = MBS*G_y*MBS.t();
			Matrice G_z(4,4);
			for (k = 0 ; k < 4 ; k++)
				for (int l = 0 ; l < 4 ; l++)
					G_z[k][l] = ctrlpoints[i+k][j+l].z;
			coeffs_z[i][j] = MBS*G_z*MBS.t();
		}
*/
}


void SurfaceBSplineCubique::mettredansreperescene(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine){
	
	Matrice Minv = cam->M.t();

	Point3D O =  cam->M * cam->pos;


	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			ctrlpoints[i][j] = Minv *(ctrlpoints[i][j] + O);
		}

	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			ctrlpoints[i][j] = ctrlpoints[i][j] - origine;
			ctrlpoints[i][j] = rot.t()*ctrlpoints[i][j];
			ctrlpoints[i][j].z /=scaz;
			ctrlpoints[i][j].y /=scay;
			ctrlpoints[i][j].x /=scax;
		}

	precalculmatrices(false);

}


void SurfaceBSplineCubique::getpoint(double s, double t, double & xpos, double & ypos, double & zpos){

	
	if (s > 1) s = 1;
	if (s < 0) s = 0;
	if (t > 1) t = 1;
	if (t < 0) t = 0;

	int j = (int)(t*(nbcols-3));  // numero de la courbe

	double tvrai = (t*(nbcols-3))-j;
	
	if (j == nbcols-3){
		j = nbcols - 4;
		tvrai=1;
	}
			
	double t2 = tvrai*tvrai;
	double t3 = t2*tvrai;

	Vecteur4D vecteur_t(t3, t2, tvrai, 1);

	int i = (int)(s*(nblignes-3));  // numero de la courbe

	double svrai = (s*(nblignes-3))-i;
	
//	int j = nopoint % echantillonage;  // position sur la courbe
	if (i == nblignes-3){
		i = nblignes - 4;
		svrai=1;
	}
			
	double s2 = svrai*svrai;
	double s3 = s2*svrai;
	Quadruplet vecteur_s(s3, s2, svrai, 1);

			xpos = ((vecteur_s*coeffs_x[i][j])*vecteur_t)[0][0]/36;
			ypos = ((vecteur_s*coeffs_y[i][j])*vecteur_t)[0][0]/36;
			zpos = ((vecteur_s*coeffs_z[i][j])*vecteur_t)[0][0]/36;

}








void SurfaceBSplineCubique::getnormale(double s, double t, double & xn, double & yn, double & zn){
	int j = (int)(t*(nbcols-3));  // numero de la courbe

	double tvrai = (t*(nbcols-3))-j;
	
	if (j == nbcols-3){
		j = nbcols - 4;
		tvrai=1;
	}
			
	double t2 = tvrai*tvrai;
	double t3 = t2*tvrai;

	Vecteur4D vecteur_t(t3, t2, tvrai, 1);
	Vecteur4D vecteur_tp(3*t2, 2*tvrai, 1, 0);

	int i = (int)(s*(nblignes-3));  // numero de la courbe

	double svrai = (s*(nblignes-3))-i;
	
//	int j = nopoint % echantillonage;  // position sur la courbe
	if (i == nblignes-3){
		i = nblignes - 4;
		svrai=1;
	}
			
	double s2 = svrai*svrai;
	double s3 = s2*svrai;
	Quadruplet vecteur_s(s3, s2, svrai, 1);
	Quadruplet vecteur_sp(3*s2, 2*svrai, 1, 0);

			Point3D dsurds(((vecteur_sp*coeffs_x[i][j])*vecteur_t)[0][0]/36,
			((vecteur_sp*coeffs_y[i][j])*vecteur_t)[0][0]/36,
			((vecteur_sp*coeffs_z[i][j])*vecteur_t)[0][0]/36);
			Point3D dsurdt(((vecteur_s*coeffs_x[i][j])*vecteur_tp)[0][0]/36,
			((vecteur_s*coeffs_y[i][j])*vecteur_tp)[0][0]/36,
			((vecteur_s*coeffs_z[i][j])*vecteur_tp)[0][0]/36);

	Point3D res = dsurds^dsurdt;
	res.normer();

	xn=res.x; yn=res.y; zn=res.z;
}








void SurfaceBSplineCubique::getdsds(double s, double t, double & xn, double & yn, double & zn){
	int j = (int)(t*(nbcols-3));  // numero de la courbe

	double tvrai = (t*(nbcols-3))-j;
	
	if (j == nbcols-3){
		j = nbcols - 4;
		tvrai=1;
	}
			
	double t2 = tvrai*tvrai;
	double t3 = t2*tvrai;

	Vecteur4D vecteur_t(t3, t2, tvrai, 1);

	int i = (int)(s*(nblignes-3));  // numero de la courbe

	double svrai = (s*(nblignes-3))-i;
	
//	int j = nopoint % echantillonage;  // position sur la courbe
	if (i == nblignes-3){
		i = nblignes - 4;
		svrai=1;
	}
			
	double s2 = svrai*svrai;
	Quadruplet vecteur_sp(3*s2, 2*svrai, 1, 0);

	xn = ((vecteur_sp*coeffs_x[i][j])*vecteur_t)[0][0]/36;
	yn = ((vecteur_sp*coeffs_y[i][j])*vecteur_t)[0][0]/36;
	zn = ((vecteur_sp*coeffs_z[i][j])*vecteur_t)[0][0]/36;
}








void SurfaceBSplineCubique::getdsdt(double s, double t, double & xn, double & yn, double & zn){
	int j = (int)(t*(nbcols-3));  // numero de la courbe

	double tvrai = (t*(nbcols-3))-j;
	
	if (j == nbcols-3){
		j = nbcols - 4;
		tvrai=1;
	}
			
	double t2 = tvrai*tvrai;

	Vecteur4D vecteur_tp(3*t2, 2*tvrai, 1, 0);

	int i = (int)(s*(nblignes-3));  // numero de la courbe

	double svrai = (s*(nblignes-3))-i;
	
//	int j = nopoint % echantillonage;  // position sur la courbe
	if (i == nblignes-3){
		i = nblignes - 4;
		svrai=1;
	}
			
	double s2 = svrai*svrai;
	double s3 = s2*svrai;
	Quadruplet vecteur_s(s3, s2, svrai, 1);

	xn = ((vecteur_s*coeffs_x[i][j])*vecteur_tp)[0][0]/36;
	yn = ((vecteur_s*coeffs_y[i][j])*vecteur_tp)[0][0]/36;
	zn = ((vecteur_s*coeffs_z[i][j])*vecteur_tp)[0][0]/36;

}













// rotation de la camera d'un angle teta autour d'un axe parallele a un axe de coordonnees
// passant par le point de focalisation de la camera (pour boite de dialogue "Controles Camera") :

void SurfaceBSplineCubique::rotatecamcentral(double teta, char noaxe, Camera * cam)
{
	Matrice Mrot(3,3);
	double costeta = (double)cos(teta*pi/180.0);  // cosinus de teta (prealablement converti en radians
	double sinteta = (double)sin(teta*pi/180.0);  // sinus (idem)
	double norme;
	Point3D dci, dcf, poscam1;

	Matrice Manc = cam->M;  // ancienne matrice de passage du repere de la scene
											// au repere de la camera


	if (noaxe == 0){  // rotation de la cam�ra autour d'un axe 
					  // parall�le � l'axe des x passant par le "centre" de la cam�ra

		// matrice de rotation autour de l'axe des x :
		Mrot[0][0] = 1; Mrot[0][1] = 0; Mrot[0][2] = 0;
		Mrot[1][0] = 0; Mrot[1][1] = costeta; Mrot[1][2] = sinteta;
		Mrot[2][0] = 0; Mrot[2][1] = -sinteta; Mrot[2][2] = costeta;

		// calcul de la distance de la position de la camera a son centre de focalisation
		norme = (cam->pos - cam->centre).norme();

		// on fait subir la rotation aux sommets des objets 3D
		// qui sont exprimmes dans le repere de la camera

		for (int i = 0 ; i < nblignes ; i++)
			for (int j = 0 ; j < nbcols ; j++){
				ctrlpoints[i][j].z -= norme;
				ctrlpoints[i][j] = Mrot * ctrlpoints[i][j];
				ctrlpoints[i][j].z += norme;
			}
		


		// Le repere de la camera change du fait de son mouvement.
		// calcul de la nouvelle matrice de passage
		cam->M = Mrot * cam->M;


		Mrot[2][1] = sinteta;  // inversion de la matrice de rotation
		Mrot[1][2] = -sinteta; // (cas de la rotation autour de l'axe des x)
		


		// calcul de la nouvelle position de la camera exprimee dans l'ancien
		// repere de la camera :
		poscam1 = Point3D(0, 0, -norme);
		poscam1 = Mrot * poscam1;
		poscam1.z += norme;


		Point3D diffposcam = Manc.t() * poscam1; // difference entre l'ancienne et la nouvelle position
												 // de la camera exprimee dans le repere de la scene

		cam->pos = cam->pos + diffposcam;   // nouvelle position
																			// de la camera exprimee dans le repere de la scene





	}



	if (noaxe == 1){  // rotation de la cam�ra autour d'un axe 
					  // parall�le � l'axe des z du repere de la scene
		Mrot[0][0] = costeta; Mrot[0][1] = sinteta; Mrot[0][2] = 0;
		Mrot[1][0] = -sinteta; Mrot[1][1] = costeta; Mrot[1][2] = 0;
		Mrot[2][0] = 0; Mrot[2][1] = 0; Mrot[2][2] = 1;
		norme = (cam->pos - cam->centre).norme();
		Point3D O =  Manc * cam->pos;
		Matrice Mrotrepcam = Manc*Mrot*Manc.t();

		for (int i = 0 ; i < nblignes ; i++)
			for (int j = 0 ; j < nbcols ; j++){
				ctrlpoints[i][j] =	Manc*(Mrot*(Manc.t()*
							(ctrlpoints[i][j]+O)-cam->centre)+cam->centre)
							-O;
			}

		
		cam->M = cam->M*Mrot;

		cam->pos = Mrot.t()*(cam->pos-cam->centre)+
									cam->centre;

	}


	// le cas suivant est plus simple que les deux cas ci-dessus
	
	if (noaxe == 2){  // rotation de la cam�ra autour d'un axe 
					  // parall�le � l'axe des z passant par le "centre" de la cam�ra

		// matrice de rotation autour de l'axe des z
		Mrot[0][0] = costeta; Mrot[0][1] = -sinteta; Mrot[0][2] = 0;
		Mrot[1][0] = sinteta; Mrot[1][1] = costeta; Mrot[1][2] = 0;
		Mrot[2][0] = 0; Mrot[2][1] = 0; Mrot[2][2] = 1;

		// rotation des sommets des objets 3D exprimes dans le repere de la camera
		// (cette fois l'axe de rotation est precisement l'axe des z)
		for (int i = 0 ; i < nblignes ; i++)
			for (int j = 0 ; j < nbcols ; j++){
				ctrlpoints[i][j] =	Mrot * ctrlpoints[i][j];
			}
		// nouvelle matrice de passage
		cam->M = Mrot * cam->M;

	}

	precalculmatrices(false);
}



