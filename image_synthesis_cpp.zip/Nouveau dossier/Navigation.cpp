#include "stdafx.h"
#include "Synth.h"
#include "Scene3D.h"

#include <math.h>
// #include <limits.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


// Translation de la camera d'un vecteur (dx, dy, dz)
// le vecteur (dx, dy, dz) est exprime dans le repere de la camera
// (cette fonction sert pour la boite de dialogue "Controles Camera").

void Scene3D::translatecamcentral(double dx, double dy, double dz)
{
	Point3D dci;
	double norme;


	// La translation suivant l'axe des z (axe de focalisation de la camera)
	// sera en fait une certaine proportion de la distance de la position au point de focalisation
	// de la camera. Le centre de focalisation restera ainsi inchange
		norme = (tabcam[nocamselect]->pos - tabcam[nocamselect]->centre).norme();

		// veritable vecteur de translation :
		if (norme >= 1e-4 || dz <=0) // on ne s'approche pas trop pres du point de focalisation
			dci = Point3D(dx, dy, dz/(maxix - minix)*norme);	//dz/(maxix - minix)*norme est dans [0,norme]
		else
			dci = Point3D(dx, dy, 0);
	
	//	translatecam(dci.x, dci.y, 0);
		Point3D sauve = tabcam[nocamselect]->centre;
		translatecam(dci.x, dci.y, dci.z);

		tabcam[nocamselect]->centre = sauve;
}





// Translation de la camera d'un vecteur (dx, dy, dz)
// le vecteur (dx, dy, dz) est exprime dans le repere de la camera
// (cette fonction sert pour la boite de dialogue "Controles Camera").

void Scene3D::translatecam(double dx, double dy, double dz)
{
	int i;
	Celluleobj * p;
	Point3D dci, dcf;

	dci = Point3D(dx, dy, dz);
	



	// translation sur les sommets des polyedres des objets 3D
	// qui sont exprimes dans le repere de la camera :
	for (p = objets.L ; p != NULL ; p = p->suiv)  // pour chaque objet (parcours de liste chainnee)
		for (i = 0 ; i < p->pobjet->nbsomm ; i++){  // pour chaque sommet de l'objet
			p->pobjet->tabsomm[i].pos = p->pobjet->tabsomm[i].pos - dci;  // translation du sommet
		}

	// translation sur les positions des sources lumineuses
	// qui sont exprimees dans le repere de la camera :
	for (i = 0 ; i < nblum ; i++){
		tablum[i].pos = tablum[i].pos - dci;
	}


	// traduction du vecteur dci dans le repere de la scene
//	Matrice Manc = tabcam[nocamselect]->M.t(); // matrice de passage du repere de la scene au repere de la camera

	Matrice Manc = tabcam[nocamselect]->M; // matrice de passage du repere de la scene au repere de la camera 2006
	dcf = Manc * dci;  // dcf est le vecteur de translation exprime dans le repere de la scene

	// modification de la donnee "position de la camera"
	// exprimee dans le repere de la scene :
	tabcam[nocamselect]->pos = tabcam[nocamselect]->pos + dcf;
	tabcam[nocamselect]->centre = tabcam[nocamselect]->centre + dcf;	// navigation avatar

	// Remarque : la matrice de passage tabcam[nocamselect]->M reste inchangee par translation
}





// rotation de la camera d'un angle teta autour d'un axe parallele a un axe de coordonnees
// passant par le point de focalisation de la camera (pour boite de dialogue "Controles Camera") :

void Scene3D::rotatecamcentral(double teta, char noaxe)
{
	Matrice Mrot(3,3);
	double costeta = (double)cos(teta*pi/180.0);  // cosinus de teta (prealablement converti en radians
	double sinteta = (double)sin(teta*pi/180.0);  // sinus (idem)
	int i;
	Celluleobj * p;
	Point3D dci, dcf, poscam1;

	Matrice Manc = tabcam[nocamselect]->M;  // ancienne matrice de passage du repere de la scene
											// au repere de la camera


	if (noaxe == 0){  // rotation de la cam�ra autour d'un axe 
					  // parall�le � l'axe des X rep�re cam�ra passant par le "centre" de la cam�ra

		// matrice de rotation autour de l'axe des x :
		Mrot[0][0] = 1; Mrot[0][1] = 0; Mrot[0][2] = 0;
		Mrot[1][0] = 0; Mrot[1][1] = costeta; Mrot[1][2] = sinteta;
		Mrot[2][0] = 0; Mrot[2][1] = -sinteta; Mrot[2][2] = costeta;

		// calcul de la distance de la position de la camera a son centre de focalisation
		double norme = (tabcam[nocamselect]->pos - tabcam[nocamselect]->centre).norme();

		// on fait subir la rotation aux sommets des objets 3D
		// qui sont exprimmes dans le repere de la camera
		for (p = objets.L ; p != NULL ; p = p->suiv)  // parcours de la liste des objets
			for (i = 0 ; i < p->pobjet->nbsomm ; i++){  // parcours des sommets de chaque objet
				p->pobjet->tabsomm[i].pos.z -= norme;  // translation du repere (le centre de la rotation est (0,0,norme))
				p->pobjet->tabsomm[i].pos = Mrot * p->pobjet->tabsomm[i].pos;  // rotation
				p->pobjet->tabsomm[i].pos.z += norme;  // translation inverse du repere
				p->pobjet->tabsomm[i].normale = Mrot * p->pobjet->tabsomm[i].normale;
			}


		// on fait subir la rotation aux positions des sources lumineuses
		// qui sont exprimmees dans le repere de la camera
		for (i = 0 ; i < nblum ; i++){
			tablum[i].pos.z -= norme;
			tablum[i].pos = Mrot * tablum[i].pos;
			tablum[i].pos.z += norme;
		}


		// Le repere de la camera change du fait de son mouvement.
		// calcul de la nouvelle matrice de passage
	//	tabcam[nocamselect]->M = Mrot * tabcam[nocamselect]->M;
		
		tabcam[nocamselect]->M = tabcam[nocamselect]->M * Mrot.t();   //2006


		Mrot[2][1] = sinteta;  // inversion de la matrice de rotation
		Mrot[1][2] = -sinteta; // (cas de la rotation autour de l'axe des x)
		


		// calcul de la nouvelle position de la camera exprimee dans l'ancien
		// repere de la camera :
		poscam1 = Point3D(0, 0, -norme);
		poscam1 = Mrot * poscam1;
		poscam1.z += norme;


	//	Point3D diffposcam = Manc.t() * poscam1; // difference entre l'ancienne et la nouvelle position
												 // de la camera exprimee dans le repere de la scene

		Point3D diffposcam = Manc * poscam1;

		tabcam[nocamselect]->pos = tabcam[nocamselect]->pos + diffposcam;   // nouvelle position
																			// de la camera exprimee dans le repere de la scene




/*	$\overrightarrow{O'O''} = \overrightarrow{O'C} - R \overrightarrow{O'C}$. 

	Point3D deplac = Point3D(0,0,norme) - (Mrot*Point3D(0,0,norme));
	Soit $(x_d, y_d, z_d)$ 

les coordonn�es de
ce vecteur d�placement calcul�es comme ci-dessus dans le rep�re de
la cam�ra. Pour calculer ce vecteur d�placement dans le rep�re de
la sc�ne, il suffit, d'apr�s la partie~\ref{sect_changinverse}, de
multiplier le vecteur par la transpos�e $^tM$ de la matrice $M$.
On obtient alors le d�placement de la position de la cam�ra dans
le rep�re de la sc�ne, qu'il suffit d'ajouter � l'ancienne
position pour obtenir la nouvelle position de la cam�ra.
*/

	}



	if (noaxe == 1){  // rotation de la cam�ra autour d'un axe 
					  // parall�le � l'axe des z du repere de la scene
		Mrot[0][0] = costeta; Mrot[0][1] = sinteta; Mrot[0][2] = 0;
		Mrot[1][0] = -sinteta; Mrot[1][1] = costeta; Mrot[1][2] = 0;
		Mrot[2][0] = 0; Mrot[2][1] = 0; Mrot[2][2] = 1;
		
	/*	Point3D O =  Manc * tabcam[nocamselect]->pos;
		Matrice Mrotrepcam = Manc*Mrot*Manc.t();
		for (p = objets.L ; p != NULL ; p = p->suiv)
			for (i = 0 ; i < p->pobjet->nbsomm ; i++){
				p->pobjet->tabsomm[i].pos = Manc*(Mrot*(Manc.t()*
							(p->pobjet->tabsomm[i].pos+O)-tabcam[nocamselect]->centre)+tabcam[nocamselect]->centre)
							-O;
				p->pobjet->tabsomm[i].normale = Mrotrepcam * p->pobjet->tabsomm[i].normale;
			}

		for (i = 0 ; i < nblum ; i++){
			tablum[i].pos = Manc*(Mrot*(Manc.t()*
							(tablum[i].pos+O)-tabcam[nocamselect]->centre)+tabcam[nocamselect]->centre)
							-O;
		}

		tabcam[nocamselect]->M = tabcam[nocamselect]->M*Mrot;

		tabcam[nocamselect]->pos = Mrot.t()*
									(tabcam[nocamselect]->pos-tabcam[nocamselect]->centre)+
									tabcam[nocamselect]->centre;
	*/
	//	Point3D O =  Manc * (tabcam[nocamselect]->centre+Mrot*(tabcam[nocamselect]->pos-tabcam[nocamselect]->centre)-tabcam[nocamselect]->pos);
	//	Matrice Mrotrepcam = Manc*Mrot*Manc.t();

		Point3D O =  Manc.t() * (tabcam[nocamselect]->centre+Mrot*(tabcam[nocamselect]->pos-tabcam[nocamselect]->centre)-tabcam[nocamselect]->pos);
		Matrice Mrotrepcam = Manc.t()*Mrot*Manc;	//2006
		for (p = objets.L ; p != NULL ; p = p->suiv)
			for (i = 0 ; i < p->pobjet->nbsomm ; i++){
				p->pobjet->tabsomm[i].pos = Mrotrepcam * p->pobjet->tabsomm[i].pos+O;
				p->pobjet->tabsomm[i].normale = Mrotrepcam * p->pobjet->tabsomm[i].normale;
			}

		for (i = 0 ; i < nblum ; i++){
			tablum[i].pos = Mrotrepcam *tablum[i].pos+O;
		}

	//	tabcam[nocamselect]->M = tabcam[nocamselect]->M*Mrot;

		tabcam[nocamselect]->M = Mrot.t()*tabcam[nocamselect]->M;

		tabcam[nocamselect]->pos = Mrot.t()*
									(tabcam[nocamselect]->pos-tabcam[nocamselect]->centre)+
									tabcam[nocamselect]->centre;
	}


	// le cas suivant est plus simple que les deux cas ci-dessus
	
	if (noaxe == 2){  // rotation de la cam�ra autour d'un axe 
					  // parall�le � l'axe des Z rep�re cam�ra passant par le "centre" de la cam�ra

		// matrice de rotation autour de l'axe des z
		Mrot[0][0] = costeta; Mrot[0][1] = sinteta; Mrot[0][2] = 0;
		Mrot[1][0] = -sinteta; Mrot[1][1] = costeta; Mrot[1][2] = 0;
		Mrot[2][0] = 0; Mrot[2][1] = 0; Mrot[2][2] = 1;

		// rotation des sommets des objets 3D exprimes dans le repere de la camera
		// (cette fois l'axe de rotation est precisement l'axe des z)
		for (p = objets.L ; p != NULL ; p = p->suiv)
			for (i = 0 ; i < p->pobjet->nbsomm ; i++){
				p->pobjet->tabsomm[i].pos = Mrot * p->pobjet->tabsomm[i].pos;
				p->pobjet->tabsomm[i].normale = Mrot * p->pobjet->tabsomm[i].normale;
			}

		for (i = 0 ; i < nblum ; i++){
			tablum[i].pos = Mrot * tablum[i].pos;
		}

		// nouvelle matrice de passage
	//	tabcam[nocamselect]->M = Mrot * tabcam[nocamselect]->M;

		tabcam[nocamselect]->M = tabcam[nocamselect]->M * Mrot.t();

	}

}






void Scene3D::rotatetranslatecam(double teta, double steptransl, char noaxe)
{


	// rotation

	rotatecam(teta, noaxe);

	// translation 

	translatecam(0,0,steptransl);
	
}






void Scene3D::rotatecam(double teta, char noaxe)
{
	Matrice Mrot(3,3);
	double costeta = (double)cos(teta*pi/180.0);  // cosinus de teta (prealablement converti en radians
	double sinteta = (double)sin(teta*pi/180.0);  // sinus (idem)
	int i;
	Celluleobj * p;
	Point3D dci, dcf, poscam1;

	Matrice Manc = tabcam[nocamselect]->M;  // ancienne matrice de passage du repere de la scene
											// au repere de la camera


	if (noaxe == 0){  // rotation de la cam�ra autour d'un axe 
					  // parall�le � l'axe des x passant par le "centre" de la cam�ra

		// matrice de rotation autour de l'axe des x :
		Mrot[0][0] = 1; Mrot[0][1] = 0; Mrot[0][2] = 0;
		Mrot[1][0] = 0; Mrot[1][1] = costeta; Mrot[1][2] = sinteta;
		Mrot[2][0] = 0; Mrot[2][1] = -sinteta; Mrot[2][2] = costeta;

	}



	// le cas suivant (noaxe == 1) est similaire au cas (noaxe == 0) ci-dessus

	if (noaxe == 1){  // rotation de la cam�ra autour d'un axe 
					  // parall�le � l'axe des y passant par le "centre" de la cam�ra
		Mrot[0][0] = costeta; Mrot[0][1] = 0; Mrot[0][2] = sinteta;
		Mrot[1][0] = 0; Mrot[1][1] = 1; Mrot[1][2] = 0;
		Mrot[2][0] = -sinteta; Mrot[2][1] = 0; Mrot[2][2] = costeta;
	}


	// le cas suivant est plus simple que les deux cas ci-dessus
	
	if (noaxe == 2){  // rotation de la cam�ra autour d'un axe 
					  // parall�le � l'axe des z passant par le "centre" de la cam�ra

		// matrice de rotation autour de l'axe des z
		Mrot[0][0] = costeta; Mrot[0][1] = -sinteta; Mrot[0][2] = 0;
		Mrot[1][0] = sinteta; Mrot[1][1] = costeta; Mrot[1][2] = 0;
		Mrot[2][0] = 0; Mrot[2][1] = 0; Mrot[2][2] = 1;
	}



	// calcul de la distance de la position de la camera a son centre de focalisation
	double norme = (tabcam[nocamselect]->pos - tabcam[nocamselect]->centre).norme();

	// on fait subir la rotation aux sommets des objets 3D
	// qui sont exprimmes dans le repere de la camera
	for (p = objets.L ; p != NULL ; p = p->suiv)  // parcours de la liste des objets
		for (i = 0 ; i < p->pobjet->nbsomm ; i++){  // parcours des sommets de chaque objet
			p->pobjet->tabsomm[i].pos = Mrot * p->pobjet->tabsomm[i].pos;  // rotation
			p->pobjet->tabsomm[i].normale = Mrot * p->pobjet->tabsomm[i].normale;
		}


	// on fait subir la rotation aux positions des sources lumineuses
	// qui sont exprimmees dans le repere de la camera
	for (i = 0 ; i < nblum ; i++){
		tablum[i].pos = Mrot * tablum[i].pos;
	}


	// Le repere de la camera change du fait de son mouvement.
	// calcul de la nouvelle matrice de passage
	tabcam[nocamselect]->M = tabcam[nocamselect]->M* Mrot.t();

		
	// Calcul de la nouvelle position du point de focalisation de la cam�ra :

	// O'C' = Mrot * O'C
	// soit dans le repere de la camera :
	Point3D OpCp = Mrot.t()*Point3D(0,0,norme);
	// ce qui donne dans le rep�re de la scene :
	tabcam[nocamselect]->centre = (Manc*OpCp) + tabcam[nocamselect]->pos;

	
}









void Scene3D::redrescam(void){

	Camera *pcam = tabcam[nocamselect];


	Point3D O;


	Matrice Manc = tabcam[nocamselect]->M;
//	matrice Minvanc = (Manc).inv();
	Matrice Minvanc = tabcam[nocamselect]->M.t();

	O =  Minvanc * tabcam[nocamselect]->pos;
	
	Celluleobj * p;
	int i;
	for (p = objets.L ; p != NULL ; p = p->suiv)
		for (i = 0 ; i < p->pobjet->nbsomm ; i++){

			p->pobjet->tabsomm[i].pos = p->pobjet->tabsomm[i].pos + O;
			p->pobjet->tabsomm[i].pos = Manc * p->pobjet->tabsomm[i].pos;
			p->pobjet->tabsomm[i].normale = Manc * p->pobjet->tabsomm[i].normale;
		}

	for (i = 0 ; i < nblum ; i++){
		tablum[i].pos = tablum[i].pos + O;
		tablum[i].pos = Manc * tablum[i].pos;
	}

	
	tabcam[nocamselect] = new Cameraperspect(pcam->pos.x, pcam->pos.y, pcam->pos.z,
		                                     pcam->centre.x, pcam->centre.y,pcam->centre.z,
											 (double)(pcam->accesanglex()*180.0/pi));
	delete pcam;

	Matrice Minv =tabcam[nocamselect]->M.t(); 
	O =  Minv * tabcam[nocamselect]->pos;


	for (p = objets.L ; p != NULL ; p = p->suiv)
		for (i = 0 ; i < p->pobjet->nbsomm ; i++){

			p->pobjet->tabsomm[i].pos = Minv * p->pobjet->tabsomm[i].pos;
			p->pobjet->tabsomm[i].pos = p->pobjet->tabsomm[i].pos - O;
			p->pobjet->tabsomm[i].normale = Minv * p->pobjet->tabsomm[i].normale;

		}

	for (i = 0 ; i < nblum ; i++){
		tablum[i].pos = Minv * tablum[i].pos;
		tablum[i].pos = tablum[i].pos - O;
	}

}


Camera * & Scene3D::cameraselectionnee(void)
{
	return tabcam[nocamselect];
}

void Scene3D::changecam(double px, double py, double pz, double cx, double cy, double cz, double ax){



		Camera *pcam = tabcam[nocamselect];


		Point3D O;


		Matrice Manc = tabcam[nocamselect]->M;
		Matrice Minvanc = tabcam[nocamselect]->M.t();

		O =  Minvanc * tabcam[nocamselect]->pos;
	
		Celluleobj * p;
		int i;
		for (p = objets.L ; p != NULL ; p = p->suiv)
			for (i = 0 ; i < p->pobjet->nbsomm ; i++){

				p->pobjet->tabsomm[i].pos = p->pobjet->tabsomm[i].pos + O;
				p->pobjet->tabsomm[i].pos = Manc * p->pobjet->tabsomm[i].pos;
				p->pobjet->tabsomm[i].normale = Manc * p->pobjet->tabsomm[i].normale;

			}

		for (i = 0 ; i < nblum ; i++){
			tablum[i].pos = tablum[i].pos + O;
			tablum[i].pos = Manc * tablum[i].pos;
		}

	
		tabcam[nocamselect] = new Cameraperspect(px, py, pz, cx, cy, cz, ax);
		delete pcam;

		Matrice Minv = tabcam[nocamselect]->M.t();
		O =  Minv * tabcam[nocamselect]->pos;


		for (p = objets.L ; p != NULL ; p = p->suiv)
			for (i = 0 ; i < p->pobjet->nbsomm ; i++){

				p->pobjet->tabsomm[i].pos = Minv * p->pobjet->tabsomm[i].pos;
				p->pobjet->tabsomm[i].pos = p->pobjet->tabsomm[i].pos - O;
				p->pobjet->tabsomm[i].normale = Minv * p->pobjet->tabsomm[i].normale;

			}

		for (i = 0 ; i < nblum ; i++){
			tablum[i].pos = Minv * tablum[i].pos;
			tablum[i].pos = tablum[i].pos - O;
		}

}

