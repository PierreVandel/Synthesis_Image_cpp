// Matrice.h: interface for the Matrice class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MATRICE_H__276E9140_49A7_11D3_B1CB_87C27177E876__INCLUDED_)
#define AFX_MATRICE_H__276E9140_49A7_11D3_B1CB_87C27177E876__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <iostream>
using namespace std;


class Point3D;
class Sommet;
class Vecteur4D;
class Quadruplet;

class Matrice
{
protected:
	int nl, nc;
	double** mat;
public:
	Matrice(void);
	Matrice(int,int);
	Matrice(Matrice&);
	~Matrice();
	double* operator [] (int i) const;
	Matrice& operator = (Matrice&);
	Matrice inv();
	Matrice operator - ();
	Matrice t ();
// friend ostream& operator << (ostream&,const Matrice&);
// friend istream& operator >> (istream&,Matrice&);
	friend Matrice  operator + (const Matrice&,const Matrice&);
	friend Matrice  operator - (const Matrice&,const Matrice&);
	friend Matrice  operator * (const Matrice&,const Matrice&);
	friend Point3D operator * (const Matrice&, const Point3D&);
//	friend Vecteur4D operator * (const Matrice&, Vecteur4D&);

	friend double operator*(const Quadruplet &q, const Vecteur4D &v);

	void normaliserotation(void);

};

class Vecteur4D : public Matrice{

public:
	Vecteur4D(){nc=nl=0; mat=NULL;}
	Vecteur4D(double a, double b, double c, double d):Matrice(4,1){mat[0][0]=a; mat[1][0]=b; mat[2][0]=c; mat[3][0]=d;}
	
	
	double operator [] (int i) const{return mat[i][0];}

	Vecteur4D& operator =(Vecteur4D& V){Matrice::operator=(V); return (*this);}
	Vecteur4D& operator =(Matrice& M){Matrice::operator=(M); return (*this);}

};



class Quadruplet : public Matrice{

public:
	Quadruplet(){nc=nl=0; mat=NULL;}
	Quadruplet(double a, double b, double c, double d):Matrice(1,4){mat[0][0]=a; mat[0][1]=b; mat[0][2]=c; mat[0][3]=d;}
	
	
	double operator [] (int i) const{return mat[0][i];}

	Quadruplet& operator =(Quadruplet& V){Matrice::operator=(V); return (*this);}
	Quadruplet& operator =(Matrice& M){Matrice::operator=(M); return (*this);}
};




#endif // !defined(AFX_MATRICE_H__276E9140_49A7_11D3_B1CB_87C27177E876__INCLUDED_)
