// Surface.h: interface for the Surface class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SURFACE_H__B450CE9A_88E1_41D0_AFEC_D51B61DE796E__INCLUDED_)
#define AFX_SURFACE_H__B450CE9A_88E1_41D0_AFEC_D51B61DE796E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <fstream>
#include "Point3D.h"
#include "Matrice.h"
using namespace std;

#define NB_POINTS_SURFACE 20

#define pi 3.1415926535897932


enum typesurface{BSPLINECUBIQUESPHERE=1, 
                  BSPLINECUBIQUEDISK=2, BSPLINECUBIQUECYL=3,
				  BSPLINECUBIQUECYLINDRE=4, BSPLINECUBIQUETORUS=5};

class Camera;

class Surface  
{
	friend class Spline3DEditable;
	friend class Scene3D;
public:
	Surface();
	virtual ~Surface();

	virtual int GetNbCtrl(void)=0;
	virtual int GetNbCols(void)=0;
	virtual int GetNbRaws(void)=0;
	virtual void getpoint(double s, double t, double & xpos, double & ypos, double & zpos)=0;
	virtual void getnormale(double s, double t, double & xn, double & yn, double & zn)=0;
	virtual void getdsds(double s, double t, double & xn, double & yn, double & zn)=0;
	virtual void getdsdt(double s, double t, double & xn, double & yn, double & zn)=0;

	virtual void affiche(CDC &cdc, Camera *cam, int dim2Dx, int dim2Dy)=0;

	virtual void affichectrlpoints(CDC& cdc, Camera *cam, int dim2Dx, int dim2Dy)=0;
	virtual void GetCtrlpointSelect(CPoint pos, int & iproche, int & jproche, Camera *cam, int dim2Dx, int dim2Dy)=0;
	virtual void DeplaceCtrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, CDC &cdc, Camera *cam, int dim2Dx, int dim2Dy)=0;
	virtual void deplaceeffectctrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, Camera*cam)=0;
	virtual Point3D GetProjectionCtrlPoint(int i, int j, double D,int dim2Dx, int dim2Dy)=0;

	virtual void ecritctrlpoints(ostream & fich)=0;

	virtual Surface * copie(void)=0;

	virtual void mettredansreperecam(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine)=0;
	virtual void mettredansreperescene(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine)=0;


	virtual void rotatecamcentral(double teta, char noaxe, Camera * cam)=0;

	virtual typesurface gettype(void)=0;

	virtual Point3D GetPosCtrlPoint(int i,int j, Camera *cam)=0;

	virtual void lisser(double amplitude)=0;
	virtual void lisser(double amplitude, int i0, int j0, int ri, int rj)=0;

	virtual void elevation(bool addlignes, bool addcols)=0;

};




class SurfaceBSplineCubique : public Surface{


	friend class Spline3DEditable;
	friend class Scene3D;

protected:
	Matrice **coeffs_x;
	Matrice **coeffs_y;
	Matrice **coeffs_z;

	Point3D **ctrlpoints;
	int nblignes;
	int nbcols;


public:

	int GetNbCtrl(void){return nblignes*nbcols;}
	int GetNbCols(void){return nbcols;}
	int GetNbRaws(void){return nblignes;}

	SurfaceBSplineCubique(void){nblignes=nbcols=0;ctrlpoints=NULL;}

	SurfaceBSplineCubique(Point3D**ctrl, int nbl, int nbc);

	SurfaceBSplineCubique(istream &fich);

	void precalculmatrices(bool allouer);
	~SurfaceBSplineCubique();


	void affiche(CDC &cdc, Camera *cam, int dim2Dx, int dim2Dy);

	void getpoint(double s, double t, double & xpos, double & ypos, double & zpos);
	void getnormale(double s, double t, double & xn, double & yn, double & zn);
	void getdsds(double s, double t, double & xn, double & yn, double & zn);
	void getdsdt(double s, double t, double & xn, double & yn, double & zn);

	void affichectrlpoints(CDC& cdc, Camera *cam, int dim2Dx, int dim2Dy);
	virtual void GetCtrlpointSelect(CPoint pos, int & iproche, int & jproche, Camera *cam, int dim2Dx, int dim2Dy);
	void DeplaceCtrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, CDC &cdc, Camera *cam, int dim2Dx, int dim2Dy);
	virtual void deplaceeffectctrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, Camera*cam)=0;
	void ecritctrlpoints(ostream & fich);


	virtual Surface * copie(void)=0;

	void mettredansreperecam(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine);
	void mettredansreperescene(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine);

	void rotatecamcentral(double teta, char noaxe, Camera * cam);

	Point3D GetPosCtrlPoint(int i,int j, Camera *cam){
									return cam->M.t() *ctrlpoints[i][j] + cam->pos;
									}
	Point3D GetProjectionCtrlPoint(int i, int j, double D,int dim2Dx, int dim2Dy);

	virtual typesurface gettype(void)=0;

	virtual void lisser(double amplitude)=0;
	virtual void lisser(double amplitude, int i0, int j0, int ri, int rj)=0;

	virtual void elevation(bool addlignes, bool addcols)=0;
};






class SurfaceBSplineCubiqueSphere : public SurfaceBSplineCubique{




public:

	SurfaceBSplineCubiqueSphere(void){nblignes=nbcols=0;ctrlpoints=NULL;}

	SurfaceBSplineCubiqueSphere(Point3D**ctrl, int nbl, int nbc):SurfaceBSplineCubique(ctrl, nbl, nbc){}

	SurfaceBSplineCubiqueSphere(istream &fich):SurfaceBSplineCubique(fich){}
	~SurfaceBSplineCubiqueSphere(){}
	void getpoint(double s, double t, double & xpos, double & ypos, double & zpos){SurfaceBSplineCubique::getpoint(s, t, xpos, ypos, zpos);}
	void getnormale(double s, double t, double & xn, double & yn, double & zn){SurfaceBSplineCubique::getnormale(s, t, xn, yn, zn);}
	void getdsds(double s, double t, double & xn, double & yn, double & zn){SurfaceBSplineCubique::getdsds(s, t, xn, yn, zn);}
	void getdsdt(double s, double t, double & xn, double & yn, double & zn){SurfaceBSplineCubique::getdsdt(s, t, xn, yn, zn);}

	void deplaceeffectctrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, Camera*cam);
	void GetCtrlpointSelect(CPoint pos, int & iproche, int & jproche, Camera *cam, int dim2Dx, int dim2Dy){SurfaceBSplineCubique::GetCtrlpointSelect(pos,iproche,jproche,cam,dim2Dx,dim2Dy);
																									if (jproche < 3){ jproche=0; iproche=0;} 
																									if (jproche >= nbcols-3){ jproche=nbcols-1; iproche=0;} 
																									}

	Surface * copie(void);
	void mettredansreperecam(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine){SurfaceBSplineCubique::mettredansreperecam(cam, rot, scax, scay, scaz, origine);}
	void mettredansreperescene(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine){SurfaceBSplineCubique::mettredansreperescene(cam, rot, scax, scay, scaz, origine);}

	void rotatecamcentral(double teta, char noaxe, Camera * cam){SurfaceBSplineCubique::rotatecamcentral(teta, noaxe, cam);}

	typesurface gettype(void){return BSPLINECUBIQUESPHERE;};

	void lisser(double amplitude);
	void lisser(double amplitude, int i0, int j0, int ri, int rj);

	void elevation(bool addlignes, bool addcols);
};



class SurfaceBSplineCubiqueTore : public SurfaceBSplineCubique{




public:

	SurfaceBSplineCubiqueTore(void){nblignes=nbcols=0;ctrlpoints=NULL;}

	SurfaceBSplineCubiqueTore(Point3D**ctrl, int nbl, int nbc):SurfaceBSplineCubique(ctrl, nbl, nbc){}

	SurfaceBSplineCubiqueTore(istream &fich):SurfaceBSplineCubique(fich){}
	~SurfaceBSplineCubiqueTore(){}
	void getpoint(double s, double t, double & xpos, double & ypos, double & zpos){SurfaceBSplineCubique::getpoint(s, t, xpos, ypos, zpos);}
	void getnormale(double s, double t, double & xn, double & yn, double & zn){SurfaceBSplineCubique::getnormale(s, t, xn, yn, zn);}
	void getdsds(double s, double t, double & xn, double & yn, double & zn){SurfaceBSplineCubique::getdsds(s, t, xn, yn, zn);}
	void getdsdt(double s, double t, double & xn, double & yn, double & zn){SurfaceBSplineCubique::getdsdt(s, t, xn, yn, zn);}

	void deplaceeffectctrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, Camera*cam);
	void GetCtrlpointSelect(CPoint pos, int & iproche, int & jproche, Camera *cam, int dim2Dx, int dim2Dy){SurfaceBSplineCubique::GetCtrlpointSelect(pos,iproche,jproche,cam,dim2Dx,dim2Dy);} 
																									

	Surface * copie(void);
	void mettredansreperecam(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine){SurfaceBSplineCubique::mettredansreperecam(cam, rot, scax, scay, scaz, origine);}
	void mettredansreperescene(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine){SurfaceBSplineCubique::mettredansreperescene(cam, rot, scax, scay, scaz, origine);}

	void rotatecamcentral(double teta, char noaxe, Camera * cam){SurfaceBSplineCubique::rotatecamcentral(teta, noaxe, cam);}

	typesurface gettype(void){return BSPLINECUBIQUETORUS;};

	void lisser(double amplitude);
	void lisser(double amplitude, int i0, int j0, int ri, int rj);

	void elevation(bool addlignes, bool addcols);
};








class SurfaceBSplineCubiqueDisk : public SurfaceBSplineCubique{




public:

	SurfaceBSplineCubiqueDisk(void){nblignes=nbcols=0;ctrlpoints=NULL;}

	SurfaceBSplineCubiqueDisk(Point3D**ctrl, int nbl, int nbc):SurfaceBSplineCubique(ctrl, nbl, nbc){}

	SurfaceBSplineCubiqueDisk(istream &fich):SurfaceBSplineCubique(fich){}
	~SurfaceBSplineCubiqueDisk(){}
	void getpoint(double s, double t, double & xpos, double & ypos, double & zpos){SurfaceBSplineCubique::getpoint(s, t, xpos, ypos, zpos);}
	void getnormale(double s, double t, double & xn, double & yn, double & zn){SurfaceBSplineCubique::getnormale(s, t, xn, yn, zn);}
	void getdsds(double s, double t, double & xn, double & yn, double & zn){SurfaceBSplineCubique::getdsds(s, t, xn, yn, zn);}
	void getdsdt(double s, double t, double & xn, double & yn, double & zn){SurfaceBSplineCubique::getdsdt(s, t, xn, yn, zn);}

	void deplaceeffectctrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, Camera*cam);
	void GetCtrlpointSelect(CPoint pos, int & iproche, int & jproche, Camera *cam, int dim2Dx, int dim2Dy){SurfaceBSplineCubique::GetCtrlpointSelect(pos,iproche,jproche,cam,dim2Dx,dim2Dy);
																													if (jproche >= nbcols-2)jproche = nbcols-3;
																													if (jproche <= 2)jproche = 2;}

	Surface * copie(void);
	void mettredansreperecam(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine){SurfaceBSplineCubique::mettredansreperecam(cam, rot, scax, scay, scaz, origine);}
	void mettredansreperescene(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine){SurfaceBSplineCubique::mettredansreperescene(cam, rot, scax, scay, scaz, origine);}

	void rotatecamcentral(double teta, char noaxe, Camera * cam){SurfaceBSplineCubique::rotatecamcentral(teta, noaxe, cam);}

	typesurface gettype(void){return BSPLINECUBIQUEDISK;};

	void lisser(double amplitude);
	void lisser(double amplitude, int i0, int j0, int ri, int rj);

	void elevation(bool addlignes, bool addcols);
};






class SurfaceBSplineCubiqueCyl : public SurfaceBSplineCubique{




public:

	SurfaceBSplineCubiqueCyl(void){nblignes=nbcols=0;ctrlpoints=NULL;}

	SurfaceBSplineCubiqueCyl(Point3D**ctrl, int nbl, int nbc):SurfaceBSplineCubique(ctrl, nbl, nbc){}

	SurfaceBSplineCubiqueCyl(istream &fich):SurfaceBSplineCubique(fich){}
	~SurfaceBSplineCubiqueCyl(){}
	void getpoint(double s, double t, double & xpos, double & ypos, double & zpos){SurfaceBSplineCubique::getpoint(s, t, xpos, ypos, zpos);}
	void getnormale(double s, double t, double & xn, double & yn, double & zn){SurfaceBSplineCubique::getnormale(s, t, xn, yn, zn);}
	void getdsds(double s, double t, double & xn, double & yn, double & zn){SurfaceBSplineCubique::getdsds(s, t, xn, yn, zn);}
	void getdsdt(double s, double t, double & xn, double & yn, double & zn){SurfaceBSplineCubique::getdsdt(s, t, xn, yn, zn);}

	void deplaceeffectctrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, Camera*cam);
	void GetCtrlpointSelect(CPoint pos, int & iproche, int & jproche, Camera *cam, int dim2Dx, int dim2Dy){SurfaceBSplineCubique::GetCtrlpointSelect(pos,iproche,jproche,cam,dim2Dx,dim2Dy);
																													if (jproche >= nbcols-2)jproche = nbcols-3;
																													if (jproche <= 2)jproche = 2;}

	Surface * copie(void);
	void mettredansreperecam(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine){SurfaceBSplineCubique::mettredansreperecam(cam, rot, scax, scay, scaz, origine);}
	void mettredansreperescene(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine){SurfaceBSplineCubique::mettredansreperescene(cam, rot, scax, scay, scaz, origine);}

	void rotatecamcentral(double teta, char noaxe, Camera * cam){SurfaceBSplineCubique::rotatecamcentral(teta, noaxe, cam);}

	typesurface gettype(void){return BSPLINECUBIQUECYL;};

	void lisser(double amplitude);
	void lisser(double amplitude, int i0, int j0, int ri, int rj);

	void elevation(bool addlignes, bool addcols);
};







class SurfaceMultiPatch : public Surface{


	friend class Spline3DEditable;
	friend class Scene3D;

protected:

	Surface *patches[6];
	int nbctrlpatch[6];
	int nbpatches;

public:

	int GetNbCtrl(void){int s=0; for (int i = 0;i<nbpatches;i++)s+=patches[i]->GetNbCtrl(); return s;}
	int GetNbCols(void){return 0;}
	int GetNbRaws(void){return 0;}
	SurfaceMultiPatch(void){nbpatches=0;}

	SurfaceMultiPatch(int nbp, Point3D***ctrl, int* nbl, int *nbc);

	SurfaceMultiPatch(istream &fich);

	void precalculmatrices(bool allouer);
	~SurfaceMultiPatch();


	void affiche(CDC &cdc, Camera *cam, int dim2Dx, int dim2Dy);

	void getpoint(double s, double t, double & xpos, double & ypos, double & zpos);
	void getnormale(double s, double t, double & xn, double & yn, double & zn);
	void getdsds(double s, double t, double & xn, double & yn, double & zn);
	void getdsdt(double s, double t, double & xn, double & yn, double & zn);

	void affichectrlpoints(CDC& cdc, Camera *cam, int dim2Dx, int dim2Dy);
	void GetCtrlpointSelect(CPoint pos, int & iproche, int & jproche, Camera *cam, int dim2Dx, int dim2Dy);
	void DeplaceCtrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, CDC &cdc, Camera *cam, int dim2Dx, int dim2Dy);
	virtual void deplaceeffectctrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, Camera*cam)=0;
	void ecritctrlpoints(ostream & fich);
	Point3D GetProjectionCtrlPoint(int i, int j, double D,int dim2Dx, int dim2Dy);

	virtual Surface * copie(void)=0;

	void mettredansreperecam(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine);
	void mettredansreperescene(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine);

	void rotatecamcentral(double teta, char noaxe, Camera * cam);

	Point3D GetPosCtrlPoint(int i,int j, Camera *cam);
	virtual typesurface gettype(void)=0;

	void lisser(double amplitude);
	virtual void lisser(double amplitude, int i0, int j0, int ri, int rj)=0;

	void elevation(bool addlignes, bool addcols);
};





class SurfaceBSplineCubiqueCylindre : public SurfaceMultiPatch{


	friend class Spline3DEditable;
	friend class Scene3D;


public:


	SurfaceBSplineCubiqueCylindre(void):SurfaceMultiPatch(){}

	SurfaceBSplineCubiqueCylindre(Point3D**ctrlbody, int nblbody, int nbcbody,
									Point3D**ctrltop, int nbltop, int nbctop,
									Point3D**ctrlbottom, int nblbottom, int nbcbottom);

	SurfaceBSplineCubiqueCylindre(istream &fich);

	void precalculmatrices(bool allouer);
//	~SurfaceBSplineCubiqueCylindre();


//	void affiche(CDC &cdc, Camera *cam, int dim2Dx, int dim2Dy);

//	void getpoint(double s, double t, double & xpos, double & ypos, double & zpos);
//	void getnormale(double s, double t, double & xn, double & yn, double & zn);
//	void getdsds(double s, double t, double & xn, double & yn, double & zn);
//	void getdsdt(double s, double t, double & xn, double & yn, double & zn);

//	void affichectrlpoints(CDC& cdc, Camera *cam, int dim2Dx, int dim2Dy);
//	void GetCtrlpointSelect(CPoint pos, int & iproche, int & jproche, Camera *cam, int dim2Dx, int dim2Dy);
//	void DeplaceCtrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, CDC &cdc, Camera *cam, int dim2Dx, int dim2Dy);
	void deplaceeffectctrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, Camera*cam);
//	void ecritctrlpoints(ostream & fich);
//	Point3D GetProjectionCtrlPoint(int i, int j, double D,int dim2Dx, int dim2Dy);

	Surface * copie(void);

//	void mettredansreperecam(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine);
//	void mettredansreperescene(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine);

//	void rotatecamcentral(double teta, char noaxe, Camera * cam);

//	Point3D GetPosCtrlPoint(int i,int j, Camera *cam);
	typesurface gettype(void){return BSPLINECUBIQUECYLINDRE;}

//	void lisser(double amplitude);
	void lisser(double amplitude, int i0, int j0, int ri, int rj);

//	void elevation(bool addlignes, bool addcols);
};






double **allouerdouble2D(int n, int m);
Point3D **allouerPoints3D(int n, int m);


void liberedouble2D(double**t, int nl);
void libererPoints3D(Point3D** t,int n);


Matrice **allouermatrices(int n, int m);
void liberematrice(Matrice**t, int nl);



#endif // !defined(AFX_SURFACE_H__B450CE9A_88E1_41D0_AFEC_D51B61DE796E__INCLUDED_)
