// ControlCameraDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Synth.h"
#include "ControlCameraDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CControlCameraDlg dialog


CControlCameraDlg::CControlCameraDlg(CView * pView)
{
	m_pView = pView;
}

CControlCameraDlg::CControlCameraDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CControlCameraDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CControlCameraDlg)
	m_rotstep = 0.0f;
	m_transstep = 0.0f;
	//}}AFX_DATA_INIT

	m_pView = NULL;
}


void CControlCameraDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CControlCameraDlg)
	DDX_Text(pDX, IDC_ROT_STEP, m_rotstep);
	DDV_MinMaxFloat(pDX, m_rotstep, -90.f, 90.f);
	DDX_Text(pDX, IDC_TRANS_STEP, m_transstep);
	//}}AFX_DATA_MAP
}


BOOL CControlCameraDlg::Create()
{
	return CDialog::Create(CControlCameraDlg::IDD, NULL);

}

BEGIN_MESSAGE_MAP(CControlCameraDlg, CDialog)
	//{{AFX_MSG_MAP(CControlCameraDlg)
	ON_BN_CLICKED(IDC_CC_ROT_DOWN, OnCcRotDown)
	ON_BN_CLICKED(IDC_CC_ROT_LEFT, OnCcRotLeft)
	ON_BN_CLICKED(IDC_CC_ROT_RIGHT, OnCcRotRight)
	ON_BN_CLICKED(IDC_CC_ROT_UP, OnCcRotUp)
	ON_BN_CLICKED(IDC_CC_TRANS_BACKWARD, OnCcTransBackward)
	ON_BN_CLICKED(IDC_CC_TRANS_DOWN, OnCcTransDown)
	ON_BN_CLICKED(IDC_CC_TRANS_FORWARD, OnCcTransForward)
	ON_BN_CLICKED(IDC_CC_TRANS_LEFT, OnCcTransLeft)
	ON_BN_CLICKED(IDC_CC_TRANS_RIGHT, OnCcTransRight)
	ON_BN_CLICKED(IDC_CC_TRANS_UP, OnCcTransUp)
	ON_BN_CLICKED(IDC_CC_ROT_RD, OnCcRotRd)
	ON_BN_CLICKED(IDC_CC_ROT_RG, OnCcRotRg)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CControlCameraDlg message handlers

void CControlCameraDlg::OnCcRotDown() 
{
	// TODO: Add your control notification handler code here
	
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR, IDC_CC_ROT_DOWN);
}

void CControlCameraDlg::OnCcRotLeft() 
{
	// TODO: Add your control notification handler code here

	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR, IDC_CC_ROT_LEFT);

}

void CControlCameraDlg::OnCcRotRight() 
{
	// TODO: Add your control notification handler code here

	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR, IDC_CC_ROT_RIGHT);

}

void CControlCameraDlg::OnCcRotUp() 
{
	// TODO: Add your control notification handler code here

	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR, IDC_CC_ROT_UP);
}

void CControlCameraDlg::OnCcTransBackward() 
{
	// TODO: Add your control notification handler code here

	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR, IDC_CC_TRANS_BACKWARD);

}

void CControlCameraDlg::OnCcTransDown() 
{
	// TODO: Add your control notification handler code here

	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR, IDC_CC_TRANS_DOWN);

}

void CControlCameraDlg::OnCcTransForward() 
{
	// TODO: Add your control notification handler code here

	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR, IDC_CC_TRANS_FORWARD);

}

void CControlCameraDlg::OnCcTransLeft() 
{
	// TODO: Add your control notification handler code here
	
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR, IDC_CC_TRANS_LEFT);

}

void CControlCameraDlg::OnCcTransRight() 
{
	// TODO: Add your control notification handler code here
	
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR, IDC_CC_TRANS_RIGHT);

}

void CControlCameraDlg::OnCcTransUp() 
{
	// TODO: Add your control notification handler code here
	
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR, IDC_CC_TRANS_UP);

}



void CControlCameraDlg::OnCcRotRd() 
{
	// TODO: Add your control notification handler code here

	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR, IDC_CC_ROT_RD);


}

void CControlCameraDlg::OnCcRotRg() 
{
	// TODO: Add your control notification handler code here
	
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR, IDC_CC_ROT_RG);


}



void CControlCameraDlg::OnCancel() 
{
	DestroyWindow();

	m_bitmapup.DeleteObject();
	m_bitmapdo.DeleteObject();
	m_bitmaple.DeleteObject();
	m_bitmapri.DeleteObject();
	m_bitmaprg.DeleteObject();
	m_bitmaprd.DeleteObject();
	m_bitmapfo.DeleteObject();
	m_bitmapba.DeleteObject();
	
//	CDialog::OnCancel();  
}

void CControlCameraDlg::OnOK() 
{
	// TODO: Add extra validation here
	
//	CDialog::OnOK();
}


BOOL CControlCameraDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_bitmapup.LoadBitmap(IDB_FLECHE_UP);
	HBITMAP hBitmapup = (HBITMAP) m_bitmapup.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CC_ROT_UP))->SetBitmap(hBitmapup);

	((CButton*) GetDlgItem(IDC_CC_TRANS_UP))->SetBitmap(hBitmapup);
	
	m_bitmapdo.LoadBitmap(IDB_FLECHE_DO);
	HBITMAP hBitmapdo = (HBITMAP) m_bitmapdo.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CC_ROT_DOWN))->SetBitmap(hBitmapdo);

	((CButton*) GetDlgItem(IDC_CC_TRANS_DOWN))->SetBitmap(hBitmapdo);

	m_bitmaple.LoadBitmap(IDB_FLECHE_LE);
	HBITMAP hBitmaple = (HBITMAP) m_bitmaple.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CC_ROT_LEFT))->SetBitmap(hBitmaple);

	((CButton*) GetDlgItem(IDC_CC_TRANS_LEFT))->SetBitmap(hBitmaple);

	m_bitmapri.LoadBitmap(IDB_FLECHE_RI);
	HBITMAP hBitmapri = (HBITMAP) m_bitmapri.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CC_ROT_RIGHT))->SetBitmap(hBitmapri);

	((CButton*) GetDlgItem(IDC_CC_TRANS_RIGHT))->SetBitmap(hBitmapri);

	m_bitmaprg.LoadBitmap(IDB_FLECHE_RG);
	HBITMAP hBitmaprg = (HBITMAP) m_bitmaprg.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CC_ROT_RG))->SetBitmap(hBitmaprg);

	m_bitmaprd.LoadBitmap(IDB_FLECHE_RD);
	HBITMAP hBitmaprd = (HBITMAP) m_bitmaprd.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CC_ROT_RD))->SetBitmap(hBitmaprd);
	
	m_bitmapfo.LoadBitmap(IDB_FLECHE_FO);
	HBITMAP hBitmapfo = (HBITMAP) m_bitmapfo.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CC_TRANS_FORWARD))->SetBitmap(hBitmapfo);

	m_bitmapba.LoadBitmap(IDB_FLECHE_BA);
	HBITMAP hBitmapba = (HBITMAP) m_bitmapba.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CC_TRANS_BACKWARD))->SetBitmap(hBitmapba);

	
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CControlCameraDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default

	m_bitmapup.DeleteObject();
	m_bitmapdo.DeleteObject();
	m_bitmaple.DeleteObject();
	m_bitmapri.DeleteObject();
	m_bitmaprg.DeleteObject();
	m_bitmaprd.DeleteObject();
	m_bitmapfo.DeleteObject();
	m_bitmapba.DeleteObject();

	
	CDialog::OnClose();
}
/////////////////////////////////////////////////////////////////////////////
// CControlNavigatDialog dialog


CControlNavigatDialog::CControlNavigatDialog(CView * pView)
{
	m_pView = pView;
	m_backward = FALSE;
}


CControlNavigatDialog::CControlNavigatDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CControlNavigatDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CControlNavigatDialog)
	m_rotstep = 0.0;
	m_transstep = 0.0;
	m_backward = FALSE;
	//}}AFX_DATA_INIT
	m_pView = NULL;
}


void CControlNavigatDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CControlNavigatDialog)
	DDX_Text(pDX, IDC_ROT_STEP, m_rotstep);
	DDX_Text(pDX, IDC_TRANS_STEP, m_transstep);
	DDX_Check(pDX, IDC_ARRIERE, m_backward);
	//}}AFX_DATA_MAP
}


BOOL CControlNavigatDialog::Create()
{
	return CDialog::Create(CControlNavigatDialog::IDD, NULL);

}


BEGIN_MESSAGE_MAP(CControlNavigatDialog, CDialog)
	//{{AFX_MSG_MAP(CControlNavigatDialog)
	ON_BN_CLICKED(IDC_CN_ROT_DOWN, OnCnRotDown)
	ON_BN_CLICKED(IDC_CN_ROT_LEFT, OnCnRotLeft)
	ON_BN_CLICKED(IDC_CN_ROT_RIGHT, OnCnRotRight)
	ON_BN_CLICKED(IDC_CN_ROT_UP, OnCnRotUp)
	ON_BN_CLICKED(IDC_CN_TRANS_BACKWARD, OnCnTransBackward)
	ON_BN_CLICKED(IDC_CN_TRANS_DOWN, OnCnTransDown)
	ON_BN_CLICKED(IDC_CN_TRANS_FORWARD, OnCnTransForward)
	ON_BN_CLICKED(IDC_CN_TRANS_LEFT, OnCnTransLeft)
	ON_BN_CLICKED(IDC_CN_TRANS_RIGHT, OnCnTransRight)
	ON_BN_CLICKED(IDC_CN_TRANS_UP, OnCnTransUp)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_CN_ROT_RD, OnCnRotRd)
	ON_BN_CLICKED(IDC_CN_ROT_RG, OnCnRotRg)
	ON_BN_CLICKED(IDC_CN_ROTTRANS_DOWN, OnCnRottransDown)
	ON_BN_CLICKED(IDC_CN_ROTTRANS_LEFT, OnCnRottransLeft)
	ON_BN_CLICKED(IDC_CN_ROTTRANS_RD, OnCnRottransRd)
	ON_BN_CLICKED(IDC_CN_ROTTRANS_RG, OnCnRottransRg)
	ON_BN_CLICKED(IDC_CN_ROTTRANS_RIGHT, OnCnRottransRight)
	ON_BN_CLICKED(IDC_CN_ROTTRANS_UP, OnCnRottransUp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CControlNavigatDialog message handlers


void CControlNavigatDialog::OnCancel() 
{
	// TODO: Add extra cleanup here
	

	DestroyWindow();

	m_bitmapup.DeleteObject();
	m_bitmapdo.DeleteObject();
	m_bitmaple.DeleteObject();
	m_bitmapri.DeleteObject();
	m_bitmaprg.DeleteObject();
	m_bitmaprd.DeleteObject();
	m_bitmapfo.DeleteObject();
	m_bitmapba.DeleteObject();
	
	
//	CDialog::OnCancel();
}

void CControlNavigatDialog::OnOK() 
{
	// TODO: Add extra validation here
	
//	CDialog::OnOK();
}



void CControlNavigatDialog::OnCnRotDown() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_ROT_DOWN);
	
}

void CControlNavigatDialog::OnCnRotLeft() 
{
	// TODO: Add your control notification handler code here
	
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_ROT_LEFT);
}

void CControlNavigatDialog::OnCnRotRight() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_ROT_RIGHT);

}

void CControlNavigatDialog::OnCnRotUp() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_ROT_UP);

}

void CControlNavigatDialog::OnCnTransBackward() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_TRANS_BACKWARD);

}

void CControlNavigatDialog::OnCnTransDown() 
{
	// TODO: Add your control notification handler code here
	
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_TRANS_DOWN);
}

void CControlNavigatDialog::OnCnTransForward() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_TRANS_FORWARD);

}

void CControlNavigatDialog::OnCnTransLeft() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_TRANS_LEFT);

}

void CControlNavigatDialog::OnCnTransRight() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_TRANS_RIGHT);

}

void CControlNavigatDialog::OnCnTransUp() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_TRANS_UP);

}



void CControlNavigatDialog::OnCnRotRd() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_ROT_RD);

}

void CControlNavigatDialog::OnCnRotRg() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_ROT_RG);

}


void CControlNavigatDialog::OnCnRottransDown() 
{
	// TODO: Add your control notification handler code here
	
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_ROTTRANS_DOWN);
}

void CControlNavigatDialog::OnCnRottransLeft() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_ROTTRANS_LEFT);
	
}

void CControlNavigatDialog::OnCnRottransRd() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_ROTTRANS_RD);

}

void CControlNavigatDialog::OnCnRottransRg() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_ROTTRANS_RG);

}

void CControlNavigatDialog::OnCnRottransRight() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_ROTTRANS_RIGHT);

}

void CControlNavigatDialog::OnCnRottransUp() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_pView->PostMessage(WM_RAFFRAICHIR_NAVIGAT, IDC_CN_ROTTRANS_UP);

}


BOOL CControlNavigatDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_bitmapup.LoadBitmap(IDB_FLECHE_UP);
	HBITMAP hBitmapup = (HBITMAP) m_bitmapup.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CN_ROT_UP))->SetBitmap(hBitmapup);

	((CButton*) GetDlgItem(IDC_CN_TRANS_UP))->SetBitmap(hBitmapup);
	
	((CButton*) GetDlgItem(IDC_CN_ROTTRANS_UP))->SetBitmap(hBitmapup);

	m_bitmapdo.LoadBitmap(IDB_FLECHE_DO);
	HBITMAP hBitmapdo = (HBITMAP) m_bitmapdo.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CN_ROT_DOWN))->SetBitmap(hBitmapdo);

	((CButton*) GetDlgItem(IDC_CN_TRANS_DOWN))->SetBitmap(hBitmapdo);

	((CButton*) GetDlgItem(IDC_CN_ROTTRANS_DOWN))->SetBitmap(hBitmapdo);

	m_bitmaple.LoadBitmap(IDB_FLECHE_LE);
	HBITMAP hBitmaple = (HBITMAP) m_bitmaple.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CN_ROT_LEFT))->SetBitmap(hBitmaple);

	((CButton*) GetDlgItem(IDC_CN_TRANS_LEFT))->SetBitmap(hBitmaple);

	((CButton*) GetDlgItem(IDC_CN_ROTTRANS_LEFT))->SetBitmap(hBitmaple);

	m_bitmapri.LoadBitmap(IDB_FLECHE_RI);
	HBITMAP hBitmapri = (HBITMAP) m_bitmapri.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CN_ROT_RIGHT))->SetBitmap(hBitmapri);

	((CButton*) GetDlgItem(IDC_CN_TRANS_RIGHT))->SetBitmap(hBitmapri);

	((CButton*) GetDlgItem(IDC_CN_ROTTRANS_RIGHT))->SetBitmap(hBitmapri);

	m_bitmaprg.LoadBitmap(IDB_FLECHE_RG);
	HBITMAP hBitmaprg = (HBITMAP) m_bitmaprg.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CN_ROT_RG))->SetBitmap(hBitmaprg);

	((CButton*) GetDlgItem(IDC_CN_ROTTRANS_RG))->SetBitmap(hBitmaprg);

	m_bitmaprd.LoadBitmap(IDB_FLECHE_RD);
	HBITMAP hBitmaprd = (HBITMAP) m_bitmaprd.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CN_ROT_RD))->SetBitmap(hBitmaprd);
	
	((CButton*) GetDlgItem(IDC_CN_ROTTRANS_RD))->SetBitmap(hBitmaprd);
	
	m_bitmapfo.LoadBitmap(IDB_FLECHE_FO);
	HBITMAP hBitmapfo = (HBITMAP) m_bitmapfo.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CN_TRANS_FORWARD))->SetBitmap(hBitmapfo);

	m_bitmapba.LoadBitmap(IDB_FLECHE_BA);
	HBITMAP hBitmapba = (HBITMAP) m_bitmapba.GetSafeHandle();
	((CButton*) GetDlgItem(IDC_CN_TRANS_BACKWARD))->SetBitmap(hBitmapba);

	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CControlNavigatDialog::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	
	m_bitmapup.DeleteObject();
	m_bitmapdo.DeleteObject();
	m_bitmaple.DeleteObject();
	m_bitmapri.DeleteObject();
	m_bitmaprg.DeleteObject();
	m_bitmaprd.DeleteObject();
	m_bitmapfo.DeleteObject();
	m_bitmapba.DeleteObject();

	
	CDialog::OnClose();
}


