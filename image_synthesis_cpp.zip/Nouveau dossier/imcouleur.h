// imcouleur.h: interface for the imcouleur class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMCOULEUR_H__5EBBF871_725E_11D3_BDD9_0080C8FA31E1__INCLUDED_)
#define AFX_IMCOULEUR_H__5EBBF871_725E_11D3_BDD9_0080C8FA31E1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000






class imcouleur  
{
	public:
	
	int larg, haut;
	int larg_scanline;
	LPBYTE bitimage;
	BITMAPINFO *pbitmapinfo;  // Header du Bitmap DIB
	
	imcouleur(void){larg = haut = 0; bitimage = NULL; pbitmapinfo = NULL;}
	imcouleur(int hauteur, int largeur);
	~imcouleur(){
		if (haut*larg > 0){
			delete [] bitimage; 
			haut=larg=0; 
			bitimage = NULL; 
			delete pbitmapinfo;
		}
	}
	imcouleur& operator=(const imcouleur& im);
	imcouleur(imcouleur& im);
	
	int largeur(void) const {return larg;}
	int hauteur(void) const {
		return haut;
	}

	bool setdim(int l, int h);
	void setpixel(int x, int y, unsigned char r, unsigned char g, unsigned char b){
		if (x < larg && y < haut){
			int coordy = (haut - 1 - y);
			bitimage[coordy*larg_scanline+3*x] = b;
			bitimage[coordy*larg_scanline+3*x+1] = g;
			bitimage[coordy*larg_scanline+3*x+2] = r;
		}
	}

	void getpixel(int x, int y, double& r, double& g, double& b) const{
		if (x >= larg) x = larg - 1;
		if (y >= haut) y = haut - 1;
		if (x < 0) x = 0;
		if (y < 0) y = 0;
		int coordy = (haut - 1 - y);
		b = ((double)bitimage[coordy*larg_scanline+3*x])/255.0;
		g = ((double)bitimage[coordy*larg_scanline+3*x+1])/255.0;
		r = ((double)bitimage[coordy*larg_scanline+3*x+2])/255.0;
	}


	void getpixelinterpol(double x, double y, double& r, double& g, double& b) const;

	double getlevel(double x, double y) const{
		double r,g,b;
		getpixelinterpol(x,y,r,g,b);
		return 0.299*r + 0.587*g + 0.114*b;
	}

	void getderivative(double x, double y, double& dsds, double & dsdt, bool cyliquex, bool cycliquey) const;

	char ecritbmp(char *fich);
	void EpilogueBmp(FILE* df);
	void DonneesBmp(FILE* df);
	void CouleursBmp(FILE* df);
	void EnteteBmp(FILE * fp,int nrow,int ncol, int nbbits);

	bool load_bmp(char *fich);
	bool LitEnteteBmp(FILE * fp);
	void imcouleur::LitDonneesBmp(FILE* df);



};

#endif // !defined(AFX_IMCOULEUR_H__5EBBF871_725E_11D3_BDD9_0080C8FA31E1__INCLUDED_)
