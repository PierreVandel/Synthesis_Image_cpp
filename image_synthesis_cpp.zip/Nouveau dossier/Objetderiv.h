// Objetderiv.h: interface for the Objetderiv class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OBJETDERIV_H__3E9CE980_4992_11D3_B1CB_A89EAD92E170__INCLUDED_)
#define AFX_OBJETDERIV_H__3E9CE980_4992_11D3_B1CB_A89EAD92E170__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


#include <fstream>
#include "Objet3D.h"
#include "Spline2D.h"
#include "imcouleur.h"
using namespace std;


class Cloche : public Objet3D{

	double xmin, ymin, zmin, xmax, ymax, zmax;
	int nbmerid;

public:
	Cloche(void):Objet3D(){xmin = ymin = zmin = xmax = ymax = zmax = 0; nbmerid=0;}
	Cloche(double xma, double yma, double zma, double xmi, double ymi, double zmi, int nbmer){
		xmin = xmi;
		xmax = xma;
		ymin = ymi;
		ymax = yma;
		zmin = zmi;
		zmax = zma;
		nbmerid=nbmer;
	}
	Cloche(double x1, double y1, double z1, double h1, double h2, double h3,
			int nbmer,
	   	  double rotx, double roty, double rotz,
	      double scalex, double scaley, double scalez,
		  MaterialData mat, const TextureData &text);


	Objet3D * copie(void);

	Objet3D * edite(int nbsplines2D, Spline2D** pSplines2D);

	typobjet gettype(void){return BOITE;}

	void ecritfich(ostream& fich);

	bool calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture);
	bool testintersect(const Rayon & ray_sce, double tlimit);

	Surface *GetSurface(void){return NULL;}

	double computesolidangle(Point3D p3d, double & costhetamax){return 0;}
	
};

class Polyedre : public Objet3D{


public:

	Polyedre(void):Objet3D(){}
	Polyedre(ifstream* fich, Point3D orig, 
					  double scax, double scay, double scaz,
					  double rx, double ry, double rz,
					  MaterialData mat,
					  TextureData& text);

	Objet3D * copie(void);

	Objet3D * edite(int nbsplines2D, Spline2D** pSplines2D);

	void ecritfich(ostream& fich);

	bool calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture);
//	bool testintersect(const Rayon & ray_sce, double tlimit);

	typobjet gettype(void){return POLYEDRE;}

	Surface *GetSurface(void){return NULL;}

	double computesolidangle(Point3D p3d, double & costhetamax){return 0;}
};


class Sphere : public Objet3D{

	double rayon;
	int nbmeridien, nbparallele;

public:
	Sphere(void):Objet3D(){rayon = 0; nbparallele = nbmeridien = 0;}
	Sphere(double r, int m, int p):Objet3D(){rayon=r; nbparallele=p; nbmeridien=m;}
	Sphere(double xc, double yc, double zc, 
			   double rotx, double roty, double rotz,
			   double scalex, double scaley, double scalez,
			   double r,
			   int nbparal, int nbmerid,
			   MaterialData mat, const TextureData &text);

	Objet3D * copie(void);

	typobjet gettype(void){return SPHERE;}

	Objet3D * edite(int nbsplines2D, Spline2D** pSplines2D);

	void ecritfich(ostream& fich);

	bool calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture);
//	bool testintersect(const Rayon & ray_sce, double tlimit);

	Surface *GetSurface(void){return NULL;}

	double computesolidangle(Point3D p3d, double & costhetamax);
};



class Cylinrevol : public Objet3D{

	double rayon, hauteur;
	int nbmeridien;

public:
	Cylinrevol(void):Objet3D(){rayon = hauteur = 0; nbmeridien = 0;}
	Cylinrevol(double r, double h, int m):Objet3D(){rayon=r; hauteur=h; nbmeridien=m;}
	Cylinrevol(double xor, double yor, double zor, 
			   double rotx, double roty, double rotz,
			   double scalex, double scaley, double scalez,
			   double r, double h,
			   int nbmerid,
			   MaterialData mat, const TextureData &text);

	Objet3D * copie(void);

	Objet3D * edite(int nbsplines2D, Spline2D** pSplines2D);

	typobjet gettype(void){return CYLINREVOL;}

	void ecritfich(ostream& fich);

	bool calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture);
//	bool testintersect(const Rayon & ray_sce, double tlimit);

	Surface *GetSurface(void){return NULL;}

	double computesolidangle(Point3D p3d, double & costhetamax){return 0;}
};




class Conerevoltronq : public Objet3D{

	double rayon, hauteur, rayontronq;
	int nbmeridien, nbparallele;

public:
	Conerevoltronq(void):Objet3D(){rayon = hauteur = 0; nbmeridien = 0;}
	Conerevoltronq(double r, double h, double rt, int m, int p):
					Objet3D(){rayon=r; hauteur=h; rayontronq = rt; nbmeridien=m; nbparallele=p;}
	Conerevoltronq(double xor, double yor, double zor, 
			   double rotx, double roty, double rotz,
			   double scalex, double scaley, double scalez,
			   double r, double hauttronq, double rt,
			   int nbmerid, int nbparal,
			   MaterialData mat, const TextureData &text);

	Objet3D * copie(void);

	Objet3D * edite(int nbsplines2D, Spline2D** pSplines2D);

	typobjet gettype(void){return CONEREVOLTRONQ;}

	void ecritfich(ostream& fich);

	bool calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture);
//	bool testintersect(const Rayon & ray_sce, double tlimit);

	Surface *GetSurface(void){return NULL;}

	double computesolidangle(Point3D p3d, double & costhetamax){return 0;}
};



class Cylinspline : public Objet3D{

	double hauteur;
	int echantillonage;
	int nbparal;
	Spline2D * spline2d;
	double topreduction;

public:
	Cylinspline(void):Objet3D(){hauteur = 0; echantillonage=0;}
	Cylinspline(double h, double topr, int ech, int nbp, Spline2D * sp):Objet3D(){hauteur=h; topreduction=topr; echantillonage = ech; nbparal=nbp; spline2d = sp;}
	Cylinspline(double xor, double yor, double zor, 
			   double rotx, double roty, double rotz,
			   double scalex, double scaley, double scalez,
			   Spline2D * sp, double h,
			   double factor_reduc,
			   int ech,  // nombre de points calcules pour chaque partie de la spline 2D
			   int nbparallele,
			   MaterialData mat, const TextureData &text);

	Objet3D * copie(void);

	Objet3D * edite(int nbsplines2D, Spline2D** pSplines2D);

	typobjet gettype(void){return CYLINSPLINE;}

	void ecritfich(ostream& fich);

	bool calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture);
//	bool testintersect(const Rayon & ray_sce, double tlimit);

	Surface *GetSurface(void){return NULL;}

	double computesolidangle(Point3D p3d, double & costhetamax){return 0;}
};



class Spline3Drevol : public Objet3D{

	int echantillonage;
	int nbmeridiens;
	Spline2D * spline2d;

public:
	Spline3Drevol(void):Objet3D(){echantillonage=0; nbmeridiens=0;}
	Spline3Drevol(int ech, int nbm, Spline2D * sp):Objet3D(){echantillonage = ech; nbmeridiens=nbm; spline2d=sp;}
	Spline3Drevol(double xor, double yor, double zor, 
			   double rotx, double roty, double rotz,
			   double scalex, double scaley, double scalez,
			   Spline2D * sp, 
			   int nbmerid, int ech,
			   MaterialData mat, const TextureData &text);

	Objet3D * copie(void);

	Objet3D * edite(int nbsplines2D, Spline2D** pSplines2D);

	typobjet gettype(void){return SPLINE3DREVOL;}

	void ecritfich(ostream& fich);

	bool calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture);
//	bool testintersect(const Rayon & ray_sce, double tlimit);

	Surface *GetSurface(void){return NULL;}

	double computesolidangle(Point3D p3d, double & costhetamax){return 0;}
};





class Spline3Dextru : public Objet3D{

	int echantforme;
	int echantame;
	Spline2D * spline2dforme;
	Spline2D * spline2dame;
	double scalea;

	bool chanfrein;
	double propchanf_ba;
	double propchanf_bf;
	double propchanf_ea;
	double propchanf_ef;

public:
	Spline3Dextru(void):Objet3D(){echantforme=echantame=0;chanfrein=false;}
	Spline3Dextru(int echf, int echa, Spline2D * spf, Spline2D * spa, double sca_a, bool chan, double pc_ba, double pc_bf, double pc_ea, double pc_ef)
		:Objet3D(){echantforme = echf; echantame = echa; 
					spline2dforme=spf; spline2dame=spa;
					scalea=sca_a;
					chanfrein=chan;
					propchanf_ba = pc_ba; propchanf_bf = pc_bf; propchanf_ea = pc_ea; propchanf_ef=pc_ef;}
	Spline3Dextru(double xor, double yor, double zor, 
			   double rotx, double roty, double rotz,
			   double scalex, double scaley, double scalez,
			   Spline2D * spf, Spline2D * spa, double sca_a,
			   int echf, int echa,
			   bool chan, double pc_ba, double pc_bf, double pc_ea, double pc_ef,
			   MaterialData mat, const TextureData &text);

	Objet3D * copie(void);

	Objet3D * edite(int nbsplines2D, Spline2D** pSplines2D);

	typobjet gettype(void){return SPLINE3DEXTRU;}

	void ecritfich(ostream& fich);

	bool calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture);
//	bool testintersect(const Rayon & ray_sce, double tlimit);

	Surface *GetSurface(void){return NULL;}

	double computesolidangle(Point3D p3d, double & costhetamax){return 0;}
};





class Spline3DEditable : public Objet3D{

	friend class Scene3D;
	Surface *surface;

	int nbmeridiens, nbparalleles;
public:
	Spline3DEditable(void):Objet3D(){surface = NULL;;}
	Spline3DEditable(int nbm, int nbp, Surface *surf):Objet3D(){nbmeridiens=nbm;nbparalleles=nbp;surface=surf->copie();}
	~Spline3DEditable(){delete surface;}

	// constructeur de surface de revolution deformable
	Spline3DEditable(double xor, double yor, double zor, 
			   double rotx, double roty, double rotz,
			   double scalex, double scaley, double scalez,
			   Spline2D * sp, 
			   int nbmerid, int ech, int nbctrlcercle,  
			   MaterialData mat, const TextureData &text);

	// constructeur de surface spherique extrusion
	Spline3DEditable(double xor, double yor, double zor, 
						   double rotx, double roty, double rotz,
						   double scalex, double scaley, double scalez,
						   Spline2D * spf, Spline2D * spa, double sca_a,
						   int echf, int echa,
						   double pc_ba, double pc_ea,
						   MaterialData mat,  const TextureData &text);


	// reconstruction a partir d'une surface spline
	Spline3DEditable(double xor, double yor, double zor, 
							double rotx, double roty, double rotz,
							double scalex, double scaley, double scalez,
							int nbmerid, int nbparal, Surface *surf,
							MaterialData mat, const TextureData &text);

	// constructeur de cylindre deformable cone de r�volution
	Spline3DEditable::Spline3DEditable(double xor, double yor, double zor, 
							double rotx, double roty, double rotz,
							double scalex, double scaley, double scalez,
						    double r, double hauttronq, double rt,
						    int nbmerid, int nbparal, int nbdisk, int nbctrlcercle, int nbctrlhaut, int nbctrldisk,
							MaterialData mat,const TextureData &text);

	// constructeur de cylindre deformable extrusion
	Spline3DEditable::Spline3DEditable(double xor, double yor, double zor, 
						   double rotx, double roty, double rotz,
						   double scalex, double scaley, double scalez,
						   Spline2D * spf, Spline2D * spa, double sca_a,
						   int echf, int echa,
						   bool chan, double pc_ba, double pc_bf, double pc_ea, double pc_ef,
						   MaterialData mat,const TextureData &text);

	// construction de tore d�formable extrusion
	Spline3DEditable::Spline3DEditable(double xor, double yor, double zor, 
						   double rotx, double roty, double rotz,
						   double scalex, double scaley, double scalez,
						   Spline2D * spf, Spline2D * spa, double sca_a,
						   int echf, int echa,
						   MaterialData mat,  const TextureData &text);

	void construction_spherical(double xor, double yor, double zor, 
							double rotx, double roty, double rotz,
							double scalex, double scaley, double scalez,
							int nbmerid, int nbparal, Surface *surf,
							MaterialData mat,const TextureData &text);
	void construction_cylindrical(double xor, double yor, double zor, 
							double rotx, double roty, double rotz,
							double scalex, double scaley, double scalez,
							int nbmerid, int nbparal, Surface *surf,
							MaterialData mat,const TextureData &text);
	void construction_torical(double xor, double yor, double zor, 
							double rotx, double roty, double rotz,
							double scalex, double scaley, double scalez,
							int nbmerid, int nbparal, Surface *surf,
							MaterialData mat,const TextureData &text);
	Objet3D * copie(void);

	Objet3D * edite(int nbsplines2D, Spline2D** pSplines2D);

	typobjet gettype(void){return SPLINE3DEDITABLE;}

	void ecritfich(ostream& fich);

	bool calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture);
//	bool testintersect(const Rayon & ray_sce, double tlimit);

	Surface *GetSurface(void){return surface;}
	Surface *&ManipluleSurface(void){return surface;}

	double computesolidangle(Point3D p3d, double & costhetamax){return 0;}
};







#endif // !defined(AFX_OBJETDERIV_H__3E9CE980_4992_11D3_B1CB_A89EAD92E170__INCLUDED_)
