// BSPtree.cpp: implementation of the BSPtree class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "math.h"
#include "Synth.h"
#include "BSPtree.h"
#include "Scene3DRay.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

bool objetsimple(typobjet typ){
	return (typ == BOITE || typ == SPHERE || typ == CYLINREVOL || typ == CONEREVOLTRONQ);
}

BSPtree::BSPtree()
{

}

BSPtree::~BSPtree()
{

}

BSPtree::BSPtree(Boiteenglobante &box){

	if (box.xmax - box.xmin >= box.ymax - box.ymin &&
		box.xmax - box.xmin >= box.zmax - box.zmin){
		box.ymax = box.ymin + (box.xmax - box.xmin);
		box.zmax = box.zmin + (box.xmax - box.xmin);
	}else{
		if (box.ymax - box.ymin >= box.xmax - box.xmin &&
			box.ymax - box.ymin >= box.zmax - box.zmin){
			box.xmax = box.xmin + (box.ymax - box.ymin);
			box.zmax = box.zmin + (box.ymax - box.ymin);
		}else{
			box.xmax = box.xmin + (box.zmax - box.zmin);
			box.ymax = box.ymin + (box.zmax - box.zmin);
		}
	}
	T=new BSPRegularNode(box);
}


void Scene3DRay::precomputeboundingboxes(void){

	globalboundingbox.xmin = INFINI;
	globalboundingbox.ymin = INFINI;
	globalboundingbox.zmin = INFINI;
	globalboundingbox.xmax = -INFINI;
	globalboundingbox.ymax = -INFINI;
	globalboundingbox.zmax = -INFINI;

	Celluleobj *p;
	int countobj=0;
	for (p = objets.L ; p != NULL ; p = p->suiv)
		countobj++;
	countobj-=3;
	int count;
	for (p = objets.L, count=0 ; p != NULL && count < countobj; p = p->suiv, count++){
		p->pobjet->boundingbox.xmin = INFINI;
		p->pobjet->boundingbox.ymin = INFINI;
		p->pobjet->boundingbox.zmin = INFINI;
		p->pobjet->boundingbox.xmax = -INFINI;
		p->pobjet->boundingbox.ymax = -INFINI;
		p->pobjet->boundingbox.ymax = -INFINI;
		for (int i = 0 ; i < p->pobjet->nbfaces ; i++){
			double xmini, xmaxi, ymini, ymaxi, zmini, zmaxi;
			xmini = ymini = zmini = INFINI;
			xmaxi = ymaxi = zmaxi = -INFINI;
			for (int j = 0 ; j < p->pobjet->faces[i].nbsomm ; j++){
				if (xmini > p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.x)
					xmini = p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.x;
				if (xmaxi < p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.x)
					xmaxi = p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.x;
				if (ymini > p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.y)
					ymini = p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.y;
				if (ymaxi < p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.y)
					ymaxi = p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.y;
				if (zmini > p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.z)
					zmini = p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.z;
				if (zmaxi < p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.z)
					zmaxi = p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.z;
			}
			xmini -= 1e-5;
			xmaxi += 1e-5;
			ymini -= 1e-5;
			ymaxi += 1e-5;
			zmini -= 1e-5;
			zmaxi += 1e-5;
			p->pobjet->faces[i].boundingbox = Boiteenglobante(xmini, xmaxi, ymini, ymaxi, zmini, zmaxi);
			if (p->pobjet->boundingbox.xmin > xmini)
				p->pobjet->boundingbox.xmin = xmini;
			if (p->pobjet->boundingbox.xmax < xmaxi)
				p->pobjet->boundingbox.xmax = xmaxi;
			if (p->pobjet->boundingbox.ymin > ymini)
				p->pobjet->boundingbox.ymin = ymini;
			if (p->pobjet->boundingbox.ymax < ymaxi)
				p->pobjet->boundingbox.ymax = ymaxi;
			if (p->pobjet->boundingbox.zmin > zmini)
				p->pobjet->boundingbox.zmin = zmini;
			if (p->pobjet->boundingbox.zmax < zmaxi)
				p->pobjet->boundingbox.zmax = zmaxi;

			if (globalboundingbox.xmin > xmini)
				globalboundingbox.xmin = xmini;
			if (globalboundingbox.xmax < xmaxi)
				globalboundingbox.xmax = xmaxi;
			if (globalboundingbox.ymin > ymini)
				globalboundingbox.ymin = ymini;
			if (globalboundingbox.ymax < ymaxi)
				globalboundingbox.ymax = ymaxi;
			if (globalboundingbox.zmin > zmini)
				globalboundingbox.zmin = zmini;
			if (globalboundingbox.zmax < zmaxi)
				globalboundingbox.zmax = zmaxi;

				
		}
	}

}



void Scene3DRay::constructBSPtree(bool gouraud){

	precomputeboundingboxes();

	bsptree = new BSPtree(globalboundingbox);

	bsptree->totalnbfaces=0;
	bsptree->nbsimpleobjects=0;
	Celluleobj *p;
	int countobj=0;
	for (p = objets.L ; p != NULL ; p = p->suiv)
		countobj++;
	countobj-=3;
	int count;
	for (p = objets.L, count=0 ; p != NULL && count < countobj; p = p->suiv, count++){
		if (objetsimple(p->pobjet->gettype()) && (!gouraud || !getenableradiosite())){
			bsptree->totalnbfaces += 1;
			bsptree->nbsimpleobjects++;
		}else
			bsptree->totalnbfaces += p->pobjet->nbfaces;
	}

	bsptree->allthefaces = new ObjectToIntersect*[bsptree->totalnbfaces];
	int counter=0;
	for (p = objets.L, count=0 ; p != NULL && count < countobj; p = p->suiv, count++){
		if (objetsimple(p->pobjet->gettype()) && (!gouraud || !getenableradiosite())){
			bsptree->allthefaces[counter] = new ObjectToIntersect;
			bsptree->allthefaces[counter]->object = p->pobjet;			
			bsptree->allthefaces[counter++]->simpleobject = true;
		}
	}

	for (p = objets.L, count=0 ; p != NULL && count < countobj; p = p->suiv, count++){
		if (!objetsimple(p->pobjet->gettype()) || (gouraud && getenableradiosite())){
			for (int i = 0 ; i < p->pobjet->nbfaces ; i++){
				bsptree->allthefaces[counter] = new ObjectToIntersect;
				bsptree->allthefaces[counter]->object = p->pobjet;
				bsptree->allthefaces[counter]->simpleobject=false;
				bsptree->allthefaces[counter++]->face = &p->pobjet->faces[i];
			}
		}
	}

	// a enlever :
//	bsptree->T = new BSPObjectLeave(globalboundingbox, bsptree->allthefaces, bsptree->totalnbfaces);

	double rapport=rapportthreshold*(globalboundingbox.xmax-globalboundingbox.xmin)*(globalboundingbox.xmax-globalboundingbox.xmin);
	bsptree->construction(minsizecell, maxdepth, nbfacesmax, rapport);

}



void BSPtree::construction(double minsizecell, int maxdepth, int nbfacesmax, double rapport){
	T->recursiveconstruction(minsizecell, maxdepth, nbfacesmax, rapport, allthefaces, totalnbfaces, 1);
}

void BSPRegularNode::recursiveconstruction(double minsizecell, int maxdepth, int nbfacesmax, double rapport,
										   ObjectToIntersect **allthefaces, int totalnbfaces,
										   int depth){
	ObjectToIntersect **faceschild = new ObjectToIntersect*[totalnbfaces];
	int nbfaceschild;

	for (int i = 0 ; i < 2 ; i++)
		for (int j = 0 ; j < 2 ; j++)
			for (int k = 0 ; k < 2 ; k++){
				nbfaceschild=0;
				double xmin = (1.0-i/2.0)*boundingbox.xmin+i/2.0*boundingbox.xmax;
				double xmax = xmin + (boundingbox.xmax-boundingbox.xmin)/2.0;
				double ymin = (1.0-j/2.0)*boundingbox.ymin+j/2.0*boundingbox.ymax;
				double ymax = ymin + (boundingbox.ymax-boundingbox.ymin)/2.0;
				double zmin = (1.0-k/2.0)*boundingbox.zmin+k/2.0*boundingbox.zmax;
				double zmax = zmin + (boundingbox.zmax-boundingbox.zmin)/2.0;

//				xmin -= 1e-5;
//				xmax += 1e-5;
//				ymin -= 1e-5;
//				ymax += 1e-5;
//				zmin -= 1e-5;
//				zmax += 1e-5;

				Boiteenglobante box(xmin, xmax, ymin, ymax, zmin, zmax);
				
				for (int noface=0; noface < totalnbfaces ; noface++){
					if ((allthefaces[noface]->simpleobject) && box.testintersect2boites(allthefaces[noface]->object->boundingbox)){
						faceschild[nbfaceschild] = allthefaces[noface];
						nbfaceschild++;
					}
					if ((!allthefaces[noface]->simpleobject)  && box.testintersect2boites(allthefaces[noface]->face->boundingbox)){
						faceschild[nbfaceschild] = allthefaces[noface];
						nbfaceschild++;
					}
				}

				if (nbfaceschild > nbfacesmax &&
					nbfaceschild*(box.xmax-box.xmin)*(box.xmax-box.xmin) > rapport && 
					box.xmax-box.xmin >= minsizecell &&
					depth < maxdepth){
						child[i][j][k] = new BSPRegularNode(box);
						child[i][j][k]->recursiveconstruction(minsizecell, maxdepth, nbfacesmax, rapport,
																faceschild, nbfaceschild,
																depth+1);
				}else{
					if (nbfaceschild > 0){
						child[i][j][k] = new BSPObjectLeave(box, faceschild, nbfaceschild);
					}
				}
			}
			

	delete [] faceschild;

}




void Scene3DRay::destroyBSP(void){

	if (bsptree != NULL)
		bsptree->T->destroy();
		if (bsptree->totalnbfaces != 0)
			delete [] bsptree->allthefaces;
}





bool Scene3DRay::calculintersectprocheBSP(
						Rayon ray,
						int &numobjetproche,  // numero de l'objet intersect�
						ResultIntersect &resplusproche,  // resultat de l'intersection
						double &min_t_inter, // distance de l'objet le plus proche � l'observateur
						Objet3D * &objetintersecte,
						bool testshadow, double& attenuation, double distance,
						bool gouraud){

	for (int i = 0 ; i < bsptree->nbsimpleobjects ; i++)
		bsptree->allthefaces[i]->alreadytested=false;

	ray.initx = ray.vectdirect.x >= 0 ? 0:1;
	ray.inity = ray.vectdirect.y >= 0 ? 0:1;
	ray.initz = ray.vectdirect.z >= 0 ? 0:1;
	ray.stepx = ray.vectdirect.x >= 0 ? 1:-1;
	ray.stepy = ray.vectdirect.y >= 0 ? 1:-1;
	ray.stepz = ray.vectdirect.z >= 0 ? 1:-1;
	ray.endx = 1 - ray.initx + ray.stepx;
	ray.endy = 1 - ray.inity + ray.stepy;
	ray.endz = 1 - ray.initz + ray.stepz;

	
	bool intersect = bsptree->T->calculintersectprocheBSP(ray, resplusproche, min_t_inter, objetintersecte,
															testshadow, attenuation, distance, gouraud, this);
	
	if (intersect && !testshadow){
//		if (!objetintersecte->texturestexture){
//			resplusproche.couleur = objetintersecte->material.couleur;
//		}
		resplusproche.t_inter = min_t_inter;

		numobjetproche = objetintersecte->numero;
	}

	return intersect;
}



bool BSPRegularNode::calculintersectprocheBSP(
						Rayon ray,
						ResultIntersect &resplusproche,  // resultat de l'intersection
						double &min_t_inter, // distance de l'objet le plus proche � l'observateur
						Objet3D * &objetintersecte,
						bool testshadow, double& attenuation, double distance,
						bool gouraud, Scene3DRay * scene){

	if (!boundingbox.testintersect(ray))
		return false;
//	bool intersect = false;
	for (int i = ray.initx ; i != ray.endx ; i+=ray.stepx)
		for (int j = ray.inity ; j != ray.endy ; j+=ray.stepy)
			for (int k = ray.initz ; k != ray.endz ; k+=ray.stepz){
				if (child[i][j][k] != NULL){
					if (child[i][j][k]->calculintersectprocheBSP(ray, resplusproche, min_t_inter, objetintersecte,
															testshadow, attenuation, distance,
															gouraud, scene)){
//						intersect=true;
//						if (testshadow) return true;
						return true;
					}
				}
			}
	return false;
}



bool BSPObjectLeave::calculintersectprocheBSP(
						Rayon ray,
						ResultIntersect &resplusproche,  // resultat de l'intersection
						double &min_t_inter, // distance de l'objet le plus proche � l'observateur
						Objet3D * &objetintersecte,
						bool testshadow, double& attenuation, double distance,
						bool gouraud, Scene3DRay * scene){
	
	if (!boundingbox.testintersect(ray))
		return false;

	bool intersect=false;

	for (int i = 0 ; i < nbfaces ; i++){
		if (listfaces[i]->simpleobject && listfaces[i]->alreadytested){
			if (!listfaces[i]->intersect)
				continue;
			if (listfaces[i]->t < min_t_inter && !testshadow && boundingbox.appartient(listfaces[i]->p3d)){
				resplusproche.t_inter = min_t_inter = listfaces[i]->t;
				resplusproche.normale = listfaces[i]->normale;
				resplusproche.couleur = listfaces[i]->couleur;
				if (gouraud)
					resplusproche.intens = listfaces[i]->intens;
				objetintersecte = listfaces[i]->object;
				intersect = true;
			}
//			if (testshadow){
				// objet partiellement transparent :
//				attenuation *= listfaces[i]->object->attenuation();
//				if (attenuation==0)
//					return true;
//			}
		}else{
				if (listfaces[i]->calculintersectprocheBSP(ray, resplusproche, min_t_inter, objetintersecte,
															testshadow, attenuation, distance,
															gouraud, scene,
															boundingbox)){
						intersect = true;
						if (testshadow) return true;
				}
		}
	}
	return intersect;
}



bool ObjectToIntersect::calculintersectprocheBSP(
						Rayon ray,
						ResultIntersect &resplusproche,  // resultat de l'intersection
						double &min_t_inter, // distance de l'objet le plus proche � l'observateur
						Objet3D * &objetintersecte,
						bool testshadow, double& attenuation, double distance,
						bool gouraud, Scene3DRay * scene,
						Boiteenglobante box){

	ResultIntersect resinter;
		
	alreadytested=true;

	if (simpleobject){
		if (!object->boundingbox.testintersect(ray)){

			intersect=false;
			return false;
		}else{
			if (object->calculintersect(ray, resinter,  
					testshadow, attenuation, distance,
					object->material.phongenable,
					scene->renduenabletexture)){
				intersect=true;
				if (testshadow)
					return true;
				t = resinter.t_inter;
				p3d = ray.origine + t*ray.vectdirect;
				normale=resinter.normale;
				couleur = resinter.couleur;
			}else{
				intersect=false;
				return false;
			}
		}
	}
		
	if (!simpleobject){
		if (!face->boundingbox.testintersect(ray)){
			alreadytested=true;
			intersect=false;
			return false;
		}

		Point3D tabsommetsprojetes[10000];

		double lambda;

		double axpbypcz = face->normale.x*ray.vectdirect.x + 
						  face->normale.y*ray.vectdirect.y + 
						  face->normale.z*ray.vectdirect.z;
		double aoxpboypcoz = face->normale.x*ray.origine.x + 
						  face->normale.y*ray.origine.y + 
						  face->normale.z*ray.origine.z;
		lambda = (-face->D - aoxpboypcoz) / axpbypcz;
		if (lambda < EPSILON){
			alreadytested=true;
			intersect=false;
			return false;
		}

		// intersection avec le polygone 2d :

		p3d = ray.origine + lambda*ray.vectdirect;


		double absx = face->normale.x>=0 ? face->normale.x : -face->normale.x;
		double absy = face->normale.y>=0 ? face->normale.y : -face->normale.y;
		double absz = face->normale.z>=0 ? face->normale.z : -face->normale.z;
		if (absz > 0.57){
			for (int j = 0 ; j < face->nbsomm ; j++){
				tabsommetsprojetes[j] = object->tabsomm[face->tabnosomm[j]].pos;
				tabsommetsprojetes[j].z=0;
				tabsommetsprojetes[j].x -= p3d.x;
				tabsommetsprojetes[j].y -= p3d.y;
			}
		}else{

			if (absy >= 0.57){
				for (int j = 0 ; j < face->nbsomm ; j++){
					tabsommetsprojetes[j].x = object->tabsomm[face->tabnosomm[j]].pos.x;
					tabsommetsprojetes[j].y = object->tabsomm[face->tabnosomm[j]].pos.z;
					tabsommetsprojetes[j].z=0;
					tabsommetsprojetes[j].x -= p3d.x;
					tabsommetsprojetes[j].y -= p3d.z;
				}
			}else{
				for (int j = 0 ; j < face->nbsomm ; j++){
					tabsommetsprojetes[j].x = object->tabsomm[face->tabnosomm[j]].pos.y;
					tabsommetsprojetes[j].y = object->tabsomm[face->tabnosomm[j]].pos.z;
					tabsommetsprojetes[j].z=0;
					tabsommetsprojetes[j].x -= p3d.y;
					tabsommetsprojetes[j].y -= p3d.z;
				}
			}
		}

	//	alreadytested = true;
		intersect = false;
		for (int j = 0 ; j < face->nbsomm ; j++){
			double x1 = tabsommetsprojetes[j].x;
			double y1 = tabsommetsprojetes[j].y;
			double x2 = (j == face->nbsomm - 1) ? tabsommetsprojetes[0].x : tabsommetsprojetes[j+1].x;
			double y2 = (j == face->nbsomm - 1) ? tabsommetsprojetes[0].y : tabsommetsprojetes[j+1].y;
		
			if ((y1 >= 0 && y2 >= 0) || (y1 <= 0 && y2 <= 0))
				continue;
			double xinter = (x1*y2 - x2*y1)/(y2 - y1);
			if (xinter > 0)
				intersect = !intersect;
		}
		t = lambda;

		if (intersect && !testshadow){
			couleur = object->material.couleur;
			normale = face->normale;

			Sommet somm;
			if (object->textures.withtexture[face->notexture] || 
				gouraud || object->material.phongenable || 
				object->textures.withbumpmap[face->notexture]){
				if (face->nbsomm == 3){
					somm = object->interpolesommettriang(*face, p3d);
				}else   
					if (face->nbsomm == 4){
						somm = object->interpolesommetcarre(*face, p3d);
					}
			}

			

			normale = (object->material.phongenable || gouraud) ? somm.normale : normale;


			if (object->textures.withbumpmap[face->notexture] && face->nbsomm <=4){
				double dbumpSds, dbumpSdt;
				double coordX = somm.coordtextureX*object->textures.imbumpmap[face->notexture].largeur();
				double coordY = somm.coordtextureY*object->textures.imbumpmap[face->notexture].hauteur();
				object->textures.imbumpmap[face->notexture].getderivative((int)coordX, (int)coordY, dbumpSds, dbumpSdt, false, false);
				normale = somm.dpsds^somm.dpsdt;
				normale = normale + object->textures.factorbump/normale.norme()*(dbumpSdt*(normale^somm.dpsds) - dbumpSds*(normale^somm.dpsdt));
				normale.normer();
			}

			if (!object->textures.withtexture[face->notexture] || face->nbsomm > 4){
				couleur = object->material.couleur;
			}else{
				double coordtextX = somm.coordtextureX*object->textures.imtexture[face->notexture].largeur();
				double coordtextY = somm.coordtextureY*object->textures.imtexture[face->notexture].hauteur();
				object->textures.imtexture[face->notexture].getpixelinterpol(coordtextX, coordtextY, couleur.R, couleur.G, couleur.B);
			}
			
			if (gouraud){
				if (face->nbsomm <= 4){
					intens = somm.intens;
				}else{
					intens.rdR = 0;
					intens.rdG = 0;
					intens.rdB = 0;
					scene->calcultermedifus(p3d, intens.rdR, intens.rdG, intens.rdB, *object);
					intens.rdR /= object->material.couleur.R;
					intens.rdG /= object->material.couleur.G;
					intens.rdB /= object->material.couleur.B;	
					intens.rsR = 0;
					intens.rsG = 0;
					intens.rsB = 0;
				}
			}
		}
		if (intersect && testshadow && lambda < distance  && box.appartient(p3d)){
			attenuation *= object->attenuation();
			if (attenuation == 0)
				return true;
		}
	}
		


	if (intersect && !testshadow && t < min_t_inter && box.appartient(p3d)){
			min_t_inter = t;
			resplusproche.normale=normale;
			resplusproche.couleur = couleur;
			resplusproche.intens = intens;
			resplusproche.t_inter = t;
			objetintersecte = object;
			return true;
	}

	return false;
}

