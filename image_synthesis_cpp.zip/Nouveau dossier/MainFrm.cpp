// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Synth.h"

#include "MainFrm.h"

#include "SynthDoc.h"
#include "SynthView.h"
#include "Spline2DView.h"
#include "Spline3DView.h"
#include "Objetderiv.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame



IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	ON_MESSAGE(WM_DETRUIRE_VUESP3D, OnDetruireVueSp3D)
	ON_MESSAGE(WM_SET_CHILD_VUESP3D, OnSetChildVueSp3DNull)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_AFFICHAGE_SPLINE2DVIEW, OnAffichageSpline2dview)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE_SPLINE2DVIEW, OnUpdateAffichageSpline2dview)
	ON_COMMAND(ID_EDITE_FORME_OBJETSPLINE, OnEditeFormeObjetspline)
	ON_UPDATE_COMMAND_UI(ID_EDITE_FORME_OBJETSPLINE, OnUpdateEditeFormeObjetspline)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	icone_sp2d = AfxGetApp()->LoadIcon(IDI_ICON_SP2D);
	icone_sp3d = AfxGetApp()->LoadIcon(IDI_ICON_SP3D);
	icone_sphere = AfxGetApp()->LoadIcon(IDI_ICON_SPHERE);

	pchildvuesp3D=NULL;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	SetTitle(CString("French 3D"));
	SetIcon(icone_sphere, false);
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	if (!CMDIFrameWnd::PreCreateWindow(cs))
		return FALSE;


	CRect rect;
	GetDesktopWindow()->GetWindowRect(rect);
	cs.cx = rect.Width();
	cs.cy = rect.Width()/2+50;
	cs.x = rect.left;
	cs.y = rect.top + 100;

	

	return TRUE;

// return CMDIFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers




/////////////////////////////////////////////////////////////////////////////
// evenement de creation d'une nouvelle vue Spline2D :


void CMainFrame::OnAffichageSpline2dview() 
{
	// TODO: Add your command handler code here
//	SwitchToView(SPLINE2D);

	CMDIChildWnd*pActiveChild = MDIGetActive();

	CDocument * pDocument;

	if (pActiveChild == NULL ||
		(pDocument = pActiveChild->GetActiveDocument()) == NULL){
		AfxMessageBox(CString("Impossible de cr�er la nouvelle fen�tre"));
		return;
	}

	// sinon, creation de la nouvelle fenetre

	CDocTemplate * pTemplate = ((CSynthApp*) AfxGetApp())->m_pTemplateSpline2D;
	ASSERT_VALID(pTemplate);
	CFrameWnd *pFrame = pTemplate->CreateNewFrame(pDocument, pActiveChild);

	if (pFrame == NULL){
		AfxMessageBox(CString("Impossible de cr�er la nouvelle fen�tre"));
		return;
	}

	pFrame->SetIcon(icone_sp2d, false);
	pTemplate->InitialUpdateFrame(pFrame, pDocument);
}

void CMainFrame::OnUpdateAffichageSpline2dview(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here

//	pCmdUI->SetCheck(GetActiveDocument()->GetActiveView()->IsKindOf(RUNTIME_CLASS(Spline2DView)));
//	pCmdUI->Enable(!GetActiveDocument()->GetActiveView()->IsKindOf(RUNTIME_CLASS(Spline2DView)));
	pCmdUI->Enable(true);

}


void CMainFrame::OnEditeFormeObjetspline() 
{
	// TODO: Add your command handler code here
	
//	SwitchToView(SPLINE3D);

	CMDIChildWnd*pActiveChild = MDIGetActive();

	CDocument * pDocument;

	if (pActiveChild == NULL ||
		(pDocument = pActiveChild->GetActiveDocument()) == NULL){
		AfxMessageBox(CString("Impossible de cr�er la nouvelle fen�tre"));
		return;
	}

	CSynthDoc * pdoc = (CSynthDoc*) pDocument;
	 pdoc->objetedite = ((CSynthView*)(pActiveChild->GetActiveView()))->scene.getobjetselect();
	 pdoc->cam = ((CSynthView*)(pActiveChild->GetActiveView()))->scene.getcamselect();
	pdoc->fenetreSpline3DViewouverte=true;

	// sinon, creation de la nouvelle fenetre

	CDocTemplate * pTemplate = ((CSynthApp*) AfxGetApp())->m_pTemplateSpline3D;
	ASSERT_VALID(pTemplate);
	CFrameWnd *pFrame = pTemplate->CreateNewFrame(pDocument, pActiveChild);

	if (pFrame == NULL){
		AfxMessageBox(CString("Impossible de cr�er la nouvelle fen�tre"));
		return;
	}

	pFrame->SetIcon(icone_sp3d, false);
	pTemplate->InitialUpdateFrame(pFrame, pDocument);

	pchildvuesp3D = MDIGetActive();

}

void CMainFrame::OnUpdateEditeFormeObjetspline(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	


	CMDIChildWnd*pActiveChild = MDIGetActive();

	CSynthDoc *pDoc=(CSynthDoc*)pActiveChild->GetActiveView()->GetDocument();
	if (pDoc->vue_active != VUE3D){
		pCmdUI->Enable(false);	
		return;
	}

	CSynthView* pView = (CSynthView*)(pActiveChild->GetActiveView());
	if (pDoc->objetedite != NULL || pDoc->fenetreSpline3DViewouverte){
		pCmdUI->Enable(false);	
		return;
	}

	Objet3D *objetselect=pView->scene.getobjetselect();
	bool test = (objetselect != NULL && objetselect->gettype() == SPLINE3DEDITABLE);
	pCmdUI->Enable(test);
}


BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CRect rect;
	GetClientRect(rect);
	lpcs->cx = rect.Width()/2;
	lpcs->cy = rect.Height();
	lpcs->x = rect.left;
	lpcs->y = rect.top;
	return CMDIFrameWnd::OnCreateClient(lpcs, pContext);
}


LRESULT CMainFrame::OnDetruireVueSp3D(WPARAM wParam, LPARAM lParam){

	if (pchildvuesp3D!=NULL)
		pchildvuesp3D->MDIDestroy();
	pchildvuesp3D=NULL;
	return 0L;
}


LRESULT CMainFrame::OnSetChildVueSp3DNull(WPARAM wParam, LPARAM lParam){

	pchildvuesp3D = NULL;
	return 0L;
}

