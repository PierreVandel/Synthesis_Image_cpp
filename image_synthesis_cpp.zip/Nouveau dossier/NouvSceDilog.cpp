// NouvSceDilog.cpp : implementation file
//

#include "stdafx.h"
#include "Synth.h"
#include "NouvSceDilog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNouvSceDilog dialog


CNouvSceDilog::CNouvSceDilog(CWnd* pParent /*=NULL*/)
	: CDialog(CNouvSceDilog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNouvSceDilog)
	m_hautcam = 0.0f;
	m_lumambiantB = 0.0f;
	m_lumambiantG = 0.0f;
	m_lumambiantR = 0.0f;
	m_nbcam = 0;
	m_nblum = 0;
	m_xmax = 0.0f;
	m_xmin = 0.0f;
	m_ymax = 0.0f;
	m_ymin = 0.0f;
	m_zmax = 0.0f;
	m_zmin = 0.0f;
	m_fondB = 0.0;
	m_fondG = 0.0;
	m_fondR = 0.0;
	//}}AFX_DATA_INIT
}


void CNouvSceDilog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNouvSceDilog)
	DDX_Text(pDX, IDC_HAUTCAM, m_hautcam);
	DDX_Text(pDX, IDC_LUMAMB_B, m_lumambiantB);
	DDV_MinMaxFloat(pDX, m_lumambiantB, 0.f, 20.f);
	DDX_Text(pDX, IDC_LUMAMB_G, m_lumambiantG);
	DDV_MinMaxFloat(pDX, m_lumambiantG, 0.f, 20.f);
	DDX_Text(pDX, IDC_LUMAMB_R, m_lumambiantR);
	DDV_MinMaxFloat(pDX, m_lumambiantR, 0.f, 20.f);
	DDX_Text(pDX, IDC_NBCAM, m_nbcam);
	DDV_MinMaxInt(pDX, m_nbcam, 0, 500);
	DDX_Text(pDX, IDC_NBLUM, m_nblum);
	DDV_MinMaxInt(pDX, m_nblum, 0, 500);
	DDX_Text(pDX, IDC_XMAX, m_xmax);
	DDX_Text(pDX, IDC_XMIN, m_xmin);
	DDX_Text(pDX, IDC_YMAX, m_ymax);
	DDX_Text(pDX, IDC_YMIN, m_ymin);
	DDX_Text(pDX, IDC_ZMAX, m_zmax);
	DDX_Text(pDX, IDC_ZMIN, m_zmin);
	DDX_Text(pDX, IDC_FOND_B, m_fondB);
	DDV_MinMaxDouble(pDX, m_fondB, 0., 1.);
	DDX_Text(pDX, IDC_FOND_G, m_fondG);
	DDV_MinMaxDouble(pDX, m_fondG, 0., 1.);
	DDX_Text(pDX, IDC_FOND_R, m_fondR);
	DDV_MinMaxDouble(pDX, m_fondR, 0., 1.);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNouvSceDilog, CDialog)
	//{{AFX_MSG_MAP(CNouvSceDilog)
	ON_BN_CLICKED(IDC_OK, OnClickedOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNouvSceDilog message handlers

void CNouvSceDilog::OnOK() 
{
	// TODO: Add extra validation here
	
//	CDialog::OnOK();
}

void CNouvSceDilog::OnClickedOk() 
{
	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}
