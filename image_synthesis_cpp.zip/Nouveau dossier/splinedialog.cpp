// SplineDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Synth.h"
#include "SplineDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSpline2DDialog dialog


CSpline2DDialog::CSpline2DDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CSpline2DDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSpline2DDialog)
	m_nom = _T("");
	//}}AFX_DATA_INIT
}


void CSpline2DDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSpline2DDialog)
	DDX_Text(pDX, IDC_NOM_SPLINE2D, m_nom);
	DDV_MaxChars(pDX, m_nom, 20);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSpline2DDialog, CDialog)
	//{{AFX_MSG_MAP(CSpline2DDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSpline2DDialog message handlers
/////////////////////////////////////////////////////////////////////////////
// CRayonDeformDialog dialog


CRayonDeformDialog::CRayonDeformDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CRayonDeformDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRayonDeformDialog)
	m_speeddeform = 0.0;
	m_amplitudelissage = 0.0;
	m_ri = 0;
	m_rj = 0;
	m_rayondeform_i = 0.0;
	m_rayondeform_j = 0.0;
	//}}AFX_DATA_INIT
}


void CRayonDeformDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRayonDeformDialog)
	DDX_Text(pDX, IDC_SPEEDDEFORM, m_speeddeform);
	DDX_Text(pDX, IDC_AMPLITUDELISSAGES, m_amplitudelissage);
	DDV_MinMaxDouble(pDX, m_amplitudelissage, 0., 1.);
	DDX_Text(pDX, IDC_RI, m_ri);
	DDV_MinMaxInt(pDX, m_ri, 0, 100000);
	DDX_Text(pDX, IDC_RJ, m_rj);
	DDV_MinMaxInt(pDX, m_rj, 0, 100000);
	DDX_Text(pDX, IDC_RAYONDEFORM_I, m_rayondeform_i);
	DDX_Text(pDX, IDC_RAYONDEFORM_J, m_rayondeform_j);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRayonDeformDialog, CDialog)
	//{{AFX_MSG_MAP(CRayonDeformDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRayonDeformDialog message handlers
/////////////////////////////////////////////////////////////////////////////
// CDegreeElevationDialog dialog


CDegreeElevationDialog::CDegreeElevationDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CDegreeElevationDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDegreeElevationDialog)
	m_elev_i = FALSE;
	m_elev_j = FALSE;
	//}}AFX_DATA_INIT
}


void CDegreeElevationDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDegreeElevationDialog)
	DDX_Check(pDX, IDC_ELEV_I, m_elev_i);
	DDX_Check(pDX, IDC_ELEV_J, m_elev_j);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDegreeElevationDialog, CDialog)
	//{{AFX_MSG_MAP(CDegreeElevationDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDegreeElevationDialog message handlers
