#include "stdafx.h"
#include "Synth.h"
#include "Camera.h"
#include "SurfaceSpline.h"
#include "Spline2D.h"
#include <fstream>
#include "math.h"
using namespace std;

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif



Surface * SurfaceBSplineCubiqueSphere::copie(void){

	SurfaceBSplineCubiqueSphere* surf = new SurfaceBSplineCubiqueSphere(ctrlpoints, nblignes, nbcols);

	return surf;
}




void SurfaceBSplineCubiqueSphere::deplaceeffectctrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, Camera*cam){

//	ctrlpoints[i][j] = ctrlpoints[i][j]+v;

	Matrice Minv = cam->M;
	v = Minv * v;

	double rayj = rayondeform_j;
	double rayi = rayondeform_i;
	if (rayondeform_j > nbcols - 5)
		rayj = nbcols-5;
	if (rayondeform_i > nblignes - 4)
		rayi = nblignes-5;



	if ((i==0 && j==0) || (i==0 && j==nbcols-1)){
		if (j==0){
			for (int a = 0 ; a < nblignes ; a++)
				for (int b = 0 ; b < (int) rayondeform_j+4 ; b++){
					if (b < 3)
						ctrlpoints[a][b] = ctrlpoints[a][b] + v;
					else{
						double distance = b-2;
						if (distance > rayondeform_j)
							continue;
						double x = distance/rayondeform_j;
						double facteur = (x-1)*(x-1)*(x+1)*(x+1);
						ctrlpoints[a][b] = ctrlpoints[a][b] + facteur*v;
					}
				}
		}
		if (j==nbcols-1){
			for (int a = 0 ; a < nblignes ; a++)
				for (int b = nbcols-(int)rayondeform_j-4 ; b < nbcols ; b++){
					if (b >= nbcols-3)
						ctrlpoints[a][b] = ctrlpoints[a][b] + v;
					else{
						double distance = nbcols-3-b;
						if (distance > rayondeform_j)
							continue;
						double x = distance/rayondeform_j;
						double facteur = (x-1)*(x-1)*(x+1)*(x+1);
						ctrlpoints[a][b] = ctrlpoints[a][b] + facteur*v;
					}
				}
		}
		return;
	}

	for (int i0 = i-(int)rayi ; i0 <= i + (int) rayi ; i0++)
		for (int j0 = j - (int)rayj ; j0 <= j + (int)rayj ; j0++){

			double x = sqrt((i0-i)*(i0-i)/(rayondeform_i*rayondeform_i)+
							(j0-j)*(j0-j)/(rayondeform_j*rayondeform_j));
			if (x > 1)
				continue;
			double facteur = (x-1)*(x-1)*(x+1)*(x+1);
			
			int I = (i0 < 0) ? i0 + nblignes-3 : i0%(nblignes-3);
			if (j0 < 3 || j0 >= nbcols-3)
				continue;

			if (I < 3)
				ctrlpoints[I+(nblignes-3)][j0] = ctrlpoints[I+(nblignes-3)][j0] + facteur*v;
						
					ctrlpoints[I][j0] = ctrlpoints[I][j0] + facteur*v;
		}

	precalculmatrices(false);

}



void SurfaceBSplineCubiqueSphere::lisser(double amplitude){
	
	Point3D **deplacements;
	deplacements=allouerPoints3D(nblignes,nbcols);
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 3 ; j < nbcols-3 ; j++){
			deplacements[i][j] = amplitude*(0.25*(ctrlpoints[(i+1)%(nblignes-3)][j] +
				                         ctrlpoints[(i-1) < 0 ? nblignes-4 : i-1][j] +
										 ctrlpoints[i][j+1] +
										 ctrlpoints[i][j-1])
										 - ctrlpoints[i][j]);

		}

	Point3D moyenne(0,0,0);
	for (int i = 0 ; i < nblignes-3 ; i++)
		moyenne = moyenne + ctrlpoints[i][3];
	moyenne = (1/(double)(nblignes-3))*moyenne;
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < 3 ; j++){
			deplacements[i][j] = amplitude*(moyenne - ctrlpoints[i][j]);

		}

	moyenne = Point3D(0,0,0);
	for (int i = 0 ; i < nblignes-3 ; i++)
		moyenne = moyenne + ctrlpoints[i][nbcols-4];
	moyenne = (1/(double)(nblignes-3))*moyenne;
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = nbcols-3 ; j < nbcols ; j++){
			deplacements[i][j] = amplitude*(moyenne - ctrlpoints[i][j]);

		}


	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			ctrlpoints[i][j] = ctrlpoints[i][j] + deplacements[i][j];
		}

	if (deplacements!=NULL){
		for (int i = 0 ; i < nblignes ; i++)
			delete deplacements[i]; 
		delete [] deplacements;
	}

	precalculmatrices(false);
	
}



void SurfaceBSplineCubiqueSphere::lisser(double amplitude, int i0, int j0, int ri, int rj){
	
	Point3D **deplacements;
	deplacements=allouerPoints3D(nblignes,nbcols);
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 3 ; j < nbcols-3 ; j++){
			deplacements[i][j] = amplitude*(0.25*(ctrlpoints[(i+1)%(nblignes-3)][j] +
				                         ctrlpoints[(i-1) < 0 ? nblignes-4 : i-1][j] +
										 ctrlpoints[i][j+1] +
										 ctrlpoints[i][j-1])
										 - ctrlpoints[i][j]);

		}

	Point3D moyenne(0,0,0);
	for (int i = 0 ; i < nblignes-3 ; i++)
		moyenne = moyenne + ctrlpoints[i][3];
	moyenne = (1/(double)(nblignes-3))*moyenne;
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < 3 ; j++){
			deplacements[i][j] = amplitude*(moyenne - ctrlpoints[i][j]);

		}

	moyenne = Point3D(0,0,0);
	for (int i = 0 ; i < nblignes-3 ; i++)
		moyenne = moyenne + ctrlpoints[i][nbcols-4];
	moyenne = (1/(double)(nblignes-3))*moyenne;
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = nbcols-3 ; j < nbcols ; j++){
			deplacements[i][j] = amplitude*(moyenne - ctrlpoints[i][j]);

		}

	
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			int deltai = i-i0 > 0 ? i-i0 : i0-i;
			if (deltai > ri && i <= i0)
				deltai = (i+nblignes-3)-i0 > 0 ? (i+nblignes-3)-i0 : i0-(i+nblignes-3);
			if (deltai > ri && i > i0)
				deltai = (i-nblignes+3)-i0 > 0 ? (i-nblignes+3)-i0 : i0-(i-nblignes+3);
			if (j0 < 3)
				j0 = 2;
			if (j0 >= nbcols-3)
				j0 = nbcols-3;
			int deltaj = j-j0 > 0 ? j-j0 : j0-j;
			if (j < 3)
				deltaj = j0-2;
			if (j >= nbcols-3)
				deltaj = nbcols-3-j0;
			if ((deltai <= ri || j<3 || j>=nbcols-3) && deltaj <= rj)
				ctrlpoints[i][j] = ctrlpoints[i][j] + deplacements[i][j];
		}

	if (deplacements!=NULL){
		for (int i = 0 ; i < nblignes ; i++)
			delete deplacements[i]; 
		delete [] deplacements;
	}

	precalculmatrices(false);
	
}


void SurfaceBSplineCubiqueSphere::elevation(bool addlignes, bool addcols){

	int elev_i = nblignes-3;
	int elev_j = nbcols-5;

	Point3D** nouveauctrl = allouerPoints3D(nblignes+elev_i,nbcols+elev_j);




	for (int i = 0 ; i < nblignes-3 ; i++)
		for (int j = 2 ; j < nbcols-3 ; j++){
			nouveauctrl[2*i+1][2*j-1] = 0.75*(0.25*ctrlpoints[i][j] + 0.75*ctrlpoints[i+1][j]) +
										0.25*(0.25*ctrlpoints[i][j+1] + 0.75*ctrlpoints[i+1][j+1]);
			nouveauctrl[2*i+1][2*j] = 0.25*(0.25*ctrlpoints[i][j] + 0.75*ctrlpoints[i+1][j]) +
										0.75*(0.25*ctrlpoints[i][j+1] + 0.75*ctrlpoints[i+1][j+1]);
			nouveauctrl[2*i][2*j-1] = 0.75*(0.75*ctrlpoints[i][j] + 0.25*ctrlpoints[i+1][j]) +
										0.25*(0.75*ctrlpoints[i][j+1] + 0.25*ctrlpoints[i+1][j+1]);
			nouveauctrl[2*i][2*j] = 0.25*(0.75*ctrlpoints[i][j] + 0.25*ctrlpoints[i+1][j]) +
										0.75*(0.75*ctrlpoints[i][j+1] + 0.25*ctrlpoints[i+1][j+1]);
		}

	nblignes += elev_i;
	nbcols += elev_j;

	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < 3 ; j++)
			nouveauctrl[i][j] = ctrlpoints[0][0];
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = nbcols-3 ; j < nbcols ; j++)
			nouveauctrl[i][j] = ctrlpoints[0][nbcols-elev_j-1];
	for (int i = nblignes-3 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++)
			nouveauctrl[i][j] = nouveauctrl[i-(nblignes-3)][j];

	int ancnblignes = nblignes - elev_i;
	if (ctrlpoints!=NULL){
		for (int i = 0 ; i < ancnblignes ; i++)
			delete ctrlpoints[i]; 
		delete [] ctrlpoints;
	}

	liberematrice(coeffs_x, ancnblignes-3);
	liberematrice(coeffs_y, ancnblignes-3);
	liberematrice(coeffs_z, ancnblignes-3);

	ctrlpoints = nouveauctrl;

	precalculmatrices(true);
		
}






Surface * SurfaceBSplineCubiqueDisk::copie(void){

	SurfaceBSplineCubiqueDisk* surf = new SurfaceBSplineCubiqueDisk(ctrlpoints, nblignes, nbcols);

	return surf;
}




void SurfaceBSplineCubiqueDisk::deplaceeffectctrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, Camera*cam){

//	ctrlpoints[i][j] = ctrlpoints[i][j]+v;

	Matrice Minv = cam->M;
	v = Minv * v;

	double rayi = rayondeform_i;
	if (rayondeform_i > (nblignes-4)/2)
		rayi = (nblignes-3)/2;

	int modifi = 0;
	if (2*rayi+1 > nblignes-3)
		modifi = 1;


	if (j==2){
		for (int a = 0 ; a < nblignes ; a++)
			for (int b = 0 ; b < (int) rayondeform_j+4 ; b++){
				if (b < 3)
					ctrlpoints[a][b] = ctrlpoints[a][b] + v;
				else{
					double distance = b-2;
					if (distance > rayondeform_j)
						continue;
					double x = distance/rayondeform_j;
					double facteur = (x-1)*(x-1)*(x+1)*(x+1);
					ctrlpoints[a][b] = ctrlpoints[a][b] + facteur*v;
				}
			}
		return;
	}

	for (int i0 = i-(int)rayi+modifi ; i0 <= i + (int) rayi ; i0++)
		for (int j0 = j - (int)rayondeform_j ; j0 <= j + (int)rayondeform_j ; j0++){

			double x = sqrt((i0-i)*(i0-i)/(rayondeform_i*rayondeform_i)+
							(j0-j)*(j0-j)/(rayondeform_j*rayondeform_j));
			if (x > 1)
				continue;
			double facteur = (x-1)*(x-1)*(x+1)*(x+1);
			
			if (i0-i >= nblignes/2 || i0-i < -nblignes/2)
				continue;
			int I = (i0 < 0) ? i0 + nblignes-3 : i0%(nblignes-3);
			if (j0 < 3 || j0 >nbcols-3)
				continue;

			if (I < 0)
				continue;
			if (I < 3){
				ctrlpoints[I+(nblignes-3)][j0] = ctrlpoints[I+(nblignes-3)][j0] + facteur*v;
				if (j0 == nbcols-3){
					ctrlpoints[I+(nblignes-3)][j0+1] = ctrlpoints[I+(nblignes-3)][j0+1] + facteur*v;
					ctrlpoints[I+(nblignes-3)][j0+2] = ctrlpoints[I+(nblignes-3)][j0+2] + facteur*v;
			}

			}
			
			if (j0 == nbcols-3){
				ctrlpoints[I][j0+1] = ctrlpoints[I][j0+1] + facteur*v;
				ctrlpoints[I][j0+2] = ctrlpoints[I][j0+2] + facteur*v;
			}
			
			ctrlpoints[I][j0] = ctrlpoints[I][j0] + facteur*v;
		}

	precalculmatrices(false);

}



void SurfaceBSplineCubiqueDisk::lisser(double amplitude){
	
	Point3D **deplacements;
	deplacements=allouerPoints3D(nblignes,nbcols);
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 3 ; j < nbcols-3 ; j++){
			deplacements[i][j] = amplitude*(0.25*(ctrlpoints[(i+1)%(nblignes-3)][j] +
				                         ctrlpoints[(i-1) < 0 ? nblignes-4 : i-1][j] +
										 ctrlpoints[i][j+1] +
										 ctrlpoints[i][j-1])
										 - ctrlpoints[i][j]);

		}

	Point3D moyenne(0,0,0);
	for (int i = 0 ; i < nblignes-3 ; i++)
		moyenne = moyenne + ctrlpoints[i][3];
	moyenne = (1/(double)(nblignes-3))*moyenne;
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < 3 ; j++){
			deplacements[i][j] = amplitude*(moyenne - ctrlpoints[i][j]);

		}

	moyenne = Point3D(0,0,0);
	for (int i = 0 ; i < nblignes ; i++){
		moyenne = 0.5*(ctrlpoints[(i+1)%(nblignes-3)][nbcols-3]+ctrlpoints[(i-1)<0?nblignes-4:i-1][nbcols-3]);
		for (int j = nbcols-3 ; j < nbcols ; j++){
			deplacements[i][j] = amplitude*(moyenne - ctrlpoints[i][j]);

		}
	}


	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			ctrlpoints[i][j] = ctrlpoints[i][j] + deplacements[i][j];
		}

	if (deplacements!=NULL){
		for (int i = 0 ; i < nblignes ; i++)
			delete deplacements[i]; 
		delete [] deplacements;
	}

	precalculmatrices(false);
	
}



void SurfaceBSplineCubiqueDisk::lisser(double amplitude, int i0, int j0, int ri, int rj){
	
	Point3D **deplacements;
	deplacements=allouerPoints3D(nblignes,nbcols);
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 3 ; j < nbcols-3 ; j++){
			deplacements[i][j] = amplitude*(0.25*(ctrlpoints[(i+1)%(nblignes-3)][j] +
				                         ctrlpoints[(i-1) < 0 ? nblignes-4 : i-1][j] +
										 ctrlpoints[i][j+1] +
										 ctrlpoints[i][j-1])
										 - ctrlpoints[i][j]);

		}

	Point3D moyenne(0,0,0);
	for (int i = 0 ; i < nblignes-3 ; i++)
		moyenne = moyenne + ctrlpoints[i][3];
	moyenne = (1/(double)(nblignes-3))*moyenne;
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < 3 ; j++){
			deplacements[i][j] = amplitude*(moyenne - ctrlpoints[i][j]);

		}

	moyenne = Point3D(0,0,0);
	for (int i = 0 ; i < nblignes ; i++){
		moyenne = 0.5*(ctrlpoints[(i+1)%(nblignes-3)][nbcols-3]+ctrlpoints[(i-1)<0?nblignes-4:i-1][nbcols-3]);
		for (int j = nbcols-3 ; j < nbcols ; j++){
			deplacements[i][j] = amplitude*(moyenne - ctrlpoints[i][j]);

		}
	}

	
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			int deltai = i-i0 > 0 ? i-i0 : i0-i;
			if (deltai > ri && i <= i0)
				deltai = (i+nblignes-3)-i0 > 0 ? (i+nblignes-3)-i0 : i0-(i+nblignes-3);
			if (deltai > ri && i > i0)
				deltai = (i-nblignes+3)-i0 > 0 ? (i-nblignes+3)-i0 : i0-(i-nblignes+3);
			if (j0 < 3)
				j0 = 2;
			if (j0 >= nbcols-3 && j0 < nbcols)
				j0 = nbcols-3;
			int deltaj = j-j0 > 0 ? j-j0 : j0-j;
			if ((deltai <= ri || j<3) && deltaj <= rj)
				ctrlpoints[i][j] = ctrlpoints[i][j] + deplacements[i][j];
		}

	if (deplacements!=NULL){
		for (int i = 0 ; i < nblignes ; i++)
			delete deplacements[i]; 
		delete [] deplacements;
	}

	precalculmatrices(false);
	
}


void SurfaceBSplineCubiqueDisk::elevation(bool addlignes, bool addcols){

	int elev_i = nblignes-3;
	int elev_j = nbcols-2;

	Point3D** nouveauctrl = allouerPoints3D(nblignes+elev_i,nbcols+elev_j);




	for (int i = 0 ; i < nblignes-3 ; i++)
		for (int j = 2 ; j < nbcols-2 ; j++){
			nouveauctrl[2*i+1][2*j-1] = 0.75*(0.25*ctrlpoints[i][j] + 0.75*ctrlpoints[i+1][j]) +
										0.25*(0.25*ctrlpoints[i][j+1] + 0.75*ctrlpoints[i+1][j+1]);
			nouveauctrl[2*i+1][2*j] = 0.25*(0.25*ctrlpoints[i][j] + 0.75*ctrlpoints[i+1][j]) +
										0.75*(0.25*ctrlpoints[i][j+1] + 0.75*ctrlpoints[i+1][j+1]);
			nouveauctrl[2*i][2*j-1] = 0.75*(0.75*ctrlpoints[i][j] + 0.25*ctrlpoints[i+1][j]) +
										0.25*(0.75*ctrlpoints[i][j+1] + 0.25*ctrlpoints[i+1][j+1]);
			nouveauctrl[2*i][2*j] = 0.25*(0.75*ctrlpoints[i][j] + 0.25*ctrlpoints[i+1][j]) +
										0.75*(0.75*ctrlpoints[i][j+1] + 0.25*ctrlpoints[i+1][j+1]);
		}

	nblignes += elev_i;
	nbcols += elev_j;

	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < 3 ; j++)
			nouveauctrl[i][j] = ctrlpoints[0][0];
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = nbcols-2 ; j < nbcols ; j++)
			nouveauctrl[i][j] = nouveauctrl[i][nbcols-3];
	for (int i = nblignes-3 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++)
			nouveauctrl[i][j] = nouveauctrl[i-(nblignes-3)][j];

	int ancnblignes = nblignes - elev_i;
	if (ctrlpoints!=NULL){
		for (int i = 0 ; i < ancnblignes ; i++)
			delete ctrlpoints[i]; 
		delete [] ctrlpoints;
	}

	liberematrice(coeffs_x, ancnblignes-3);
	liberematrice(coeffs_y, ancnblignes-3);
	liberematrice(coeffs_z, ancnblignes-3);

	ctrlpoints = nouveauctrl;

	precalculmatrices(true);
		
}









Surface * SurfaceBSplineCubiqueCyl::copie(void){

	SurfaceBSplineCubiqueCyl* surf = new SurfaceBSplineCubiqueCyl(ctrlpoints, nblignes, nbcols);

	return surf;
}




void SurfaceBSplineCubiqueCyl::deplaceeffectctrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, Camera*cam){

//	ctrlpoints[i][j] = ctrlpoints[i][j]+v;

	Matrice Minv = cam->M;
	v = Minv * v;

//	double rayj = rayondeform_j;
	double rayi = rayondeform_i;
	if (rayondeform_i > (nblignes-4)/2)
		rayi = (nblignes-3)/2;

	int modifi = 0;
	if (2*rayi+1 > nblignes-3)
		modifi = 1;

	for (int i0 = i-(int)rayi+modifi ; i0 <= i + (int) rayi ; i0++)
		for (int j0 = j - (int)rayondeform_j ; j0 <= j + (int)rayondeform_j ; j0++){

			double x = sqrt((i0-i)*(i0-i)/(rayondeform_i*rayondeform_i)+
							(j0-j)*(j0-j)/(rayondeform_j*rayondeform_j));
			if (x > 1)
				continue;
			double facteur = (x-1)*(x-1)*(x+1)*(x+1);
			
//			if (i0-i >= nblignes/2 || i0-i < -nblignes/2)
//				continue;
			int I = (i0 < 0) ? i0 + nblignes-3 : i0%(nblignes-3);
			if (j0 < 2 || j0 >nbcols-3)
				continue;

			if (I < 0)
				continue;

			if (I < 3){
				ctrlpoints[I+(nblignes-3)][j0] = ctrlpoints[I+(nblignes-3)][j0] + facteur*v;
				if (j0 == nbcols-3){
					ctrlpoints[I+(nblignes-3)][j0+1] = ctrlpoints[I+(nblignes-3)][j0+1] + facteur*v;
					ctrlpoints[I+(nblignes-3)][j0+2] = ctrlpoints[I+(nblignes-3)][j0+2] + facteur*v;
				}
				if (j0 == 2){
					ctrlpoints[I+(nblignes-3)][j0-1] = ctrlpoints[I+(nblignes-3)][j0-1] + facteur*v;
					ctrlpoints[I+(nblignes-3)][j0-2] = ctrlpoints[I+(nblignes-3)][j0-2] + facteur*v;
				}

			}
			
			if (j0 == nbcols-3){
				ctrlpoints[I][j0+1] = ctrlpoints[I][j0+1] + facteur*v;
				ctrlpoints[I][j0+2] = ctrlpoints[I][j0+2] + facteur*v;
			}
			if (j0 == 2){
				ctrlpoints[I][j0-1] = ctrlpoints[I][j0-1] + facteur*v;
				ctrlpoints[I][j0-2] = ctrlpoints[I][j0-2] + facteur*v;
			}
			
			ctrlpoints[I][j0] = ctrlpoints[I][j0] + facteur*v;
		}

	precalculmatrices(false);

}



void SurfaceBSplineCubiqueCyl::lisser(double amplitude){
	
	Point3D **deplacements;
	deplacements=allouerPoints3D(nblignes,nbcols);
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 3 ; j < nbcols-3 ; j++){
			deplacements[i][j] = amplitude*(0.25*(ctrlpoints[(i+1)%(nblignes-3)][j] +
				                         ctrlpoints[(i-1) < 0 ? nblignes-4 : i-1][j] +
										 ctrlpoints[i][j+1] +
										 ctrlpoints[i][j-1])
										 - ctrlpoints[i][j]);

		}

	Point3D moyenne(0,0,0);
	for (int i = 0 ; i < nblignes ; i++){
		moyenne = 0.5*(ctrlpoints[(i+1)%(nblignes-3)][2]+ctrlpoints[(i-1)<0?nblignes-4:i-1][2]);
		for (int j = 0 ; j < 3 ; j++){
			deplacements[i][j] = amplitude*(moyenne - ctrlpoints[i][j]);

		}
	}

	moyenne = Point3D(0,0,0);
	for (int i = 0 ; i < nblignes ; i++){
		moyenne = 0.5*(ctrlpoints[(i+1)%(nblignes-3)][nbcols-3]+ctrlpoints[(i-1)<0?nblignes-4:i-1][nbcols-3]);
		for (int j = nbcols-3 ; j < nbcols ; j++){
			deplacements[i][j] = amplitude*(moyenne - ctrlpoints[i][j]);

		}
	}


	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			ctrlpoints[i][j] = ctrlpoints[i][j] + deplacements[i][j];
		}

	if (deplacements!=NULL){
		for (int i = 0 ; i < nblignes ; i++)
			delete deplacements[i]; 
		delete [] deplacements;
	}

	precalculmatrices(false);
	
}



void SurfaceBSplineCubiqueCyl::lisser(double amplitude, int i0, int j0, int ri, int rj){
	
	Point3D **deplacements;
	deplacements=allouerPoints3D(nblignes,nbcols);
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 3 ; j < nbcols-3 ; j++){
			deplacements[i][j] = amplitude*(0.25*(ctrlpoints[(i+1)%(nblignes-3)][j] +
				                         ctrlpoints[(i-1) < 0 ? nblignes-4 : i-1][j] +
										 ctrlpoints[i][j+1] +
										 ctrlpoints[i][j-1])
										 - ctrlpoints[i][j]);

		}

	Point3D moyenne(0,0,0);
	for (int i = 0 ; i < nblignes ; i++){
		moyenne = 0.5*(ctrlpoints[(i+1)%(nblignes-3)][2]+ctrlpoints[(i-1)<0?nblignes-4:i-1][2]);
		for (int j = 0 ; j < 3 ; j++){
			deplacements[i][j] = amplitude*(moyenne - ctrlpoints[i][j]);

		}
	}

	moyenne = Point3D(0,0,0);
	for (int i = 0 ; i < nblignes ; i++){
		moyenne = 0.5*(ctrlpoints[(i+1)%(nblignes-3)][nbcols-3]+ctrlpoints[(i-1)<0?nblignes-4:i-1][nbcols-3]);
		for (int j = nbcols-3 ; j < nbcols ; j++){
			deplacements[i][j] = amplitude*(moyenne - ctrlpoints[i][j]);

		}
	}

	
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			int deltai = i-i0 > 0 ? i-i0 : i0-i;
			if (deltai > ri && i <= i0)
				deltai = (i+nblignes-3)-i0 > 0 ? (i+nblignes-3)-i0 : i0-(i+nblignes-3);
			if (deltai > ri && i > i0)
				deltai = (i-nblignes+3)-i0 > 0 ? (i-nblignes+3)-i0 : i0-(i-nblignes+3);
			if (j0 < 3)
				j0 = 2;
			if (j0 >= nbcols-3 && j0 < nbcols)
				j0 = nbcols-3;
			int deltaj = j-j0 > 0 ? j-j0 : j0-j;
			if (deltai <= ri && deltaj <= rj)
				ctrlpoints[i][j] = ctrlpoints[i][j] + deplacements[i][j];
		}

	if (deplacements!=NULL){
		for (int i = 0 ; i < nblignes ; i++)
			delete deplacements[i]; 
		delete [] deplacements;
	}

	precalculmatrices(false);
	
}


void SurfaceBSplineCubiqueCyl::elevation(bool addlignes, bool addcols){

	int elev_i = nblignes-3;
	int elev_j = nbcols-2;

	Point3D** nouveauctrl = allouerPoints3D(nblignes+elev_i,nbcols+elev_j);




	for (int i = 0 ; i < nblignes-3 ; i++)
		for (int j = 1 ; j < nbcols-2 ; j++){
			nouveauctrl[2*i+1][2*j-1] = 0.75*(0.25*ctrlpoints[i][j] + 0.75*ctrlpoints[i+1][j]) +
										0.25*(0.25*ctrlpoints[i][j+1] + 0.75*ctrlpoints[i+1][j+1]);
			nouveauctrl[2*i+1][2*j] = 0.25*(0.25*ctrlpoints[i][j] + 0.75*ctrlpoints[i+1][j]) +
										0.75*(0.25*ctrlpoints[i][j+1] + 0.75*ctrlpoints[i+1][j+1]);
			nouveauctrl[2*i][2*j-1] = 0.75*(0.75*ctrlpoints[i][j] + 0.25*ctrlpoints[i+1][j]) +
										0.25*(0.75*ctrlpoints[i][j+1] + 0.25*ctrlpoints[i+1][j+1]);
			nouveauctrl[2*i][2*j] = 0.25*(0.75*ctrlpoints[i][j] + 0.25*ctrlpoints[i+1][j]) +
										0.75*(0.75*ctrlpoints[i][j+1] + 0.25*ctrlpoints[i+1][j+1]);
		}

	nblignes += elev_i;
	nbcols += elev_j;

	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < 3 ; j++)
			nouveauctrl[i][j] = ctrlpoints[0][0];
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = nbcols-2 ; j < nbcols ; j++)
			nouveauctrl[i][j] = nouveauctrl[i][nbcols-3];
	for (int i = nblignes-3 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++)
			nouveauctrl[i][j] = nouveauctrl[i-(nblignes-3)][j];

	int ancnblignes = nblignes - elev_i;
	if (ctrlpoints!=NULL){
		for (int i = 0 ; i < ancnblignes ; i++)
			delete ctrlpoints[i]; 
		delete [] ctrlpoints;
	}

	liberematrice(coeffs_x, ancnblignes-3);
	liberematrice(coeffs_y, ancnblignes-3);
	liberematrice(coeffs_z, ancnblignes-3);

	ctrlpoints = nouveauctrl;

	precalculmatrices(true);
		
}























Surface * SurfaceBSplineCubiqueTore::copie(void){

	SurfaceBSplineCubiqueTore* surf = new SurfaceBSplineCubiqueTore(ctrlpoints, nblignes, nbcols);

	return surf;
}




void SurfaceBSplineCubiqueTore::deplaceeffectctrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, Camera*cam){

//	ctrlpoints[i][j] = ctrlpoints[i][j]+v;

	Matrice Minv = cam->M;
	v = Minv * v;

	double rayj = rayondeform_j;
	double rayi = rayondeform_i;
	if (rayondeform_j > (nbcols-3)/2)
		rayj = (nbcols-3)/2;
	if (rayondeform_i > (nblignes-4)/2)
		rayi = (nblignes-3)/2;

	int modifi = 0;
	if (2*rayi+1 > nblignes-3)
		modifi = 1;
	int modifj = 0;
	if (2*rayj+1 > nbcols-3)
		modifj = 1;


	for (int i0 = i-(int)rayi +modifi ; i0 <= i + (int) rayi ; i0++)
		for (int j0 = j - (int)rayj +modifj ; j0 <= j + (int)rayj ; j0++){

			double x = sqrt((i0-i)*(i0-i)/(rayondeform_i*rayondeform_i)+
							(j0-j)*(j0-j)/(rayondeform_j*rayondeform_j));
			if (x > 1)
				continue;
			double facteur = (x-1)*(x-1)*(x+1)*(x+1);
			
			int I = (i0 < 0) ? i0 + nblignes-3 : i0%(nblignes-3);
			int J = (j0 < 0) ? j0 + nbcols-3 : j0%(nbcols-3);

			if (I < 0 || J < 0)
				continue;

			if (I < 3)
				ctrlpoints[I+(nblignes-3)][J] = ctrlpoints[I+(nblignes-3)][J] + facteur*v;
			if (J < 3)
				ctrlpoints[I][J+(nbcols-3)] = ctrlpoints[I][J+(nbcols-3)] + facteur*v;
			if (I < 3 && J < 3)
				ctrlpoints[I+(nblignes-3)][J+(nbcols-3)] = ctrlpoints[I+(nblignes-3)][J+(nbcols-3)] + facteur*v;
						
			ctrlpoints[I][J] = ctrlpoints[I][J] + facteur*v;
		}

	precalculmatrices(false);

}



void SurfaceBSplineCubiqueTore::lisser(double amplitude){
	
	Point3D **deplacements;
	deplacements=allouerPoints3D(nblignes,nbcols);
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			deplacements[i][j] = amplitude*(0.25*(ctrlpoints[(i+1)%(nblignes-3)][j] +
				                         ctrlpoints[(i-1) < 0 ? nblignes-4 : i-1][j] +
										 ctrlpoints[i][(j+1)%(nbcols-3)] +
										 ctrlpoints[i][(j-1) < 0 ? nbcols-4 : j-1])
										 - ctrlpoints[i][j]);

		}


	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			ctrlpoints[i][j] = ctrlpoints[i][j] + deplacements[i][j];
		}

	if (deplacements!=NULL){
		for (int i = 0 ; i < nblignes ; i++)
			delete deplacements[i]; 
		delete [] deplacements;
	}

	precalculmatrices(false);
	
}



void SurfaceBSplineCubiqueTore::lisser(double amplitude, int i0, int j0, int ri, int rj){
	
	Point3D **deplacements;
	deplacements=allouerPoints3D(nblignes,nbcols);
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			deplacements[i][j] = amplitude*(0.25*(ctrlpoints[(i+1)%(nblignes-3)][j] +
				                         ctrlpoints[(i-1) < 0 ? nblignes-4 : i-1][j] +
										 ctrlpoints[i][(j+1)%(nbcols-3)] +
										 ctrlpoints[i][(j-1) < 0 ? nbcols-4 : j-1])
										 - ctrlpoints[i][j]);

		}


	
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++){
			int deltai = i-i0 > 0 ? i-i0 : i0-i;
			if (deltai > ri && i <= i0)
				deltai = (i+nblignes-3)-i0 > 0 ? (i+nblignes-3)-i0 : i0-(i+nblignes-3);
			if (deltai > ri && i > i0)
				deltai = (i-nblignes+3)-i0 > 0 ? (i-nblignes+3)-i0 : i0-(i-nblignes+3);
			int deltaj = j-j0 > 0 ? j-j0 : j0-j;
			if (deltaj > rj && j <= j0)
				deltaj = (j+nbcols-3)-i0 > 0 ? (j+nbcols-3)-j0 : j0-(j+nbcols-3);
			if (deltaj > rj && j > j0)
				deltaj = (j-nbcols+3)-i0 > 0 ? (j-nbcols+3)-j0 : j0-(j-nbcols+3);
			if (deltai <= ri && deltaj <= rj)
				ctrlpoints[i][j] = ctrlpoints[i][j] + deplacements[i][j];
		}

	if (deplacements!=NULL){
		for (int i = 0 ; i < nblignes ; i++)
			delete deplacements[i]; 
		delete [] deplacements;
	}

	precalculmatrices(false);
	
}


void SurfaceBSplineCubiqueTore::elevation(bool addlignes, bool addcols){

	int elev_i = nblignes-3;
	int elev_j = nbcols-5;

	Point3D** nouveauctrl = allouerPoints3D(nblignes+elev_i,nbcols+elev_j);




	for (int i = 0 ; i < nblignes-3 ; i++)
		for (int j = 2 ; j < nbcols-3 ; j++){
			nouveauctrl[2*i+1][2*j-1] = 0.75*(0.25*ctrlpoints[i][j] + 0.75*ctrlpoints[i+1][j]) +
										0.25*(0.25*ctrlpoints[i][j+1] + 0.75*ctrlpoints[i+1][j+1]);
			nouveauctrl[2*i+1][2*j] = 0.25*(0.25*ctrlpoints[i][j] + 0.75*ctrlpoints[i+1][j]) +
										0.75*(0.25*ctrlpoints[i][j+1] + 0.75*ctrlpoints[i+1][j+1]);
			nouveauctrl[2*i][2*j-1] = 0.75*(0.75*ctrlpoints[i][j] + 0.25*ctrlpoints[i+1][j]) +
										0.25*(0.75*ctrlpoints[i][j+1] + 0.25*ctrlpoints[i+1][j+1]);
			nouveauctrl[2*i][2*j] = 0.25*(0.75*ctrlpoints[i][j] + 0.25*ctrlpoints[i+1][j]) +
										0.75*(0.75*ctrlpoints[i][j+1] + 0.25*ctrlpoints[i+1][j+1]);
		}

	nblignes += elev_i;
	nbcols += elev_j;

	for (int i = 0 ; i < nblignes ; i++)
		for (int j = 0 ; j < 3 ; j++)
			nouveauctrl[i][j] = ctrlpoints[0][0];
	for (int i = 0 ; i < nblignes ; i++)
		for (int j = nbcols-3 ; j < nbcols ; j++)
			nouveauctrl[i][j] = ctrlpoints[0][nbcols-elev_j-1];
	for (int i = nblignes-3 ; i < nblignes ; i++)
		for (int j = 0 ; j < nbcols ; j++)
			nouveauctrl[i][j] = nouveauctrl[i-(nblignes-3)][j];

	int ancnblignes = nblignes - elev_i;
	if (ctrlpoints!=NULL){
		for (int i = 0 ; i < ancnblignes ; i++)
			delete ctrlpoints[i]; 
		delete [] ctrlpoints;
	}

	liberematrice(coeffs_x, ancnblignes-3);
	liberematrice(coeffs_y, ancnblignes-3);
	liberematrice(coeffs_z, ancnblignes-3);

	ctrlpoints = nouveauctrl;

	precalculmatrices(true);
		
}




