#include "stdafx.h"
#include "Synth.h"
#include "Camera.h"
#include "SurfaceSpline.h"
#include <fstream>
#include "math.h"
using namespace std;

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


void SurfaceMultiPatch::affiche(CDC &cdc, Camera *cam, int dim2Dx, int dim2Dy){
	for (int i = 0 ; i < nbpatches ; i ++){
		patches[i]->affiche(cdc,cam,dim2Dx,dim2Dy);
	}
}


void SurfaceMultiPatch::affichectrlpoints(CDC& cdc, Camera *cam, int dim2Dx, int dim2Dy){
	for (int i = 0 ; i < nbpatches ; i ++){
		patches[i]->affichectrlpoints(cdc,cam,dim2Dx,dim2Dy);
	}
}

void SurfaceMultiPatch::GetCtrlpointSelect(CPoint pos, int & iproche, int & jproche, Camera *cam, int dim2Dx, int dim2Dy){
	

	double D = (double)((((double)dim2Dx)/2.0)/tan(cam->accesanglex()/2));
	Point3D projp(pos.x, pos.y,0);
	
	
	int indi[6], indj[6];
	
	int imin=0;
	double dmin = 1e10;

	int s = 0;
	int smin=0;

	for (int i = 0 ; i < nbpatches ; i ++){
		patches[i]->GetCtrlpointSelect(pos, indi[i],indj[i],cam,dim2Dx,dim2Dy);
		double dpatch = (projp-patches[i]->GetProjectionCtrlPoint(indi[i],indj[i],D, dim2Dx,dim2Dy)).normecarre();

		if (dpatch < dmin){
			imin = i;
			dmin = dpatch;
			smin = s;
		}
		s += nbctrlpatch[i];
	}	

	iproche = smin+indi[imin];
	jproche = indj[imin];
}

Point3D SurfaceMultiPatch::GetProjectionCtrlPoint(int i, int j, double D,int dim2Dx, int dim2Dy){


	int s = 0;
	for (int ind = 0 ; ind < nbpatches ; ind ++){
		if (i < s + nbctrlpatch[ind])
			return patches[ind]->GetProjectionCtrlPoint(i-s,j,D, dim2Dx, dim2Dy);
		s += nbctrlpatch[ind];
	}
	return Point3D(0,0,0);
}

Point3D SurfaceMultiPatch::GetPosCtrlPoint(int i,int j, Camera *cam){
	int s = 0;
	for (int ind = 0 ; ind < nbpatches ; ind ++){
		if (i < s + nbctrlpatch[ind])
			return patches[ind]->GetPosCtrlPoint(i-s,j,cam);
		s += nbctrlpatch[ind];
	}
	return Point3D(0,0,0);
}



void SurfaceMultiPatch::ecritctrlpoints(ostream & fich){

	for (int i = 0 ; i < nbpatches ; i ++){
		patches[i]->ecritctrlpoints(fich);
	}

}



SurfaceMultiPatch::~SurfaceMultiPatch(){

	for (int i = 0 ; i < nbpatches ; i ++){
		delete patches[i];
	}
}





void SurfaceMultiPatch::mettredansreperecam(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine){

	for (int i = 0 ; i < nbpatches ; i ++){
		patches[i] ->mettredansreperecam(cam,rot,scax,scay,scaz,origine);
	}
}


void SurfaceMultiPatch::mettredansreperescene(Camera*cam, Matrice rot, double scax, double scay, double scaz, Point3D origine){
	
	for (int i = 0 ; i < nbpatches ; i ++){
		patches[i]->mettredansreperescene(cam,rot,scax,scay,scaz,origine);
	}

}


void SurfaceMultiPatch::getpoint(double s, double t, double & xpos, double & ypos, double & zpos){

	
	for (int i = 0 ; i < nbpatches ; i ++){
		if (s <= 2*i + 1.5){
			patches[i]->getpoint(s-2*i,t,xpos,ypos,zpos);
			return;
		}
	}
}








void SurfaceMultiPatch::getnormale(double s, double t, double & xn, double & yn, double & zn){
	for (int i = 0 ; i < nbpatches ; i ++){
		if (s <= 2*i + 1.5){
			if (s < 2*i+1e-6) s += 1e-4;
			if (s > 2*i+0.999999) s -=1e-4;
			if (t < 1e-6) t += 1e-4;
			if (t > 0.999999) t -=1e-4;
			patches[i]->getnormale(s-2*i,t,xn,yn,zn);
			return;
		}
	}
}








void SurfaceMultiPatch::getdsds(double s, double t, double & xn, double & yn, double & zn){
	for (int i = 0 ; i < nbpatches ; i ++){
		if (s <= 2*i + 1.5){
			if (s < 2*i+1e-6) s += 1e-4;
			if (s > 2*i+0.999999) s -=1e-4;
			if (t < 1e-6) t += 1e-4;
			if (t > 0.999999) t -=1e-4;
			patches[i]->getdsds(s-2*i,t,xn,yn,zn);
			return;
		}
	}
}








void SurfaceMultiPatch::getdsdt(double s, double t, double & xn, double & yn, double & zn){
	for (int i = 0 ; i < nbpatches ; i ++){
		if (s <= 2*i + 1.5){
			if (s < 2*i+1e-6) s += 1e-4;
			if (s > 2*i+0.999999) s -=1e-4;
			if (t < 1e-6) t += 1e-4;
			if (t > 0.999999) t -=1e-4;
			patches[i]->getdsdt(s-2*i,t,xn,yn,zn);
			return;
		}
	}
}













// rotation de la camera d'un angle teta autour d'un axe parallele a un axe de coordonnees
// passant par le point de focalisation de la camera (pour boite de dialogue "Controles Camera") :

void SurfaceMultiPatch::rotatecamcentral(double teta, char noaxe, Camera * cam)
{
	for (int i = 0 ; i < nbpatches ; i ++){
		patches[i]->rotatecamcentral(teta,noaxe,cam);
	}
}





void SurfaceMultiPatch::lisser(double amplitude){
	
	for (int i = 0 ; i < nbpatches ; i++){
		patches[i]->lisser(amplitude);	
	}
}





void SurfaceMultiPatch::elevation(bool addlignes, bool addcols){

	for (int i = 0 ; i < nbpatches ; i ++){
		patches[i]->elevation(addlignes,addcols);	
	}
		
}


void SurfaceMultiPatch::DeplaceCtrlpoint(int i, int j, Point3D v, double rayondeform_i, double rayondeform_j, CDC &cdc, Camera *cam, int dim2Dx, int dim2Dy){

	CPen penblanc(1, PS_SOLID, RGB(255,255,255));
	cdc.SelectObject(penblanc);
	affiche(cdc, cam, dim2Dx, dim2Dy);
	affichectrlpoints(cdc, cam, dim2Dx, dim2Dy);

	deplaceeffectctrlpoint(i,j,v, rayondeform_i, rayondeform_j, cam);
	

	CPen pennoir(1, PS_SOLID, RGB(0,0,0));
	cdc.SelectObject(pennoir);
	affiche(cdc, cam, dim2Dx, dim2Dy);
	affichectrlpoints(cdc, cam, dim2Dx, dim2Dy);


}
