

#include "stdafx.h"
#include "Synth.h"
#include "Objet3D.h"



#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif



#define SEUIL 0.57




Point3D interpolenormaletriang1(Point3D p1, Point3D p2, Point3D p3,
								Point3D n1, Point3D n2, Point3D n3,
								Point3D point)
{   

	return Point3D(0,0,0);
}






Point3D Objet3D::interpolenormaletriang(const Facette& face, Point3D point) const
{   


	return Point3D(0,0,0);

}




Point3D Objet3D::interpolenormalecarre(const Facette& face, Point3D point) const
{   

	return Point3D(0,0,0);
}











Sommet interpolesommettriang1(Sommet n1, Sommet n2, Sommet n3, Point3D point)
{   
	
	return n1;		//TO DO HERE  A Modifier evidemment
	
}




Sommet Objet3D::interpolesommettriang(const Facette& face, Point3D point) const
{   
	Sommet S;

//	if (face.nbsomm==3){
		
		S=interpolesommettriang1(tabsomm[face.tabnosomm[0]],tabsomm[face.tabnosomm[1]],tabsomm[face.tabnosomm[2]],point);
//	}

	return S;

}




Sommet Objet3D::interpolesommetcarre(const Facette& face, Point3D point) const
{   

	Point3D p1 = tabsomm[face.tabnosomm[0]].pos,
			p2 = tabsomm[face.tabnosomm[1]].pos,
			p3 = tabsomm[face.tabnosomm[2]].pos,
			p4 = tabsomm[face.tabnosomm[3]].pos;


	if (((p3.y-p1.y)*(point.x - p1.x) - (p3.x-p1.x)*(point.y - p1.y))*
		((p3.y-p1.y)*(p2.x - p1.x) - (p3.x-p1.x)*(p2.y - p1.y)) >= 0){
		return interpolesommettriang1( tabsomm[face.tabnosomm[0]],
									   tabsomm[face.tabnosomm[1]],
									   tabsomm[face.tabnosomm[2]],
									   point);
	}else
		return interpolesommettriang1( tabsomm[face.tabnosomm[0]],
									   tabsomm[face.tabnosomm[2]],
									   tabsomm[face.tabnosomm[3]],
									   point);

}








