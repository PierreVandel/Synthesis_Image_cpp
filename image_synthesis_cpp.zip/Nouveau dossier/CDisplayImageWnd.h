/////////////////////////////////////////////////////////////////////////////
// CDisplayImageWnd window

#include "imcouleur.h"


#define WM_SET_RENDER_DISPLAY_WND_NULL WM_USER + 100


class CDisplayImageWnd : public CWnd
{
	imcouleur image;
	CString class_name;
	CBrush brosse;
	HWND hdesktop;
	HMENU hmenu;
	int dimx, dimy;
	bool is_hroz_enabled;
	bool is_vert_enabled;

public:
	bool isdestroyed;
// Construction
public:
	CDisplayImageWnd();

	CDisplayImageWnd(imcouleur im);

// Attributes
public:

// Operations
public:

	void CreateAndDisplay();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDisplayImageWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDisplayImageWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDisplayImageWnd)
	afx_msg void OnFileSave();
	afx_msg void OnPaint();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnClose();
	afx_msg void OnDestroy();
	afx_msg void OnWindowPosChanged(WINDOWPOS FAR* lpwndpos);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
