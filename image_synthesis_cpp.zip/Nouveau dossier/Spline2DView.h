#if !defined(AFX_SPLINE2DVIEW_H__CB512E60_4BA1_11D4_B8E6_525405F505A7__INCLUDED_)
#define AFX_SPLINE2DVIEW_H__CB512E60_4BA1_11D4_B8E6_525405F505A7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Spline2DView.h : header file
//

#include "Spline2D.h"


/////////////////////////////////////////////////////////////////////////////
// Spline2DView view

class Spline2DView : public CView
{

	Pixel tableauctrlpoints[MAX_NB_CTRL_POINTS];
	int nbcontrolpoints;
	bool splinefermeeenconstruction;
	bool splinerevolenconstruction;
	bool splineouverteenconstruction;
	Pixel preced_ctrlpoint;

	CRect rectvuespline2D;  // rectangle de la zone client de la vue spline2D
	Pixel originevuespline2D; // centre de la zone client de la vue spline2D



	void dessinevuesplinefermee(CDC * pDC);
	void dessinevuesplinerevol(CDC * pDC);
//	void dessinevuesplineouverte(CDC * pDC);

public:
	Spline2DView();           // public constructor used by dynamic creation
protected:
	DECLARE_DYNCREATE(Spline2DView)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Spline2DView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~Spline2DView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(Spline2DView)
	afx_msg void OnInsereSpline2dFermee();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnInsereSpline2dRevol();
	afx_msg void OnInsereSplineouverte();
	afx_msg void OnUpdateInsereSplineouverte(CCmdUI* pCmdUI);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPLINE2DVIEW_H__CB512E60_4BA1_11D4_B8E6_525405F505A7__INCLUDED_)
