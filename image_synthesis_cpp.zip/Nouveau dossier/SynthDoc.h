// SynthDoc.h : interface of the CSynthDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SYNTHDOC_H__5208426C_4674_11D3_B1CB_C729201D0A7D__INCLUDED_)
#define AFX_SYNTHDOC_H__5208426C_4674_11D3_B1CB_C729201D0A7D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


#define WM_DETRUIRE_VUESP3D WM_USER + 50
#define WM_SET_CHILD_VUESP3D WM_USER + 51



class Spline2D;
class Pixel;
class Objet3D;
class Camera;
class Surface;

enum EnumView {VUE3D=1, SPLINE2D=2, SPLINE3D=3};



class CSynthDoc : public CDocument
{
protected: // create from serialization only
	CSynthDoc();
	DECLARE_DYNCREATE(CSynthDoc)

// Attributes
public:

	bool hasaname;
	char filename[150];
	CWnd* p_mywindow;
	CBitmap mybitmap;
	CDC*bitcdc;
	CDC compatiblecdc;

	Spline2D **p_Splines2D;
	int nbmaxSpline2D;
	int nbSpline2D;

	Objet3D *objetedite;
	Camera *cam;


	EnumView vue_active;


	CView* pSpline2DView;  // Pointeur sur la vue Spline2D
	CView* pSynthView;  // pointeur sur la vue 3D

	double hauteur_effective;

	bool besoinupdateobjetseditables;
	bool fenetreSpline3DViewouverte;

	Surface* surfaceobj;

	HICON icone_sphere;


// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSynthDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSynthDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSynthDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SYNTHDOC_H__5208426C_4674_11D3_B1CB_C729201D0A7D__INCLUDED_)
