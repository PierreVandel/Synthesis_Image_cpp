// Spline3DView.cpp : implementation file
//

#include "stdafx.h"
#include "Synth.h"
#include "Spline3DView.h"
#include "SynthDoc.h"
#include "SurfaceSpline.h"
#include "Objet3D.h"
#include "SplineDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSpline3DView

IMPLEMENT_DYNCREATE(CSpline3DView, CView)

CSpline3DView::CSpline3DView()
{
	steprot=1;
	steptrans=10;

	gaucheenfonce = false;
	droiteenfonce = false;

	noplan=0;

	rayondeform_i=1;
	rayondeform_j=1;
	speeddeform=0.5;
	amplitudelissage=0.25;

	ri = 0;
	rj = 0;
	noctrlpoinselect.x = 3;
	noctrlpoinselect.y = 3;

}

CSpline3DView::~CSpline3DView()
{
}


BEGIN_MESSAGE_MAP(CSpline3DView, CView)
	//{{AFX_MSG_MAP(CSpline3DView)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_KILLFOCUS()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_SPLINE_DEFORM_XY, OnSplineDeformXy)
	ON_UPDATE_COMMAND_UI(ID_SPLINE_DEFORM_XY, OnUpdateSplineDeformXy)
	ON_COMMAND(ID_SPLINE_DEFORM_XZ, OnSplineDeformXz)
	ON_UPDATE_COMMAND_UI(ID_SPLINE_DEFORM_XZ, OnUpdateSplineDeformXz)
	ON_COMMAND(ID_SPLINE_DEFORM_YZ, OnSplineDeformYz)
	ON_UPDATE_COMMAND_UI(ID_SPLINE_DEFORM_YZ, OnUpdateSplineDeformYz)
	ON_WM_DESTROY()
	ON_COMMAND(ID_SPLINE_SETRAYONDEFORM, OnSplineSetrayondeform)
	ON_COMMAND(ID_SPLINES_LISSAGE, OnSplinesLissage)
	ON_COMMAND(ID_SPLINE_LISSAGE_LOCAL, OnSplineLissageLocal)
	ON_UPDATE_COMMAND_UI(ID_SPLINE_LISSAGE_LOCAL, OnUpdateSplineLissageLocal)
	ON_COMMAND(ID_SPLINE_ELEVATION, OnSplineElevation)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSpline3DView drawing

void CSpline3DView::OnDraw(CDC* pDC)
{
	CSynthDoc* pDoc = (CSynthDoc*)GetDocument();
	// TODO: add draw code here

	CRect fenetre;
	GetClientRect(fenetre);
	dimx = fenetre.Width();
	dimy=fenetre.Height();

	if (pDoc->surfaceobj==NULL)
		return;


	if (pDoc->surfaceobj != NULL)
		pDoc->surfaceobj->affiche(*pDC, pDoc->cam, dimx, dimy);
}

/////////////////////////////////////////////////////////////////////////////
// CSpline3DView diagnostics

#ifdef _DEBUG
void CSpline3DView::AssertValid() const
{
	CView::AssertValid();
}

void CSpline3DView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSpline3DView message handlers

void CSpline3DView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	
	CWnd *mainwindow = AfxGetMainWnd();
	CRect rect;

	CWnd *fils = mainwindow->GetWindow(GW_CHILD);
	fils->GetClientRect(rect);

	CWnd *parent = GetParent();

	parent->MoveWindow(rect.left+rect.Width()/2, rect.top, rect.Width()/2, rect.Height(), false);


	CSynthDoc* pDoc = (CSynthDoc*)GetDocument();
	if (pDoc->surfaceobj!=NULL)
		delete pDoc->surfaceobj;
	pDoc->surfaceobj = pDoc->objetedite->GetSurface()->copie();
	pDoc->surfaceobj->mettredansreperecam(pDoc->cam, pDoc->objetedite->getrot(), 
													pDoc->objetedite->getscax(),
													pDoc->objetedite->getscay(),
													pDoc->objetedite->getscaz(),
													pDoc->objetedite->getorigine());
}

void CSpline3DView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default


	CSynthDoc* pDoc = (CSynthDoc*)GetDocument();
	if (pDoc->surfaceobj==NULL)
		return;

	CClientDC cdc(this);

	if (droiteenfonce){
		
		CPen penblanc(1, PS_SOLID, RGB(255,255,255));
		cdc.SelectObject(penblanc);
		pDoc->surfaceobj->affiche(cdc, pDoc->cam, dimx, dimy);

		pDoc->surfaceobj->rotatecamcentral(-steprot*(point.y-anciensouris.y), 0, pDoc->cam);
		pDoc->surfaceobj->rotatecamcentral(-steprot*(point.x-anciensouris.x), 1, pDoc->cam);

		CPen pennoir(1, PS_SOLID, RGB(0,0,0));
		cdc.SelectObject(pennoir);
		pDoc->surfaceobj->affiche(cdc, pDoc->cam, dimx, dimy);
	}

	if (gaucheenfonce){
		if (ctrlpoinselect){
			Point3D v;
			if (noplan==0)
				v = Point3D(point.x-anciensouris.x, -(point.y-anciensouris.y), 0);
			if (noplan==1)
				v = Point3D(point.x-anciensouris.x, 0, -(point.y-anciensouris.y));
			if (noplan==2)
				v = Point3D(0 , point.x-anciensouris.x, -(point.y-anciensouris.y));
			v = speeddeform*v;

			pDoc->surfaceobj->DeplaceCtrlpoint(noctrlpoinselect.x, noctrlpoinselect.y, v, rayondeform_i, rayondeform_j, cdc, pDoc->cam, dimx, dimy);

			char message[100];
			sprintf(message, "Point de controle (%d, %d)", noctrlpoinselect.x, noctrlpoinselect.y);
			cdc.TextOut(5,5, CString(message));

			Point3D P = pDoc->surfaceobj->GetPosCtrlPoint(noctrlpoinselect.x,noctrlpoinselect.y, pDoc->cam);
			sprintf(message, "x = %2.2f,  y = %2.2f,  z = %2.2f   ", P.x, P.y, P.z);
			cdc.TextOut(5,30, CString(message));

			anciensouris=point;
		}
		}

	anciensouris = point;
	
	CView::OnMouseMove(nFlags, point);
}

void CSpline3DView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CView::OnLButtonDown(nFlags, point);

	anciensouris = point;

	gaucheenfonce = true;
	droiteenfonce = false;

	CSynthDoc* pDoc = (CSynthDoc*)GetDocument();
	if (pDoc->surfaceobj==NULL)
		return;

	int x, y;
	pDoc->surfaceobj->GetCtrlpointSelect(point, x, y, pDoc->cam, dimx, dimy);

	CClientDC cdc(this);
	char message[100];
	sprintf(message, "Point de controle (%d, %d)", x, y);
	cdc.TextOut(5,5, CString(message));

	Point3D P = pDoc->surfaceobj->GetPosCtrlPoint(x,y, pDoc->cam);
	sprintf(message, "x = %2.2f,  y = %2.2f,  z = %2.2f   ", P.x, P.y, P.z);
	cdc.TextOut(5, 30, CString(message));

	noctrlpoinselect.x=x;
	noctrlpoinselect.y=y;
	ctrlpoinselect=true;		

	anciensouris=point;
}

void CSpline3DView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CView::OnLButtonUp(nFlags, point);

	gaucheenfonce = false;


}

void CSpline3DView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CView::OnRButtonDown(nFlags, point);

	anciensouris = point;

	droiteenfonce = true;
	gaucheenfonce = false;
}

void CSpline3DView::OnRButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CView::OnRButtonUp(nFlags, point);

	droiteenfonce = false;
}

void CSpline3DView::OnDragLeave() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CView::OnDragLeave();

	droiteenfonce = false;
	gaucheenfonce = false;

}

void CSpline3DView::OnKillFocus(CWnd* pNewWnd) 
{
	CView::OnKillFocus(pNewWnd);
	
	// TODO: Add your message handler code here
	CSynthDoc* pDoc = (CSynthDoc*)GetDocument();

	pDoc->besoinupdateobjetseditables = true;
}

void CSpline3DView::OnSetFocus(CWnd* pOldWnd) 
{
	CView::OnSetFocus(pOldWnd);
	
	// TODO: Add your message handler code here

	CSynthDoc* pDoc = (CSynthDoc*)GetDocument();

	if (pDoc->objetedite == NULL){
		if (pDoc->surfaceobj != NULL)
			delete pDoc->surfaceobj;
		pDoc->surfaceobj=NULL;

	}
	pDoc->vue_active = SPLINE3D;
}

void CSpline3DView::OnSplineDeformXy() 
{
	// TODO: Add your command handler code here
	
	noplan=0;

}

void CSpline3DView::OnUpdateSplineDeformXy(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(noplan==0);
}

void CSpline3DView::OnSplineDeformXz() 
{
	// TODO: Add your command handler code here
	
	noplan=1;
}

void CSpline3DView::OnUpdateSplineDeformXz(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here

	pCmdUI->SetCheck(noplan==1);
}

void CSpline3DView::OnSplineDeformYz() 
{
	// TODO: Add your command handler code here
	noplan=2;

}

void CSpline3DView::OnUpdateSplineDeformYz(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(noplan==2);

}

void CSpline3DView::OnDestroy() 
{
	CView::OnDestroy();
	
	// TODO: Add your message handler code here
	CSynthDoc* pDoc = (CSynthDoc*)GetDocument();
	pDoc->objetedite = NULL;
	pDoc->fenetreSpline3DViewouverte=false;

	AfxGetMainWnd()->PostMessage(WM_SET_CHILD_VUESP3D);
}

void CSpline3DView::OnSplineSetrayondeform() 
{
	// TODO: Add your command handler code here

	CRayonDeformDialog dlg;
	dlg.m_rayondeform_i = rayondeform_i;
	dlg.m_rayondeform_j = rayondeform_j;
	dlg.m_speeddeform = speeddeform;
	dlg.m_amplitudelissage = amplitudelissage;
	dlg.m_ri = ri;
	dlg.m_rj = rj;

	dlg.DoModal();

	rayondeform_i = dlg.m_rayondeform_i;
	rayondeform_j = dlg.m_rayondeform_j;
	speeddeform = dlg.m_speeddeform;
	amplitudelissage = dlg.m_amplitudelissage;
	ri = dlg.m_ri;
	rj = dlg.m_rj;
}

void CSpline3DView::OnSplinesLissage() 
{
	// TODO: Add your command handler code here
	
	CSynthDoc* pDoc = (CSynthDoc*)GetDocument();
	if (pDoc->surfaceobj==NULL)
		return;

	int ret = AfxMessageBox(CString("Effectuer lissage global ?"), MB_OKCANCEL);

	if (ret == IDCANCEL)
		return;

	pDoc->surfaceobj->lisser(amplitudelissage);

	CRect rect;
	GetClientRect(rect);
	InvalidateRect(rect);
}

void CSpline3DView::OnSplineLissageLocal() 
{
	// TODO: Add your command handler code here

	CSynthDoc* pDoc = (CSynthDoc*)GetDocument();
	if (pDoc->surfaceobj==NULL)
		return;
	pDoc->surfaceobj->lisser(amplitudelissage, noctrlpoinselect.x, noctrlpoinselect.y, ri, rj);

	CRect rect;
	GetClientRect(rect);
	InvalidateRect(rect);
	
}

void CSpline3DView::OnUpdateSplineLissageLocal(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(true);
}

void CSpline3DView::OnSplineElevation() 
{
	// TODO: Add your command handler code here

	CSynthDoc* pDoc = (CSynthDoc*)GetDocument();
	if (pDoc->surfaceobj==NULL)
		return;

	int ret = AfxMessageBox(CString("Quadrupler le nombre de points de controle ?"), MB_OKCANCEL);

	if (ret == IDCANCEL)
		return;


	CClientDC cdc(this);
	CPen penblanc(1, PS_SOLID, RGB(255,255,255));
	cdc.SelectObject(penblanc);
	pDoc->surfaceobj->affiche(cdc, pDoc->cam, dimx, dimy);
	pDoc->surfaceobj->affichectrlpoints(cdc, pDoc->cam, dimx, dimy);

	pDoc->surfaceobj->elevation(true, true);

	CPen pennoir(1, PS_SOLID, RGB(0,0,0));
	cdc.SelectObject(pennoir);
	pDoc->surfaceobj->affiche(cdc, pDoc->cam, dimx, dimy);
	pDoc->surfaceobj->affichectrlpoints(cdc, pDoc->cam, dimx, dimy);
}
