#include <stdlib.h>

#include "stdafx.h"
#include "Synth.h"

#include "SynthDoc.h"
#include "SynthView.h"
#include "CDisplayImageWnd.h"

#include "RenduDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CWinThread *thread_calcul;


UINT ThreadRayTracing(LPVOID pParam);


UINT ThreadRayTracing(LPVOID pParam){
	CSynthView *vue = (CSynthView*)pParam;

	vue->activinsere=false;
	vue->enableuseinterface=false;
	vue->scene.lancer_general(vue->bitmap_render, false, vue->percentcalcul);
	vue->activinsere=true;
	vue->enableuseinterface=true;
	vue->raytracingfinished = true;
	return 0;

}



void CSynthView::OnRenduCalculerImage() 
{
	// TODO: Add your command handler code here
	// TODO: Add your command handler code here

	
	CRenduGlobalDialog dlg;
	dlg.m_pourcentnegl = scene.getpourcenneglig();
	dlg.m_procrecur = scene.getprofrecurmax();
	dlg.m_maxdepth = scene.getmaxdepth();
	dlg.m_minsizecell = scene.getminsizecell();
	dlg.m_nbfacesmax = scene.getnbfacesmax();
	dlg.m_use_bsp = scene.getusebsp();
	dlg.m_rapportthreshold = scene.getrapportthreshold();
	dlg.m_seuiladapt = scene.getseuiladaptraytra();
	dlg.m_enableextendedlight = scene.getenableextendedlight();
	dlg.m_nbrayslights = scene.getnbrayslights();
	dlg.m_save_calcul = scene.getsave_calcul();
	scene.getrenderwindow(dlg.m_winwidth, dlg.m_winheight);

	if (displaywnd != NULL){
		CString message("Erase previously computed image ?");
		if (IDCANCEL==AfxMessageBox(CString(message, MB_OKCANCEL)))
			return;

		displaywnd->DestroyWindow();
		delete displaywnd;
		displaywnd=NULL;
	}

	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
		scene.setpourcenneglig(dlg.m_pourcentnegl);
		scene.setprofrecurmax(dlg.m_procrecur);
		scene.setmaxdepth(dlg.m_maxdepth);
		scene.setminsizecell(dlg.m_minsizecell);
		scene.setnbfacesmax(dlg.m_nbfacesmax);
		scene.setrapportthreshold(dlg.m_rapportthreshold);
		scene.setseuiladaptraytra(dlg.m_seuiladapt);
		scene.setusebsp(dlg.m_use_bsp ? 1 : 0);
		scene.setenableextendedlight(dlg.m_enableextendedlight ? 1 : 0);
		scene.setnbrayslights(dlg.m_nbrayslights);
		scene.setsave_calcul(dlg.m_save_calcul ? 1 : 0);
		scene.setdim2Drender(dlg.m_winwidth, dlg.m_winheight);
		bitmap_render.setdim(dlg.m_winwidth, dlg.m_winheight);


//		scene.lancer_general(bitmap_dib, false);

		SetTimer(1,100,NULL);
		percentcalcul=0;
		firstphase=true;
		raytracingfinished=false;


		if (progressdlg == NULL)
			progressdlg = new CMyProgresDialog;
		if (progressdlg->GetSafeHwnd() == 0){
			if (progressdlg->Create(IDD_PROGRESS, NULL) == 0){
			}

		}

		if (scene.getrenduetatsurechant()==0){
			progressdlg->SetWindowText(CString("Ray tracing : first phase"));
		}
//		CRect rectctrl(0,0,400,100);
//		progres->Create( PBS_SMOOTH, rectctrl, progressdlg, ID_MYPROGRESSBAR );
//		progres->SetPos(0);

		scene.setcalcul_is_continuing(false);
		thread_calcul = AfxBeginThread(ThreadRayTracing, this);

		CClientDC cdc(this);
		OnDraw(&cdc);
	}


}



void CSynthView::OnUpdateRenduCalculerImage(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
		pCmdUI->Enable(activinsere);	

}






void CSynthView::OnRenduOptioneclairementReflexionsinterobjets() 
{
	// TODO: Add your command handler code here
	scene.setrenduenablereflexion(!scene.getrenduenablereflexion());
}

void CSynthView::OnUpdateRenduOptioneclairementReflexionsinterobjets(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(scene.getrenduenablereflexion());
	pCmdUI->Enable(activinsere);

}



void CSynthView::OnRenduOptioneclairementRefraction() 
{
	// TODO: Add your command handler code here
	scene.setrenduenablerefraction(!scene.getrenduenablerefraction());
}

void CSynthView::OnUpdateRenduOptioneclairementRefraction(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(scene.getrenduenablerefraction());
	pCmdUI->Enable(activinsere);
	
}
	


void CSynthView::OnRenduOptioneclairementTransmissionDiffuse() 
{
	// TODO: Add your command handler code here
	scene.setrenduenabletransmdifuse(!scene.getrenduenabletransmdifuse());
}

void CSynthView::OnUpdateRenduOptioneclairementTransmissionDiffuse(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(scene.getrenduenabletransmdifuse());
	pCmdUI->Enable(activinsere);
	
}




void CSynthView::OnRenduOptioneclairementTransmissionSpeculaire() 
{
	// TODO: Add your command handler code here
	scene.setrenduenabletransmspecular(!scene.getrenduenabletransmspecular());
}

void CSynthView::OnUpdateRenduOptioneclairementTransmissionSpeculaire(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(scene.getrenduenabletransmspecular());
	pCmdUI->Enable(activinsere);
	
}



void CSynthView::OnRenduOptionsclairementLumireambiante() 
{
	// TODO: Add your command handler code here
	scene.setrenduenableambiante(!scene.getrenduenableambiante());
}

void CSynthView::OnUpdateRenduOptionsclairementLumireambiante(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(scene.getrenduenableambiante());
	pCmdUI->Enable(activinsere);
	
}



void CSynthView::OnRenduOptionsclairementPhong() 
{
	// TODO: Add your command handler code here
	scene.setrenduenablephong(!scene.getrenduenablephong());
}

void CSynthView::OnUpdateRenduOptionsclairementPhong(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->SetCheck(scene.getrenduenablephong());
	pCmdUI->Enable(activinsere);
}



void CSynthView::OnRenduOptionsclairementReflexiondifuse() 
{
	// TODO: Add your command handler code here
	scene.setrenduenabledifuse(!scene.getrenduenabledifuse());
}

void CSynthView::OnUpdateRenduOptionsclairementReflexiondifuse(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->SetCheck(scene.getrenduenabledifuse());
	pCmdUI->Enable(activinsere);
}


void CSynthView::OnRenduOptionsclairementReflexionspeculaire() 
{
	// TODO: Add your command handler code here
	scene.setrenduenablespecular(!scene.getrenduenablespecular());
	
}

void CSynthView::OnUpdateRenduOptionsclairementReflexionspeculaire(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->SetCheck(scene.getrenduenablespecular());
	pCmdUI->Enable(activinsere);
}



void CSynthView::OnRenduOptionsclairementTextures() 
{
	// TODO: Add your command handler code here
	scene.setrenduenabletexture(!scene.getrenduenabletexture());
}

void CSynthView::OnUpdateRenduOptionsclairementTextures(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->SetCheck(scene.getrenduenabletexture());
	pCmdUI->Enable(activinsere);
}



void CSynthView::OnRenduOptioneclairementOmbres() 
{
	// TODO: Add your command handler code here
	scene.setrenduenableombres(!scene.getrenduenableombres());
}

void CSynthView::OnUpdateRenduOptioneclairementOmbres(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(scene.getrenduenableombres());
	pCmdUI->Enable(activinsere);
	
}




void CSynthView::OnRenduOptionsglobales() 
{
	// TODO: Add your command handler code here
	CRenduGlobalDialog dlg;

	dlg.m_pourcentnegl = scene.getpourcenneglig();
	dlg.m_procrecur = scene.getprofrecurmax();
	dlg.m_maxdepth = scene.getmaxdepth();
	dlg.m_minsizecell = scene.getminsizecell();
	dlg.m_nbfacesmax = scene.getnbfacesmax();
	dlg.m_use_bsp = scene.getusebsp();
	dlg.m_rapportthreshold = scene.getrapportthreshold();
	dlg.m_seuiladapt = scene.getseuiladaptraytra();
	dlg.m_enableextendedlight = scene.getenableextendedlight();
	dlg.m_nbrayslights = scene.getnbrayslights();
	scene.getrenderwindow(dlg.m_winwidth, dlg.m_winheight);

	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
		scene.setpourcenneglig(dlg.m_pourcentnegl);
		scene.setprofrecurmax(dlg.m_procrecur);
		scene.setmaxdepth(dlg.m_maxdepth);
		scene.setminsizecell(dlg.m_minsizecell);
		scene.setnbfacesmax(dlg.m_nbfacesmax);
		scene.setrapportthreshold(dlg.m_rapportthreshold);
		scene.setseuiladaptraytra(dlg.m_seuiladapt);
		scene.setusebsp(dlg.m_use_bsp ? 1 : 0);
		scene.setenableextendedlight(dlg.m_enableextendedlight ? 1 : 0);
		scene.setnbrayslights(dlg.m_nbrayslights);
		scene.setdim2Drender(dlg.m_winwidth, dlg.m_winheight);
	}
}

void CSynthView::OnUpdateRenduOptionsglobales(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(activinsere);
	
}





void CSynthView::OnRenduSurech1() 
{
	// TODO: Add your command handler code here
	if (scene.getrenduetatsurechant() != 1){
		scene.setrenduetatsurechant(1);
	}

}

void CSynthView::OnUpdateRenduSurech1(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(scene.getrenduetatsurechant() == 1);
	pCmdUI->Enable(activinsere);

}

void CSynthView::OnRenduSurech2() 
{
	// TODO: Add your command handler code here
	
	if (scene.getrenduetatsurechant() != 2){
		scene.setrenduetatsurechant(2);
	}
}

void CSynthView::OnUpdateRenduSurech2(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->SetCheck(scene.getrenduetatsurechant() == 2);
	pCmdUI->Enable(activinsere);
}

void CSynthView::OnRenduSurech3() 
{
	// TODO: Add your command handler code here
	if (scene.getrenduetatsurechant() != 3){
		scene.setrenduetatsurechant(3);
	}

}

void CSynthView::OnUpdateRenduSurech3(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(scene.getrenduetatsurechant() == 3);
	pCmdUI->Enable(activinsere);
	
}


void CSynthView::OnAdaptAntialiazing() 
{
	// TODO: Add your command handler code here
	if (scene.getrenduetatsurechant() != 0){
		scene.setrenduetatsurechant(0);
	}
	
}

void CSynthView::OnUpdateAdaptAntialiazing(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(scene.getrenduetatsurechant() == 0);
	pCmdUI->Enable(activinsere);
	
}




void CSynthView::OnRenduContinueRaytra() 
{
	// TODO: Add your command handler code here

	CFileDialog dlg(TRUE, CString("cal"), CString("*.cal"));

	char namecal[200];

	CSynthDoc* pdoc = (CSynthDoc*)GetDocument();
	int ret = dlg.DoModal();

	int i = 0;
	if (ret != IDCANCEL){
		int longueur = dlg.GetPathName().GetLength();
		for (i = 0 ; i < longueur ; i++){
			namecal[i] = dlg.GetPathName().GetAt(i);
		}
		namecal[i] = '\0';

		if (displaywnd != NULL){
			if (IDCANCEL==AfxMessageBox(CString("Erase previously computed image ?"), MB_OKCANCEL))
				return;

			displaywnd->DestroyWindow();
			delete displaywnd;
			displaywnd=NULL;
		}


		SetTimer(1,100,NULL);
		percentcalcul=0;
		firstphase=true;
		raytracingfinished=false;


		if (progressdlg == NULL)
			progressdlg = new CMyProgresDialog;
		if (progressdlg->GetSafeHwnd() == 0){
			if (progressdlg->Create(IDD_PROGRESS, NULL) == 0){
			}

		}

		if (scene.getrenduetatsurechant()==0){
			progressdlg->SetWindowText(CString("Ray tracing : continuing"));
		}

		scene.setcalcul_is_continuing(true);
		scene.setnomcal(namecal);
		thread_calcul = AfxBeginThread(ThreadRayTracing, this);
	}
}

void CSynthView::OnUpdateRenduContinueRaytra(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);
}




void CSynthView::OnOpenDisplayWindow() 
{
	// TODO: Add your command handler code here
	if (displaywnd->isdestroyed)
		displaywnd->CreateAndDisplay();
	else
		displaywnd->SetForegroundWindow();

}

void CSynthView::OnUpdateOpenDisplayWindow(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here

	pCmdUI->Enable(displaywnd != NULL);
}




LRESULT CSynthView::OnSetRenderDisplayWndNull(WPARAM wParam, LPARAM lParam){

	if (displaywnd != NULL)
		delete displaywnd;
	displaywnd=NULL;
	return 0L;
}
