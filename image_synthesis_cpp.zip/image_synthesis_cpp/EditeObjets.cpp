#include "stdafx.h"
#include "Synth.h"
#include "Objetderiv.h"
#include "Scene3D.h"

#include "objetsdialog.h"
#include "SplineDialog.h"
#include "MaterialPropPage.h"

#include "math.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


bool belongs(unsigned short *tab, int nb, unsigned short no){
	for (int i = 0 ; i < nb ; i++)
		if (tab[i] == no)
			return true;
	return false;
}

unsigned short Scene3D::selectionneobjet(CPoint pixel, CDC & cdc, unsigned short * numobjetselect, int & nbobjetselect, bool ctrlpressed){

	if (pixel.x < 0 || pixel.x >= dimfenetrex ||
		pixel.y < 0 || pixel.y >= dimfenetrey ||
		numobjets[pixel.x][pixel.y]<=3)
		return 0;

	if (belongs(numobjetselect, nbobjetselect, numobjets[pixel.x][pixel.y]))
		return 0;
	for (int x = 0 ; x < dimfenetrex ; x++)
		for (int y = 0 ; y < dimfenetrey ; y++)
			if (nogroupe[numobjets[x][y]]==nogroupe[numobjets[pixel.x][pixel.y]] || (ctrlpressed && belongs(numobjetselect, nbobjetselect, numobjets[x][y])))
				cdc.SetPixel(CPoint(x,y), RGB(255, 126, 126));
	objetselect=NULL;
	if (!ctrlpressed)
		nbobjetselect = 0;
	for (Celluleobj * p = objets.L ; p != NULL ; p = p->suiv)
		if (nogroupe[p->pobjet->numero] == nogroupe[numobjets[pixel.x][pixel.y]] ){
			numobjetselect[nbobjetselect++] = p->pobjet->numero;
			if (nbobjetselect == 1)
				objetselect = p->pobjet;
		}

	if (nbobjetselect != 1)
		objetselect = NULL;

	return numobjets[pixel.x][pixel.y];
}


void Scene3D::groupeobjets(unsigned short *numobjetselect, int nbobjetselect){
	if (nbobjetselect <= 1)
		return;

	for (int i = 0 ; i < nbobjetselect ; i++){
		nogroupe[numobjetselect[i]] = numobjetselect[0];
	}

}



void Scene3D::ungroupobjets(unsigned short *numobjetselect, int nbobjetselect){
	if (nbobjetselect <= 1)
		return;

	for (int i = 0 ; i < nbobjetselect ; i++){
		nogroupe[numobjetselect[i]] = numobjetselect[i];
	}

}




Point3D Scene3D::GetCenterSelectedObjects(unsigned short * numobjetselect, int & nbobjetselect){

	int count = 0;
	Point3D moy(0,0,0);
	for (Celluleobj * p = objets.L ; p != NULL ; p = p->suiv)
		if (belongs(numobjetselect, nbobjetselect, p->pobjet->numero)){
			count++;
			moy = moy + p->pobjet->origine;
		}

	moy = (1/(double) count)*moy;

	return moy;
}

void Scene3D::transform(Point3D translat, Point3D orig, double sca, Point3D diraxe, double angle, unsigned short * numobjetselect, int & nbobjetselect){
	for (Celluleobj * p = objets.L ; p != NULL ; p = p->suiv)
		if (belongs(numobjetselect, nbobjetselect, p->pobjet->numero)){
			MettreDansRepereScene(p->pobjet);
			p->pobjet->transform(translat, orig, sca, diraxe, angle);
			MettreDansRepereCamera(p->pobjet);
		}

}

void Objet3D::transform(Point3D translat, Point3D orig, double sca, Point3D diraxe, double angle){

	angle *= pi/180.0;
	Matrice passage(3,3);

	diraxe.normer();

	Point3D vect1 = diraxe;
	Point3D vect2;
	if (diraxe.x == 0 && diraxe.y == 0){
		vect2 = Point3D(1,0,0);
	}
	else
		vect2 = vect1^Point3D(0,0,1);
	vect2.normer();
	Point3D vect3 = vect1^vect2;
	passage[0][0] = vect1.x;
	passage[1][0] = vect1.y;
	passage[2][0] = vect1.z;

	passage[0][1] = vect2.x;
	passage[1][1] = vect2.y;
	passage[2][1] = vect2.z;

	passage[0][2] = vect3.x;
	passage[1][2] = vect3.y;
	passage[2][2] = vect3.z;

	Matrice mrotx(3,3);

	mrotx[0][0] = 1;
	mrotx[1][1] = (double)cos(angle);
	mrotx[2][1] = (double)sin(angle);
	mrotx[1][2] = (double)-sin(angle);
	mrotx[2][2] = (double)cos(angle);


	Matrice mrotvrai = passage*mrotx*passage.t();

	Point3D test = mrotvrai*vect1;

	Matrice mrot = mrotvrai*rotation;

	Point3D vect = mrot*Point3D(1,0,0);

	vect.z = 0;

	double thetaz;

	if (vect.norme() == 0)
		thetaz = 0;
	else
		thetaz = acos(vect.x /vect.norme());

	if (vect.y < 0)
		thetaz = -thetaz;

	Matrice mrotz(3,3);

		// matrice de la rotation d'un angle teta autour de Oz
	mrotz[0][0] = (double)cos(thetaz);
	mrotz[1][1] =  (double)cos(thetaz);
	mrotz[1][0] = (double)sin(thetaz);
	mrotz[0][1] = (double)-sin(thetaz);
	mrotz[2][2] = 1;

	mrot = mrotz.t()*mrot;

	vect = mrot*Point3D(1,0,0);



	double thetay;

	thetay = acos(vect.x /vect.norme());

	if (vect.z > 0)
		thetay = -thetay;

	Matrice mroty(3,3);

	mroty[0][0] = (double)cos(thetay);
	mroty[1][1] =  1;
	mroty[2][0] = (double)-sin(thetay);
	mroty[0][2] = (double)sin(thetay);
	mroty[2][2] = (double)cos(thetay);


	mrotx = mroty.t()*mrot;

	vect = mrotx*Point3D(0,1,0);


	double thetax;

	thetax = -acos(vect.y /vect.norme());

	if (vect.z > 0)
		thetax = -thetax;

	mrotx[0][0] = 1;
	mrotx[1][1] = (double)cos(thetax);
	mrotx[2][1] = (double)sin(thetax);
	mrotx[1][2] = (double)-sin(thetax);
	mrotx[2][2] = (double)cos(thetax);

	// changements d'echelle suivant les differents axes,
	// rotations, et translation
	for (int i = 0 ; i < nbsomm ; i++){
		tabsomm[i].pos = tabsomm[i].pos - origine;
		tabsomm[i] = rotation.t()*tabsomm[i];
		tabsomm[i].normale.x *= scalex;
		tabsomm[i].normale.y *= scaley;
		tabsomm[i].normale.z *= scalez;
		tabsomm[i].pos.x /= scalex;
		tabsomm[i].pos.y /= scaley;
		tabsomm[i].pos.z /= scalez;
		tabsomm[i].dpsds.x /= scalex;
		tabsomm[i].dpsds.y /= scaley;
		tabsomm[i].dpsds.z /= scalez;
		tabsomm[i].dpsdt.x /= scalex;
		tabsomm[i].dpsdt.y /= scaley;
		tabsomm[i].dpsdt.z /= scalez;
	}
	// changements d'echelle suivant les differents axes,
	// rotations, et translation

	rotx = thetax*180.0/pi;
	roty = thetay*180.0/pi;
	rotz = thetaz*180.0/pi;
	scalex *= sca;
	scaley *= sca;
	scalez *= sca;
	rotation = mrotz*mroty*mrotx;
	origine = orig + sca*(mrotvrai*(origine-orig)) + translat;
	for (int i = 0 ; i < nbsomm ; i++){
		tabsomm[i].pos.x *= scalex;
		tabsomm[i].pos.y *= scaley;
		tabsomm[i].pos.z *= scalez;
		tabsomm[i].dpsds.x *= scalex;
		tabsomm[i].dpsds.y *= scaley;
		tabsomm[i].dpsds.z *= scalez;
		tabsomm[i].dpsdt.x *= scalex;
		tabsomm[i].dpsdt.y *= scaley;
		tabsomm[i].dpsdt.z *= scalez;
		tabsomm[i].normale.x /= scalex;
		tabsomm[i].normale.y /= scaley;
		tabsomm[i].normale.z /= scalez;
		tabsomm[i].normale.normer();
		tabsomm[i] = rotation*tabsomm[i];
		tabsomm[i].pos = tabsomm[i].pos + origine;
	}

}


int Scene3D::editeobjet(unsigned short numobjetselect, int nbsplines2D, Spline2D** pSplines2D, Objet3D *&pobjetselect){

	Celluleobj* p;

	for (p = objets.L ; p != NULL ; p = p->suiv)
		if (p->pobjet->numero == numobjetselect){
			Objet3D * nouvelobjet = p->pobjet->edite(nbsplines2D, pSplines2D);
			if (nouvelobjet != NULL){
				if (objetselect==p->pobjet)
					pobjetselect =  nouvelobjet;
				nouvelobjet->numero=numobjetselect;

				delete p->pobjet;
				p->pobjet=nouvelobjet;

			//	Matrice Minv = tabcam[nocamselect]->M;
				Matrice Minv = tabcam[nocamselect]->M.t();

				Point3D O =  Minv * tabcam[nocamselect]->pos;



				int i;
				for (i = 0 ; i < p->pobjet->nbsomm ; i++){	

					p->pobjet->tabsomm[i] = Minv * p->pobjet->tabsomm[i];
					p->pobjet->tabsomm[i].pos = p->pobjet->tabsomm[i].pos - O;
				}
				objetselect=NULL;
				return IDOK;
			}
			return IDCANCEL;
		}
	return IDCANCEL;	
}



Objet3D *Cloche::edite(int nbsplines2D, Spline2D** pSplines2D){



	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	material.InitMaterialDialog(dlgMat1, dlgMat2);


	CMultiTextureDialog dlgText;
	textures.initTextureDialog(dlgText);


	CBoxGeomPropPage dlg;

	dlg.m_cx = origine.x;
	dlg.m_cy = origine.y;
	dlg.m_cz = origine.z;
	dlg.m_dimx = (xmax-xmin)*scalex;
	dlg.m_dimy = (ymax-ymin)*scaley;
	dlg.m_dimz = (zmax-zmin)*scalez;
	dlg.m_rotx = rotx;
	dlg.m_roty = roty;
	dlg.m_rotz = rotz;
	dlg.m_nbmerid = nbmerid;




	CPropertySheet sheet(CString("Sphere"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);

	

	int ret = sheet.DoModal();




	if (ret != IDCANCEL){
		TextureData text(dlgText.m_withtexture_s ? 1 : 0, dlgText.m_textname_s, 
						dlgText.m_withtexture_t ? 1 : 0, dlgText.m_textname_t, 
						dlgText.m_withtexture_b ? 1 : 0, dlgText.m_textname_b,
						dlgText.m_withbump_s ? 1 : 0, dlgText.m_bumpname_s,
						dlgText.m_withbump_t ? 1 : 0, dlgText.m_bumpname_t, 
						dlgText.m_withbump_b ? 1 : 0, dlgText.m_bumpname_b, 
						dlgText.m_factorbump);
		MaterialData mater(dlgMat1, dlgMat2);
		return (Objet3D*) new Cloche(dlg.m_cx, dlg.m_cy, dlg.m_cz,
						dlg.m_dimx, dlg.m_dimy, dlg.m_dimz,
						dlg.m_nbmerid,
						dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
						1,1,1,
						mater, text);
	}

	return NULL;

}


Objet3D *Sphere::edite(int nbsplines2D, Spline2D** pSplines2D){

	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	material.InitMaterialDialog(dlgMat1, dlgMat2);

	CTexturePropPage dlgText;
	textures.initTextureDialog(dlgText);


	CSphereGeomPropPage dlg;

	dlg.m_cx = (float)origine.x;
	dlg.m_cy = (float)origine.y;
	dlg.m_cz = (float)origine.z;
	dlg.m_radius = (float)rayon;
	dlg.m_nbmerid = nbmeridien;
	dlg.m_nbparal = nbparallele;
	dlg.m_rotx = (float)rotx;
	dlg.m_roty = (float)roty;
	dlg.m_rotz = (float)rotz;
	dlg.m_scax = (float)scalex;
	dlg.m_scay = (float)scaley;
	dlg.m_scaz = (float)scalez;





	CPropertySheet sheet(CString("Sphere"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);

	

	int ret = sheet.DoModal();



	if (ret != IDCANCEL){
		TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
						false, CString(""), false, CString(""),
						dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
						false, CString(""), false, CString(""), dlgText.m_factorbump);

		MaterialData mater(dlgMat1, dlgMat2);
		return new Sphere(dlg.m_cx, dlg.m_cy, dlg.m_cz, 
								dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
								dlg.m_scax, dlg.m_scay, dlg.m_scaz,
								dlg.m_radius, dlg.m_nbparal, dlg.m_nbmerid,
								mater, text);

	}



	return NULL;
}


Objet3D *Cylinrevol::edite(int nbsplines2D, Spline2D** pSplines2D){

	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	material.InitMaterialDialog(dlgMat1, dlgMat2);


	CTexturePropPage dlgText;
	textures.initTextureDialog(dlgText);


	CCylRevolGeomPropPage dlg;

	dlg.m_radius = (float)rayon;
	dlg.m_hauteur = (float)hauteur;
	dlg.m_nbmerid = nbmeridien;
	dlg.m_cx = (float)origine.x;
	dlg.m_cy = (float)origine.y;
	dlg.m_cz = (float)origine.z;
	dlg.m_rotx = (float)rotx;
	dlg.m_roty = (float)roty;
	dlg.m_rotz = (float)rotz;
	dlg.m_scax = (float)scalex;
	dlg.m_scay = (float)scaley;
	dlg.m_scaz = (float)scalez;






	CPropertySheet sheet(CString("Cylinder"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);

	

	int ret = sheet.DoModal();





	if (ret != IDCANCEL){
		TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
						false, CString(""), false, CString(""),
						dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
						false, CString(""), false, CString(""), dlgText.m_factorbump);

		MaterialData mater(dlgMat1, dlgMat2);
		return new Cylinrevol(dlg.m_cx, dlg.m_cy, dlg.m_cz, 
								dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
								dlg.m_scax, dlg.m_scay, dlg.m_scaz,
								dlg.m_radius, dlg.m_hauteur,
								dlg.m_nbmerid,
								mater, text);
	}


	return NULL;

}


Objet3D *Conerevoltronq::edite(int nbsplines2D, Spline2D** pSplines2D){

	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	material.InitMaterialDialog(dlgMat1, dlgMat2);


	CTexturePropPage dlgText;
	textures.initTextureDialog(dlgText);


	CConeRevolPropPage dlg;

	dlg.m_bottomradius = (float)rayon;
	dlg.m_hauttronq = (float)hauteur;
	dlg.m_topradius = rayontronq;
	dlg.m_nbmerid = nbmeridien;
	dlg.m_nbparal = nbparallele;
	dlg.m_cx = (float)origine.x;
	dlg.m_cy = (float)origine.y;
	dlg.m_cz = (float)origine.z;
	dlg.m_rotx = (float)rotx;
	dlg.m_roty = (float)roty;
	dlg.m_rotz = (float)rotz;
	dlg.m_scax = (float)scalex;
	dlg.m_scay = (float)scaley;
	dlg.m_scaz = (float)scalez;






	CPropertySheet sheet(CString("Cone"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);

	

	int ret = sheet.DoModal();






	if (ret != IDCANCEL){
		TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
						false, CString(""), false, CString(""),
						dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
						false, CString(""), false, CString(""), dlgText.m_factorbump);
		
		MaterialData mater(dlgMat1, dlgMat2);
		return new Conerevoltronq(dlg.m_cx, dlg.m_cy, dlg.m_cz, 
								dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
								dlg.m_scax, dlg.m_scay, dlg.m_scaz,
								dlg.m_bottomradius, dlg.m_hauttronq, dlg.m_topradius,
								dlg.m_nbmerid, dlg.m_nbparal,
								mater, text);

	}

	return NULL;

}


Objet3D *Polyedre::edite(int nbsplines2D, Spline2D** pSplines2D){

	AfxMessageBox(CString("Edition de polyedres non implementee (sorry)"));

	return NULL;

}



Objet3D *Cylinspline::edite(int nbsplines2D, Spline2D** pSplines2D){


	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	material.InitMaterialDialog(dlgMat1, dlgMat2);


	CTexturePropPage dlgText;
	textures.initTextureDialog(dlgText);


	CCylinSplineGeomPropPage dlg;
	dlg.m_nomsp = spline2d->getnom();
	dlg.m_hauteur = hauteur;
	dlg.m_topreduction = topreduction;
	dlg.m_echanthauteur = nbparal;
	dlg.m_echantspline = echantillonage;
	dlg.m_cx = (float)origine.x;
	dlg.m_cy = (float)origine.y;
	dlg.m_cz = (float)origine.z;
	dlg.m_rotx = (float)rotx;
	dlg.m_roty = (float)roty;
	dlg.m_rotz = (float)rotz;
	dlg.m_scax = (float)scalex;
	dlg.m_scay = (float)scaley;
	dlg.m_scaz = (float)scalez;


	CPropertySheet sheet(CString("Cylindric surface"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);





	int ret = IDOK;
	bool correctspline = false;
	while (!correctspline && ret != IDCANCEL){
		ret = sheet.DoModal();
		if (ret != IDCANCEL){
			Spline2D *sp = NULL;
			for (int i = 0 ; i < nbsplines2D ; i++)
				if (pSplines2D[i]->getnom() == dlg.m_nomsp){
					sp = pSplines2D[i];
					break;
				}
		
			if (sp == NULL || sp->gettype() != SPLINE2D_FERMEE){
				AfxMessageBox(CString("Nom de spline 2D introuvable ou\n spline 2D de type incorrect"));
			}else{
				correctspline = true;
				TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
								false, CString(""), false, CString(""),
								dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
								false, CString(""), false, CString(""), dlgText.m_factorbump);

				MaterialData mater(dlgMat1, dlgMat2);

				return new Cylinspline(dlg.m_cx, dlg.m_cy, dlg.m_cz,
									dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
									dlg.m_scax, dlg.m_scay, dlg.m_scaz,
									sp, dlg.m_hauteur,
									dlg.m_topreduction,
									dlg.m_echantspline,
									dlg.m_echanthauteur,
									mater, text);
			}
		}
	}


	return NULL;

}


Objet3D *Spline3Drevol::edite(int nbsplines2D, Spline2D** pSplines2D){


	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	material.InitMaterialDialog(dlgMat1, dlgMat2);


	CTexturePropPage dlgText;
	textures.initTextureDialog(dlgText);


	CSplineRevolGeometryPropPage dlg;
	dlg.m_nomsp = spline2d->getnom();
	dlg.m_echantcercle = nbmeridiens;
	dlg.m_echantspline = echantillonage;
	dlg.m_cx = (float)origine.x;
	dlg.m_cy = (float)origine.y;
	dlg.m_cz = (float)origine.z;
	dlg.m_rotx = (float)rotx;
	dlg.m_roty = (float)roty;
	dlg.m_rotz = (float)rotz;
	dlg.m_scax = (float)scalex;
	dlg.m_scay = (float)scaley;
	dlg.m_scaz = (float)scalez;



	CPropertySheet sheet(CString("Revolution surface"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);





	int ret = IDOK;
	bool correctspline = false;
	while (!correctspline && ret != IDCANCEL){
		ret = sheet.DoModal();
		if (ret != IDCANCEL){
			Spline2D *sp = NULL;
			for (int i = 0 ; i < nbsplines2D ; i++)
				if (pSplines2D[i]->getnom() == dlg.m_nomsp){
					sp = pSplines2D[i];
					break;
				}
		
			if (sp == NULL || sp->gettype() != SPLINE2D_OUVERTE){
				AfxMessageBox(CString("Nom de spline 2D introuvable ou\n spline 2D de type incorrect"));
			}else{
				correctspline = true;
				TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
								false, CString(""), false, CString(""),
								dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
								false, CString(""), false, CString(""), dlgText.m_factorbump);

				MaterialData mater(dlgMat1, dlgMat2);
				return new Spline3Drevol(dlg.m_cx, dlg.m_cy, dlg.m_cz,
									dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
									dlg.m_scax, dlg.m_scay, dlg.m_scaz,
									sp, 
									dlg.m_echantcercle, dlg.m_echantspline,
									mater, text);
			}
		}
	}

	return NULL;

}


Objet3D *Spline3Dextru::edite(int nbsplines2D, Spline2D** pSplines2D){

	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	material.InitMaterialDialog(dlgMat1, dlgMat2);

	CTexturePropPage dlgText;
	textures.initTextureDialog(dlgText);

	CExtrusionGeomPropPage dlg;

	dlg.m_nomforme = spline2dforme->getnom();
	dlg.m_nomame = spline2dame->getnom();
	dlg.m_echantame = echantame;
	dlg.m_echantforme = echantforme;
	dlg.m_scashape = scalea;
	dlg.m_cx = (float)origine.x;
	dlg.m_cy = (float)origine.y;
	dlg.m_cz = (float)origine.z;
	dlg.m_rotx = (float)rotx;
	dlg.m_roty = (float)roty;
	dlg.m_rotz = (float)rotz;
	dlg.m_scax = (float)scalex;
	dlg.m_scay = (float)scaley;
	dlg.m_scaz = (float)scalez;
	dlg.m_withchanfrein=chanfrein;
	dlg.m_pcba=propchanf_ba;
	dlg.m_pcbf=propchanf_bf;
	dlg.m_pcea=propchanf_ea;
	dlg.m_pcef=propchanf_ef;



	CPropertySheet sheet(CString("Extrusion surface"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);






	int ret = IDOK;
	bool correctspline = false;
	while (!correctspline && ret != IDCANCEL){
		ret = sheet.DoModal();
		if (ret != IDCANCEL){
			Spline2D *spf = NULL;
			for (int i = 0 ; i < nbsplines2D ; i++)
				if (pSplines2D[i]->getnom() == dlg.m_nomforme){
					spf = pSplines2D[i];
					break;
				}
		
			Spline2D *spa = NULL;
			for (int i = 0 ; i < nbsplines2D ; i++)
				if (pSplines2D[i]->getnom() == dlg.m_nomame){
					spa = pSplines2D[i];
					break;
				}
			if (spf == NULL || spf->gettype() != SPLINE2D_FERMEE ||
				spa == NULL || spa->gettype() != SPLINE2D_OUVERTE){
				AfxMessageBox(CString("Nom de spline 2D introuvable ou\n spline 2D de type incorrect"));
			}else{
				correctspline = true;
				TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
								false, CString(""), false, CString(""),
								dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
								false, CString(""), false, CString(""), dlgText.m_factorbump);

				MaterialData mater(dlgMat1, dlgMat2);
				return new Spline3Dextru(dlg.m_cx, dlg.m_cy, dlg.m_cz,
									dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
									dlg.m_scax, dlg.m_scay, dlg.m_scaz,
									spf, spa, dlg.m_scashape,
									dlg.m_echantforme, dlg.m_echantame,
									dlg.m_withchanfrein ? 1 : 0, dlg.m_pcba, dlg.m_pcbf, dlg.m_pcea, dlg.m_pcef,
									mater, text);
			}
		}
	}


	return NULL;

}




Objet3D *Spline3DEditable::edite(int nbsplines2D, Spline2D** pSplines2D){


	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	material.InitMaterialDialog(dlgMat1, dlgMat2);


	CTexturePropPage dlgText;
	textures.initTextureDialog(dlgText);


	CSplineRevolGeometryPropPage dlg;
	dlg.m_nomsp = "";
	dlg.m_echantcercle = nbmeridiens;
	dlg.m_echantspline = nbparalleles;
	dlg.m_cx = (float)origine.x;
	dlg.m_cy = (float)origine.y;
	dlg.m_cz = (float)origine.z;
	dlg.m_rotx = (float)rotx;
	dlg.m_roty = (float)roty;
	dlg.m_rotz = (float)rotz;
	dlg.m_scax = (float)scalex;
	dlg.m_scay = (float)scaley;
	dlg.m_scaz = (float)scalez;



	CPropertySheet sheet(CString("Deformable sphere"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);





	int ret = IDOK;
		ret = sheet.DoModal();
	if (ret != IDCANCEL){
		TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
						false, CString(""), false, CString(""),
						dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
						false, CString(""), false, CString(""), dlgText.m_factorbump);

		MaterialData mater(dlgMat1, dlgMat2);

		return new Spline3DEditable(dlg.m_cx, dlg.m_cy, dlg.m_cz,
									dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
									dlg.m_scax, dlg.m_scay, dlg.m_scaz,
									dlg.m_echantcercle, dlg.m_echantspline, surface, 
									mater, text);
	}
		


	return NULL;

}






int Scene3D::editsourcelum(int nosource){
	CNewLight dlg;


	// traduction des coordonnees de la source lumineuse dans le repere de la camera :
	Matrice Minv = (tabcam[nocamselect]->M.t());  // matrice de passage
	Point3D O =  Minv * tabcam[nocamselect]->pos;  
//	tablum[nblum].pos = Minv * tablum[nblum].pos;
//	tablum[nblum].pos = tablum[nblum].pos - O;

	Point3D posscene = tabcam[nocamselect]->M * tablum[nosource].pos + tabcam[nocamselect]->pos;
	dlg.m_posx = (float)posscene.x;
	dlg.m_posy = (float)posscene.y;
	dlg.m_posz = (float)posscene.z;
	dlg.m_coulR = (float)tablum[nosource].intensiteR;
	dlg.m_coulG = (float)tablum[nosource].intensiteG;
	dlg.m_coulB = (float)tablum[nosource].intensiteB;
	dlg.m_directionnel=tablum[nosource].directionnel;
	dlg.m_dirx = tablum[nosource].direction.x;
	dlg.m_diry = tablum[nosource].direction.y;
	dlg.m_dirz = tablum[nosource].direction.z;
	dlg.m_exposantdirect = tablum[nosource].exponentdirect;;
	dlg.m_attenuation = tablum[nosource].attenuationdist;
	dlg.m_c1 = tablum[nosource].c1;
	dlg.m_c2 = tablum[nosource].c2;
	dlg.m_c3 = tablum[nosource].c3;


	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
		posscene.x = dlg.m_posx;
		posscene.y = dlg.m_posy;
		posscene.z = dlg.m_posz;
		tablum[nosource].pos = Minv * posscene;
		tablum[nosource].pos = tablum[nosource].pos - O;
		tablum[nosource].intensiteR = dlg.m_coulR;
		tablum[nosource].intensiteG = dlg.m_coulG;
		tablum[nosource].intensiteB = dlg.m_coulB;
		tablum[nosource].directionnel = dlg.m_directionnel?true:false;
		tablum[nosource].direction = Point3D(dlg.m_dirx,dlg.m_diry,dlg.m_dirz);
		tablum[nosource].exponentdirect = dlg.m_exposantdirect;
		tablum[nosource].attenuationdist = dlg.m_attenuation?true:false;
		tablum[nosource].c1 = dlg.m_c1;
		tablum[nosource].c2 = dlg.m_c2;
		tablum[nosource].c3 = dlg.m_c3;
		tablum[nosource].directionnorme = tablum[nosource].direction;
		tablum[nosource].directionnorme.normer();
		tablum[nosource].directionnorme = tabcam[nocamselect]->M.t()*tablum[nosource].directionnorme;
	}

	return ret;
}



int Scene3D::supprimeobjet(unsigned short* numobjetselect, int nbobjetselect){

	Celluleobj *p, *preced=NULL;


	int nobobjsuppr = 0;
	for (int i=0 ; i < nbobjetselect ; i++){
		preced=NULL;
		for (p = objets.L ; p != NULL && p->pobjet->numero != numobjetselect[i] ; p = p->suiv)
			preced = p;

		if (p==NULL)
			continue;

		if (preced != NULL)
			preced->suiv = p->suiv;
		else
			objets.L = p->suiv;

		delete p->pobjet;
		delete p;
	}

	int count=0;
	for (p=objets.L ; p!=NULL ; p=p->suiv)
		count++;

	Celluleobj *q = NULL;
	for (int i=0 ; i < count ; i++){
		for (p=objets.L ; p!=NULL ; p=p->suiv){
			if (p->suiv == q)
				break;
		}
		q=p;
		for (int j = 0 ; j <= objets.L->pobjet->numero ; j++)
			if (nogroupe[j] == p->pobjet->numero)
				nogroupe[j] = i+1;
		nogroupe[i+1] = nogroupe[p->pobjet->numero];
		p->pobjet->numero = i+1;
	}

	for (int i = 0 ; i < nbobjetselect ; i++)
		nogroupe[count+1+i] = count+1+i;

	objetselect=NULL;


	return 1;
}


int Scene3D::supprimesourcelum(int nosource){

	for (int i = nosource+1 ; i < nblum ; i++)
		tablum[i-1] = tablum[i];
	nblum--;

	return 1;
}

