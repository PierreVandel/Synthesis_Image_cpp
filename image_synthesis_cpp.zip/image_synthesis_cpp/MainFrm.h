// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__52084268_4674_11D3_B1CB_C729201D0A7D__INCLUDED_)
#define AFX_MAINFRM_H__52084268_4674_11D3_B1CB_C729201D0A7D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

//#ifndef EnumView
//enum EnumView {VUE3D=1, SPLINE2D=2};
//#endif


class CMainFrame : public CMDIFrameWnd
{

	CMDIChildWnd* pchildvuesp3D;

	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

// Attributes
public:

	HICON icone_sp2d;
	HICON icone_sp3d;
	HICON icone_sphere;


// Operations
public:
	enum EnumView {VUE3D=1, SPLINE2D=2, SPLIN3D=3};
	void SwitchToView(EnumView nView);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnAffichageSpline2dview();
	afx_msg void OnUpdateAffichageSpline2dview(CCmdUI* pCmdUI);
	afx_msg void OnEditeFormeObjetspline();
	afx_msg void OnUpdateEditeFormeObjetspline(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	afx_msg LRESULT OnDetruireVueSp3D(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnSetChildVueSp3DNull(WPARAM wParam, LPARAM lParam);

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__52084268_4674_11D3_B1CB_C729201D0A7D__INCLUDED_)
