// Synth.h : main header file for the SYNTH application
//

#if !defined(AFX_SYNTH_H__52084264_4674_11D3_B1CB_C729201D0A7D__INCLUDED_)
#define AFX_SYNTH_H__52084264_4674_11D3_B1CB_C729201D0A7D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSynthApp:
// See Synth.cpp for the implementation of this class
//

class CSynthApp : public CWinApp
{
public:
	CMultiDocTemplate *m_pTemplateSpline2D;
	CMultiDocTemplate *m_pTemplateSpline3D;
	virtual int ExitInstance();
	CSynthApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSynthApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSynthApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SYNTH_H__52084264_4674_11D3_B1CB_C729201D0A7D__INCLUDED_)
