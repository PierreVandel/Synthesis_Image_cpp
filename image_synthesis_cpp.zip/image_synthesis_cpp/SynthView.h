// SynthView.h : interface of the CSynthView class
//
/////////////////////////////////////////////////////////////////////////////

#include "Scene3DRay.h"
#include "imcouleur.h"

#if !defined(AFX_SYNTHVIEW_H__5208426E_4674_11D3_B1CB_C729201D0A7D__INCLUDED_)
#define AFX_SYNTHVIEW_H__5208426E_4674_11D3_B1CB_C729201D0A7D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define MAXDIMX 1200  // Dimensions max de la fenetre graphique
#define MAXDIMY 900  // idem

#define ID_MYPROGRESSBAR 500

class CControlCameraDlg;
class CControlNavigatDialog;
class CMyProgresDialog;
class CDisplayImageWnd;


class CSynthView : public CView
{

	friend class CMainFrame;

	CRect clientrect;  // Rectangle de la fenetre graphique
	int dimx, dimy;   // Dimensions effectives de la fenetre graphique

//public:
	Scene3DRay scene;  // unique scene en memoire (voir Scene3D.h)


	bool activinsere;  // Pour mise � jour des menus de l'interface

	int percentcalcul;
	bool firstphase;
	CProgressCtrl *progres;
	CMyProgresDialog* progressdlg;

	bool raytracingfinished;

	CDisplayImageWnd *displaywnd;
	imcouleur bitmap_render;

	friend UINT ThreadSceneLoading(LPVOID p);
	friend UINT ThreadRayTracing(LPVOID pParam);
	bool enableuseinterface;
	bool enabledraw;
private:
	int nbobjetselect;  // vrai si un objet est selectionne
	unsigned short numobjetselect[100]; // numero de l'objet selectionne
	bool ctrlpressed;


	CControlCameraDlg * m_pDlg;  // pointeur sur boite dialogue non modale pour controles camera
	CControlNavigatDialog * m_pDlgnavigat;  // pointeur sur boite dialogue non modale navigation
	double steptrans, steprot;  // donn�es de cette boite de dialogue
	double steptransnavigat, steprotnavigat;  // donn�es de cette boite de dialogue



	bool modeaffichageradio;

	CString rendudiscretenvoisources;

public:


	imcouleur bitmap_dib;  // Bitmap DIB pour affichage a l'ecran (voir imcouleur.h et imcouleur.cpp)


	CSynthView();
protected: // create from serialization only
	DECLARE_DYNCREATE(CSynthView)

// Attributes
public:
	CSynthDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSynthView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
	virtual ~CSynthView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSynthView)
	afx_msg void OnFileNouvsce();
	afx_msg void OnInsereSphere();
	afx_msg void OnUpdateInsereSphere(CCmdUI* pCmdUI);
	afx_msg void OnInsereCylRevol();
	afx_msg void OnUpdateInsereCylRevol(CCmdUI* pCmdUI);
	afx_msg void OnInsereConerevol();
	afx_msg void OnUpdateInsereConerevol(CCmdUI* pCmdUI);
	afx_msg void OnInsereLight();
	afx_msg void OnUpdateInsereLight(CCmdUI* pCmdUI);
	afx_msg void OnAffichageControlcam();
	afx_msg void OnUpdateAffichageControlcam(CCmdUI* pCmdUI);
	afx_msg void OnAffichageSelectcam();
	afx_msg void OnUpdateAffichageSelectcam(CCmdUI* pCmdUI);
	afx_msg void OnAffichageRedresserCam();
	afx_msg void OnUpdateAffichageRedresserCam(CCmdUI* pCmdUI);
	afx_msg void OnEditCamera();
	afx_msg void OnUpdateEditCamera(CCmdUI* pCmdUI);
	afx_msg void OnFileSortiebmp();
	afx_msg void OnUpdateFileSortiebmp(CCmdUI* pCmdUI);
	afx_msg void OnAffichageSimplezbuffer();
	afx_msg void OnUpdateAffichageSimplezbuffer(CCmdUI* pCmdUI);
	afx_msg void OnAffichageDoublezbuffer();
	afx_msg void OnUpdateAffichageDoublezbuffer(CCmdUI* pCmdUI);
	afx_msg void OnAffichageTriplezbuffer();
	afx_msg void OnUpdateAffichageTriplezbuffer(CCmdUI* pCmdUI);
	afx_msg void OnInsereSpline3dCyl();
	afx_msg void OnInsereNouvboite();
	afx_msg void OnUpdateInsereNouvboite(CCmdUI* pCmdUI);
	afx_msg void OnFileExportPolytext();
	afx_msg void OnUpdateFileExportPolytext(CCmdUI* pCmdUI);
	afx_msg void OnFichierImportPolytext();
	afx_msg void OnUpdateInsereSpline3dCyl(CCmdUI* pCmdUI);
	afx_msg void OnInsereSpline3dRevol();
	afx_msg void OnUpdateInsereSpline3dRevol(CCmdUI* pCmdUI);
	afx_msg void OnAffichageVoirAxes();
	afx_msg void OnUpdateAffichageVoirAxes(CCmdUI* pCmdUI);
	afx_msg void OnInsereSplineExtrusion();
	afx_msg void OnUpdateInsereSplineExtrusion(CCmdUI* pCmdUI);
	afx_msg void OnAffichageOptionsclairementLumireambiante();
	afx_msg void OnUpdateAffichageOptionsclairementLumireambiante(CCmdUI* pCmdUI);
	afx_msg void OnAffichageOptionsclairementPhong();
	afx_msg void OnUpdateAffichageOptionsclairementPhong(CCmdUI* pCmdUI);
	afx_msg void OnAffichageOptionsclairementReflexiondifuse();
	afx_msg void OnUpdateAffichageOptionsclairementReflexiondifuse(CCmdUI* pCmdUI);
	afx_msg void OnAffichageOptionsclairementReflexionspeculaire();
	afx_msg void OnUpdateAffichageOptionsclairementReflexionspeculaire(CCmdUI* pCmdUI);
	afx_msg void OnAffichageOptionsclairementTextures();
	afx_msg void OnUpdateAffichageOptionsclairementTextures(CCmdUI* pCmdUI);
	afx_msg void OnRenduCalculerImage();
	afx_msg void OnUpdateRenduCalculerImage(CCmdUI* pCmdUI);
	afx_msg void OnRenduOptioneclairementReflexionsinterobjets();
	afx_msg void OnUpdateRenduOptioneclairementReflexionsinterobjets(CCmdUI* pCmdUI);
	afx_msg void OnRenduOptioneclairementRefraction();
	afx_msg void OnUpdateRenduOptioneclairementRefraction(CCmdUI* pCmdUI);
	afx_msg void OnRenduOptioneclairementTransmissionDiffuse();
	afx_msg void OnUpdateRenduOptioneclairementTransmissionDiffuse(CCmdUI* pCmdUI);
	afx_msg void OnRenduOptioneclairementTransmissionSpeculaire();
	afx_msg void OnUpdateRenduOptioneclairementTransmissionSpeculaire(CCmdUI* pCmdUI);
	afx_msg void OnRenduOptionsclairementLumireambiante();
	afx_msg void OnUpdateRenduOptionsclairementLumireambiante(CCmdUI* pCmdUI);
	afx_msg void OnRenduOptionsclairementPhong();
	afx_msg void OnUpdateRenduOptionsclairementPhong(CCmdUI* pCmdUI);
	afx_msg void OnRenduOptionsclairementReflexiondifuse();
	afx_msg void OnUpdateRenduOptionsclairementReflexiondifuse(CCmdUI* pCmdUI);
	afx_msg void OnRenduOptionsclairementReflexionspeculaire();
	afx_msg void OnUpdateRenduOptionsclairementReflexionspeculaire(CCmdUI* pCmdUI);
	afx_msg void OnRenduOptionsclairementTextures();
	afx_msg void OnUpdateRenduOptionsclairementTextures(CCmdUI* pCmdUI);
	afx_msg void OnRenduOptionsglobales();
	afx_msg void OnUpdateRenduOptionsglobales(CCmdUI* pCmdUI);
	afx_msg void OnRenduSurech1();
	afx_msg void OnUpdateRenduSurech1(CCmdUI* pCmdUI);
	afx_msg void OnRenduSurech2();
	afx_msg void OnUpdateRenduSurech2(CCmdUI* pCmdUI);
	afx_msg void OnRenduSurech3();
	afx_msg void OnUpdateRenduSurech3(CCmdUI* pCmdUI);
	afx_msg void OnRenduOptioneclairementOmbres();
	afx_msg void OnUpdateRenduOptioneclairementOmbres(CCmdUI* pCmdUI);
	afx_msg void OnAffichageOptionsclairementGouraud();
	afx_msg void OnUpdateAffichageOptionsclairementGouraud(CCmdUI* pCmdUI);
	afx_msg void OnControlesNavigat();
	afx_msg void OnUpdateControlesNavigat(CCmdUI* pCmdUI);
	afx_msg void OnEditObjet3d();
	afx_msg void OnUpdateEditObjet3d(CCmdUI* pCmdUI);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnEditSource();
	afx_msg void OnUpdateEditSource(CCmdUI* pCmdUI);
	afx_msg void OnEditSupprimerObjet();
	afx_msg void OnUpdateEditSupprimerObjet(CCmdUI* pCmdUI);
	afx_msg void OnEditSupprimerSource();
	afx_msg void OnUpdateEditSupprimerSource(CCmdUI* pCmdUI);
	afx_msg void OnInsereSplinerevolEditable();
	afx_msg void OnUpdateInsereSplinerevolEditable(CCmdUI* pCmdUI);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnImportObjet3d();
	afx_msg void OnUpdateImportObjet3d(CCmdUI* pCmdUI);
	afx_msg void OnExportObjet3d();
	afx_msg void OnUpdateExportObjet3d(CCmdUI* pCmdUI);
	afx_msg void OnFileOpen();
	afx_msg void OnFileSave();
	afx_msg void OnUpdateFileSave(CCmdUI* pCmdUI);
	afx_msg void OnFileSaveAs();
	afx_msg void OnUpdateFileSaveAs(CCmdUI* pCmdUI);
	afx_msg void OnAdaptAntialiazing();
	afx_msg void OnUpdateAdaptAntialiazing(CCmdUI* pCmdUI);
	afx_msg void OnInsereCylindrevolDeformable();
	afx_msg void OnUpdateInsereCylindrevolDeformable(CCmdUI* pCmdUI);
	afx_msg void OnInsereDeformableCylExtru();
	afx_msg void OnUpdateInsereDeformableCylExtru(CCmdUI* pCmdUI);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnEditGroupobjets();
	afx_msg void OnUpdateEditGroupobjets(CCmdUI* pCmdUI);
	afx_msg void OnEditTransform();
	afx_msg void OnUpdateEditTransform(CCmdUI* pCmdUI);
	afx_msg void OnEditUngroupObjects();
	afx_msg void OnUpdateEditUngroupObjects(CCmdUI* pCmdUI);
	afx_msg void OnInsereExtrusionSphere();
	afx_msg void OnUpdateInsereExtrusionSphere(CCmdUI* pCmdUI);
	afx_msg void OnInsereExtrusionTorus();
	afx_msg void OnUpdateInsereExtrusionTorus(CCmdUI* pCmdUI);
	afx_msg void OnInsereDeformRevolTorus();
	afx_msg void OnUpdateInsereDeformRevolTorus(CCmdUI* pCmdUI);
	afx_msg void OnAffichageOptionsclairementBumpmaps();
	afx_msg void OnUpdateAffichageOptionsclairementBumpmaps(CCmdUI* pCmdUI);
	afx_msg void OnRenduContinueRaytra();
	afx_msg void OnUpdateRenduContinueRaytra(CCmdUI* pCmdUI);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnUpdateFileNouvsce(CCmdUI* pCmdUI);
	afx_msg void OnOpenDisplayWindow();
	afx_msg void OnUpdateOpenDisplayWindow(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFichierImportPolytext(CCmdUI* pCmdUI);
	//}}AFX_MSG
	afx_msg LRESULT OnModifCamera(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnModifCameraNavigat(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnSetRenderDisplayWndNull(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SynthView.cpp
inline CSynthDoc* CSynthView::GetDocument()
   { return (CSynthDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SYNTHVIEW_H__5208426E_4674_11D3_B1CB_C729201D0A7D__INCLUDED_)
