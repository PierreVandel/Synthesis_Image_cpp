// Scene3DRay.cpp: implementation of the Scene3DRay class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Synth.h"
#include "Scene3DRay.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Scene3DRay::Scene3DRay(int dimx, int dimy, 
			double xmin, double xmax, double ymin, double ymax, double zmin, double zmax,
			int nbcamera, double hautcam, int nblumiere,
			double lumambR, double lumambG, double lumambB,
			double fR, double fG, double fB)
//			int nbmaxsp2D, int nbsp2D, Spline2D **psp2D)
			:Scene3D(dimx, dimy, 
					xmin, xmax, ymin, ymax, zmin, zmax,
					nbcamera, hautcam, nblumiere,
					lumambR, lumambG, lumambB,
					fR, fG, fB)
//					nbmaxsp2D, nbsp2D, psp2D)
{
	InitOptions();
}


void Scene3DRay::InitOptions(void){
	renduetatsurechant = 0;
	seuiladaptraytra = 15;
	renduetatvoiraxes=true;
	renduenableambiante=true;
	renduenablephong=true;
	renduenabledifuse=true;
	renduenablespecular=true;
	renduenabletexture=true;
	renduenabletransmdifuse=true;
	renduenabletransmspecular=true;
	renduenablerefraction=true;
	renduenablereflexion=true;
	renduenableombres=true;
	profrecurmax = 15;
	pourcenneglig = 5;

	usebsp=true;
	minsizecell = 0.1; 
	maxdepth = 100;
	nbfacesmax = 10;
	rapportthreshold = 0.02;

	dimrenderwindowx = 0;
	dimrenderwindowy = 0;
	bufferRenderR = NULL;
	bufferRenderG = NULL;
	bufferRenderB = NULL;
	dim2Drendux = 3*dimrenderwindowx;
	dim2Drenduy = 3*dimrenderwindowy;
	setdim2Drender(dimfenetrex,dimfenetrey);

	enableextendedlight = false;
	nbrayslights = 1;

	save_calcul=false;
	calcul_is_continuing=false;


}



void Scene3DRay::destruction(void){



	Scene3D::destruction();

}

bool Scene3DRay::setdim2D(int dimx, int dimy)
{
	return Scene3D::setdim2D(dimx,dimy);

	

}


bool Scene3DRay::setdim2Drender(int dimx, int dimy)
{

	if (dimx == dimrenderwindowx && dimy == dimrenderwindowy)
		return true;

	int ancdimrenderx = dim2Drendux;
	int ancdimrendery = dim2Drenduy;
	int ancdimfenx = dimrenderwindowx;
	int ancdimfeny = dimrenderwindowy;
	bool probleme_memoire = false;

	dimrenderwindowx = dimx;
	dimrenderwindowy = dimy;

	dim2Drendux = (renduetatsurechant==0?3:renduetatsurechant)*dimrenderwindowx;
	dim2Drenduy = (renduetatsurechant==0?3:renduetatsurechant)*dimrenderwindowy;

	liberer(bufferRenderB, 3*ancdimfenx);
	liberer(bufferRenderG, 3*ancdimfenx);
	liberer(bufferRenderR, 3*ancdimfenx);


	bufferRenderR = alloueruchar2D(3*dimrenderwindowx, 3*dimrenderwindowy);
	if (bufferRenderR == NULL)
		probleme_memoire = true;

	bufferRenderG = alloueruchar2D(3*dimrenderwindowx, 3*dimrenderwindowy);
	if (bufferRenderG == NULL)
		probleme_memoire = true;

	bufferRenderB = alloueruchar2D(3*dimrenderwindowx, 3*dimrenderwindowy);
	if (bufferRenderB == NULL)
		probleme_memoire = true;


	if (probleme_memoire){
		liberer(numobjets, dimrenderwindowx);
		liberer(bufferRenderB, 3*dimrenderwindowx);
		liberer(bufferRenderG, 3*dimrenderwindowx);
		liberer(bufferRenderR, 3*dimrenderwindowx);
		liberer(minz, dim2Drendux);
		dim2Drendux = 0;
		dim2Drenduy = 0;
		dimrenderwindowx = 0;
		dimrenderwindowy = 0;
	}

	return probleme_memoire;
}



