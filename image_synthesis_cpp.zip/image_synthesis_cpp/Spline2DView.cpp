// Spline2DView.cpp : implementation file
//

#include "stdafx.h"
#include "Synth.h"
#include "SynthDoc.h"
#include "Spline2DView.h"
#include "SplineDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Spline2DView

IMPLEMENT_DYNCREATE(Spline2DView, CView)

Spline2DView::Spline2DView()
{

	nbcontrolpoints=0;

	splinefermeeenconstruction = false;
	splinerevolenconstruction = false;
	splineouverteenconstruction=false;
}

Spline2DView::~Spline2DView()
{
}


BEGIN_MESSAGE_MAP(Spline2DView, CView)
	//{{AFX_MSG_MAP(Spline2DView)
	ON_COMMAND(ID_INSERE_SPLINE2D_FERMEE, OnInsereSpline2dFermee)
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(ID_INSERE_SPLINE2D_REVOL, OnInsereSpline2dRevol)
	ON_COMMAND(ID_INSERE_SPLINEOUVERTE, OnInsereSplineouverte)
	ON_UPDATE_COMMAND_UI(ID_INSERE_SPLINEOUVERTE, OnUpdateInsereSplineouverte)
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Spline2DView drawing

void Spline2DView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here

	if (splinefermeeenconstruction)
		dessinevuesplinefermee(pDC);
	else
		if (splinerevolenconstruction)
			dessinevuesplinerevol(pDC);
		else
			if (splineouverteenconstruction)
				dessinevuesplinefermee(pDC);
}

void Spline2DView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();

	CWnd *mainwindow = AfxGetMainWnd();
	CRect rect;

	CWnd *fils = mainwindow->GetWindow(GW_CHILD);
	fils->GetClientRect(rect);

	CWnd *parent = GetParent();

	parent->MoveWindow(rect.left+rect.Width()/2, rect.top, rect.Width()/2, rect.Height(), false);

	
	// TODO: Add your specialized code here and/or call the base class
//	CSynthDoc* pDoc = (CSynthDoc*)GetDocument();
//	this->SetIcon(pDoc->icone_sp2d,false);
}

/////////////////////////////////////////////////////////////////////////////
// Spline2DView diagnostics

#ifdef _DEBUG
void Spline2DView::AssertValid() const
{
	CView::AssertValid();
}

void Spline2DView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// Spline2DView message handlers


void Spline2DView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

//	boutongaucheenfonce=true;

	if (nbcontrolpoints > MAX_NB_CTRL_POINTS)
		return;

	CSynthDoc * pdoc = (CSynthDoc*)GetDocument();

	if (splinefermeeenconstruction){
		double hauteur_effect = pdoc->hauteur_effective;
		double facteur_echelle = hauteur_effect / (rectvuespline2D.bottom - originevuespline2D.y);

		CPoint point1;
		point1.x = point.x - originevuespline2D.x; 
		point1.y = -(point.y - originevuespline2D.y); 
		point1.x = (int)(point1.x * facteur_echelle); 
		point1.y = (int)(point1.y * facteur_echelle); 
		if (nbcontrolpoints == 0){
			tableauctrlpoints[nbcontrolpoints++] = point1;
			preced_ctrlpoint = point;
		}
		else{
			CClientDC clientdc(this);
			CPen pen(PS_SOLID, 1, RGB(0,0,0));
			CPen* psauvepen = (CPen*) clientdc.SelectObject(&pen);
			clientdc.MoveTo(preced_ctrlpoint.x, preced_ctrlpoint.y);
			tableauctrlpoints[nbcontrolpoints++] = point1;
			preced_ctrlpoint = point;
			clientdc.LineTo(point);
			clientdc.SelectObject(psauvepen);
			pen.DeleteObject();
		}

	}
	
	if (splinerevolenconstruction){
		double hauteur_effect = pdoc->hauteur_effective;
		double facteur_echelle = hauteur_effect / (rectvuespline2D.bottom - originevuespline2D.y);

		if (nbcontrolpoints == 0)
			point.x = 20;     // meme horizontale, x=20;
		CPoint point1;
		point1.x = point.x - originevuespline2D.x; 
		point1.y = -(point.y - originevuespline2D.y); 
		point1.x = (int)(point1.x * facteur_echelle); 
		point1.y = (int)(point1.y * facteur_echelle); 
		if (nbcontrolpoints == 0){
			tableauctrlpoints[nbcontrolpoints++] = point1;
			tableauctrlpoints[nbcontrolpoints++] = point1;
			tableauctrlpoints[nbcontrolpoints++] = point1;
			preced_ctrlpoint = point;
		}
		else{
			CClientDC clientdc(this);
			CPen pen(PS_SOLID, 1, RGB(0,0,0));
			CPen* psauvepen = (CPen*) clientdc.SelectObject(&pen);
			clientdc.MoveTo(preced_ctrlpoint.x, preced_ctrlpoint.y);
			tableauctrlpoints[nbcontrolpoints++] = point1;
			preced_ctrlpoint = point;
			clientdc.LineTo(point);
			clientdc.SelectObject(psauvepen);
			pen.DeleteObject();
		}

	}


	if (splineouverteenconstruction){
		double hauteur_effect = pdoc->hauteur_effective;
		double facteur_echelle = hauteur_effect / (rectvuespline2D.bottom - originevuespline2D.y);


		CPoint point1;
		point1.x = point.x - originevuespline2D.x; 
		point1.y = -(point.y - originevuespline2D.y); 
		point1.x = (int)(point1.x * facteur_echelle); 
		point1.y = (int)(point1.y * facteur_echelle); 
		if (nbcontrolpoints == 0){
			tableauctrlpoints[nbcontrolpoints++] = point1;
			tableauctrlpoints[nbcontrolpoints++] = point1;
			tableauctrlpoints[nbcontrolpoints++] = point1;
			preced_ctrlpoint = point;
		}
		else{
			CClientDC clientdc(this);
			CPen pen(PS_SOLID, 1, RGB(0,0,0));
			CPen* psauvepen = (CPen*) clientdc.SelectObject(&pen);
			clientdc.MoveTo(preced_ctrlpoint.x, preced_ctrlpoint.y);
			tableauctrlpoints[nbcontrolpoints++] = point1;
			preced_ctrlpoint = point;
			clientdc.LineTo(point);
			clientdc.SelectObject(psauvepen);
			pen.DeleteObject();
		}
	}


	CView::OnLButtonDown(nFlags, point);
}

void Spline2DView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CView::OnRButtonDown(nFlags, point);

	if (splinefermeeenconstruction){
		splinefermeeenconstruction = false;
		if (nbcontrolpoints <= 2){
			nbcontrolpoints = 0;
		}else{

			CSpline2DDialog dlg;
			dlg.m_nom = "";
			int ret = dlg.DoModal();
		
			if (ret == IDCANCEL){
				splinefermeeenconstruction = false;
				nbcontrolpoints = 0;
				return;
			}

			CClientDC clientdc(this);

			CRect rect;
			GetClientRect(rect);
			CBrush brosse(RGB(255,255,255));
			CRgn region;
			region.CreateRectRgnIndirect(&rect);
			clientdc.FillRgn(&region, &brosse);
			brosse.DeleteObject();
			dessinevuesplinefermee(&clientdc);

			CPen blackpen(PS_SOLID, 1, RGB(0,0,0));
			CPen* psauvepen = (CPen*) clientdc.SelectObject(&blackpen);

			CSynthDoc * pdoc = (CSynthDoc*)GetDocument();
			double hauteur_effect = pdoc->hauteur_effective;
			double facteur_echelle = hauteur_effect / (rectvuespline2D.bottom - originevuespline2D.y);
			CPoint point1;
			point1.x = point.x - originevuespline2D.x; 
			point1.y = -(point.y - originevuespline2D.y); 
			point1.x = (int)(point1.x * facteur_echelle); 
			point1.y = (int)(point1.y * facteur_echelle); 

			tableauctrlpoints[nbcontrolpoints++] = point1;
			preced_ctrlpoint = point;
			CSynthDoc *pDoc = (CSynthDoc*) GetDocument();
			pDoc->p_Splines2D[pDoc->nbSpline2D] = new SplineCubiquefermee(tableauctrlpoints, nbcontrolpoints, dlg.m_nom,pDoc->nbSpline2D);
			pDoc->nbSpline2D++;



			pDoc->p_Splines2D[pDoc->nbSpline2D-1]->affiche(clientdc, originevuespline2D, facteur_echelle);
			clientdc.SelectObject(psauvepen);
			blackpen.DeleteObject();
		}
	}



	if (splinerevolenconstruction || splineouverteenconstruction){
		if (nbcontrolpoints <= 3){
			nbcontrolpoints = 0;
		}else{

			CSpline2DDialog dlg;
			dlg.m_nom = "";
			int ret = dlg.DoModal();
		
			if (ret == IDCANCEL){
				splinerevolenconstruction = false;
				splineouverteenconstruction=false;
				nbcontrolpoints = 0;
				return;
			}
			CClientDC clientdc(this);

			CRect rect;
			GetClientRect(rect);
			CBrush brosse(RGB(255,255,255));
			CRgn region;
			region.CreateRectRgnIndirect(&rect);
			clientdc.FillRgn(&region, &brosse);
			brosse.DeleteObject();
			if (splinerevolenconstruction)
				dessinevuesplinerevol(&clientdc);
			else
				dessinevuesplinefermee(&clientdc);

			CPen blackpen(PS_SOLID, 1, RGB(0,0,0));
			CPen* psauvepen = (CPen*) clientdc.SelectObject(&blackpen);

			CSynthDoc * pdoc = (CSynthDoc*)GetDocument();
			double hauteur_effect = pdoc->hauteur_effective;
			double facteur_echelle = hauteur_effect / (rectvuespline2D.bottom - originevuespline2D.y);
			
			if (splinerevolenconstruction)
				point.x = 20;  // meme horizontale, x=20
			CPoint point1;
			point1.x = point.x - originevuespline2D.x; 
			point1.y = -(point.y - originevuespline2D.y); 
			point1.x = (int)(point1.x * facteur_echelle); 
			point1.y = (int)(point1.y * facteur_echelle); 

			tableauctrlpoints[nbcontrolpoints++] = point1;
			tableauctrlpoints[nbcontrolpoints++] = point1;
			tableauctrlpoints[nbcontrolpoints++] = point1;
		
			if (splinerevolenconstruction && tableauctrlpoints[nbcontrolpoints-1].y < tableauctrlpoints[0].y){
				for (int i=0 ; i < (nbcontrolpoints)/2 ; i++){
					Pixel interm = tableauctrlpoints[nbcontrolpoints-1-i];
					tableauctrlpoints[nbcontrolpoints-1-i] = tableauctrlpoints[i];
					tableauctrlpoints[i] = interm;
				}
			}
			preced_ctrlpoint = point;
			CSynthDoc *pDoc = (CSynthDoc*) GetDocument();
			pDoc->p_Splines2D[pDoc->nbSpline2D] = new SplineCubiqueouverte(tableauctrlpoints, nbcontrolpoints, dlg.m_nom, pDoc->nbSpline2D);
			pDoc->nbSpline2D++;


			pDoc->p_Splines2D[pDoc->nbSpline2D-1]->affiche(clientdc, originevuespline2D, facteur_echelle);
			clientdc.SelectObject(psauvepen);
			blackpen.DeleteObject();
		}
		splinerevolenconstruction = splineouverteenconstruction = false;
	}

	CSynthDoc *pDoc = (CSynthDoc*) GetDocument();
	if (pDoc->nbSpline2D >= pDoc->nbmaxSpline2D)
		AfxMessageBox(CString("depassement du nombre de splines,\n la scene est trop complexe\nContactez le concepteur du programme."));
}



void Spline2DView::dessinevuesplinefermee(CDC * pDC)
{

	GetClientRect(&rectvuespline2D);

	originevuespline2D = Pixel((rectvuespline2D.right + rectvuespline2D.left)/2, 
								(rectvuespline2D.bottom + rectvuespline2D.top)/2);

	CSynthDoc * pdoc = (CSynthDoc*)GetDocument();

	double hauteur_effect = pdoc->hauteur_effective;

//	int multiple_de_10;
//	for (multiple_de_10 = 1 ; multiple_de_10 < hauteur_effect/10 ; multiple_de_10 *= 10)
//		;

	CPen pen(PS_SOLID, 1, RGB(0,0,0));
	pDC->SelectObject(pen);
	pDC->MoveTo(originevuespline2D.x, rectvuespline2D.bottom);

	pDC->LineTo(originevuespline2D.x, rectvuespline2D.top);

	pDC->MoveTo(rectvuespline2D.left, originevuespline2D.y);

	pDC->LineTo(rectvuespline2D.right, originevuespline2D.y);

	pDC->SetTextColor(RGB(0,0,0));
	pDC->TextOut(originevuespline2D.x + 10, originevuespline2D.y + 10, CString("0"));

	char buffer[100];

	// Legende axe des y :
	_itoa((int)(-hauteur_effect*0.9), buffer, 10);
	pDC->TextOut(originevuespline2D.x + 10, 
				 (int)(originevuespline2D.y + 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2),
				CString( buffer));
	pDC->MoveTo(originevuespline2D.x + 4, 
				 (int)(originevuespline2D.y + 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2));

	pDC->LineTo(originevuespline2D.x - 4, 
				 (int)(originevuespline2D.y + 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2));

	
	_itoa((int)(hauteur_effect*0.9), buffer, 10);
	pDC->TextOut(originevuespline2D.x + 10, 
				 (int)(originevuespline2D.y - 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2),
				 CString(buffer));
	pDC->MoveTo(originevuespline2D.x + 4, 
				 (int)(originevuespline2D.y - 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2));

	pDC->LineTo(originevuespline2D.x - 4, 
				 (int)(originevuespline2D.y - 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2));


	// Legende axe des x :
	_itoa((int)(hauteur_effect*0.9), buffer, 10);
	pDC->TextOut((int)(originevuespline2D.x + 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2),
				 originevuespline2D.y + 10,
				 CString(buffer));
	pDC->MoveTo((int)(originevuespline2D.x + 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2),
				 originevuespline2D.y + 4);

	pDC->LineTo((int)(originevuespline2D.x + 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2),
				 originevuespline2D.y - 4);

	
	_itoa((int)(-hauteur_effect*0.9), buffer, 10);
	pDC->TextOut((int)(originevuespline2D.x - 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2),
				 originevuespline2D.y + 10,
				 CString(buffer));
	pDC->MoveTo((int)(originevuespline2D.x - 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2),
				 originevuespline2D.y + 4);

	pDC->LineTo((int)(originevuespline2D.x - 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2),
				 originevuespline2D.y - 4);

	DeleteObject(pen);


	DeleteObject(pen);


}




void Spline2DView::dessinevuesplinerevol(CDC * pDC)
{

	GetClientRect(&rectvuespline2D);

	originevuespline2D = Pixel(rectvuespline2D.left+20, 
								(rectvuespline2D.bottom + rectvuespline2D.top)/2);

	CSynthDoc * pdoc = (CSynthDoc*)GetDocument();

	double hauteur_effect = pdoc->hauteur_effective;

//	int multiple_de_10;
//	for (multiple_de_10 = 1 ; multiple_de_10 < hauteur_effect/10 ; multiple_de_10 *= 10)
//		;

	CPen pen(PS_SOLID, 1, RGB(0,0,0));
	pDC->SelectObject(pen);
	pDC->MoveTo(originevuespline2D.x, rectvuespline2D.bottom);

	pDC->LineTo(originevuespline2D.x, rectvuespline2D.top);

	pDC->MoveTo(rectvuespline2D.left, originevuespline2D.y);

	pDC->LineTo(rectvuespline2D.right, originevuespline2D.y);

	pDC->SetTextColor(RGB(0,0,0));
	pDC->TextOut(originevuespline2D.x + 10, originevuespline2D.y + 10, CString("0"));

	char buffer[100];

	// Legende axe des y :
	_itoa((int)(-hauteur_effect*0.9), buffer, 10);
	pDC->TextOut(originevuespline2D.x + 10, 
				 (int)(originevuespline2D.y + 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2),
				 CString(buffer));
	pDC->MoveTo(originevuespline2D.x + 4, 
				 (int)(originevuespline2D.y + 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2));

	pDC->LineTo(originevuespline2D.x - 4, 
				 (int)(originevuespline2D.y + 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2));

	
	_itoa((int)(hauteur_effect*0.9), buffer, 10);
	pDC->TextOut(originevuespline2D.x + 10, 
				 (int)(originevuespline2D.y - 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2),
				 CString(buffer));
	pDC->MoveTo(originevuespline2D.x + 4, 
				 (int)(originevuespline2D.y - 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2));

	pDC->LineTo(originevuespline2D.x - 4, 
				 (int)(originevuespline2D.y - 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2));


	// Legende axe des x :
	_itoa((int)(hauteur_effect*0.9), buffer, 10);
	pDC->TextOut((int)(originevuespline2D.x + 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2),
				 originevuespline2D.y + 10,
				 CString(buffer));
	pDC->MoveTo((int)(originevuespline2D.x + 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2),
				 originevuespline2D.y + 4);

	pDC->LineTo((int)(originevuespline2D.x + 0.9*(rectvuespline2D.bottom - rectvuespline2D.top)/2),
				 originevuespline2D.y - 4);

	

}


void Spline2DView::OnInsereSpline2dFermee() 
{
	// TODO: Add your command handler code here
	
	nbcontrolpoints = 0;

	splinefermeeenconstruction = true;
	splinerevolenconstruction = false;
	splineouverteenconstruction = false;
	
	CClientDC clientdc(this);
	CRect rect;
	GetClientRect(rect);
	CBrush brosse(RGB(255,255,255));
	CRgn region;
	region.CreateRectRgnIndirect(&rect);
	clientdc.FillRgn(&region, &brosse);
	brosse.DeleteObject();
	dessinevuesplinefermee(&clientdc);

}

void Spline2DView::OnInsereSpline2dRevol() 
{
	// TODO: Add your command handler code here
	
	nbcontrolpoints = 0;

	splinefermeeenconstruction = false;
	splinerevolenconstruction = true;
	splineouverteenconstruction = false;
	
	CClientDC clientdc(this);
	CRect rect;
	GetClientRect(rect);
	CBrush brosse(RGB(255,255,255));
	CRgn region;
	region.CreateRectRgnIndirect(&rect);
	clientdc.FillRgn(&region, &brosse);
	brosse.DeleteObject();
	dessinevuesplinerevol(&clientdc);
}

void Spline2DView::OnInsereSplineouverte() 
{
	// TODO: Add your command handler code here

	nbcontrolpoints = 0;

	splinefermeeenconstruction = false;
	splinerevolenconstruction = false;
	splineouverteenconstruction = true;
	
	CClientDC clientdc(this);
	CRect rect;
	GetClientRect(rect);
	CBrush brosse(RGB(255,255,255));
	CRgn region;
	region.CreateRectRgnIndirect(&rect);
	clientdc.FillRgn(&region, &brosse);
	brosse.DeleteObject();
	dessinevuesplinefermee(&clientdc);

}

void Spline2DView::OnUpdateInsereSplineouverte(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(true);
}

void Spline2DView::OnSetFocus(CWnd* pOldWnd) 
{
	CView::OnSetFocus(pOldWnd);
	
	// TODO: Add your message handler code here
	CSynthDoc* pDoc = (CSynthDoc*)GetDocument();

	pDoc->vue_active = SPLINE2D;

}

