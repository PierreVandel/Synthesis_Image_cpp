// Scene3DRay.h: interface for the Scene3DRay class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCENE3DRAY_H__3941CA74_BAB3_4F6B_AE7E_3007A40C15B2__INCLUDED_)
#define AFX_SCENE3DRAY_H__3941CA74_BAB3_4F6B_AE7E_3007A40C15B2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Scene3D.h"
#include "BSPtree.h"
#include "imcouleur.h"

class Scene3DRay  : public Scene3D
{

	friend class ObjectToIntersect;

protected:
		// donnees relatives au rendu par lancer de rayons :

	int dimrenderwindowx, dimrenderwindowy;
	int dim2Drendux, dim2Drenduy;  // dimension des buffers pour lancer de rayon
	unsigned char **bufferRenderR;
	unsigned char **bufferRenderG;
	unsigned char **bufferRenderB;
//	imcouleur bitmap_render;

	char renduetatsurechant;   // surechantillonage adaptative = 0, simple = 1, double = 2, triple = 3 
	bool renduetatvoiraxes;   
	bool renduenableambiante;
	bool renduenablephong;
	bool renduenabledifuse;
	bool renduenablespecular;
	bool renduenabletexture;
	bool renduenabletransmdifuse;
	bool renduenabletransmspecular;
	bool renduenablerefraction;
	bool renduenablereflexion;
	bool renduenableombres;

	double seuiladaptraytra;

	bool enableextendedlight;
	int nbrayslights;

	bool save_calcul;
	bool calcul_is_continuing;
	char nomcal[300];



	int profrecurmax;
	double pourcenneglig;


	// donnees pour arbres BSP :
	Boiteenglobante globalboundingbox;
	BSPtree *bsptree;

	double minsizecell; 
	int maxdepth; 
	int nbfacesmax;
	double rapportthreshold;
	bool usebsp;

	Objet3D *extendedsources[100];
	int nbextendedsources;
public:
	Scene3DRay(void):Scene3D(){}

	// initialisation de la scene et initialisation des cameras :
	Scene3DRay(int dimx, int dimy, 
			double xmin, double xmax, double ymin, double ymax, double zmin, double zmax,
			int nbcamera, double hautcam, int nblumiere,
			double lumambR, double lumambG, double lumambB,
			double fR, double fG, double fB);
//			int nbmaxsp2D, int nbsp2D, Spline2D **psp2D);

	void InitOptions(void);
	void destruction(void);

	void charge_scene(ifstream& fich, Spline2D **& ppSpline2D, int& nbmaxsp2d, int& nbsp2d, int dimx, int dimy);

	void calcultermedifus(Point3D p3d, double &R, double &G, double &B, Objet3D &objet){}
	bool getenableradiosite(void){return false;}
	virtual void calculsommetsgouraudradio(bool envoiesourcediscret){}
		// compute diffuse term at some point p3d of the surface of an object


	// fonctions pour le lancer de rayons :
	bool setdim2D(int dimx, int dimy);
	bool setdim2Drender(int dimx, int dimy);

	void setrenduetatsurechant(char etat){renduetatsurechant = etat;
											if (etat==0){
												dim2Drendux = 3*dimrenderwindowx;
												dim2Drenduy = 3*dimrenderwindowy;
											}else{
												dim2Drendux = renduetatsurechant*dimrenderwindowx;
												dim2Drenduy = renduetatsurechant*dimrenderwindowy;
											}
										}
	void setrenduetatvoiraxes(bool etat){renduetatvoiraxes = etat;}
	void setrenduenableambiante(bool etat){renduenableambiante = etat;}
	void setrenduenablephong(bool etat){renduenablephong = etat;}
	void setrenduenabledifuse(bool etat){renduenabledifuse = etat;}
	void setrenduenablespecular(bool etat){renduenablespecular = etat;}
	void setrenduenabletexture(bool etat){renduenabletexture = etat;}
	void setrenduenabletransmdifuse(bool etat){renduenabletransmdifuse = etat;}
	void setrenduenabletransmspecular(bool etat){renduenabletransmspecular = etat;}
	void setrenduenablerefraction(bool etat){renduenablerefraction = etat;}
	void setrenduenablereflexion(bool etat){renduenablereflexion = etat;}
	void setrenduenableombres(bool etat){renduenableombres = etat;}
	void setprofrecurmax(int etat){profrecurmax = etat;}
	void setpourcenneglig(double etat){pourcenneglig = etat;}
	void setseuiladaptraytra(double etat){seuiladaptraytra = etat;}
	void setenableextendedlight(bool etat){enableextendedlight=etat;}
	void setnbrayslights(int etat){nbrayslights=etat;}
	void setsave_calcul(bool etat){save_calcul=etat;}
	void setcalcul_is_continuing(bool etat){calcul_is_continuing=etat;}
	void setnomcal(char *s){strcpy(nomcal,s);}

	void getrenderwindow(int & dx, int &dy){dx = dimrenderwindowx; dy = dimrenderwindowy;}
	char getrenduetatsurechant(void){return renduetatsurechant;}
	bool getrenduetatvoiraxes(void){return renduetatvoiraxes;}
	bool getrenduenableambiante(void){return renduenableambiante;}
	bool getrenduenablephong(void){return renduenablephong;}
	bool getrenduenabledifuse(void){return renduenabledifuse;}
	bool getrenduenablespecular(void){return renduenablespecular;}
	bool getrenduenabletexture(void){return renduenabletexture;}
	bool getrenduenabletransmdifuse(void){return renduenabletransmdifuse;}
	bool getrenduenabletransmspecular(void){return renduenabletransmspecular;}
	bool getrenduenablerefraction(void){return renduenablerefraction;}
	bool getrenduenablereflexion(void){return renduenablereflexion;}
	bool getrenduenableombres(void){return renduenableombres;}
	int getprofrecurmax(void){return profrecurmax;}
	double getpourcenneglig(void){return pourcenneglig;}
	double getseuiladaptraytra(void){return seuiladaptraytra;}
	bool getenableextendedlight(void){return enableextendedlight;}
	int getnbrayslights(void){return nbrayslights;}
	int getsave_calcul(void){return save_calcul;}
	bool getcalcul_is_continuing(void){return calcul_is_continuing;}

	
	void setminsizecell(double etat){minsizecell = etat;}
	void setmaxdepth(int etat){maxdepth = etat;}
	void setnbfacesmax(int etat){nbfacesmax = etat;}
	void setrapportthreshold(double etat){rapportthreshold = etat;}
	void setusebsp(bool etat){usebsp = etat;}

	double getminsizecell(void){return minsizecell;}
	int getmaxdepth(void){return maxdepth;}
	int getnbfacesmax(void){return nbfacesmax;}
	double getrapportthreshold(void){return rapportthreshold;}
	bool getusebsp(void){return usebsp;}

	void calculboitesenglobantes(void);
	void detruitboitesenglobantes(void);

	// slow intersection functions :
	bool calculintersectproche(
						Rayon ray,
						int &numobjetproche,  // numero de l'objet intersect�
						ResultIntersect &resplusproche,  // resultat de l'intersection
						double &min_t_inter, // distance de l'objet le plus proche � l'observateur
						Objet3D * &objetintersecte);
	bool testshadow(Rayon ray, double distance, double & attenuation);

	void lancer_general(imcouleur& bitmap_bitmap_render, bool gouraud, int & percentcalcul);
	void continue_lancer_general(bool gouraud, char* nomc);
	bool lancer_recursif(Rayon ray, Couleur & I,
						int prof, int prof_max, double pourcent, double pourcent_min, 
						bool gouraud);
	void initbitmapfrombuffersray(imcouleur &bitmap_dib, unsigned char** subdivise);
	void convertcaltobitmap(char* nomcal, char* nombmp);




	// fonctions pour les arbres BSP :

	void precomputeboundingboxes(void);
	void constructBSPtree(bool gouraud);
	void destroyBSP(void);

	// intersection function using BSP trees :
	bool calculintersectprocheBSP(
						Rayon ray,
						int &numobjetproche,  // numero de l'objet intersect�
						ResultIntersect &resplusproche,  // resultat de l'intersection
						double &min_t_inter, // distance de l'objet le plus proche � l'observateur
						Objet3D * &objetintersecte,
						bool testshadow, double& attenuation, double distance,
						bool gouraud);


	void computePointLight(Objet3D* objetintersecte, Couleur couleur, bool transparent, bool reflexiontotale, 
								Point3D p3d, 
							  Point3D V, Point3D normale, Point3D R, Point3D T, Couleur & I);
	void computeExtendedLight(Objet3D* objetintersecte, Couleur couleur, bool transparent, bool reflexiontotale, 
								Point3D p3d, 
							  Point3D V, Point3D normale, Point3D R, Point3D T, Couleur & Iglobal);

};

#endif // !defined(AFX_SCENE3DRAY_H__3941CA74_BAB3_4F6B_AE7E_3007A40C15B2__INCLUDED_)
