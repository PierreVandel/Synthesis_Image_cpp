// BSPtree.h: interface for the BSPtree class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BSPTREE_H__D56AD33B_091F_45D1_B963_81E8E1BA0689__INCLUDED_)
#define AFX_BSPTREE_H__D56AD33B_091F_45D1_B963_81E8E1BA0689__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "Objet3D.h"



class ObjectToIntersect{


public:
	Facette *face;
	Objet3D *object;
	bool simpleobject;
	Point3D p3d;
	Point3D normale;
	Couleur couleur;
	Intensitesgouraud intens;

	double t;
	bool intersect;
	bool alreadytested;

public:
	ObjectToIntersect(void){object=NULL; simpleobject=false; face=NULL; intersect=false; alreadytested=false; t=1e6;}

	bool calculintersectprocheBSP(
						Rayon ray,
						ResultIntersect &resplusproche,  // resultat de l'intersection
						double &min_t_inter, // distance de l'objet le plus proche � l'observateur
						Objet3D * &objetintersecte,
						bool testshadow, double& attenuation, double distance,
						bool gouraud, Scene3DRay * scene,
						Boiteenglobante box);
};



class BSPGenericNode{

public:
	virtual void recursiveconstruction(double minsizecell, int maxdepth, int nbfacesmax, double rapport,
										ObjectToIntersect **allthefaces, int totalnbfaces,
										int depth)=0;

	virtual bool calculintersectprocheBSP(
						Rayon ray,
						ResultIntersect &resplusproche,  // resultat de l'intersection
						double &min_t_inter, // distance de l'objet le plus proche � l'observateur
						Objet3D * &objetintersecte,
						bool testshadow, double& attenuation, double distance,
						bool gouraud, Scene3DRay * scene)=0;

	virtual void destroy(void)=0;
};


class BSPRegularNode : public BSPGenericNode{

	BSPGenericNode * (child[2][2][2]);

	Boiteenglobante boundingbox;

public:

	BSPRegularNode(Boiteenglobante box){boundingbox=box;
										for (int i = 0 ; i < 8 ; i++)
											child[i&1][(i&2)>>1][(i&4)>>2]=NULL;
										}

	void recursiveconstruction(double minsizecell, int maxdepth, int nbfacesmax, double rapport,
								ObjectToIntersect **allthefaces, int totalnbfaces,
								int depth);
	bool calculintersectprocheBSP(
						Rayon ray,
						ResultIntersect &resplusproche,  // resultat de l'intersection
						double &min_t_inter, // distance de l'objet le plus proche � l'observateur
						Objet3D * &objetintersecte,
						bool testshadow, double& attenuation, double distance,
						bool gouraud, Scene3DRay * scene);

	void destroy(void){for (int i = 0 ; i < 8 ; i++)
								if (child[i&1][(i&2)>>1][(i&4)>>2] != NULL)
											child[i&1][(i&2)>>1][(i&4)>>2]->destroy();
						}
};




class BSPObjectLeave : public BSPGenericNode{

	ObjectToIntersect **listfaces;
	int nbfaces;

	Boiteenglobante boundingbox;

public:
	void recursiveconstruction(double minsizecell, int maxdepth, int nbfacesmax, double rapport,
								ObjectToIntersect **allthefaces, int totalnbfaces,
								int depth){}
	BSPObjectLeave(Boiteenglobante box, ObjectToIntersect **listf, int nbf){
													boundingbox = box;
													nbfaces=nbf;
													listfaces=new ObjectToIntersect *[nbfaces];
													for (int i = 0 ; i < nbfaces ; i++)
														listfaces[i] = listf[i];
													}
	bool calculintersectprocheBSP(
						Rayon ray,
						ResultIntersect &resplusproche,  // resultat de l'intersection
						double &min_t_inter, // distance de l'objet le plus proche � l'observateur
						Objet3D * &objetintersecte,
						bool testshadow, double& attenuation, double distance,
						bool gouraud, Scene3DRay * scene);

	void destroy(void){if (nbfaces != 0 && listfaces != NULL) delete [] listfaces;}
};




class BSPtree  
{	
	friend class Scene3DRay;

	BSPGenericNode *T;

	ObjectToIntersect **allthefaces;
	int totalnbfaces;
	int nbsimpleobjects;


public:
	BSPtree();
	virtual ~BSPtree();

	BSPtree(Boiteenglobante &box);

	void construction(double minsizecell, int maxdepth, int nbfacesmax, double rapport);
};

#endif // !defined(AFX_BSPTREE_H__D56AD33B_091F_45D1_B963_81E8E1BA0689__INCLUDED_)
