#include "stdafx.h"
#include "Synth.h"
#include "Scene3DRay.h"
#include "imcouleur.h"
#include "Rayon.h"
#include "CDisplayImageWnd.h"



#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif




bool Scene3DRay::lancer_recursif(Rayon ray , Couleur & I,
							  int prof, int prof_max, double pourcent, double pourcent_min,
							  bool gouraud){

	// condition d'arr�t de la r�cursivit� :
	if (pourcent < pourcent_min || prof > prof_max){
		I.R = I.G = I.B = 0.0;
		return false;
	}
	

	bool intersectobjet=false; // vrai si le rayon intersecte un objet

	int numobjetproche;  // numero de l'objet intersect�
	Objet3D * objetintersecte;  // pointeur sur l'objet intersect�
	bool interieur;  // vrai si l'origine du rayon est int�rieure � l'objet

	ResultIntersect resinter, resplusproche;  // resultat de l'intersection
	double min_t_inter = INFINI; // distance de l'objet le plus proche � l'observateur

	double rubish;

	// Calcul de l'objet intersecte le plus proche :
	if (!usebsp)
		intersectobjet = calculintersectproche(ray, numobjetproche, 
												resplusproche, min_t_inter, objetintersecte);
	else
		intersectobjet = calculintersectprocheBSP(ray, numobjetproche, 
												resplusproche, min_t_inter, objetintersecte,
															false, rubish, 0,
															gouraud);



	// si le rayon n'intersection aucun objet -> couleur du fond
	if (!intersectobjet){
		I.R=fondR; I.G = fondG, I.B = fondB;
		return false;
	}

	// on d�termine si l'origine du rayon est � l'interueur de l'objet le plus proche detect� :
	// pour cela, on parcourt le tableau des objets contenant l'origine du rayon
	interieur = false;
	for (int indobj = 0 ; indobj < ray.nbobjetscontenant ; indobj++){
		if (objetintersecte == ray.objetscontenant[indobj])
			interieur = true;
	}


	// variables pour l'�clairement
	Point3D normale, R, V;

	// point d'intersection du rayon avec l'objet :
	Point3D p3d = (ray.origine + resplusproche.t_inter*ray.vectdirect);

	// couleur donn�e par l'algo d'intersection, r�sultant �ventuellement d'une texture
	Couleur couleur = resplusproche.couleur;

	// initialisation de l'intensit� parcourant le rayon :
	if (renduenableambiante && !getenableradiosite()){
				// terme de lumi�re ambiante :
		I.R = lumambiantR*objetintersecte->material.coef_ambiant*couleur.R;
		I.G = lumambiantG*objetintersecte->material.coef_ambiant*couleur.G;
		I.B = lumambiantB*objetintersecte->material.coef_ambiant*couleur.B;
	}else
		{I.R=I.G=I.B=0;}

	if (!getenableradiosite()){
		I.R += objetintersecte->material.emitance;
		I.G += objetintersecte->material.emitance;
		I.B += objetintersecte->material.emitance;
	}

	if (getenableradiosite()){
		if (gouraud){
			I=calculcouleurgouraud(resplusproche.intens, resplusproche.couleur);
		}
		else{
			calcultermedifus(p3d, I.R, I.G, I.B, *objetintersecte);

		}
	}

	// termes lies aux nblum sources lumineuses du tableau tablum :

	normale =  resplusproche.normale;
	if (normale*(p3d-ray.origine) > 0)
		normale = -normale;


	V = ray.origine-p3d;  // vecteur du rayon incident
	V.normer();


	// calcul de la direction du rayon r�fl�chi :
	R = 2*(V*normale)*normale - V;
	
	// calcul de la direction du rayon transmis :
	Point3D T;
	bool reflexiontotale = false;
	bool transparent =	(renduenablerefraction && objetintersecte->material.coef_ti != 0) || 
						(renduenabletransmdifuse && objetintersecte->material.coef_td != 0) ||
						(renduenabletransmspecular && objetintersecte->material.coef_ts != 0);

	if (transparent){
		double etarl = interieur ? 
							objetintersecte->material.indice_refr / ((ray.nbobjetscontenant==0) ? 1.0 : ray.objetscontenant[ray.nbobjetscontenant-1]->material.indice_refr)  
							: ((ray.nbobjetscontenant==0) ? 1.0 : ray.objetscontenant[ray.nbobjetscontenant-1]->material.indice_refr) / objetintersecte->material.indice_refr;
		double NV = normale*V;
		double sousradical = 1 - etarl*etarl*(1 - NV*NV);
		if (sousradical< 0)
			reflexiontotale=true;
		else
			reflexiontotale=false;

		double costetaT; 
		if (!reflexiontotale){
			costetaT = sqrt(sousradical);
			T = (etarl*NV - costetaT)*normale - etarl*V;
		}
	}


	if (enableextendedlight){
		computeExtendedLight(objetintersecte, couleur, transparent, reflexiontotale, p3d, 
			 V, normale, R, T, I);
	}else{
		computePointLight(objetintersecte, couleur, transparent, reflexiontotale, p3d, 
			 V, normale, R, T, I);
	}

	
	// r�flexions et transmissions id�ales :

	Couleur IP;
	double coefR = 0;

	if (renduenablerefraction && objetintersecte->material.coef_ti != 0){
		double i1 = acos(V*normale);
		double i2 = acos(T*(-normale));
		double sini1mi2 = sin(i1-i2);
		double sini1pi2 = sin(i1+i2);
		double cosi1mi2 = cos(i1-i2);
		double cosi1pi2 = cos(i1+i2);
		double fraction = (sini1mi2*sini1mi2)/(sini1pi2*sini1pi2);
		coefR = 0.5*(fraction + fraction*(cosi1pi2*cosi1pi2)/(cosi1mi2*cosi1mi2));
		if (coefR > 1)
			coefR = 1;
	}


	// rayon transmis :
	if (renduenablerefraction &&
		transparent && 
		!reflexiontotale && 
		objetintersecte->material.coef_ti != 0 
		&& 
		coefR < 1){

		// rayon transmis
		Rayon ray1;
		ray1.origine=p3d;
		ray1.vectdirect=T;

		// Tableau des objets contenant l'origine du rayon transmis
		ray1.nbobjetscontenant = 0;
		if (interieur){
			for (int indobj = 0 ; indobj < ray.nbobjetscontenant ; indobj++)
				if (ray.objetscontenant[indobj] != objetintersecte)
					ray1.objetscontenant[ray1.nbobjetscontenant++] = ray.objetscontenant[indobj];
		}else{
			for (int indobj = 0 ; indobj < ray.nbobjetscontenant ; indobj++)
				ray1.objetscontenant[ray1.nbobjetscontenant++] = ray.objetscontenant[indobj];
			ray1.objetscontenant[ray1.nbobjetscontenant++] = objetintersecte;
		}

		// appel r�cursif :
		lancer_recursif(ray1, IP, 
						prof+1, prof_max, pourcent*objetintersecte->material.coef_ti*(1-coefR), pourcent_min, gouraud);

		// ajout du terme d'intensit�
		I.R+=objetintersecte->material.coef_ti*(1-coefR)*IP.R;
		I.G+=objetintersecte->material.coef_ti*(1-coefR)*IP.G;
		I.B+=objetintersecte->material.coef_ti*(1-coefR)*IP.B;
	}
	
	// rayon reflechi :
	if (renduenablereflexion && objetintersecte->material.coef_ri != 0 || coefR > 0){
		// rayon r�fl�chi :
		Rayon ray2;
		ray2.origine=p3d;
		ray2.vectdirect= R;
		ray2.vectdirect.normer();

		// Tableau des objets contenant l'origine du rayon transmis
		ray2.nbobjetscontenant = 0;
		for (int indobj = 0 ; indobj < ray.nbobjetscontenant ; indobj++)
			ray2.objetscontenant[ray2.nbobjetscontenant++] = ray.objetscontenant[indobj];

		// appel r�cursif :
		lancer_recursif(ray2, IP, 
						prof+1, prof_max, pourcent*(objetintersecte->material.coef_ri+coefR), pourcent_min, gouraud);

		// ajout du terme d'intensit�
		I.R+=(objetintersecte->material.coef_ri+coefR)*IP.R;
		I.G+=(objetintersecte->material.coef_ri+coefR)*IP.G;
		I.B+=(objetintersecte->material.coef_ri+coefR)*IP.B;
	}

	

	return intersectobjet;  // vrai si on intersecte un objet
}


void Scene3DRay::lancer_general(imcouleur& bitmap_render, bool gouraud, int & percentcalcul){

	unsigned char fR, fG, fB;
	fR = (unsigned char) (fondR*255);
	fG = (unsigned char) (fondG*255);
	fB = (unsigned char) (fondB*255);

	int dimfx, dimfy, dimrx, dimry;
	char etat;
	int temp;
	int x, y;
	int debutx;
	if (!calcul_is_continuing){
			debutx=0;
			temp=1;
	}else{

		FILE* fp;
    fopen_s(&fp, nomcal,"rb");
		int tmpbool;

		save_calcul = true;
		fread(&seuiladaptraytra, sizeof(double), 1, fp);
		fread(&tmpbool, sizeof(int), 1, fp);
		fread(&nbrayslights, sizeof(int), 1, fp);
		enableextendedlight = tmpbool ? true : false;
		fread(&etat, sizeof(char), 1, fp);
		setrenduetatsurechant(etat);
		fread(&temp, sizeof(int), 1, fp);
		fread(&dimfx, sizeof(int), 1, fp);
		fread(&dimfy, sizeof(int), 1, fp);
		int olddimfx = dimrenderwindowx;
		int olddimfy = dimrenderwindowy;
		setdim2Drender(dimfx, dimfy);
		bitmap_render.setdim(dimfx, dimfy);
		fread(&dimrx, sizeof(int), 1, fp);
		fread(&dimry, sizeof(int), 1, fp);
		fread(&x, sizeof(int), 1, fp);
		debutx = x;
		fread(&y, sizeof(int), 1, fp);
		for (int x1 = 0 ; x1 < dimrx ; x1++)
			for (int y1 = 0 ; y1 < dimry ; y1++){
				unsigned char r, g, b;
				fread(&r, sizeof(unsigned char), 1, fp);								
				fread(&g, sizeof(unsigned char), 1, fp);								
				if (1!=fread(&b, sizeof(unsigned char), 1, fp))
					AfxMessageBox(CString("Problem with the calculation file (.cal)"));

				bufferRenderR[x1][y1] = r;
				bufferRenderG[x1][y1] = g;
				bufferRenderB[x1][y1] = b;
					
			}
		fclose(fp);
	}
	// on ramene les objets et les sources lumineuses dans le repere de la scene :
	int i;

	MettreTousObjetsDansRepereScene();
	Celluleobj *p;
	for (p = objets.L; p!=NULL; p=p->suiv){
		for (i = 0 ; i < p->pobjet->nbfaces ; i++){
			p->pobjet->faces[i].calculnormaleetplan(p->pobjet->tabsomm);
		}
	}

	if (enableextendedlight){
		nbextendedsources = 0;
		for (p = objets.L; p!=NULL; p=p->suiv){
			if (p->pobjet->material.emitance > 0)
				extendedsources[nbextendedsources++]=p->pobjet;
		}
	}

	if (usebsp)
		constructBSPtree(gouraud);
	else{
		// calcul des boites englobantes des polyedres :
		calculboitesenglobantes();
	}

	if (gouraud){
		if (!getenableradiosite()){
			gouraud=false;
		}else
			calculsommetsgouraudradio(true);
	}

	// initialisation des bufferRenders � la couleur du fond :
	if (!calcul_is_continuing){
		for (x = 0 ; x < dim2Drendux ; x++)
			for (y = 0 ; y < dim2Drenduy ; y++){
				bufferRenderR[x][y] = fR;
				bufferRenderG[x][y] = fG;
				bufferRenderB[x][y] = fB;
			}
	}


	// distance d de l'observateur au plan de l'ecran :
	double d = (double)((((double)dim2Drendux)/2.0)/tan(tabcam[nocamselect]->accesanglex()/2));

	// rayon a travers chaque pixel :
	Rayon ray, ray_sce;
	ray.origine = Point3D(0,0,0);
	Couleur I;

	int pourcent=0;
	long temps_init=(long)time(NULL);
	int compt_pixel=0;

	if (temp==1){
		for (x = debutx ; x < dim2Drendux ; x++)
			for (y = 0 ; y < dim2Drenduy ; y++){
				if (renduetatsurechant!=0 || (x%3 == 1 && y%3 == 1)){
					// rayon a travers le pixel (x, y, d) dans le repere de la camera:
					ray.vectdirect = Point3D((double)x - dim2Drendux/2, (double)y - dim2Drenduy/2, d);
					ray.vectdirect.normer();

					// on ramene le rayon dans lerepere de la scene
					ray_sce.origine=tabcam[nocamselect]->pos;
					ray_sce.vectdirect = (tabcam[nocamselect]->M).t() * ray.vectdirect;

					// rayon hors de tout objet :
					ray_sce.nbobjetscontenant = 0;

					// Lancer du rayon et memorisation de la couleur des pixels:
					if (lancer_recursif(ray_sce, I, 1, profrecurmax, 100, pourcenneglig, gouraud)){  // si le rayon frappe un objet
						if (I.R > 1) 
							I.R = 1;  // seuillage
						if (I.G > 1) 
							I.G = 1;  // seuillage
						if (I.B > 1) 
							I.B = 1;  // seuillage
						bufferRenderR[x][y] = (unsigned char) (255*I.R);
						bufferRenderG[x][y] = (unsigned char) (255*I.G);
						bufferRenderB[x][y] = (unsigned char) (255*I.B);
					}

					compt_pixel++;
					if ((x*100)/(dim2Drendux-1) > pourcent){
						pourcent = (x*100)/(dim2Drendux-1);
						long temps=(long)time(NULL)-temps_init;
						ofstream fich("inforayon.txt");
						if (renduetatsurechant == 0){
							fich << "phase initiale\n";
							fich << "nombre de pixels calcules : " << compt_pixel <<"\n";
						}else
							fich << "nombre de pixels calcules : " << compt_pixel <<"\n";
						fich << "pourcentage des pixels traites : " << pourcent << "\n";
						percentcalcul=pourcent;
						fich << "temps : " << temps /(60*60) <<"h"<< temps%(60*60)/60 <<"mn"<< temps%60<<"s\n";
						temps = (long)(temps*((double)(100-pourcent))/((double)pourcent));
						fich << "temps restant estime : " << temps /(60*60) <<"h"<< temps%(60*60)/60 <<"mn"<< temps%60<<"s\n";
						fich.close();
						if (save_calcul && pourcent%5 == 0){
							char name[50];
							sprintf(name, "sauve_calcul%d.cal", (pourcent/5)%2);
							FILE* fp;
              fopen_s(&fp,name,"wb");
							int temp=1;

							int tmpbool = enableextendedlight ? 1 : 0;
							fwrite(&seuiladaptraytra, sizeof(double), 1, fp);
							fwrite(&tmpbool, sizeof(int), 1, fp);
							fwrite(&nbrayslights, sizeof(int), 1, fp);
							fwrite(&renduetatsurechant, sizeof(char), 1, fp);
							fwrite(&temp, sizeof(int), 1, fp);
							fwrite(&dimrenderwindowx, sizeof(int), 1, fp);
							fwrite(&dimrenderwindowy, sizeof(int), 1, fp);
							fwrite(&dim2Drendux, sizeof(int), 1, fp);
							fwrite(&dim2Drenduy, sizeof(int), 1, fp);
							fwrite(&x, sizeof(int), 1, fp);
							fwrite(&y, sizeof(int), 1, fp);
							for (int x1 = 0 ; x1 < dim2Drendux ; x1++)
								for (int y1 = 0 ; y1 < dim2Drenduy ; y1++){
									fwrite(&bufferRenderR[x1][y1], sizeof(unsigned char), 1, fp);								
									fwrite(&bufferRenderG[x1][y1], sizeof(unsigned char), 1, fp);								
									fwrite(&bufferRenderB[x1][y1], sizeof(unsigned char), 1, fp);								
								}
							fclose(fp);
							convertcaltobitmap(name, "sauve_image.bmp");
						}
					}
				}
			}
	}
	if (renduetatsurechant==0  && temp==1){
		for (x = 0 ; x < dim2Drendux ; x++)
			for (y=0 ; y < dim2Drenduy ; y++){
					bufferRenderR[x][y] = bufferRenderR[3*(x/3)+1][3*(y/3)+1];
					bufferRenderG[x][y] = bufferRenderG[3*(x/3)+1][3*(y/3)+1];
					bufferRenderB[x][y] = bufferRenderB[3*(x/3)+1][3*(y/3)+1];
			}		
	}

	long temps_phase1 = (long)time(NULL)-temps_init;
	temps_init = (long)time(NULL);
	pourcent=0;
	int j;
	unsigned char **subdivise;
	if (renduetatsurechant == 0){ // adaptative antialiasing
		subdivise = alloueruchar2D(dimrenderwindowx, dimrenderwindowy);
		for (x = 0 ; x < dimrenderwindowx ; x++)
			for (y = 0 ; y < dimrenderwindowy ; y++){
				subdivise[x][y]=0;
				Point3D pixelxy(bufferRenderR[3*x+1][3*y+1], bufferRenderG[3*x+1][3*y+1], bufferRenderB[3*x+1][3*y+1]);
				for (i = -1 ; i < 2 ; i++)
					for (j = -1 ; j < 2 ; j++){
						if ((i!=0 || j!=0) && 
							(3*(x+i)+1 >= 0 && 3*(y+j)+1 >=0 &&
							3*(x+i)+1 <= dim2Drendux && 3*(y+j)+1 <= dim2Drenduy)){
							Point3D pixelvoisin(bufferRenderR[3*(x+i)+1][3*(y+j)+1], bufferRenderG[3*(x+i)+1][3*(y+j)+1], bufferRenderB[3*(x+i)+1][3*(y+j)+1]);
							if ((pixelxy-pixelvoisin).norme() >= seuiladaptraytra)
								subdivise[x][y]=1;
						}
					}
				
			}
		for (x = (temp == 1 ? 0 : debutx) ; x < dim2Drendux ; x++)
			for (y = 0 ; y < dim2Drenduy ; y++){
				if (subdivise[x/3][y/3] && (x%3!=1 || y%3!=1)){
					// rayon a travers le pixel (x, y, d) dans le repere de la camera:
					ray.vectdirect = Point3D((double)x - dim2Drendux/2, (double)y - dim2Drenduy/2, d);
					ray.vectdirect.normer();

					// on ramene le rayon dans lerepere de la scene
					ray_sce.origine=tabcam[nocamselect]->pos;
					ray_sce.vectdirect = (tabcam[nocamselect]->M).t() * ray.vectdirect;

					// rayon hors de tout objet :
					ray_sce.nbobjetscontenant = 0;

					// Lancer du rayon et memorisation de la couleur des pixels:
					if (lancer_recursif(ray_sce, I, 1, profrecurmax, 100, pourcenneglig, gouraud)){  // si le rayon frappe un objet
						if (I.R > 1) I.R = 1;  // seuillage
						if (I.G > 1) I.G = 1;  // seuillage
						if (I.B > 1) I.B = 1;  // seuillage
						bufferRenderR[x][y] = (unsigned char) (255*I.R);
						bufferRenderG[x][y] = (unsigned char) (255*I.G);
						bufferRenderB[x][y] = (unsigned char) (255*I.B);
					}

					compt_pixel++;
				}else{
					if (x%3!=1 || y%3!=1){
						bufferRenderR[x][y] = bufferRenderR[3*(x/3)+1][3*(y/3)+1];
						bufferRenderG[x][y] = bufferRenderG[3*(x/3)+1][3*(y/3)+1];
						bufferRenderB[x][y] = bufferRenderB[3*(x/3)+1][3*(y/3)+1];
					}

				}
					if ((x*100)/(dim2Drendux-1) > pourcent){
						pourcent = (x*100)/(dim2Drendux-1);
						long temps=(long)time(NULL)-temps_init;
						ofstream fich("inforayon.txt");
						if (renduetatsurechant == 0){
							fich << "deuxieme phase\n";
							fich << "duree premiere phase : " << temps_phase1 /(3600) << "h" <<  temps_phase1%(60*60)/60 <<"mn"<< temps_phase1%60 << "s\n";

							fich << "nombre total de pixels calcules : " << compt_pixel <<"\n";
						}else
							fich << "nombre de pixels calcules : " << compt_pixel <<"\n";
						fich << "pourcentage des pixels traites : " << pourcent << "\n";
						percentcalcul=pourcent;
						fich << "temps : " << temps /(60*60) <<"h"<< temps%(60*60)/60 <<"mn"<< temps%60<<"s\n";
						temps = (long)(temps*((double)(100-pourcent))/((double)pourcent));
						fich << "temps restant estime : " << temps /(60*60) <<"h"<< temps%(60*60)/60 <<"mn"<< temps%60<<"s\n";
						fich.close();
						if (save_calcul && pourcent%5 == 0){
							char name[50];
							sprintf(name, "sauve_calcul%d.cal", (pourcent/5)%2);
							FILE* fp;
              fopen_s(&fp,name,"wb");
							int temp=2;
							int tmpbool = enableextendedlight ? 1 : 0;

							fwrite(&seuiladaptraytra, sizeof(double), 1, fp);
							fwrite(&tmpbool, sizeof(int), 1, fp);
							fwrite(&nbrayslights, sizeof(int), 1, fp);
							fwrite(&renduetatsurechant, sizeof(char), 1, fp);
							fwrite(&temp, sizeof(int), 1, fp);
							fwrite(&dimrenderwindowx, sizeof(int), 1, fp);
							fwrite(&dimrenderwindowy, sizeof(int), 1, fp);
							fwrite(&dim2Drendux, sizeof(int), 1, fp);
							fwrite(&dim2Drenduy, sizeof(int), 1, fp);
							fwrite(&x, sizeof(int), 1, fp);
							fwrite(&y, sizeof(int), 1, fp);
							for (int x1 = 0 ; x1 < dim2Drendux ; x1++)
								for (int y1 = 0 ; y1 < dim2Drenduy ; y1++){
									fwrite(&bufferRenderR[x1][y1], sizeof(unsigned char), 1, fp);								
									fwrite(&bufferRenderG[x1][y1], sizeof(unsigned char), 1, fp);								
									fwrite(&bufferRenderB[x1][y1], sizeof(unsigned char), 1, fp);								
								}
							fclose(fp);
							initbitmapfrombuffersray(bitmap_render, subdivise);

							bitmap_render.ecritbmp("sauve_image.bmp");
						}
					}
			}

		liberer(subdivise,dimrenderwindowx);
	}
	// on remet les objets et sources lumineuses dans le rep�re de la cam�ra :
	MettreTousObjetsDansRepereCamera();

	if (usebsp)
		destroyBSP();
	else{
		// destruction des boites englobantes :
		detruitboitesenglobantes();
	}

	initbitmapfrombuffersray(bitmap_render, subdivise);

	bitmap_render.ecritbmp("sauve.bmp");
	percentcalcul=100;
}

void Scene3DRay::initbitmapfrombuffersray(imcouleur &bitmap_render, unsigned char** subdivise){

	// calcul du bitmap pour affichage et sauvegarde au format BMP :
	int moyenneR, moyenneG, moyenneB;
	int largpixel = renduetatsurechant;
	int nbpoints = (largpixel == 1) ? 1 : ((largpixel == 2) ? 4 : 9);
	largpixel = (largpixel == 1) ? 1 : ((largpixel == 2) ? 2 : 3);

	
//	if (renduetatsurechant != 0){
		for (int x = 0, X=0 ; x < dimrenderwindowx ; x++, X+=largpixel)
			for (int y = 0, Y=0 ; y < dimrenderwindowy ; y++, Y+=largpixel){
				moyenneR = moyenneG = moyenneB = 0;

				for (int i = 0 ; i < largpixel ; i++)
					for (int j = 0 ; j < largpixel ; j++){
						moyenneR += bufferRenderR[X+i][Y+j];
						moyenneG += bufferRenderG[X+i][Y+j];
						moyenneB += bufferRenderB[X+i][Y+j];
					}

				moyenneR /= nbpoints;
				moyenneG /= nbpoints;
				moyenneB /= nbpoints;

				bitmap_render.setpixel(x, y, moyenneR, moyenneG, moyenneB);
			}
/*	}else{
		for (int x = 0; x < dimrenderwindowx ; x++)
			for (int y = 0; y < dimrenderwindowy ; y++){
				if (!subdivise[x][y])
					bitmap_render.setpixel(x, y, bufferRenderR[3*x+1][3*y+1], bufferRenderG[3*x+1][3*y+1], bufferRenderB[3*x+1][3*y+1]);
				else{
					moyenneR = moyenneG = moyenneB = 0;

					for (int i = 0 ; i < 3 ; i++)
						for (int j = 0 ; j < 3 ; j++){
							moyenneR += bufferRenderR[3*x+i][3*y+j];
							moyenneG += bufferRenderG[3*x+i][3*y+j];
							moyenneB += bufferRenderB[3*x+i][3*y+j];
						}

					moyenneR /= nbpoints;
					moyenneG /= nbpoints;
					moyenneB /= nbpoints;

					bitmap_render.setpixel(x, y, moyenneR, moyenneG, moyenneB);
				}
			}
*/

//	}
		
}


void Scene3DRay::convertcaltobitmap(char* nomcal, char* nombmp){

	int dimfx, dimfy, dimrx, dimry;
	char etat;
	int temp;
	int x, y;

	FILE* fp;
  fopen_s(&fp,nomcal,"rb");
	int tmpbool;

	fread(&seuiladaptraytra, sizeof(double), 1, fp);
	fread(&tmpbool, sizeof(int), 1, fp);
	fread(&nbrayslights, sizeof(int), 1, fp);
	enableextendedlight = tmpbool ? true : false;
	fread(&etat, sizeof(char), 1, fp);
	fread(&temp, sizeof(int), 1, fp);
	fread(&dimfx, sizeof(int), 1, fp);
	fread(&dimfy, sizeof(int), 1, fp);
	fread(&dimrx, sizeof(int), 1, fp);
	fread(&dimry, sizeof(int), 1, fp);
	fread(&x, sizeof(int), 1, fp);
	fread(&y, sizeof(int), 1, fp);
	imcouleur bitmap(dimfy,dimfx);
	for (int x1 = 0 ; x1 < dimrx ; x1++)
		for (int y1 = 0 ; y1 < dimry ; y1++){
			unsigned char r, g, b;
			fread(&r, sizeof(unsigned char), 1, fp);								
			fread(&g, sizeof(unsigned char), 1, fp);								
			fread(&b, sizeof(unsigned char), 1, fp);
			if (etat!=0 || temp==2 || (x1%3 == 1 && y1%3 == 1)){
				int cx = (etat == 0) ? x1/3 : x1/etat;
				int cy = (etat == 0) ? y1/3 : y1/etat;
				bitmap.setpixel(cx, cy, r, g, b);
			}
		}
	fclose(fp);


	bitmap.ecritbmp(nombmp);

}






void Scene3DRay::continue_lancer_general(bool gouraud, char* nom){
	unsigned char fR, fG, fB;
	fR = (unsigned char) (fondR*255);
	fG = (unsigned char) (fondG*255);
	fB = (unsigned char) (fondB*255);

	int dimfx, dimfy, dimrx, dimry;
	char etat;
	int temp;
	int x, y;

	FILE* fp;
  fopen_s(&fp,nomcal,"rb");
	int tmpbool;

	save_calcul = true;
	fread(&seuiladaptraytra, sizeof(double), 1, fp);
	fread(&tmpbool, sizeof(int), 1, fp);
	fread(&nbrayslights, sizeof(int), 1, fp);
	enableextendedlight = tmpbool ? true : false;
	fread(&etat, sizeof(char), 1, fp);
	setrenduetatsurechant(etat);
	fread(&temp, sizeof(int), 1, fp);
	fread(&dimfx, sizeof(int), 1, fp);
	fread(&dimfy, sizeof(int), 1, fp);
	int olddimfx = dimrenderwindowx;
	int olddimfy = dimrenderwindowy;
	setdim2Drender(dimfx, dimfy);
	imcouleur bitmap_render(dimfx, dimfy);
	fread(&dimrx, sizeof(int), 1, fp);
	fread(&dimry, sizeof(int), 1, fp);
	fread(&x, sizeof(int), 1, fp);
	int debutx = x;
	fread(&y, sizeof(int), 1, fp);
	imcouleur bitmap(dimfy,dimfx);
	for (int x1 = 0 ; x1 < dimrx ; x1++)
		for (int y1 = 0 ; y1 < dimry ; y1++){
			unsigned char r, g, b;
			fread(&r, sizeof(unsigned char), 1, fp);								
			fread(&g, sizeof(unsigned char), 1, fp);								
			fread(&b, sizeof(unsigned char), 1, fp);
			bufferRenderR[x1][y1] = r;
			bufferRenderG[x1][y1] = g;
			bufferRenderB[x1][y1] = b;
				
		}
	fclose(fp);

	// on ramene les objets et les sources lumineuses dans le repere de la scene :
	int i;

	MettreTousObjetsDansRepereScene();
	Celluleobj *p;
	for (p = objets.L; p!=NULL; p=p->suiv){
		for (i = 0 ; i < p->pobjet->nbfaces ; i++){
			p->pobjet->faces[i].calculnormaleetplan(p->pobjet->tabsomm);
		}
	}

	if (enableextendedlight){
		nbextendedsources = 0;
		for (p = objets.L; p!=NULL; p=p->suiv){
			if (p->pobjet->material.emitance > 0)
				extendedsources[nbextendedsources++]=p->pobjet;
		}
	}

	if (usebsp)
		constructBSPtree(gouraud);
	else{
		// calcul des boites englobantes des polyedres :
		calculboitesenglobantes();
	}

	if (gouraud){
		if (!getenableradiosite()){
			gouraud=false;
		}else
			calculsommetsgouraudradio(true);
	}



	// distance d de l'observateur au plan de l'ecran :
	double d = (double)((((double)dim2Drendux)/2.0)/tan(tabcam[nocamselect]->accesanglex()/2));

	// rayon a travers chaque pixel :
	Rayon ray, ray_sce;
	ray.origine = Point3D(0,0,0);
	Couleur I;

	int pourcent=0;
	long temps_init=(long)time(NULL);
	int compt_pixel=0;

	if (temp==1){
		for (x = debutx ; x < dim2Drendux ; x++)
			for (y=0 ; y < dim2Drenduy ; y++){
				if (renduetatsurechant!=0 || (x%3 == 1 && y%3 == 1)){
					// rayon a travers le pixel (x, y, d) dans le repere de la camera:
					ray.vectdirect = Point3D((double)x - dim2Drendux/2, (double)y - dim2Drenduy/2, d);
					ray.vectdirect.normer();

					// on ramene le rayon dans lerepere de la scene
					ray_sce.origine=tabcam[nocamselect]->pos;
					ray_sce.vectdirect = (tabcam[nocamselect]->M).t() * ray.vectdirect;

					// rayon hors de tout objet :
					ray_sce.nbobjetscontenant = 0;

					// Lancer du rayon et memorisation de la couleur des pixels:
					if (lancer_recursif(ray_sce, I, 1, profrecurmax, 100, pourcenneglig, gouraud)){  // si le rayon frappe un objet
						if (I.R > 1) 
							I.R = 1;  // seuillage
						if (I.G > 1) 
							I.G = 1;  // seuillage
						if (I.B > 1) 
							I.B = 1;  // seuillage
						bufferRenderR[x][y] = (unsigned char) (255*I.R);
						bufferRenderG[x][y] = (unsigned char) (255*I.G);
						bufferRenderB[x][y] = (unsigned char) (255*I.B);
					}

					compt_pixel++;
					if ((x*100)/(dim2Drendux-1) > pourcent){
						pourcent = (x*100)/(dim2Drendux-1);
						long temps=(long)time(NULL)-temps_init;
						ofstream fich("inforayon.txt");
						if (renduetatsurechant == 0){
							fich << "phase initiale\n";
							fich << "nombre de pixels calcules : " << compt_pixel <<"\n";
						}else
							fich << "nombre de pixels calcules : " << compt_pixel <<"\n";
						fich << "pourcentage des pixels traites : " << pourcent << "\n";
						fich << "temps : " << temps /(60*60) <<"h"<< temps%(60*60)/60 <<"mn"<< temps%60<<"s\n";
						temps = (long)(temps*((double)(100-pourcent))/((double)pourcent));
						fich << "temps restant estime : " << temps /(60*60) <<"h"<< temps%(60*60)/60 <<"mn"<< temps%60<<"s\n";
						fich.close();
						if (save_calcul && pourcent%5 == 0){
							FILE* fp;
              fopen_s(&fp,"sauve_calcul.cal","wb");
							int temp=1;

							int tmpbool = enableextendedlight ? 1 : 0;
							fwrite(&seuiladaptraytra, sizeof(double), 1, fp);
							fwrite(&tmpbool, sizeof(int), 1, fp);
							fwrite(&nbrayslights, sizeof(int), 1, fp);
							fwrite(&renduetatsurechant, sizeof(char), 1, fp);
							fwrite(&temp, sizeof(int), 1, fp);
							fwrite(&dimrenderwindowx, sizeof(int), 1, fp);
							fwrite(&dimrenderwindowy, sizeof(int), 1, fp);
							fwrite(&dim2Drendux, sizeof(int), 1, fp);
							fwrite(&dim2Drenduy, sizeof(int), 1, fp);
							fwrite(&x, sizeof(int), 1, fp);
							fwrite(&y, sizeof(int), 1, fp);
							for (int x1 = 0 ; x1 < dim2Drendux ; x1++)
								for (int y1 = 0 ; y1 < dim2Drenduy ; y1++){
									fwrite(&bufferRenderR[x1][y1], sizeof(unsigned char), 1, fp);								
									fwrite(&bufferRenderG[x1][y1], sizeof(unsigned char), 1, fp);								
									fwrite(&bufferRenderB[x1][y1], sizeof(unsigned char), 1, fp);								
								}
							fclose(fp);
							convertcaltobitmap("sauve_calcul.cal", "sauve_image.bmp");
						}
					}
				}
			}
		if (renduetatsurechant==0 && temp==1){
			for (x = 0 ; x < dim2Drendux ; x++)
				for (y=0 ; y < dim2Drenduy ; y++){
						bufferRenderR[x][y] = bufferRenderR[3*(x/3)+1][3*(y/3)+1];
						bufferRenderG[x][y] = bufferRenderG[3*(x/3)+1][3*(y/3)+1];
						bufferRenderB[x][y] = bufferRenderB[3*(x/3)+1][3*(y/3)+1];
				}		
		}
	}

	long temps_phase1 = (long)time(NULL)-temps_init;
	temps_init = (long)time(NULL);
	pourcent=0;
	int j;
	unsigned char **subdivise;
	if (renduetatsurechant == 0){ // adaptative antialiasing
		subdivise = alloueruchar2D(dimrenderwindowx, dimrenderwindowy);
		for (x = 0 ; x < dimrenderwindowx ; x++)
			for (y = 0 ; y < dimrenderwindowy ; y++){
				subdivise[x][y]=0;
				Point3D pixelxy(bufferRenderR[3*x+1][3*y+1], bufferRenderG[3*x+1][3*y+1], bufferRenderB[3*x+1][3*y+1]);
				for (i = -1 ; i < 2 ; i++)
					for (j = -1 ; j < 2 ; j++){
						if ((i!=0 || j!=0) && 
							(3*(x+i)+1 >= 0 && 3*(y+j)+1 >=0 &&
							3*(x+i)+1 <= dim2Drendux && 3*(y+j)+1 <= dim2Drenduy)){
							Point3D pixelvoisin(bufferRenderR[3*(x+i)+1][3*(y+j)+1], bufferRenderG[3*(x+i)+1][3*(y+j)+1], bufferRenderB[3*(x+i)+1][3*(y+j)+1]);
							if ((pixelxy-pixelvoisin).norme() >= seuiladaptraytra)
								subdivise[x][y]=1;
						}
					}
				
			}
		for (x = (temp==2 ? debutx : 0) ; x < dim2Drendux ; x++)
			for (y = 0 ; y < dim2Drenduy ; y++){
				if (subdivise[x/3][y/3] && (x%3!=1 || y%3!=1)){
					// rayon a travers le pixel (x, y, d) dans le repere de la camera:
					ray.vectdirect = Point3D((double)x - dim2Drendux/2, (double)y - dim2Drenduy/2, d);
					ray.vectdirect.normer();

					// on ramene le rayon dans lerepere de la scene
					ray_sce.origine=tabcam[nocamselect]->pos;
					ray_sce.vectdirect = (tabcam[nocamselect]->M).t() * ray.vectdirect;

					// rayon hors de tout objet :
					ray_sce.nbobjetscontenant = 0;

					// Lancer du rayon et memorisation de la couleur des pixels:
					if (lancer_recursif(ray_sce, I, 1, profrecurmax, 100, pourcenneglig, gouraud)){  // si le rayon frappe un objet
						if (I.R > 1) I.R = 1;  // seuillage
						if (I.G > 1) I.G = 1;  // seuillage
						if (I.B > 1) I.B = 1;  // seuillage
						bufferRenderR[x][y] = (unsigned char) (255*I.R);
						bufferRenderG[x][y] = (unsigned char) (255*I.G);
						bufferRenderB[x][y] = (unsigned char) (255*I.B);
					}

					compt_pixel++;
				}else{
					if (x%3!=1 || y%3!=1){
						bufferRenderR[x][y] = bufferRenderR[3*(x/3)+1][3*(y/3)+1];
						bufferRenderG[x][y] = bufferRenderG[3*(x/3)+1][3*(y/3)+1];
						bufferRenderB[x][y] = bufferRenderB[3*(x/3)+1][3*(y/3)+1];
					}

				}
					if ((x*100)/(dim2Drendux-1) > pourcent){
						pourcent = (x*100)/(dim2Drendux-1);
						long temps=(long)time(NULL)-temps_init;
						ofstream fich("inforayon.txt");
						if (renduetatsurechant == 0){
							fich << "deuxieme phase\n";
							fich << "duree premiere phase : " << temps_phase1 /(3600) << "h" <<  temps_phase1%(60*60)/60 <<"mn"<< temps_phase1%60 << "s\n";

							fich << "nombre total de pixels calcules : " << compt_pixel <<"\n";
						}else
							fich << "nombre de pixels calcules : " << compt_pixel <<"\n";
						fich << "pourcentage des pixels traites : " << pourcent << "\n";
						fich << "temps : " << temps /(60*60) <<"h"<< temps%(60*60)/60 <<"mn"<< temps%60<<"s\n";
						temps = (long)(temps*((double)(100-pourcent))/((double)pourcent));
						fich << "temps restant estime : " << temps /(60*60) <<"h"<< temps%(60*60)/60 <<"mn"<< temps%60<<"s\n";
						fich.close();
						if (save_calcul && pourcent%5 == 0){
							FILE* fp;
              fopen_s(&fp,"sauve_calcul.cal","wb");
							int temp=2;
							int tmpbool = enableextendedlight ? 1 : 0;

							fwrite(&seuiladaptraytra, sizeof(double), 1, fp);
							fwrite(&tmpbool, sizeof(int), 1, fp);
							fwrite(&nbrayslights, sizeof(int), 1, fp);
							fwrite(&renduetatsurechant, sizeof(char), 1, fp);
							fwrite(&temp, sizeof(int), 1, fp);
							fwrite(&dimrenderwindowx, sizeof(int), 1, fp);
							fwrite(&dimrenderwindowy, sizeof(int), 1, fp);
							fwrite(&dim2Drendux, sizeof(int), 1, fp);
							fwrite(&dim2Drenduy, sizeof(int), 1, fp);
							fwrite(&x, sizeof(int), 1, fp);
							fwrite(&y, sizeof(int), 1, fp);
							for (int x1 = 0 ; x1 < dim2Drendux ; x1++)
								for (int y1 = 0 ; y1 < dim2Drenduy ; y1++){
									fwrite(&bufferRenderR[x1][y1], sizeof(unsigned char), 1, fp);								
									fwrite(&bufferRenderG[x1][y1], sizeof(unsigned char), 1, fp);								
									fwrite(&bufferRenderB[x1][y1], sizeof(unsigned char), 1, fp);								
								}
							fclose(fp);
							initbitmapfrombuffersray(bitmap_render, subdivise);

							bitmap_render.ecritbmp("sauve_image.bmp");
						}
					}
			}

		liberer(subdivise,dimrenderwindowx);
	}
	// on remet les objets et sources lumineuses dans le rep�re de la cam�ra :
	MettreTousObjetsDansRepereCamera();

	if (usebsp)
		destroyBSP();
	else{
		// destruction des boites englobantes :
		detruitboitesenglobantes();
	}

	initbitmapfrombuffersray(bitmap, subdivise);

	bitmap.ecritbmp("resultat_rayon.bmp");

}

