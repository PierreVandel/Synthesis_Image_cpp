// Objetderiv.cpp: implementation of the Objetderiv class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Synth.h"
#include "Objetderiv.h"

#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif



// Constructeur de Cloche : x1, y1, z1 vecteur translation par rapport � l'origine 
// parametres de la cloche (h1, h2, h3 , m) d�finis dans le sujet
Cloche::Cloche(double x1, double y1, double z1, double h1, double h2, double h3,
			 int m,
			 double rotx, double roty, double rotz,
   		     double scalex, double scaley, double scalez,
			 MaterialData mat, const TextureData &text)
			 :Objet3D(x1, y1, z1, 
			 scalex, scaley, scalez, 
			 rotx, roty, rotz,  
			 mat, text) 
{


	// initialisation des attributs de la classe Cloche (ne pas s'attarder a leur denomination)
	nbmerid=m;
	xmin = x1;
	ymin = y1;
	zmin=z1;
	xmax=h1;
	ymax=h2;
	zmax=h3;
	
	

	

}

Objet3D * Cloche::copie(void)
{
	Objet3D *res = new Cloche(xmax, ymax, zmax, xmin, ymin, zmin, nbmerid);


	res->copieObjet3D(*this);

	return res;
	
}


void Cloche::ecritfich(ostream& fich){

	/*fich << gettype() << "\n";
	Objet3D::ecritdonneesobjet3D(fich);
	fich << xmax << " " << ymax << " " << zmax << " " << xmin << " "  << ymin << " " << zmin << "\n";
	fich << nbmerid << "\n";*/
	
}

// constructeur de polyedre :

Polyedre::Polyedre(ifstream *fich, Point3D orig, 
					  double scax, double scay, double scaz,
					  double rx, double ry, double rz,
					  MaterialData mat,
					  TextureData& text)
			:Objet3D(0, 0, 0, 
			 scalex, scaley, scalez, 
			 rotx, roty, rotz,  
			 mat, text){

		origine = orig;
		scalex = scax;
		scaley = scay;
		scalez = scaz;
		rotx = rx;
		roty = ry;
		rotz = rz;
		material = mat;

		(*fich) >> nbsomm >> nbfaces;
		tabsomm = new Sommet[nbsomm];

		int i;
		for (i = 0 ; i < nbsomm ; i++){
			(*fich) >> tabsomm[i].pos.x;
			(*fich) >> tabsomm[i].pos.y;
			(*fich) >> tabsomm[i].pos.z;
			(*fich) >> tabsomm[i].normale.x;
			(*fich) >> tabsomm[i].normale.y;
			(*fich) >> tabsomm[i].normale.z;
			(*fich) >> tabsomm[i].dpsds.x;
			(*fich) >> tabsomm[i].dpsds.y;
			(*fich) >> tabsomm[i].dpsds.z;
			(*fich) >> tabsomm[i].dpsdt.x;
			(*fich) >> tabsomm[i].dpsdt.y;
			(*fich) >> tabsomm[i].dpsdt.z;
			(*fich) >> tabsomm[i].coordtextureX >> tabsomm[i].coordtextureY;
		}
		faces = new Facette[nbfaces];
		for (i = 0 ; i < nbfaces ; i++){
			(*fich) >> faces[i].nbsomm;
			faces[i].tabnosomm = new int[faces[i].nbsomm];
			for (int j = 0 ; j < faces[i].nbsomm ; j++)
				(*fich) >> faces[i].tabnosomm[j];			
		}

}

Objet3D * Polyedre::copie(void)
{
	Objet3D *res = new Polyedre();


	res->copieObjet3D(*this);

	return res;
}



void Polyedre::ecritfich(ostream& fich){


// Attention le poly�dre doit �tre dans le repere de la scene !
	fich << gettype() << "\n";
	Objet3D::ecritdonneesobjet3D(fich);

	fich << nbsomm << "\n" << nbfaces << "\n";
	int i;
	for (i = 0 ; i < nbsomm ; i++){
			Sommet som = tabsomm[i];
			fich << som.pos.x << " ";
			fich << som.pos.y << " ";
			fich << som.pos.z << "\n";
			fich << som.normale.x << " ";
			fich << som.normale.y << " ";
			fich << som.normale.z << "\n";
			fich << som.dpsds.x << " ";
			fich << som.dpsds.y << " ";
			fich << som.dpsds.z << "\n";
			fich << som.dpsdt.x << " ";
			fich << som.dpsdt.y << " ";
			fich << som.dpsdt.z << "\n";
			fich << som.coordtextureX << " " << som.coordtextureY << "\n";
	}
	for (i = 0 ; i < nbfaces ; i++){
		fich << faces[i].nbsomm << " ";
		for (int j = 0 ; j < faces[i].nbsomm ; j++)
			fich << faces[i].tabnosomm[j] << " ";
		fich << "\n";
	}

}



// Constructeur de sphere :

Sphere::Sphere(double xc, double yc, double zc,    // centre de la sphere
			   double rotx, double roty, double rotz, // angles de rotation autour des axes
			   double scalex, double scaley, double scalez,  // changements d'echelle suivant les 3 axes (pour ellopsoide)
			   double r,  // rayon de la sphere
			   int nbparal, int nbmerid,  // nombres de meridiens et paralleles pour le decoupage de la sphere
			   MaterialData mat, const TextureData &text)
			   // appel au constructeur generique d'Objet3D
			   :Objet3D(xc, yc, zc, 
						scalex, scaley, scalez, 
						rotx, roty, rotz, 
			            mat, text)
{

	int i, j;

	rayon = r;
	nbmeridien = nbmerid;
	nbparallele = nbparal;

	// construction des sommets 
	nbsomm = nbparal * (nbmerid + 1) + 2;
	tabsomm = new Sommet[nbsomm];

	int cpt = 0;
	for (i = 0; i <= nbmerid; i++) {
		double thetai = (2 * pi * i) / nbmerid;
		double costhetai = cos(thetai);
		double sinthetai = sin(thetai);

		for (j = 1;j <= nbparal;j++) {
			double phij = (pi * j) / (nbparal + 1);
			double cosphij = cos(phij);
			double sinphij = sin(phij);


			tabsomm[cpt].pos.x = r * costhetai * sinphij;
			tabsomm[cpt].pos.y = r * sinthetai * sinphij;
			tabsomm[cpt].pos.z = r * cosphij;
			tabsomm[cpt].normale.x = costhetai * sinphij;
			tabsomm[cpt].normale.y = sinthetai * sinphij;
			tabsomm[cpt].normale.z = cosphij;

			tabsomm[cpt].coordtextureX = thetai / (2 * pi);
			tabsomm[cpt].coordtextureY = phij / pi;

			cpt++;
		}
	}


	//Pole Sud
	tabsomm[cpt].pos.x = 0;
	tabsomm[cpt].pos.y = 0;
	tabsomm[cpt].pos.z = -r;
	tabsomm[cpt].normale.x = 0;
	tabsomm[cpt].normale.y = 0;
	tabsomm[cpt].normale.z = -1;

	tabsomm[cpt].coordtextureX = 0;
	tabsomm[cpt].coordtextureY = 1;
	cpt++;

	//Pole Nord
	tabsomm[cpt].pos.x = 0;
	tabsomm[cpt].pos.y = 0;
	tabsomm[cpt].pos.z = r;
	tabsomm[cpt].normale.x = 0;
	tabsomm[cpt].normale.y = 0;
	tabsomm[cpt].normale.z = 1;

	tabsomm[cpt].coordtextureX = 0;
	tabsomm[cpt].coordtextureY = 0;
	cpt++;



	// changements d'echelle suivant les differents axes,
	// rotations, et translation
	for (i = 0; i < nbsomm; i++) {
		tabsomm[i].pos.x *= scalex;
		tabsomm[i].pos.y *= scaley;
		tabsomm[i].pos.z *= scalez;
		tabsomm[i].dpsds.x *= scalex;
		tabsomm[i].dpsds.y *= scaley;
		tabsomm[i].dpsds.z *= scalez;
		tabsomm[i].dpsdt.x *= scalex;
		tabsomm[i].dpsdt.y *= scaley;
		tabsomm[i].dpsdt.z *= scalez;
		tabsomm[i].normale.x /= scalex;
		tabsomm[i].normale.y /= scaley;
		tabsomm[i].normale.z /= scalez;
		tabsomm[i].normale.normer();
		tabsomm[i] = rotation * tabsomm[i];
		tabsomm[i].pos = tabsomm[i].pos + origine;
	}

	// construction des facettes


	nbfaces = nbmerid * (nbparal + 1);  // nombre de facettes
	faces = new Facette[nbfaces];  // allocation des facettes



	int compteur = 0;  // compteur de faces

	// allocation de chaque faccette et
	// initialisation des numeros de sommets de chaque facette
	for (i = 0; i < nbmerid; i++) {
		for (j = 1; j < nbparal;j++) {
			faces[compteur].tabnosomm = new int[4];  // facette (i,j) avec 4 sommets
			faces[compteur].nbsomm = 4;

			// numeros des sommets de la facette :
			faces[compteur].tabnosomm[0] = i * nbparal + j - 1;
			faces[compteur].tabnosomm[1] = (i + 1) * nbparal + j - 1;
			faces[compteur].tabnosomm[2] = (i + 1) * nbparal + j;
			faces[compteur].tabnosomm[3] = i * nbparal + j;

			compteur++;
		}

	}


	// faces a 3 sommets pole N
	for (i = 0; i < nbmerid; i++) {
		faces[compteur].tabnosomm = new int[3];  // facette (i,j) avec 3 sommets
		faces[compteur].nbsomm = 3;

		// numeros des sommets de la facette :
		faces[compteur].tabnosomm[0] = (nbmerid + 1) * nbparal + 1;
		faces[compteur].tabnosomm[1] = (i + 1) * nbparal;
		faces[compteur].tabnosomm[2] = i * nbparal;


		compteur++;
	}

	// faces a 3 sommets pole S
	for (i = 0; i < nbmerid; i++) {
		faces[compteur].tabnosomm = new int[3];  // facette (i,j) avec 3 sommets
		faces[compteur].nbsomm = 3;

		// numeros des sommets de la facette :
		faces[compteur].tabnosomm[0] = (nbmerid + 1) * nbparal;
		faces[compteur].tabnosomm[1] = (i + 1) * nbparal - 1;
		faces[compteur].tabnosomm[2] = (i + 2) * nbparal - 1;


		compteur++;
	}


}


// implementation de la fonction virtuelle de recopie d'un objet :
Objet3D * Sphere::copie(void)
{
	Objet3D *res = new Sphere(rayon, nbmeridien, nbparallele);



	res->copieObjet3D(*this);

	return res;
}



void Sphere::ecritfich(ostream& fich){

	fich << gettype() << "\n";
	Objet3D::ecritdonneesobjet3D(fich);
	fich << rayon << " " << nbmeridien << " " << nbparallele << "\n";

}




// constructeur de cylindre de revolution :
Cylinrevol::Cylinrevol(double xor, double yor, double zor, // centre du cylindre
			   double rotx, double roty, double rotz,  // angles de rotation autour des 3 axes
			   double scalex, double scaley, double scalez, // parametres de changement d'echelle suiant les 3 axes
			   double r, double h,  // rayon et hauteur du cylindre
			   int nbmerid, // nombre de meridiens de la facettisation
			   MaterialData mat, const TextureData &text)
			   // appel au constructeur generique d'objet 3D :
			   :Objet3D(xor, yor, zor, 
						scalex, scaley, scalez, 
						 rotx, roty, rotz,  
			            mat, text)
{
	
	int i;
	double teta, sinteta, costeta;

	nbmeridien = nbmerid;



	rayon = r;
	hauteur = h;

	// calcul du nombre de sommets du polyedre
	// et allocation des sommets :	
	nbsomm = 4*nbmerid+2;
	tabsomm = new Sommet[nbsomm];



	

	// initialisation de la position des sommets, et des normales
	for (i = 0 ; i <= nbmerid ; i++){
		teta = 2*(double)pi*((double) i / (double) nbmerid);
		costeta = (double)cos(teta);
		sinteta = (double)sin(teta);
		
		// nbmerid premiers sommets :
		tabsomm[i].pos.x = r*costeta;
		tabsomm[i].pos.z = -hauteur/2;       // hauteur bas;
		tabsomm[i].pos.y = r*sinteta;

		tabsomm[i].normale.x = costeta;
		tabsomm[i].normale.z = 0;       // normale horizontale
		tabsomm[i].normale.y = sinteta;	

		tabsomm[i].coordtextureX = teta / (2 * pi);
		tabsomm[i].coordtextureY = 1;
		
	}


	for (i = nbmerid+1 ; i <= 2*nbmerid+1 ; i++){
		teta = 2*(double)pi*((double) (i-(nbmerid+1)) / (double) nbmerid);
		costeta = (double)cos(teta);
		sinteta = (double)sin(teta);
		
			
		tabsomm[i].pos.x = r*costeta;
		tabsomm[i].pos.z = hauteur/2;       // hauteur haut;
		tabsomm[i].pos.y = r*sinteta;

		tabsomm[i].normale.x = costeta;
		tabsomm[i].normale.z = 0;       // normale horizontale
		tabsomm[i].normale.y = sinteta;
		
		tabsomm[i].coordtextureX = teta / (2 * pi);
		tabsomm[i].coordtextureY = 0;
	}


	// sommets correspondant � la "face du bas" :
	for (i = 2*nbmerid+2 ; i <= 3*nbmerid+1 ; i++){
		
		tabsomm[i].pos.x = tabsomm[i-(2*nbmerid+2)].pos.x;
		tabsomm[i].pos.z = tabsomm[i-(2*nbmerid+2)].pos.z;     
		tabsomm[i].pos.y = tabsomm[i-(2*nbmerid+2)].pos.y;

		tabsomm[i].normale.x = 0;
		tabsomm[i].normale.z = -1;       
		tabsomm[i].normale.y = 0;

	}

	
	
	// sommets correspondant � la "face du haut" :
	
	for (i = 3*nbmerid+2 ; i <= 4*nbmerid+1 ; i++){
		
		tabsomm[i].pos.x = tabsomm[i-(2*nbmerid+1)].pos.x;
		tabsomm[i].pos.z = tabsomm[i-(2*nbmerid+1)].pos.z;       
		tabsomm[i].pos.y = tabsomm[i-(2*nbmerid+1)].pos.y;

		tabsomm[i].normale.x = 0;
		tabsomm[i].normale.z = 1;       
		tabsomm[i].normale.y = 0;

	}





	
	// changements d'echelle suivant les differents axes,
	// rotations, et translation
	for (i = 0 ; i < nbsomm ; i++){
		tabsomm[i].pos.x *= scalex;
		tabsomm[i].pos.y *= scaley;
		tabsomm[i].pos.z *= scalez;
		tabsomm[i].dpsds.x *= scalex;
		tabsomm[i].dpsds.y *= scaley;
		tabsomm[i].dpsds.z *= scalez;
		tabsomm[i].dpsdt.x *= scalex;
		tabsomm[i].dpsdt.y *= scaley;
		tabsomm[i].dpsdt.z *= scalez;
		tabsomm[i].normale.x /= scalex;
		tabsomm[i].normale.y /= scaley;
		tabsomm[i].normale.z /= scalez;
		tabsomm[i].normale.normer();
		tabsomm[i] = rotation*tabsomm[i];
		tabsomm[i].pos = tabsomm[i].pos + origine;
	}




	nbfaces = nbmerid + 2;  // nombre de facettes
	faces = new Facette[nbfaces];  // allocation des facettes

	
	// allocation de chaque facette et
	// initialisation des numeros de sommets de chaque facette
	int compteur=0;
	for (i = 0 ; i < nbmerid ; i++){
		
		faces[compteur].tabnosomm = new int[4];  
		faces[compteur].nbsomm = 4;

		// numeros des sommets de la facette :
		faces[compteur].tabnosomm[0] = i ;
		faces[compteur].tabnosomm[1] = (i+1);
		faces[compteur].tabnosomm[2] = (nbmerid+i+2);
		faces[compteur].tabnosomm[3] = (nbmerid+i+1);		
		compteur++;
	}


		// face du bas
	faces[nbmerid].tabnosomm = new int[nbmerid]; // allocation de nbmerid numeros de sommets
	faces[nbmerid].nbsomm = nbmerid;  // nombre de sommets de la facette
	// numeros de sommets de la facette :
	compteur=3*nbmerid+1;
	for (i = 0 ; i < nbmerid ; i++){
		faces[nbmerid].tabnosomm[i] = compteur;
		compteur--;
	}

	
	// face du haut :
	faces[nbmerid+1].tabnosomm = new int[nbmerid];  // allocation de nbmerid numeros de sommets
	faces[nbmerid+1].nbsomm = nbmerid;  // nombre de sommets de la facette

	// numeros de sommets de la facette :
	compteur=3*nbmerid+2;
	for (i = 0 ; i < nbmerid ; i++){
		faces[nbmerid+1].tabnosomm[i] = compteur;
		compteur++;
	}

	

	


}



// implementation de la fonction virtuelle de recopie :
Objet3D * Cylinrevol::copie(void)
{
	Objet3D *res = new Cylinrevol(rayon, hauteur, nbmeridien);



	res->copieObjet3D(*this);

	return res;
}



void Cylinrevol::ecritfich(ostream& fich){

	fich << gettype() << "\n";
	Objet3D::ecritdonneesobjet3D(fich);
	fich << rayon << " " << hauteur << " " << nbmeridien << "\n";
}




// constructeur de cone tronque

Conerevoltronq::Conerevoltronq(double xor, double yor, double zor, 
			   double rotx, double roty, double rotz,
			   double scalex, double scaley, double scalez,
			   double r, double hauttronq, double rt,
			   int nbmerid, int nbparal,
			   MaterialData mat, const TextureData &text)
			   :Objet3D(xor, yor, zor, 
						scalex, scaley, scalez, 
						 rotx, roty, rotz,   
			            mat, text)
{
	rayon = r;
	hauteur = hauttronq;
	rayontronq = rt;
	nbmeridien = nbmerid;

	// construction des sommets 
	nbsomm = 4 * nbmerid + 2;
	tabsomm = new Sommet[nbsomm];


	for (int i = 0; i <= nbmerid; i++) {
		double thetai = (2 * pi * i) / nbmerid;
		double costhetai = cos(thetai);
		double sinthetai = sin(thetai);


		tabsomm[i].pos.x = r * costhetai;
		tabsomm[i].pos.y = r * sinthetai;
		tabsomm[i].pos.z = 0;
		//grad=(h�x,h�y,(rh+(rt-r)z)(r-rt))
		// ici ca donne (h�r cosi, h�r sini, hr(r-rt))
		// soit (h cosi, h sini, r-rt)
		tabsomm[i].normale.x = hauteur * costhetai;
		tabsomm[i].normale.y = hauteur * sinthetai;
		tabsomm[i].normale.z = (r - rt);
		tabsomm[i].normale.normer();

		tabsomm[i].coordtextureX = thetai / (2 * pi);
		tabsomm[i].coordtextureY = 0;


		tabsomm[i + nbmerid + 1].pos.x = rt * costhetai;
		tabsomm[i + nbmerid + 1].pos.y = rt * sinthetai;
		tabsomm[i + nbmerid + 1].pos.z = hauteur;
		//grad=(h�x,h�y,(rh+(rt-r)z)(r-rt) )
		// ici ca donne (h�rt cosi, h�rt sini, (hr+(rt-r)h)(r-rt) )
		// soit (h�rt cosi, h�rt sini, (rt h)(r-rt) )
		// soit (h cosi, h sini, r-rt) IDEM Precedent
		tabsomm[i + nbmerid + 1].normale = tabsomm[i].normale;

		tabsomm[i + nbmerid + 1].coordtextureX = thetai / (2 * pi);
		tabsomm[i + nbmerid + 1].coordtextureY = 1;

	}



	int deb1 = 2 * nbmerid + 2;
	int deb2 = deb1 + nbmerid;
	int i;

	//face du bas
	for (i = deb1;i < deb2; i++) {
		tabsomm[i].pos.x = tabsomm[i - deb1].pos.x;
		tabsomm[i].pos.y = tabsomm[i - deb1].pos.y;
		tabsomm[i].pos.z = tabsomm[i - deb1].pos.z;
		tabsomm[i].normale.x = 0;
		tabsomm[i].normale.y = 0;
		tabsomm[i].normale.z = -1;

	}

	for (i = deb2;i < deb2 + nbmerid; i++) {
		// face du haut
		tabsomm[i].pos.x = tabsomm[i - deb1 + 1].pos.x;
		tabsomm[i].pos.y = tabsomm[i - deb1 + 1].pos.y;
		tabsomm[i].pos.z = tabsomm[i - deb1 + 1].pos.z;
		tabsomm[i].normale.x = 0;
		tabsomm[i].normale.y = 0;
		tabsomm[i].normale.z = 1;
	}



	// changements d'echelle suivant les differents axes,
	// rotations, et translation
	for (i = 0; i < nbsomm; i++) {
		tabsomm[i].pos.x *= scalex;
		tabsomm[i].pos.y *= scaley;
		tabsomm[i].pos.z *= scalez;
		tabsomm[i].dpsds.x *= scalex;
		tabsomm[i].dpsds.y *= scaley;
		tabsomm[i].dpsds.z *= scalez;
		tabsomm[i].dpsdt.x *= scalex;
		tabsomm[i].dpsdt.y *= scaley;
		tabsomm[i].dpsdt.z *= scalez;
		tabsomm[i].normale.x /= scalex;
		tabsomm[i].normale.y /= scaley;
		tabsomm[i].normale.z /= scalez;
		tabsomm[i].normale.normer();
		tabsomm[i] = rotation * tabsomm[i];
		tabsomm[i].pos = tabsomm[i].pos + origine;
	}

	// construction des facettes


	nbfaces = nbmerid + 2;  // nombre de facettes
	faces = new Facette[nbfaces];  // allocation des facettes



	int compteur = 0;  // compteur de faces

	// allocation de chaque faccette et
	// initialisation des numeros de sommets de chaque facette
	for (i = 0; i < nbmerid; i++) {
		faces[compteur].tabnosomm = new int[4];  // facette (i,j) avec 4 sommets
		faces[compteur].nbsomm = 4;

		// numeros des sommets de la facette :
		faces[compteur].tabnosomm[0] = i;
		faces[compteur].tabnosomm[1] = i + 1;
		faces[compteur].tabnosomm[2] = nbmerid + i + 2;
		faces[compteur].tabnosomm[3] = nbmerid + i + 1;

		compteur++;

	}


	// face du bas
	faces[compteur].tabnosomm = new int[nbmerid]; // allocation de nbmerid numeros de sommets
	faces[compteur].nbsomm = nbmerid;  // nombre de sommets de la facette


	// numeros de sommets de la facette :
	for (i = 0; i < nbmerid; i++) {
		faces[compteur].tabnosomm[i] = 3 * nbmerid + 1 - i;
	}

	compteur++;

	// face du haut :
	faces[compteur].tabnosomm = new int[nbmerid];  // allocation de nbmerid numeros de sommets
	faces[compteur].nbsomm = nbmerid;  // nombre de sommets de la facette

	// numeros de sommets de la facette :
	for (i = 0; i < nbmerid; i++) {
		faces[compteur].tabnosomm[i] = 3 * nbmerid + 2 + i;
	}


	
	
}


Objet3D * Conerevoltronq::copie(void)
{
	Objet3D *res = new Conerevoltronq(rayon, hauteur, rayontronq, nbmeridien, nbparallele);



	res->copieObjet3D(*this);

	return res;
}


void Conerevoltronq::ecritfich(ostream& fich){

	fich << gettype() << "\n";
	Objet3D::ecritdonneesobjet3D(fich);
	fich << rayon << " " << hauteur << " " << rayontronq << " " << nbmeridien  << " " <<  nbparallele << "\n";

}

