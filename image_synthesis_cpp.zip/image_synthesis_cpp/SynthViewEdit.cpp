#include <stdlib.h>

#include "stdafx.h"
#include "Synth.h"

#include "SynthDoc.h"
#include "SynthView.h"
#include "ObjetsDialog.h"

#include "Objet3D.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



void CSynthView::OnEditCamera() 
{
	// TODO: Add your command handler code here

	Camera *  pcam = scene.cameraselectionnee();

	CEditCameraDialog dlg;
	dlg.m_anglex = (float)(pcam->accesanglex()*180.0/pi);
	dlg.m_posx = (float)pcam->accespos().x;
	dlg.m_posy = (float)pcam->accespos().y;
	dlg.m_posz = (float)pcam->accespos().z;
	dlg.m_cx = (float)pcam->accescentre().x;
	dlg.m_cy = (float)pcam->accescentre().y;
	dlg.m_cz = (float)pcam->accescentre().z;


	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
	

		scene.changecam((double)dlg.m_posx, (double)dlg.m_posy, (double)dlg.m_posz,
			            (double)dlg.m_cx, (double)dlg.m_cy, (double)dlg.m_cz,
                        (double)dlg.m_anglex);
		scene.zbuffer(bitmap_dib);
		CClientDC cdc(this);
		OnDraw(&cdc);
	}

}

void CSynthView::OnUpdateEditCamera(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);
}



void CSynthView::OnEditObjet3d() 
{
	// TODO: Add your command handler code here

	CSynthDoc * pdoc = (CSynthDoc*)GetDocument();

	if (nbobjetselect == 1 && IDCANCEL != scene.editeobjet(numobjetselect[0],pdoc->nbSpline2D, pdoc->p_Splines2D, pdoc->objetedite)){
		pdoc->objetedite=NULL;
		scene.zbuffer(bitmap_dib);
		CClientDC cdc(this);
		OnDraw(&cdc);
//		scene.detruitdonneesdiscretes();
	}
}

void CSynthView::OnUpdateEditObjet3d(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere && (nbobjetselect==1));
}





void CSynthView::OnEditSource() 
{
	// TODO: Add your command handler code here
	CSelectSourceDialog dlg1;
	int nblum = scene.getnblum();
	dlg1.m_no =  nblum - 1;

	int ret = dlg1.DoModal();

	if (ret == IDCANCEL)
		return;

	if (dlg1.m_no < 0 || dlg1.m_no >= nblum){
		AfxMessageBox(CString("Mauvais numero de source lumineuse"));
		return;
	}

	if (IDCANCEL != scene.editsourcelum(dlg1.m_no)){
		scene.zbuffer(bitmap_dib);
		CClientDC cdc(this);
		OnDraw(&cdc);

	}
}

void CSynthView::OnUpdateEditSource(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here


	
	pCmdUI->Enable(activinsere && activinsere);
}





void CSynthView::OnEditSupprimerObjet() 
{
	// TODO: Add your command handler code here

	if (IDOK==AfxMessageBox(CString("Are you sure you want to delete the object ?"), MB_OKCANCEL))
		if (IDCANCEL != scene.supprimeobjet(numobjetselect, nbobjetselect)){
			scene.zbuffer(bitmap_dib);
			CClientDC cdc(this);
			nbobjetselect=0;
			OnDraw(&cdc);

		}

}

void CSynthView::OnUpdateEditSupprimerObjet(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(nbobjetselect != 0);
	
}

void CSynthView::OnEditSupprimerSource() 
{
	// TODO: Add your command handler code here
	CSelectSourceDialog dlg1;
	int nblum = scene.getnblum();
	dlg1.m_no =  nblum - 1;

	int ret = dlg1.DoModal();

	if (ret == IDCANCEL)
		return;

	if (dlg1.m_no < 0 || dlg1.m_no >= nblum){
		AfxMessageBox(CString("Mauvais numero de source lumineuse"));
		return;
	}

	if (IDCANCEL != scene.supprimesourcelum(dlg1.m_no)){
		scene.zbuffer(bitmap_dib);
		CClientDC cdc(this);
		OnDraw(&cdc);

	}

}

void CSynthView::OnUpdateEditSupprimerSource(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);
}



void CSynthView::OnEditGroupobjets() 
{
	// TODO: Add your command handler code here
	scene.groupeobjets(numobjetselect, nbobjetselect);
}

void CSynthView::OnUpdateEditGroupobjets(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(activinsere && nbobjetselect >= 2);
}

void CSynthView::OnEditUngroupObjects() 
{
	// TODO: Add your command handler code here
	
	scene.ungroupobjets(numobjetselect, nbobjetselect);
}

void CSynthView::OnUpdateEditUngroupObjects(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere && nbobjetselect >= 2);
}


void CSynthView::OnEditTransform() 
{
	// TODO: Add your command handler code here

	Point3D moy = scene.GetCenterSelectedObjects(numobjetselect, nbobjetselect);
	CTransformDialog dlg;
	dlg.m_angle = 0;
	dlg.m_axisx = 0;
	dlg.m_axisy = 0;
	dlg.m_axisz = 1;
	dlg.m_origx = moy.x;
	dlg.m_origy = moy.y;
	dlg.m_origz = moy.z;
	dlg.m_scale = 1;

	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
		scene.transform(Point3D(dlg.m_translatx, dlg.m_translaty, dlg.m_translatz),
						Point3D(dlg.m_origx, dlg.m_origy, dlg.m_origz),
							dlg.m_scale, Point3D(dlg.m_axisx, dlg.m_axisy, dlg.m_axisz),
							dlg.m_angle, numobjetselect, nbobjetselect);

		scene.zbuffer(bitmap_dib);
		CClientDC cdc(this);
		OnDraw(&cdc);

	}
}

void CSynthView::OnUpdateEditTransform(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(nbobjetselect != 0);
}
