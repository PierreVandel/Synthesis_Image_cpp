#if !defined(AFX_NOUVSCEDILOG_H__95321DC0_5648_11D3_B1CB_FCBCE6F3CA77__INCLUDED_)
#define AFX_NOUVSCEDILOG_H__95321DC0_5648_11D3_B1CB_FCBCE6F3CA77__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// NouvSceDilog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNouvSceDilog dialog

class CNouvSceDilog : public CDialog
{
// Construction
public:
	CNouvSceDilog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNouvSceDilog)
	enum { IDD = IDD_DIALOG1 };
	float	m_hautcam;
	float	m_lumambiantB;
	float	m_lumambiantG;
	float	m_lumambiantR;
	int		m_nbcam;
	int		m_nblum;
	float	m_xmax;
	float	m_xmin;
	float	m_ymax;
	float	m_ymin;
	float	m_zmax;
	float	m_zmin;
	double	m_fondB;
	double	m_fondG;
	double	m_fondR;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNouvSceDilog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNouvSceDilog)
	virtual void OnOK();
	afx_msg void OnClickedOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NOUVSCEDILOG_H__95321DC0_5648_11D3_B1CB_FCBCE6F3CA77__INCLUDED_)
