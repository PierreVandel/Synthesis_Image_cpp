


#include "stdafx.h"
#include "Synth.h"
#include "Point3D.h"
#include "Matrice.h"

#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


#define NBMAXARETES 1000
#define INFINI 1.5e38



//////////////////////////////////////////////////////////////////////
// Fonctions de la classe Point3D
//////////////////////////////////////////////////////////////////////

// addition :

Point3D Point3D::operator+(const Point3D& P)
{
	Point3D res(x+P.x, y+P.y, z+P.z);
	return res;
}

// soustraction

Point3D Point3D::operator-(const Point3D& P) const
{
	Point3D res(x-P.x, y-P.y, z-P.z);
	return res;
}

// oppose

Point3D Point3D::operator-(void){
	Point3D res(-x, -y, -z);
	return res;
}


// produit scalaire

double Point3D::operator*(const Point3D& p){

	return x*p.x + y*p.y + z*p.z;
}

// produit vectoriel

Point3D Point3D::operator^(const Point3D& p){

	Point3D res;

	res.x = y*p.z - z*p.y;
	res.y = z*p.x - x*p.z;
	res.z = x*p.y - y*p.x;

	return res;
}



// multiplication a gauche par un nombre

Point3D operator*(double lambda, const Point3D& p){
	
	Point3D res;

	res.x = lambda*p.x;
	res.y = lambda*p.y;
	res.z = lambda*p.z;

	return res;
}

// multiplication a droite par un nombre

Point3D operator*(const Point3D& p, double lambda){
	
	Point3D res;

	res.x = lambda*p.x;
	res.y = lambda*p.y;
	res.z = lambda*p.z;

	return res;
}

// division d'un vecteur par sa norme

bool Point3D::normer(void){

	double norme = sqrt(x*x + y*y + z*z);
	if (norme > 1e-6){
		x /= norme; y /= norme; z /= norme;  // normalisation
		return true;
	}else
		return false;
}

// calcul de la norme d'un vecteur (ou la distance d'un point a l'origine).

double Point3D::norme(void){
	return sqrt(x*x + y*y + z*z);
}


double Point3D::normecarre(void){
	return (x*x + y*y + z*z);
}



Sommet Sommet::operator+(const Sommet& s){  // addition

	Sommet res;

	res.normale = normale+s.normale;
	res.intens = intens + s.intens;
	res.dpsds = dpsds + s.dpsds;
	res.dpsdt = dpsdt + s.dpsdt;
	res.coordtextureX = coordtextureX + s.coordtextureX;
	res.coordtextureY = coordtextureY + s.coordtextureY;

	return res;

}

Sommet Sommet::operator+(const Point3D& p){  // addition

	Sommet res = (*this);

	res.pos = res.pos + p;

	return res;
}
	
Sommet Sommet::operator-(const Sommet& s) const{  // soustraction

	Sommet res;

	res.normale = normale - s.normale;
	res.intens = intens - s.intens;
	res.dpsds = dpsds - s.dpsds;
	res.dpsdt = dpsdt - s.dpsdt;
	res.coordtextureX = coordtextureX - s.coordtextureX;
	res.coordtextureY = coordtextureY - s.coordtextureY;

	return res;

}

Sommet operator*(double t, const Sommet& s){
	
	// multiplication par un nombre
	Sommet res;

	res.normale = t* s.normale;
	res.intens = s.intens*t;
	res.dpsds = t* s.dpsds;
	res.dpsdt = t* s.dpsdt;
	res.coordtextureX = t* s.coordtextureX;
	res.coordtextureY = t* s.coordtextureY;

	return res;
}
	
Sommet operator*(const Sommet& s, double t){

	// multiplication par un nombre
	Sommet res;

	res.normale = t* s.normale;
	res.intens = s.intens*t;
	res.dpsds = t* s.dpsds;
	res.dpsdt = t* s.dpsdt;
	res.coordtextureX = t* s.coordtextureX;
	res.coordtextureY = t* s.coordtextureY;

	return res;
}





Sommet operator * (const Matrice& M, const Sommet& P)
{

	Sommet res;

	res.pos = M*P.pos;
	res.normale = M*P.normale;
	res.dpsds = M*P.dpsds;
	res.dpsdt = M*P.dpsdt;
	res.coordtextureX = P.coordtextureX;
	res.coordtextureY = P.coordtextureY;
	return res;
}



