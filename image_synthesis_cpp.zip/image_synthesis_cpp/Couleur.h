// Couleur.h: interface for the Couleur class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COULEUR_H__FBEEFB53_86A4_4D45_A2FF_1E222F883810__INCLUDED_)
#define AFX_COULEUR_H__FBEEFB53_86A4_4D45_A2FF_1E222F883810__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "MaterialPropPage.h"
#include "imcouleur.h"

class Couleur  
{
public:
	double R, G, B;

	Couleur();
	virtual ~Couleur();
	Couleur(double RR, double GG, double BB);
};


class MaterialData
{
public:
	Couleur couleur;  // coefficients RGB de la couleur (entre 0 et 1)
	double coef_rd;       // coefficients de reflexion difuse
	double coef_ambiant;  // coefficient de reflexion de la lumiere ambiante
	double coef_rs;       // coefficients de reflexion speculaire
	double exp_rs;
	double coef_td;		// difuse transmission coefficient
	double coef_ts;		// specular transmission coefficient
	double coef_ri;   // ideal reflexion coefficient
	double coef_ti;   // ideal transmission coefficient
	double indice_refr;  // refraction index
	double emitance; // non zero emitance if the object is a light source

	bool phongenable; // true si Phong ou Gouraud est possible pour cet objet, false sinon

	MaterialData(){			
		couleur = Couleur(0,0,0); 
		coef_rd = 0;      
		coef_ambiant = 0; 
		coef_rs = 0;
		exp_rs = 2;
		coef_td = 0;
		coef_ts = 0;
		coef_ri = 0;   
		coef_ti = 0; 
		indice_refr = 1;
		emitance = 0; 
		phongenable = false;
	}

	MaterialData(Couleur coul, double rd, double ambiant, double crs, double ers,
		double td, double ts, double ri, double ti, double refr, double emit,
		bool phong){
			couleur = coul; 
			coef_rd = rd;      
			coef_ambiant = ambiant; 
			coef_rs = crs;
			exp_rs = ers;
			coef_td = td;
			coef_ts = ts;
			coef_ri = ri;   
			coef_ti = ti; 
			indice_refr = refr;
			emitance = emit; 
			phongenable = phong;
	}

	MaterialData(CMaterialBasicPropPage & bdlg, CMaterialRenderPropPage & rdlg){
		couleur = Couleur(bdlg.m_coulR, bdlg.m_coulG, bdlg.m_coulB); 
		coef_rd = bdlg.m_coefrd;      
		coef_ambiant = bdlg.m_coefamb; 
		coef_rs = bdlg.m_coefrs;
		exp_rs = bdlg.m_exprs;
		coef_td = rdlg.m_coeftd;
		coef_ts = rdlg.m_coefts;
		coef_ri = rdlg.m_coefri;   
		coef_ti = rdlg.m_coefti; 
		indice_refr = rdlg.m_indrefr;
		emitance = rdlg.m_emitance; 
		phongenable = bdlg.m_phongenable ? true : false;
	}


	void InitMaterialDialog(CMaterialBasicPropPage & bdlg, CMaterialRenderPropPage & rdlg){
		bdlg.m_coulR = couleur.R;
		bdlg.m_coulG = couleur.G;
		bdlg.m_coulB = couleur.B; 
		bdlg.m_coefrd = coef_rd;      
		bdlg.m_coefamb = coef_ambiant; 
		bdlg.m_coefrs = coef_rs;
		bdlg.m_exprs = exp_rs;
		rdlg.m_coeftd = coef_td;
		rdlg.m_coefts = coef_ts;
		rdlg.m_coefri = coef_ri;   
		rdlg.m_coefti = coef_ti; 
		rdlg.m_indrefr = indice_refr;
		rdlg.m_emitance = emitance; 
		bdlg.m_phongenable = phongenable;
	}


};

class TextureData{

public:
	bool withtexture[10];
	CString fichiertexture[10];
	imcouleur imtexture[10]; // texture bitmap

	bool withbumpmap[10];
	CString fichierbumpmap[10];
	imcouleur imbumpmap[10];
	double factorbump;


	TextureData(void){
		factorbump = 1;
		for (int t=0 ; t < 10 ; t++){
			withtexture[t] = false;
			withbumpmap[t] = false;
			fichiertexture[0] = CString("");
			fichierbumpmap[0] = CString("");
		}

	}
	TextureData(bool withtext1, CString imt1, 
					bool withtext2, CString imt2, bool withtext3, CString imt3,
					bool withbump1, CString imb1, 
					bool withbump2, CString imb2, bool withbump3, CString imb3, double factor){
		factorbump = factor;
		for (int t=0 ; t < 10 ; t++){
			withtexture[t] = false;
			withbumpmap[t] = false;
			fichiertexture[0] = CString("");
			fichierbumpmap[0] = CString("");
		}
		withtexture[0] = withtext1;
		withtexture[1] = withtext2;
		withtexture[2] = withtext3;
		withbumpmap[0] = withbump1;
		withbumpmap[1] = withbump2;
		withbumpmap[2] = withbump3;
		fichiertexture[0] = imt1;
		fichiertexture[1] = imt2;
		fichiertexture[2] = imt3;
		fichierbumpmap[0] = imb1;
		fichierbumpmap[1] = imb2;
		fichierbumpmap[2] = imb3;
		char nomfichier[200];
		CString message;
		for (int t=0 ; t < 10 ; t++){
			if (withtexture[t]){
				int longueur = fichiertexture[t].GetLength();
        int i;
				for (i = 0 ; i < longueur ; i++)
					nomfichier[i] = fichiertexture[t].GetAt(i);		
				nomfichier[i] = '\0';
				if (!imtexture[t].load_bmp(nomfichier)){
					message = "Impossible to load texture file"; message+= char (t + 1);
					AfxMessageBox(message);
					withtexture[t] = false;
				}else{
					withtexture[t] = true;
				}
			}
			if (withbumpmap[t]){
				int longueur = fichierbumpmap[t].GetLength();
        int i;
				for (i = 0 ; i < longueur ; i++)
					nomfichier[i] = fichierbumpmap[t].GetAt(i);		
				nomfichier[i] = '\0';
				if (!imbumpmap[t].load_bmp(nomfichier)){
					message = "Impossible to load texture file"; message += char(t + 1);
					AfxMessageBox(message);
					withbumpmap[t] = false;
				}else{
					withbumpmap[t] = true;
				}
			}
		}
	}

	TextureData(TextureData &t){
		factorbump=t.factorbump;
		for (int i = 0 ; i < 10 ; i++){
			fichierbumpmap[i] = t.fichierbumpmap[i];
			fichiertexture[i] = t.fichiertexture[i];
			withtexture[i] = t.withtexture[i];
			withbumpmap[i] = t.withbumpmap[i];
			if (withtexture[i]){
				imtexture[i] = t.imtexture[i];
			}
			if (withbumpmap[i]){
				imbumpmap[i] = t.imbumpmap[i];
			}
		}
	}


	TextureData & operator=(const TextureData &t){
		factorbump=t.factorbump;
		for (int i = 0 ; i < 10 ; i++){
			fichierbumpmap[i] = t.fichierbumpmap[i];
			fichiertexture[i] = t.fichiertexture[i];
			withtexture[i] = t.withtexture[i];
			withbumpmap[i] = t.withbumpmap[i];
			if (withtexture[i]){
				imtexture[i] = t.imtexture[i];
			}
			if (withbumpmap[i]){
				imbumpmap[i] = t.imbumpmap[i];
			}
		}
		return (*this);
	}

	void initTextureDialog(CTexturePropPage &dlg){
		dlg.m_withtexture = withtexture[0];
		dlg.m_texturename = fichiertexture[0];
		dlg.m_withbumpmap = withbumpmap[0];
		dlg.m_bumpmapname = fichierbumpmap[0];
		dlg.m_factorbump = factorbump;
	}

	void initTextureDialog(CMultiTextureDialog &dlg){
		dlg.m_factorbump = factorbump;
		dlg.m_withtexture_s = withtexture[0];
		dlg.m_textname_s = fichiertexture[0];
		dlg.m_withbump_s = withbumpmap[0];
		dlg.m_bumpname_s = fichierbumpmap[0];
		dlg.m_withtexture_t = withtexture[1];
		dlg.m_textname_t = fichiertexture[1];
		dlg.m_withbump_t = withbumpmap[1];
		dlg.m_bumpname_t = fichierbumpmap[1];
		dlg.m_withtexture_b = withtexture[2];
		dlg.m_textname_b = fichiertexture[2];
		dlg.m_withbump_b = withbumpmap[2];
		dlg.m_bumpname_b = fichierbumpmap[2];

	}
};


class Intensitesgouraud
{
public :
	double rdR, rdG, rdB, rsR, rsG, rsB;

	Intensitesgouraud(void){rdR=rdG=rdB=rsR=rsG=rsB=0;}
	Intensitesgouraud(double dr, double dg, double db, double sr, double sg, double sb){rdR=dr;rdG=dg;rdB=db;rsR=sr;rsG=sg;rsB=sb;}

	Intensitesgouraud operator+(Intensitesgouraud I) const
	{return Intensitesgouraud(rdR+I.rdR, rdG+I.rdG, rdB+I.rdB, rsR+I.rsR, rsG+I.rsG, rsB+I.rsB);}

	Intensitesgouraud operator-(Intensitesgouraud I) const
	{return Intensitesgouraud(rdR-I.rdR, rdG-I.rdG, rdB-I.rdB, rsR-I.rsR, rsG-I.rsG, rsB-I.rsB);}

	Intensitesgouraud operator*(double t) const
	{return Intensitesgouraud(rdR*t, rdG*t, rdB*t, rsR*t, rsG*t, rsB*t);}


};

#endif // !defined(AFX_COULEUR_H__FBEEFB53_86A4_4D45_A2FF_1E222F883810__INCLUDED_)
