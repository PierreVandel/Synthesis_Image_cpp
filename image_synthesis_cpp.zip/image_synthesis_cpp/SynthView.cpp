// SynthView.cpp : implementation of the CSynthView class
//



#include <stdlib.h>

#include "stdafx.h"
#include "Synth.h"

#include "SynthDoc.h"
#include "SynthView.h"
#include "ControlCameraDlg.h"
#include "RenduDialog.h"

#include "Polygone2d.h"
#include "Objetderiv.h"
#include "CDisplayImageWnd.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// CSynthView

IMPLEMENT_DYNCREATE(CSynthView, CView)

BEGIN_MESSAGE_MAP(CSynthView, CView)
	ON_MESSAGE(WM_RAFFRAICHIR, OnModifCamera)
	ON_MESSAGE(WM_RAFFRAICHIR_NAVIGAT, OnModifCameraNavigat)
	ON_MESSAGE(WM_SET_RENDER_DISPLAY_WND_NULL, OnSetRenderDisplayWndNull)
	//{{AFX_MSG_MAP(CSynthView)
	ON_COMMAND(ID_FILE_NOUVSCE, OnFileNouvsce)
	ON_COMMAND(ID_INSERE_SPHERE, OnInsereSphere)
	ON_UPDATE_COMMAND_UI(ID_INSERE_SPHERE, OnUpdateInsereSphere)
	ON_COMMAND(ID_INSERE_CYL_REVOL, OnInsereCylRevol)
	ON_UPDATE_COMMAND_UI(ID_INSERE_CYL_REVOL, OnUpdateInsereCylRevol)
	ON_COMMAND(ID_INSERE_CONEREVOL, OnInsereConerevol)
	ON_UPDATE_COMMAND_UI(ID_INSERE_CONEREVOL, OnUpdateInsereConerevol)
	ON_COMMAND(ID_INSERE_LIGHT, OnInsereLight)
	ON_UPDATE_COMMAND_UI(ID_INSERE_LIGHT, OnUpdateInsereLight)
	ON_COMMAND(ID_AFFICHAGE_CONTROLCAM, OnAffichageControlcam)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE_CONTROLCAM, OnUpdateAffichageControlcam)
	ON_COMMAND(ID_AFFICHAGE_SELECTCAM, OnAffichageSelectcam)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE_SELECTCAM, OnUpdateAffichageSelectcam)
	ON_COMMAND(ID_AFFICHAGE_REDRESSER_CAM, OnAffichageRedresserCam)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE_REDRESSER_CAM, OnUpdateAffichageRedresserCam)
	ON_COMMAND(ID_EDIT_CAMERA, OnEditCamera)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CAMERA, OnUpdateEditCamera)
	ON_COMMAND(ID_FILE_SORTIEBMP, OnFileSortiebmp)
	ON_UPDATE_COMMAND_UI(ID_FILE_SORTIEBMP, OnUpdateFileSortiebmp)
	ON_COMMAND(ID_AFFICHAGE__SIMPLEZBUFFER, OnAffichageSimplezbuffer)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE__SIMPLEZBUFFER, OnUpdateAffichageSimplezbuffer)
	ON_COMMAND(ID_AFFICHAGE_DOUBLEZBUFFER, OnAffichageDoublezbuffer)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE_DOUBLEZBUFFER, OnUpdateAffichageDoublezbuffer)
	ON_COMMAND(ID_AFFICHAGE_TRIPLEZBUFFER, OnAffichageTriplezbuffer)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE_TRIPLEZBUFFER, OnUpdateAffichageTriplezbuffer)
	ON_COMMAND(ID_INSERE_SPLINE3D_CYL, OnInsereSpline3dCyl)
	ON_COMMAND(ID_INSERE_NOUVBOITE, OnInsereNouvboite)
	ON_UPDATE_COMMAND_UI(ID_INSERE_NOUVBOITE, OnUpdateInsereNouvboite)
	ON_COMMAND(ID_FILE_EXPORT_POLYTEXT, OnFileExportPolytext)
	ON_UPDATE_COMMAND_UI(ID_FILE_EXPORT_POLYTEXT, OnUpdateFileExportPolytext)
	ON_COMMAND(ID_FICHIER_IMPORT_POLYTEXT, OnFichierImportPolytext)
	ON_UPDATE_COMMAND_UI(ID_INSERE_SPLINE3D_CYL, OnUpdateInsereSpline3dCyl)
	ON_COMMAND(ID_INSERE_SPLINE3D_REVOL, OnInsereSpline3dRevol)
	ON_UPDATE_COMMAND_UI(ID_INSERE_SPLINE3D_REVOL, OnUpdateInsereSpline3dRevol)
	ON_COMMAND(ID_AFFICHAGE_VOIR_AXES, OnAffichageVoirAxes)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE_VOIR_AXES, OnUpdateAffichageVoirAxes)
	ON_COMMAND(IDC_INSERE_SPLINE_EXTRUSION, OnInsereSplineExtrusion)
	ON_UPDATE_COMMAND_UI(IDC_INSERE_SPLINE_EXTRUSION, OnUpdateInsereSplineExtrusion)
	ON_COMMAND(ID_AFFICHAGE_OPTIONSCLAIREMENT_LUMIREAMBIANTE, OnAffichageOptionsclairementLumireambiante)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE_OPTIONSCLAIREMENT_LUMIREAMBIANTE, OnUpdateAffichageOptionsclairementLumireambiante)
	ON_COMMAND(ID_AFFICHAGE_OPTIONSCLAIREMENT_PHONG, OnAffichageOptionsclairementPhong)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE_OPTIONSCLAIREMENT_PHONG, OnUpdateAffichageOptionsclairementPhong)
	ON_COMMAND(ID_AFFICHAGE_OPTIONSCLAIREMENT_REFLEXIONDIFUSE, OnAffichageOptionsclairementReflexiondifuse)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE_OPTIONSCLAIREMENT_REFLEXIONDIFUSE, OnUpdateAffichageOptionsclairementReflexiondifuse)
	ON_COMMAND(ID_AFFICHAGE_OPTIONSCLAIREMENT_REFLEXIONSPECULAIRE, OnAffichageOptionsclairementReflexionspeculaire)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE_OPTIONSCLAIREMENT_REFLEXIONSPECULAIRE, OnUpdateAffichageOptionsclairementReflexionspeculaire)
	ON_COMMAND(ID_AFFICHAGE_OPTIONSCLAIREMENT_TEXTURES, OnAffichageOptionsclairementTextures)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE_OPTIONSCLAIREMENT_TEXTURES, OnUpdateAffichageOptionsclairementTextures)
	ON_COMMAND(ID_RENDU_CALCULER_IMAGE, OnRenduCalculerImage)
	ON_UPDATE_COMMAND_UI(ID_RENDU_CALCULER_IMAGE, OnUpdateRenduCalculerImage)
	ON_COMMAND(ID_RENDU_OPTIONECLAIREMENT_REFLEXIONSINTEROBJETS, OnRenduOptioneclairementReflexionsinterobjets)
	ON_UPDATE_COMMAND_UI(ID_RENDU_OPTIONECLAIREMENT_REFLEXIONSINTEROBJETS, OnUpdateRenduOptioneclairementReflexionsinterobjets)
	ON_COMMAND(ID_RENDU_OPTIONECLAIREMENT_REFRACTION, OnRenduOptioneclairementRefraction)
	ON_UPDATE_COMMAND_UI(ID_RENDU_OPTIONECLAIREMENT_REFRACTION, OnUpdateRenduOptioneclairementRefraction)
	ON_COMMAND(ID_RENDU_OPTIONECLAIREMENT_TRANSMISSION_DIFFUSE, OnRenduOptioneclairementTransmissionDiffuse)
	ON_UPDATE_COMMAND_UI(ID_RENDU_OPTIONECLAIREMENT_TRANSMISSION_DIFFUSE, OnUpdateRenduOptioneclairementTransmissionDiffuse)
	ON_COMMAND(ID_RENDU_OPTIONECLAIREMENT_TRANSMISSION_SPECULAIRE, OnRenduOptioneclairementTransmissionSpeculaire)
	ON_UPDATE_COMMAND_UI(ID_RENDU_OPTIONECLAIREMENT_TRANSMISSION_SPECULAIRE, OnUpdateRenduOptioneclairementTransmissionSpeculaire)
	ON_COMMAND(ID_RENDU_OPTIONSCLAIREMENT_LUMIREAMBIANTE, OnRenduOptionsclairementLumireambiante)
	ON_UPDATE_COMMAND_UI(ID_RENDU_OPTIONSCLAIREMENT_LUMIREAMBIANTE, OnUpdateRenduOptionsclairementLumireambiante)
	ON_COMMAND(ID_RENDU_OPTIONSCLAIREMENT_PHONG, OnRenduOptionsclairementPhong)
	ON_UPDATE_COMMAND_UI(ID_RENDU_OPTIONSCLAIREMENT_PHONG, OnUpdateRenduOptionsclairementPhong)
	ON_COMMAND(ID_RENDU_OPTIONSCLAIREMENT_REFLEXIONDIFUSE, OnRenduOptionsclairementReflexiondifuse)
	ON_UPDATE_COMMAND_UI(ID_RENDU_OPTIONSCLAIREMENT_REFLEXIONDIFUSE, OnUpdateRenduOptionsclairementReflexiondifuse)
	ON_COMMAND(ID_RENDU_OPTIONSCLAIREMENT_REFLEXIONSPECULAIRE, OnRenduOptionsclairementReflexionspeculaire)
	ON_UPDATE_COMMAND_UI(ID_RENDU_OPTIONSCLAIREMENT_REFLEXIONSPECULAIRE, OnUpdateRenduOptionsclairementReflexionspeculaire)
	ON_COMMAND(ID_RENDU_OPTIONSCLAIREMENT_TEXTURES, OnRenduOptionsclairementTextures)
	ON_UPDATE_COMMAND_UI(ID_RENDU_OPTIONSCLAIREMENT_TEXTURES, OnUpdateRenduOptionsclairementTextures)
	ON_COMMAND(ID_RENDU_OPTIONSGLOBALES, OnRenduOptionsglobales)
	ON_UPDATE_COMMAND_UI(ID_RENDU_OPTIONSGLOBALES, OnUpdateRenduOptionsglobales)
	ON_COMMAND(ID_RENDU_SURECH_1, OnRenduSurech1)
	ON_UPDATE_COMMAND_UI(ID_RENDU_SURECH_1, OnUpdateRenduSurech1)
	ON_COMMAND(ID_RENDU_SURECH_2, OnRenduSurech2)
	ON_UPDATE_COMMAND_UI(ID_RENDU_SURECH_2, OnUpdateRenduSurech2)
	ON_COMMAND(ID_RENDU_SURECH_3, OnRenduSurech3)
	ON_UPDATE_COMMAND_UI(ID_RENDU_SURECH_3, OnUpdateRenduSurech3)
	ON_COMMAND(ID_RENDU_OPTIONECLAIREMENT_OMBRES, OnRenduOptioneclairementOmbres)
	ON_UPDATE_COMMAND_UI(ID_RENDU_OPTIONECLAIREMENT_OMBRES, OnUpdateRenduOptioneclairementOmbres)
	ON_COMMAND(ID_AFFICHAGE_OPTIONSCLAIREMENT_GOURAUD, OnAffichageOptionsclairementGouraud)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE_OPTIONSCLAIREMENT_GOURAUD, OnUpdateAffichageOptionsclairementGouraud)
	ON_COMMAND(ID_CONTROLES_NAVIGAT, OnControlesNavigat)
	ON_UPDATE_COMMAND_UI(ID_CONTROLES_NAVIGAT, OnUpdateControlesNavigat)
	ON_COMMAND(ID_EDIT_OBJET3D, OnEditObjet3d)
	ON_UPDATE_COMMAND_UI(ID_EDIT_OBJET3D, OnUpdateEditObjet3d)
	ON_WM_RBUTTONDOWN()
	ON_WM_LBUTTONDOWN()
	ON_COMMAND(ID_EDIT_SOURCE, OnEditSource)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SOURCE, OnUpdateEditSource)
	ON_COMMAND(ID_EDIT_SUPPRIMER_OBJET, OnEditSupprimerObjet)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SUPPRIMER_OBJET, OnUpdateEditSupprimerObjet)
	ON_COMMAND(ID_EDIT_SUPPRIMER_SOURCE, OnEditSupprimerSource)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SUPPRIMER_SOURCE, OnUpdateEditSupprimerSource)
	ON_COMMAND(ID_INSERE_SPLINEREVOL_EDITABLE, OnInsereSplinerevolEditable)
	ON_UPDATE_COMMAND_UI(ID_INSERE_SPLINEREVOL_EDITABLE, OnUpdateInsereSplinerevolEditable)
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_IMPORT_OBJET3D, OnImportObjet3d)
	ON_UPDATE_COMMAND_UI(ID_IMPORT_OBJET3D, OnUpdateImportObjet3d)
	ON_COMMAND(ID_EXPORT_OBJET3D, OnExportObjet3d)
	ON_UPDATE_COMMAND_UI(ID_EXPORT_OBJET3D, OnUpdateExportObjet3d)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdateFileSave)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdateFileSaveAs)
	ON_COMMAND(ID_ADAPT_ANTIALIAZING, OnAdaptAntialiazing)
	ON_UPDATE_COMMAND_UI(ID_ADAPT_ANTIALIAZING, OnUpdateAdaptAntialiazing)
	ON_COMMAND(ID_INSERE_CYLINDREVOL_DEFORMABLE, OnInsereCylindrevolDeformable)
	ON_UPDATE_COMMAND_UI(ID_INSERE_CYLINDREVOL_DEFORMABLE, OnUpdateInsereCylindrevolDeformable)
	ON_COMMAND(ID_INSERE_DEFORMABLE_CYL_EXTRU, OnInsereDeformableCylExtru)
	ON_UPDATE_COMMAND_UI(ID_INSERE_DEFORMABLE_CYL_EXTRU, OnUpdateInsereDeformableCylExtru)
	ON_WM_KEYDOWN()
	ON_WM_KEYUP()
	ON_COMMAND(ID_EDIT_GROUPOBJETS, OnEditGroupobjets)
	ON_UPDATE_COMMAND_UI(ID_EDIT_GROUPOBJETS, OnUpdateEditGroupobjets)
	ON_COMMAND(ID_EDIT_TRANSFORM, OnEditTransform)
	ON_UPDATE_COMMAND_UI(ID_EDIT_TRANSFORM, OnUpdateEditTransform)
	ON_COMMAND(ID_EDIT_UNGROUP_OBJECTS, OnEditUngroupObjects)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNGROUP_OBJECTS, OnUpdateEditUngroupObjects)
	ON_COMMAND(ID_INSERE_EXTRUSION_SPHERE, OnInsereExtrusionSphere)
	ON_UPDATE_COMMAND_UI(ID_INSERE_EXTRUSION_SPHERE, OnUpdateInsereExtrusionSphere)
	ON_COMMAND(ID_INSERE_EXTRUSION_TORUS, OnInsereExtrusionTorus)
	ON_UPDATE_COMMAND_UI(ID_INSERE_EXTRUSION_TORUS, OnUpdateInsereExtrusionTorus)
	ON_COMMAND(ID_INSERE_DEFORM_REVOL_TORUS, OnInsereDeformRevolTorus)
	ON_UPDATE_COMMAND_UI(ID_INSERE_DEFORM_REVOL_TORUS, OnUpdateInsereDeformRevolTorus)
	ON_COMMAND(ID_AFFICHAGE_OPTIONSCLAIREMENT_BUMPMAPS, OnAffichageOptionsclairementBumpmaps)
	ON_UPDATE_COMMAND_UI(ID_AFFICHAGE_OPTIONSCLAIREMENT_BUMPMAPS, OnUpdateAffichageOptionsclairementBumpmaps)
	ON_COMMAND(ID_RENDU_CONTINUE_RAYTRA, OnRenduContinueRaytra)
	ON_UPDATE_COMMAND_UI(ID_RENDU_CONTINUE_RAYTRA, OnUpdateRenduContinueRaytra)
	ON_WM_TIMER()
	ON_UPDATE_COMMAND_UI(ID_FILE_NOUVSCE, OnUpdateFileNouvsce)
	ON_COMMAND(ID_OPEN_DISPLAY_WINDOW, OnOpenDisplayWindow)
	ON_UPDATE_COMMAND_UI(ID_OPEN_DISPLAY_WINDOW, OnUpdateOpenDisplayWindow)
	ON_UPDATE_COMMAND_UI(ID_FICHIER_IMPORT_POLYTEXT, OnUpdateFichierImportPolytext)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSynthView construction/destruction

CSynthView::CSynthView()
{
	// TODO: add construction code here

	int i;

	CelluleTA::nballocglobales++;

	if (CelluleTA::nballocglobales == 1){

		CelluleTA::tetenew = CelluleTA::memoireTA = new CelluleTA[NBMAXTA];
		for (i = 0 ; i < NBMAXTA - 1 ; i++)
			CelluleTA::memoireTA[i].suiv = &(CelluleTA::memoireTA[i+1]);
		CelluleTA::memoireTA[NBMAXTA-1].suiv = NULL;

		CelluleTAA::tetenew = CelluleTAA::memoireTAA = new CelluleTAA[NBMAXTAA];
		for (i = 0 ; i < NBMAXTAA - 1 ; i++)
			CelluleTAA::memoireTAA[i].suiv = &(CelluleTAA::memoireTAA[i+1]);
		CelluleTAA::memoireTAA[NBMAXTAA-1].suiv = NULL;
	}

	dimx = dimy = 0;

	m_pDlg = new CControlCameraDlg(this);
	m_pDlgnavigat = new CControlNavigatDialog(this);
	steptrans = 10;
	steprot = 10;
	steprotnavigat = 5;
	steptransnavigat = 10;


	activinsere = false;
	progres=NULL;
	progressdlg=new CMyProgresDialog;
	enableuseinterface=true;
	enabledraw = true;
	raytracingfinished = false;
	displaywnd = NULL;

	rendudiscretenvoisources = CString("discret");

	nbobjetselect = 0;
	ctrlpressed = false;






	scene = Scene3DRay();



}

CSynthView::~CSynthView()
{


	CelluleTA::nballocglobales--;

	if (CelluleTA::nballocglobales == 0){
		delete [] CelluleTA::memoireTA;
		delete [] CelluleTAA::memoireTAA;
	}

	delete m_pDlg;
	delete m_pDlgnavigat;


	scene.destruction();

}

BOOL CSynthView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs


	return CView::PreCreateWindow(cs);
}



/////////////////////////////////////////////////////////////////////////////
// CSynthView drawing

void CSynthView::OnDraw(CDC* pDC)
{

	CSynthDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here

	if (!enabledraw){
		pDoc->p_mywindow->SetFocus();
		pDoc->bitcdc->BitBlt(0, 0, 569, 433, &pDoc->compatiblecdc, 0,0,SRCCOPY);
		return;
	}

	if (pDoc->p_mywindow != NULL){
		pDoc->mybitmap.Detach();
		pDoc->mybitmap.DeleteObject();
		pDoc->p_mywindow->DestroyWindow();
		delete pDoc->p_mywindow;
		pDoc->p_mywindow=NULL;
	}

	nbobjetselect=0;
	int dimprovx, dimprovy;

	GetClientRect(clientrect);


	dimprovx = clientrect.right - clientrect.left;
	dimprovy = clientrect.bottom - clientrect.top;

//	if (pDoc->besoinupdateobjetseditables)
//		scene.updateobjetselect();
	
	if (dimx != dimprovx || dimy != dimprovy || pDoc->besoinupdateobjetseditables){
		while (scene.setdim2D(dimprovx, dimprovy)){
			// probleme memoire
			AfxMessageBox(CString("Probleme m�moire,\nReduction des dimensions de la fen�tre"));
			dimprovx=(dimprovx*2)/3;
			dimprovy=(dimprovy*2)/3;
		}

		if (dimprovx != clientrect.right - clientrect.left ||
			dimprovy != clientrect.bottom - clientrect.top){
			CRect rect;
			GetWindowRect(rect);
			int dimbordx = (rect.right - rect.left) - (clientrect.right - clientrect.left);
			int dimbordy = (rect.bottom - rect.top) - (clientrect.bottom - clientrect.top);
			MoveWindow(rect.left, rect.top, dimprovx + dimbordx, dimprovy + dimbordy, true);
			return;
		}
		dimx = dimprovx;
		dimy = dimprovy;

		if (bitmap_dib.setdim(dimprovx, dimprovy))
			scene.zbuffer(bitmap_dib);
		else{
			AfxMessageBox(CString("probleme m�moire fatal !"));
		}
	}






	CClientDC cdc(this);



	SetDIBitsToDevice(
		cdc,              // handle to device context
		clientrect.left,            // x-coordinate of upper-left corner of 
                        // dest. rect.
		clientrect.top,            // y-coordinate of upper-left corner of 
                        // dest. rect.
		dimx,        // source rectangle width
		dimy,       // source rectangle height
		0,             // x-coordinate of lower-left corner of 
                        // source rect.
		0,             // y-coordinate of lower-left corner of 
                        // source rect.
		0,      // first scan line in array
		dimy,      // number of scan lines
		bitmap_dib.bitimage,  // address of array with DIB bits
		bitmap_dib.pbitmapinfo,  // address of structure with bitmap info.
		DIB_RGB_COLORS       // RGB or palette indexes
		);

 
}

/////////////////////////////////////////////////////////////////////////////
// CSynthView printing

BOOL CSynthView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSynthView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSynthView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSynthView diagnostics

#ifdef _DEBUG
void CSynthView::AssertValid() const
{
	CView::AssertValid();
}

void CSynthView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSynthDoc* CSynthView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSynthDoc)));
	return (CSynthDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSynthView message handlers

UINT ThreadSceneLoading(LPVOID p){
	CSynthView *pview = (CSynthView*)p;
	CSynthDoc *pDoc= (CSynthDoc*)pview->GetDocument();

	ifstream fich(pDoc->filename);

	if (fich.bad()){
		AfxMessageBox(CString("Probleme ouverture fichier !"));
		return 0;
	}

	pDoc->hasaname=true;

	pview->scene.charge_scene(fich, pDoc->p_Splines2D, pDoc->nbmaxSpline2D, pDoc->nbSpline2D, pview->dimx, pview->dimy);


	pview->scene.zbuffer(pview->bitmap_dib);

	pview->activinsere = 1;

	pview->enabledraw=true;
	pview->enableuseinterface=true;
	pview->Invalidate(true);
	return 0;
}

void CSynthView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	CSynthDoc *pDoc= (CSynthDoc*)CView::GetDocument();
	pDoc->pSynthView = this;
	
	CWnd *mainwindow = AfxGetMainWnd();
	CRect rect;

	CWnd *fils = mainwindow->GetWindow(GW_CHILD);
	fils->GetClientRect(rect);

	CWnd *parent = GetParent();

	parent->MoveWindow(rect.left, rect.top, rect.Width()/2, rect.Height(), false);

	parent->SetIcon(pDoc->icone_sphere,false);


	if (pDoc->hasaname){
    int i;
		for (i = strlen(pDoc->filename)-1 ; i>=0 && pDoc->filename[i] != '\\' ; i--)
			;
		if (i > 0){
			char newcurrentfolder[400];
			strcpy(newcurrentfolder, pDoc->filename);
			newcurrentfolder[i] = '\0';
			SetCurrentDirectory(CString(newcurrentfolder));
		}
		pDoc->mybitmap.LoadBitmap(IDB_START_IMAGE);
		BITMAP s;
		pDoc->mybitmap.GetBitmap(&s);
		CRect rect_screen;
		GetDesktopWindow()->GetWindowRect(rect_screen);
		int center_scr_x = (rect_screen.left+rect_screen.right)/2;
		int center_scr_y = (rect_screen.top+rect_screen.bottom)/2;
		CRect rect_bitmap(center_scr_x-s.bmWidth/2,center_scr_y-s.bmHeight/2,center_scr_x-s.bmWidth/2+s.bmWidth,center_scr_y-s.bmHeight/2+s.bmHeight);
		pDoc->p_mywindow = new CWnd();

		pDoc->p_mywindow->Create(NULL, CString("bitmap window"), WS_VISIBLE, rect_bitmap, 
			GetDesktopWindow(), 50000);

		pDoc->bitcdc = pDoc->p_mywindow->GetDC();
		pDoc->compatiblecdc.CreateCompatibleDC(pDoc->bitcdc);
		pDoc->compatiblecdc.SelectObject(pDoc->mybitmap);
		if (!pDoc->bitcdc->BitBlt(0, 0, 569, 433, &pDoc->compatiblecdc, 0,0,SRCCOPY))
			AfxMessageBox(CString("probleme display bitmap"));
		pDoc->p_mywindow->ShowWindow(SW_SHOW);

		CRect clientrect;
		GetClientRect(clientrect);
		dimx = clientrect.Width();
		dimy = clientrect.Height();
		bitmap_dib.setdim(dimx, dimy);

		pDoc->SetTitle(CString(pDoc->filename));

		enabledraw=false;
		enableuseinterface=false;
		AfxBeginThread(ThreadSceneLoading, this);

	}

}






LRESULT CSynthView::OnModifCamera(WPARAM wParam, LPARAM lParam)
{
	CClientDC cdc(this);

	AfxGetMainWnd()->PostMessage(WM_DETRUIRE_VUESP3D);

	steptrans = m_pDlg->m_transstep;
	steprot = m_pDlg->m_rotstep;

	if (wParam == IDC_CC_TRANS_DOWN){
		scene.translatecamcentral(0, steptrans, 0);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CC_TRANS_UP){
		scene.translatecamcentral(0, -steptrans, 0);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CC_TRANS_LEFT){
		scene.translatecamcentral(-steptrans, 0, 0);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CC_TRANS_RIGHT){
		scene.translatecamcentral(steptrans, 0, 0);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CC_TRANS_FORWARD){
		scene.translatecamcentral(0, 0, steptrans);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CC_TRANS_BACKWARD){
		scene.translatecamcentral(0, 0, -steptrans);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CC_ROT_UP){
		scene.rotatecamcentral(-steprot, 0);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CC_ROT_DOWN){
		scene.rotatecamcentral(steprot, 0);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}


	if (wParam == IDC_CC_ROT_LEFT){
		scene.rotatecamcentral(-steprot, 1);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CC_ROT_RIGHT){
		scene.rotatecamcentral(steprot, 1);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}


	if (wParam == IDC_CC_ROT_RG){
		scene.rotatecamcentral(steprot, 2);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CC_ROT_RD){
		scene.rotatecamcentral(-steprot, 2);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	return 0L;
}







LRESULT CSynthView::OnModifCameraNavigat(WPARAM wParam, LPARAM lParam)
{
	CClientDC cdc(this);

	AfxGetMainWnd()->PostMessage(WM_DETRUIRE_VUESP3D);

	steptrans = m_pDlgnavigat->m_transstep;
	steprot = m_pDlgnavigat->m_rotstep;

	if (wParam == IDC_CN_TRANS_DOWN){
		scene.translatecam(0, steptrans, 0);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CN_TRANS_UP){
		scene.translatecam(0, -steptrans, 0);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CN_TRANS_LEFT){
		scene.translatecam(-steptrans, 0, 0);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CN_TRANS_RIGHT){
		scene.translatecam(steptrans, 0, 0);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CN_TRANS_FORWARD){
		scene.translatecam(0, 0, steptrans);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CN_TRANS_BACKWARD){
		scene.translatecam(0, 0, -steptrans);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CN_ROT_UP){
		scene.rotatecam(steprot, 0);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CN_ROT_DOWN){
		scene.rotatecam(-steprot, 0);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}


	if (wParam == IDC_CN_ROT_LEFT){
		scene.rotatecam(steprot, 1);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CN_ROT_RIGHT){
		scene.rotatecam(-steprot, 1);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}


	if (wParam == IDC_CN_ROT_RG){
		scene.rotatecam(steprot,  2);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CN_ROT_RD){
		scene.rotatecam(-steprot, 2);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	double vecttranslz = m_pDlgnavigat->m_backward ? -steptrans : steptrans;
	if (wParam == IDC_CN_ROTTRANS_UP){
		scene.rotatetranslatecam(steprot, vecttranslz, 0);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CN_ROTTRANS_DOWN){
		scene.rotatetranslatecam(-steprot, vecttranslz, 0);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}


	if (wParam == IDC_CN_ROTTRANS_LEFT){
		scene.rotatetranslatecam(steprot, vecttranslz, 1);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CN_ROTTRANS_RIGHT){
		scene.rotatetranslatecam(-steprot, vecttranslz, 1);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}


	if (wParam == IDC_CN_ROTTRANS_RG){
		scene.rotatetranslatecam(steprot, vecttranslz, 2);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	if (wParam == IDC_CN_ROTTRANS_RD){
		scene.rotatetranslatecam(-steprot, vecttranslz, 2);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

	return 0L;
}







void CSynthView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	nbobjetselect=0;
	CClientDC cdc(this);
	OnDraw(&cdc);
	CView::OnRButtonDown(nFlags, point);

	
}

void CSynthView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	CSynthDoc* pDoc = (CSynthDoc*)GetDocument();
	if (pDoc->fenetreSpline3DViewouverte){
		Beep(600, 100);	
		return;
	}

	CClientDC cdc(this);
	if (!ctrlpressed)
		OnDraw(&cdc);
	int numobjet;
	if ((numobjet=scene.selectionneobjet(point, cdc, numobjetselect, nbobjetselect, ctrlpressed)) >= 4)

	CView::OnLButtonDown(nFlags, point);
}





void CSynthView::OnSetFocus(CWnd* pOldWnd) 
{
	CView::OnSetFocus(pOldWnd);
	
	
	// TODO: Add your message handler code here
	CSynthDoc* pDoc = (CSynthDoc*)GetDocument();


	pDoc->vue_active = VUE3D;

	if (pDoc->besoinupdateobjetseditables){
		pDoc->besoinupdateobjetseditables=false;
		if (pDoc->objetedite == NULL || pDoc->objetedite->gettype() != SPLINE3DEDITABLE)
			return;
		delete ((Spline3DEditable*)pDoc->objetedite)->ManipluleSurface();
		((Spline3DEditable*)pDoc->objetedite)->ManipluleSurface() = pDoc->surfaceobj->copie();
		((Spline3DEditable*)pDoc->objetedite)->ManipluleSurface()->mettredansreperescene(pDoc->cam,
																			pDoc->objetedite->getrot(), 
																			pDoc->objetedite->getscax(),
																			pDoc->objetedite->getscay(),
																			pDoc->objetedite->getscaz(),
																			pDoc->objetedite->getorigine());
		scene.updateobjetselect(pDoc->objetedite);
		scene.zbuffer(bitmap_dib);
		CClientDC cdc(this);
		OnDraw(&cdc);
	}

}



void CSynthView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	
	if (nChar == 17)
		ctrlpressed = true;

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CSynthView::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	if (nChar == 17)
		ctrlpressed = false;

	CView::OnKeyUp(nChar, nRepCnt, nFlags);
}




void CSynthView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default


	if (progressdlg != NULL){
		progressdlg->m_progctrl.SetPos(percentcalcul);
		if (percentcalcul >= 99 && firstphase && scene.getrenduetatsurechant()==0){
			firstphase=false;
			percentcalcul=0;
			progressdlg->SetWindowText(CString("Ray tracing : second phase"));

		}

		if (raytracingfinished){
			progressdlg->DestroyWindow();
			delete progressdlg;
			progressdlg=NULL;
			displaywnd = new CDisplayImageWnd(bitmap_render);
			displaywnd->CreateAndDisplay();

			KillTimer(1);
			raytracingfinished=false;
		}
	}
	CView::OnTimer(nIDEvent);
}


