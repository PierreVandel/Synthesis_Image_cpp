// Rayon.cpp: implementation of the Rayon class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Synth.h"
#include "Rayon.h"
#include "Objetderiv.h"
#include "Scene3Dray.h"




#include <math.h>


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Rayon::Rayon()
{

}

Rayon::~Rayon()
{

}





bool Scene3DRay::calculintersectproche(
							Rayon ray,
							int &numobjetproche,  // numero de l'objet intersect�
							ResultIntersect &resplusproche,  // resultat de l'intersection
							double &min_t_inter, // distance de l'objet le plus proche � l'observateur
							Objet3D * &objetintersecte){

	bool intersectobjet=false;
	objetintersecte=NULL;  // pointeur sur l'objet intersect�
	ResultIntersect resinter;
	
	min_t_inter = INFINI;
	// calcul du nombre d'objets en dehors des axes :
	Celluleobj *p;
	int nbobjets = 0;
	for (p = objets.L ; p != NULL ; p = p->suiv)
		nbobjets++;
	nbobjets -= 3;

	// parcours des objets diff�rents des axes :
	int compteur = 0;
	for (p = objets.L ; p != NULL ; p = p->suiv){
		compteur++;
		double rubish;
		if (compteur <= nbobjets)
			if (p->pobjet->calculintersect(ray ,resinter,
											false, rubish, 0,
											renduenablephong, renduenabletexture) &&  // si intersection de l'objet
				resinter.t_inter < min_t_inter){  // et intersection plus proche
				intersectobjet=true;			// on intersecte un objet
				min_t_inter = resinter.t_inter;  // nouveau minimum
				resplusproche = resinter;  // resultat de l'intersection du plus proche
				numobjetproche=compteur;   // numero de l'objet le plus proche
				objetintersecte = p->pobjet;  // adresse de l'objet le plus proche					
			}
	}
	return intersectobjet;
}


bool Scene3DRay::testshadow(Rayon raylum, double distance, double & attenuation){

	ResultIntersect rubish;
	Celluleobj *p;
	int nbobjets = 0;
	for (p = objets.L ; p != NULL ; p = p->suiv)
		nbobjets++;
	nbobjets -= 3;
	int compteur = 0;
	for (p = objets.L ; p != NULL ; p = p->suiv){
		compteur++;
		if (compteur <= nbobjets)
			if (p->pobjet->calculintersect(raylum, rubish, true, attenuation, distance, false, false)){  // test d'intersection
				return true;
			}
			
	}
	return false;
}



bool Boiteenglobante::testintersect2boites(Boiteenglobante &boite){

	if (((xmin <= boite.xmin && boite.xmin <= xmax) ||
		 (xmin <= boite.xmax && boite.xmax <= xmax) ||
		 (boite.xmin <= xmin && xmin <= boite.xmax) ||
		 (boite.xmin <= xmax && xmax <= boite.xmax)) &&
		((ymin <= boite.ymin && boite.ymin <= ymax) ||
		 (ymin <= boite.ymax && boite.ymax <= ymax) ||
		 (boite.ymin <= ymin && ymin <= boite.ymax) ||
		 (boite.ymin <= ymax && ymax <= boite.ymax)) &&
		((zmin <= boite.zmin && boite.zmin <= zmax) ||
		 (zmin <= boite.zmax && boite.zmax <= zmax) ||
		 (boite.zmin <= zmin && zmin <= boite.zmax) ||
		 (boite.zmin <= zmax && zmax <= boite.zmax)))
		 return true;
	else
		return false;
}


void Scene3DRay::calculboitesenglobantes(void){

	Celluleobj *p;
	for (p = objets.L ; p != NULL ; p = p->suiv){
		double xminib, xmaxib;
		double yminib, ymaxib;
		double zminib, zmaxib;
		xminib = yminib = zminib = INFINI;
		xmaxib = ymaxib = zmaxib= -INFINI;

		for (int i = 0 ; i < p->pobjet->nbfaces ; i++){
			p->pobjet->faces[i].calculnormaleetplan(p->pobjet->tabsomm);
			double xmin, xmax, ymin, ymax, zmin, zmax;
			xmin = ymin = zmin = INFINI;
			xmax = ymax = zmax = -1e6;
			for (int j = 0 ; j < p->pobjet->faces[i].nbsomm ; j++){
				if (xmin > p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.x)
					xmin = p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.x;
				if (xmax < p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.x)
					xmax = p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.x;
				if (ymin > p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.y)
					ymin = p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.y;
				if (ymax < p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.y)
					ymax = p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.y;
				if (zmin > p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.z)
					zmin = p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.z;
				if (zmax < p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.z)
					zmax = p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos.z;
			}
			p->pobjet->faces[i].boundingbox = Boiteenglobante(xmin, xmax, ymin, ymax, zmin, zmax);
			if (xminib > xmin)
				xminib = xmin;
			if (xmaxib < xmax)
				xmaxib = xmax;
			if (yminib > ymin)
				yminib = ymin;
			if (ymaxib < ymax)
				ymaxib = ymax;
			if (zminib > zmin)
				zminib = zmin;
			if (zmaxib < zmax)
				zmaxib = zmax;
			
				
		}
		p->pobjet->boundingbox = Boiteenglobante(xminib, xmaxib, yminib, ymaxib, zminib, zmaxib);
	}

/*
		Boiteenglobante boundingbox;
	Boiteenglobante *tabboundingbox;
	int * nofacesdansboites;
	int * indicesfinboites;
	int nbboites;
	int racinecubiquenbboites;

*/
	for (p = objets.L ; p != NULL ; p = p->suiv){
		p->pobjet->nbboites = 1;
		p->pobjet->racinecubiquenbboites = 1;
		int approxnbboites = p->pobjet->nbfaces/50;
//		int approxnbboites = 1;
		if (approxnbboites==0)
			approxnbboites = 1;
		while (p->pobjet->nbboites < approxnbboites){
			p->pobjet->nbboites *= 8;
			p->pobjet->racinecubiquenbboites *= 2;
		}
		p->pobjet->tabboundingbox = new Boiteenglobante[p->pobjet->nbboites];
		p->pobjet->indicesfinboites = new int[p->pobjet->nbboites];

//		for (int j = 0 ; j < p->pobjet->nbfaces; j++)
//			compteurnbsomm += p->pobjet->faces[j].nbsomm;
//		p->pobjet->nofacesdansboites = new int[compteurnbsomm];
		p->pobjet->nofacesdansboites = new int[p->pobjet->nbfaces*30];

		int compt = 0;
		for (int i = 0 ; i < p->pobjet->racinecubiquenbboites ; i++)
			for (int j = 0 ; j < p->pobjet->racinecubiquenbboites ; j++)
				for (int k = 0 ; k < p->pobjet->racinecubiquenbboites ; k++){
					p->pobjet->tabboundingbox[compt++] = Boiteenglobante(
						p->pobjet->boundingbox.xmin+i*(p->pobjet->boundingbox.xmax - p->pobjet->boundingbox.xmin)/((double)p->pobjet->racinecubiquenbboites),
						p->pobjet->boundingbox.xmin+(i+1)*(p->pobjet->boundingbox.xmax - p->pobjet->boundingbox.xmin)/((double)p->pobjet->racinecubiquenbboites),
						p->pobjet->boundingbox.ymin+j*(p->pobjet->boundingbox.ymax - p->pobjet->boundingbox.ymin)/((double)p->pobjet->racinecubiquenbboites),
						p->pobjet->boundingbox.ymin+(j+1)*(p->pobjet->boundingbox.ymax - p->pobjet->boundingbox.ymin)/((double)p->pobjet->racinecubiquenbboites),
						p->pobjet->boundingbox.zmin+k*(p->pobjet->boundingbox.zmax - p->pobjet->boundingbox.zmin)/((double)p->pobjet->racinecubiquenbboites),
						p->pobjet->boundingbox.zmin+(k+1)*(p->pobjet->boundingbox.zmax - p->pobjet->boundingbox.zmin)/((double)p->pobjet->racinecubiquenbboites));
				}
	}

	for (p = objets.L ; p != NULL ; p = p->suiv){
		for (int k = 0 ; k < p->pobjet->nbboites ; k++){
			if (k == 0)
				p->pobjet->indicesfinboites[k] = 0;
			else
				p->pobjet->indicesfinboites[k] = p->pobjet->indicesfinboites[k-1];
			for (int i = 0 ; i < p->pobjet->nbfaces ; i++){
//				for (int j = 0 ; j < p->pobjet->faces[i].nbsomm; j++){
//					if (p->pobjet->tabboundingbox[k].appartient(p->pobjet->tabsomm[p->pobjet->faces[i].tabnosomm[j]].pos)){
//						p->pobjet->nofacesdansboites[p->pobjet->indicesfinboites[k]++] = i;
//						break;
//					}
//				}
				if (p->pobjet->tabboundingbox[k].testintersect2boites(p->pobjet->faces[i].boundingbox)){
					p->pobjet->nofacesdansboites[p->pobjet->indicesfinboites[k]++] = i;
					if (p->pobjet->nbfaces*30 <= p->pobjet->indicesfinboites[k]){
						AfxMessageBox(CString("Depassement nbre de faces par boite englobante"));
						p->pobjet->indicesfinboites[k] = p->pobjet->indicesfinboites[k-1];
						break;
					}
				}
			}
		}
	}
}


void Scene3DRay::detruitboitesenglobantes(void){

	Celluleobj *p;
	for (p = objets.L ; p != NULL ; p = p->suiv){
		delete [] p->pobjet->nofacesdansboites;
		delete [] p->pobjet->indicesfinboites;
		delete [] p->pobjet->tabboundingbox;

	}
}




//////////////////////////////////////////////////////////////////////
// Implementation des calculs d'intersection
//////////////////////////////////////////////////////////////////////


void Objet3D::copiedonnees(ResultIntersect & resinter){

	resinter.couleur = material.couleur; // coefficients RGB de la couleur (entre 0 et 1)
	resinter.intens.rsR = 0;
	resinter.intens.rsG = 0;
	resinter.intens.rsB = 0;
	resinter.intens.rdR = 0;
	resinter.intens.rdG = 0;
	resinter.intens.rdB = 0;

}

bool Cloche::calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture){

	Rayon ray_obj;
	ray_obj.origine = rotation.t()*(ray_sce.origine - origine);
	ray_obj.vectdirect = rotation.t()*ray_sce.vectdirect;

	double t_near = -INFINI;
	double t_far = INFINI;

	double t_1, t_2;

	char noaxeintersect = 0, noaxeintersectfar=0;


	if (scalex != 1 || scaley != 1 || scalez != 1){
		xmin*=scalex;
		xmax*=scalex;
		ymin*=scaley;
		ymax*=scaley;
		zmin*=scalez;
		zmax*=scalez;
		scalex = scaley = scalez = 1;
	}
	// axe des x :

	if (ray_obj.vectdirect.x == 0)
		if (ray_obj.origine.x < xmin || ray_obj.origine.x > xmax)
			return false;

	t_1 = (xmin - ray_obj.origine.x) / ray_obj.vectdirect.x;
	t_2 = (xmax - ray_obj.origine.x) / ray_obj.vectdirect.x;

	if (t_1 > t_2){
		double temp = t_1;
		t_1 = t_2;
		t_2 = temp;
	}

	if (t_1 > t_near){
		t_near = t_1;
		noaxeintersect = 1;	
	}

	if (t_2 < t_far){
		t_far = t_2;
		noaxeintersectfar = 1;
	}

	if (t_near > t_far || t_far < EPSILON)
		return false;


	// axe des y :

	
	if (ray_obj.vectdirect.y == 0)
		if (ray_obj.origine.y < ymin || ray_obj.origine.y > ymax)
			return false;

	t_1 = (ymin - ray_obj.origine.y) / ray_obj.vectdirect.y;
	t_2 = (ymax - ray_obj.origine.y) / ray_obj.vectdirect.y;

	if (t_1 > t_2){
		double temp = t_1;
		t_1 = t_2;
		t_2 = temp;
	}

	if (t_1 > t_near){
		t_near = t_1;
		noaxeintersect = 2;	
	}

	if (t_2 < t_far){
		t_far = t_2;
		noaxeintersectfar=2;
	}

	if (t_near > t_far || t_far < EPSILON)
		return false;

	
	// axe des z :

	if (ray_obj.vectdirect.z == 0)
		if (ray_obj.origine.z < zmin || ray_obj.origine.z > zmax)
			return false;

	t_1 = (zmin - ray_obj.origine.z) / ray_obj.vectdirect.z;
	t_2 = (zmax - ray_obj.origine.z) / ray_obj.vectdirect.z;

	if (t_1 > t_2){
		double temp = t_1;
		t_1 = t_2;
		t_2 = temp;
	}

	if (t_1 > t_near){
		t_near = t_1;
		noaxeintersect = 3;	
	}

	if (t_2 < t_far){
		t_far = t_2;
		noaxeintersectfar=3;
	}

	if (t_near > t_far || t_far < EPSILON)
		return false;

	if (testshadow){
		if (t_near > EPSILON && t_near < distance)
			attenuat *= attenuation();
		if (t_far < distance)
			attenuat *= attenuation();
		if (attenuat == 0) 
			return true;
		else
			return false;
	}
	
	Objet3D::copiedonnees(resinter);

	int noface;

	if (t_near < EPSILON){
		noaxeintersect = noaxeintersectfar;
		resinter.t_inter = t_far;
		switch (noaxeintersect){
			case 1 : resinter.normale = Point3D(1,0,0);
				noface = ray_obj.vectdirect.x >= 0 ? 2 : 5; 
					break;
			case 2 : resinter.normale = Point3D(0,1,0);
				noface = ray_obj.vectdirect.y >= 0 ? 0 : 3; 
					break;
			case 3 : resinter.normale = Point3D(0,0,1);
				noface = ray_obj.vectdirect.z >= 0 ? 1 : 4; 
					break;
		}
	}else{
		resinter.t_inter = t_near;
		switch (noaxeintersect){
			case 1 : resinter.normale = Point3D(1,0,0);
				noface = ray_obj.vectdirect.x >= 0 ? 5 : 2; 
					break;
			case 2 : resinter.normale = Point3D(0,1,0);
				noface = ray_obj.vectdirect.y >= 0 ? 3 : 0; 
					break;
			case 3 : resinter.normale = Point3D(0,0,1);
				noface = ray_obj.vectdirect.z >= 0 ? 4 : 1; 
					break;
		}
	}


	Point3D p3d = ray_obj.origine + resinter.t_inter*ray_obj.vectdirect;
	double coordx, coordy;
	Point3D dpsds, dpsdt;
	char notext;

	if (texture && (textures.withtexture[0] || textures.withtexture[1] || textures.withtexture[2]) ||
		textures.withbumpmap[0] || textures.withbumpmap[1] || textures.withbumpmap[2]){
		switch (noface){
		
		case 0: coordx = (p3d.x-xmin)/(xmax-xmin);
				coordy = 1 - (p3d.z-zmin)/(zmax-zmin);
				dpsds = Point3D(xmax-xmin,0,0);
				dpsdt = Point3D(0,0,zmax-zmin);
				notext = 0;	
				break;
		case 3: coordx = 1 - (p3d.x-xmin)/(xmax-xmin);
				coordy = 1 - (p3d.z-zmin)/(zmax-zmin);
				dpsds = Point3D(xmax-xmin,0,0);
				dpsdt = Point3D(0,0,zmax-zmin);
				notext = 0;	
				break;
		
		case 1: coordx = (p3d.x-xmin)/(xmax-xmin);
				coordy = (p3d.y-ymin)/(ymax-ymin);
				dpsds = Point3D(xmax-xmin,0,0);
				dpsdt = Point3D(0,ymin-ymax,0);
				notext = 1;	
				break;
		
		case 4: coordx = (p3d.x-xmin)/(xmax-xmin);
				coordy = (p3d.y-ymin)/(ymax-ymin);
				dpsds = Point3D(xmax-xmin,0,0);
				dpsdt = Point3D(0,ymax-ymin,0);
				notext = 2;	

				break;

		case 2: coordx = 1-(p3d.y-ymin)/(ymax-ymin);
				coordy = 1 - (p3d.z-zmin)/(zmax-zmin);
				dpsds = Point3D(0,ymin-ymax,0);
				dpsdt = Point3D(0,0,zmax-zmin);
				notext = 0;	
				break;

		case 5: coordx = (p3d.y-ymin)/(ymax-ymin);
				coordy = 1 - (p3d.z-zmin)/(zmax-zmin);
				dpsds = Point3D(0,ymax-ymin,0);
				dpsdt = Point3D(0,0,zmax-zmin);
				notext = 0;	
				break;
		
		}
		if (textures.withtexture[notext] && texture){
			textures.imtexture[notext].getpixelinterpol((coordx*((double)textures.imtexture[notext].largeur()-1.0)), 
							(coordy*((double)textures.imtexture[notext].hauteur()-1.0)),
							resinter.couleur.R, resinter.couleur.G, resinter.couleur.B);
		}

		if (textures.withbumpmap[notext]){
			resinter.normale = calculnormalebump(notext,coordx, coordy, dpsds, dpsdt);
		}
	}



	resinter.normale = rotation * resinter.normale;
	return true;
}


bool Sphere::calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture){

	Rayon ray_obj;
	ray_obj.origine = rotation.t()*(ray_sce.origine - origine) +origine;
	ray_obj.vectdirect = rotation.t()*ray_sce.vectdirect;
	double normvecdir;
	if (scalex != 1 || scaley != 1 || scalez != 1){
		ray_obj.vectdirect.x /= scalex;
		ray_obj.origine.x = origine.x + (ray_sce.origine.x - origine.x)/scalex;
		ray_obj.vectdirect.y /= scaley;
		ray_obj.origine.y = origine.y + (ray_sce.origine.y - origine.y)/scaley;
		ray_obj.vectdirect.z /= scalez;
		ray_obj.origine.z = origine.z + (ray_sce.origine.z - origine.z)/scalez;
		normvecdir = 1/ray_obj.vectdirect.norme();
		ray_obj.vectdirect = ray_obj.vectdirect*normvecdir;
	}

	double distcentrecarre = (ray_obj.origine-origine).normecarre();

	double tca = (origine-ray_obj.origine)*ray_obj.vectdirect;

	double rayoncarre=rayon*rayon;
	if (tca < 0 && distcentrecarre > (rayoncarre))
		return false;

	double D2 = distcentrecarre - tca*tca;

	double thccarre = rayoncarre - D2;

	if (thccarre < 0)
		return false;

	double t;
	if (distcentrecarre > rayoncarre){
		double thc = sqrt(thccarre);
		t = tca - thc;
		if (t < EPSILON){
			t = tca + thc;
			if (t < EPSILON)
				return false;
		}else{
			if (testshadow && t < distance){
				attenuat *= attenuation();
				t = tca + thc;
				
			}
		}
	}
	else{
		t = tca + sqrt(thccarre);
		if (t < EPSILON)
			return false;
	}

	if (testshadow){
		if (t < distance)
			attenuat *= attenuation();
		if (attenuat == 0) return true;
			else return false;
	}
	resinter.t_inter = t;

	resinter.normale = ((ray_obj.origine + t*ray_obj.vectdirect) - origine);

	Objet3D::copiedonnees(resinter);

	if ((textures.withtexture[0] && texture) || textures.withbumpmap[0]){
		Point3D ptinter = Point3D(ray_obj.origine.x + resinter.t_inter*ray_obj.vectdirect.x,
									ray_obj.origine.y + resinter.t_inter*ray_obj.vectdirect.y,
									ray_obj.origine.z + resinter.t_inter*ray_obj.vectdirect.z);		
		ptinter = (ptinter - origine);
		double cosphi = ptinter.z/this->rayon; // passage dans le rep�re de la sphere
		double costheta = ptinter.x/sqrt(ptinter.x*ptinter.x + ptinter.y*ptinter.y);
		double phi = acos(cosphi); // passage dans le rep�re de la sphere
		double theta = acos(costheta);
		if (ptinter.y < 0){
			theta = (2*pi) - theta;
		}

		if (textures.withtexture[0] && texture){
			textures.imtexture[0].getpixelinterpol((((double)textures.imtexture[0].largeur()-1.0)/(2*pi)*theta), 
							(((double)textures.imtexture[0].hauteur()-1.0)*phi/pi),
							resinter.couleur.R, resinter.couleur.G, resinter.couleur.B);
		}


		if (textures.withbumpmap[0]){
			double sintheta = sin(theta);
			double sinphi = sin(phi);
			Point3D dpsds = Point3D((-sintheta*sinphi)*2*pi*rayon, costheta*sinphi*2*pi*rayon,0);
			Point3D dpsdt = Point3D(costheta*cosphi*rayon*pi, sintheta*cosphi*rayon*pi, -sinphi*rayon*pi);
			resinter.normale = calculnormalebump(0,theta/(2*pi), phi/pi, dpsds, dpsdt);
		}
	}

	if (scalex != 1 || scaley != 1 || scalez != 1){
		resinter.normale.x /= scalex;
		resinter.normale.y /= scaley;
		resinter.normale.z /= scalez;
		resinter.t_inter*=normvecdir;
	}
	resinter.normale = rotation * resinter.normale;
	resinter.normale.normer();

	return true;
}




bool Polyedre::calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture) {

	return Objet3D::calculintersectpolyedre(ray_sce,
								resinter,  // resultat de l'intersection
								testshadow, attenuat, distance,
								phong, texture);
}

/*
bool Polyedre::testintersect(const Rayon & ray_sce, double tlimit){

	return Objet3D::testintersectpolyedre(ray_sce, tlimit);
}
*/





bool Cylinrevol::calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture){

	Rayon ray_obj;
	ray_obj.origine = rotation.t()*(ray_sce.origine - origine);
	ray_obj.vectdirect = rotation.t()*ray_sce.vectdirect;

	double scax2 = scalex*scalex;
	double scay2 = scaley*scaley;
	double a = ray_obj.vectdirect.x*ray_obj.vectdirect.x/scax2 +
				ray_obj.vectdirect.y*ray_obj.vectdirect.y/scay2;
	double b = 2*(ray_obj.origine.x*ray_obj.vectdirect.x/scax2 +
				ray_obj.origine.y*ray_obj.vectdirect.y/scay2);

	double c = ray_obj.origine.x*ray_obj.origine.x/scax2 +
		ray_obj.origine.y*ray_obj.origine.y/scay2 - rayon*rayon;


	double demihauteur = hauteur*scalez/2;
	int nbintersectcorps = 0;
	double t1, t2;
	if (a != 0.0){
		double delta = b*b - 4*a*c;
		if (delta > 0){
			t1 = (-b -sqrt(delta))/(2*a);
			t2 = (-b +sqrt(delta))/(2*a);
			if (t1 > EPSILON){
				double z1 = ray_obj.origine.z + t1*ray_obj.vectdirect.z;
				if (z1 >= -demihauteur && z1 <= demihauteur  &&  (!testshadow || t1 < distance)){
					nbintersectcorps++;
					resinter.t_inter = t1;
					if (!testshadow){
						resinter.normale.x = (ray_obj.origine.x + t1*ray_obj.vectdirect.x);
						resinter.normale.y = (ray_obj.origine.y + t1*ray_obj.vectdirect.y);
						resinter.normale.z = 0;
						resinter.normale.x /= scalex;
						resinter.normale.y /= scaley;
						resinter.normale.normer();
						resinter.normale = rotation*resinter.normale;
						Objet3D::copiedonnees(resinter);

						if (textures.withtexture[0] && texture || textures.withbumpmap[0]){
							Point3D ptinter = Point3D(ray_obj.origine.x + resinter.t_inter*ray_obj.vectdirect.x,
														ray_obj.origine.y + resinter.t_inter*ray_obj.vectdirect.y,
														ray_sce.origine.z + resinter.t_inter*ray_obj.vectdirect.z);	
							double costheta = ptinter.x/sqrt(ptinter.x*ptinter.x + ptinter.y*ptinter.y);
							double theta = acos(costheta);
							if (ptinter.y < 0){
								theta = (2*pi) - theta;
							}
							if (textures.withtexture[0] && texture)
								textures.imtexture[0].getpixelinterpol((((double)textures.imtexture[0].largeur()-1.0)/(2*pi)*theta), 
												(((double)textures.imtexture[0].hauteur()-1.0)*(z1+(hauteur/2))/hauteur),
												resinter.couleur.R, resinter.couleur.G, resinter.couleur.B);
							if (textures.withbumpmap[0]){
								double sintheta = sin(theta);
								Point3D dpsds = Point3D(-sintheta*2*pi*rayon, costheta*2*pi*rayon,0);
								Point3D dpsdt = Point3D(0, 0, hauteur);
								resinter.normale = calculnormalebump(0, theta/(2*pi), (z1+(hauteur/2))/hauteur, dpsds, dpsdt);
							}
						}

						return true;
					}
				}
			}
			if (t2 > EPSILON && (testshadow || t1 < EPSILON)){
					double z2 = ray_obj.origine.z + t2*ray_obj.vectdirect.z;
					if (z2 >= -demihauteur && z2 <= demihauteur &&  (!testshadow || t2 < distance)){
						nbintersectcorps++;						
					}
				}
			}
	

	}
	double t, tp;
	double tp1, tp2;
	bool intersect1, intersect2;
	if (ray_obj.vectdirect.z == 0.0){
		if (nbintersectcorps == 0)
			return false;
		else
			t = t2;
	}else{
		tp1 = (-demihauteur - ray_obj.origine.z)/ray_obj.vectdirect.z;
		double x1 = ray_obj.origine.x + tp1*ray_obj.vectdirect.x;
		double y1 = ray_obj.origine.y + tp1*ray_obj.vectdirect.y;
		if (tp1 < EPSILON || x1*x1/scax2 + y1*y1/scay2 > rayon*rayon || (testshadow && tp1 > distance))
			intersect1 = false;
		else
			intersect1 = true;

		tp2 = (demihauteur - ray_obj.origine.z)/ray_obj.vectdirect.z;
		double x2 = ray_obj.origine.x + tp2*ray_obj.vectdirect.x;
		double y2 = ray_obj.origine.y + tp2*ray_obj.vectdirect.y;
		if (tp2 < EPSILON || x2*x2/scax2 + y2*y2/scay2 > rayon*rayon  || (testshadow && tp2 > distance))
			intersect2 = false;
		else
			intersect2 = true;
	}


	if (nbintersectcorps>=1){
		if (testshadow){
			int nbint = nbintersectcorps + ((intersect1 || intersect2) ? 1 : 0);
			attenuat *= attenuation();
			if (nbint >= 2)
				attenuat *= attenuation();
			if (attenuat == 0) return true;
			return false;
		}
		t = t2;
		if (intersect1)
			tp = tp1;
		else
			if (intersect2)
				tp = tp2;

		if ((!intersect1 && !intersect2) || t < tp){
			resinter.t_inter = t;

			resinter.normale.x = (ray_obj.origine.x + t*ray_obj.vectdirect.x);
			resinter.normale.y = (ray_obj.origine.y + t*ray_obj.vectdirect.y);
			resinter.normale.x /= scalex;
			resinter.normale.y /= scaley;
			resinter.normale.z = 0;
			resinter.normale.normer();
			resinter.normale = rotation*resinter.normale;

			Objet3D::copiedonnees(resinter);

			if (textures.withtexture[0] && texture || textures.withbumpmap[0]){
				Point3D ptinter = Point3D(ray_obj.origine.x + resinter.t_inter*ray_obj.vectdirect.x,
													ray_obj.origine.y + resinter.t_inter*ray_obj.vectdirect.y,
													ray_obj.origine.z + resinter.t_inter*ray_obj.vectdirect.z);	
					
				double costheta = ptinter.x/sqrt(ptinter.x*ptinter.x + ptinter.y*ptinter.y);
				double theta = acos(costheta);
				if (ptinter.y < 0){
					theta = (2*pi) - theta;
				}
				if (textures.withtexture[0] && texture)
					textures.imtexture[0].getpixelinterpol((((double)textures.imtexture[0].largeur()-1.0)/(2*pi)*theta), 
											(((double)textures.imtexture[0].hauteur()-1.0)*(ptinter.z
											+(hauteur/2))/hauteur),
											resinter.couleur.R, resinter.couleur.G, resinter.couleur.B);
				if (textures.withbumpmap[0]){
					double sintheta = sin(theta);
					Point3D dpsds = Point3D(-sintheta*2*pi*rayon, costheta*2*pi*rayon,0);
					Point3D dpsdt = Point3D(0, 0, hauteur);
					resinter.normale = calculnormalebump(0, theta/(2*pi), (ptinter.z+(hauteur/2))/hauteur, dpsds, dpsdt);
				}
			}

			return true;
		}else{
			if (intersect1 || intersect2){
				resinter.t_inter = tp;
				resinter.normale = Point3D(0,0,1);
				resinter.normale = rotation*resinter.normale;
				Objet3D::copiedonnees(resinter);
				return true;
			}else
				return false;
		}
	}else{
		if (testshadow){
			int nbint = ((intersect1 && intersect2) ? 2 : ((intersect1 || intersect2) ? 1 : 0));
			
			for (int at=0 ; at < nbint ; at++)
				attenuat *= attenuation();

			if (attenuat == 0) return true;
			return false;
		}
		if (!intersect1 && !intersect2)
			return false;

		if (intersect1 && !intersect2)
			tp = tp1;
		if (intersect2 && !intersect1)
			tp = tp2;
		if (intersect1 && intersect2)
			if (tp1 < tp2)
				tp = tp1;
			else
				tp = tp2;
		resinter.t_inter = tp;
		resinter.normale = Point3D(0,0,1);
		resinter.normale = rotation*resinter.normale;
		Objet3D::copiedonnees(resinter);
		return true;
	}

	return false;
}

/*
bool Cylinrevol::testintersect(const Rayon & ray_sce, double tlimit){

	Rayon ray_obj;
	ray_obj.origine = rotation.t()*(ray_sce.origine - origine);
	ray_obj.vectdirect = rotation.t()*ray_sce.vectdirect;

	double scax2 = scalex*scalex;
	double scay2 = scaley*scaley;
	double a = ray_obj.vectdirect.x*ray_obj.vectdirect.x/scax2 +
				ray_obj.vectdirect.y*ray_obj.vectdirect.y/scay2;
	double b = 2*(ray_obj.origine.x*ray_obj.vectdirect.x/scax2 +
				ray_obj.origine.y*ray_obj.vectdirect.y/scay2);

	double c = ray_obj.origine.x*ray_obj.origine.x/scax2 +
		ray_obj.origine.y*ray_obj.origine.y/scay2 - rayon*rayon;


	double demihauteur = hauteur*scalez/2;
	int nbintersectcorps = 0;
	double t1, t2;
	if (a != 0.0){
		double delta = b*b - 4*a*c;
		if (delta > 0){
			t1 = (-b -sqrt(delta))/(2*a);
			t2 = (-b +sqrt(delta))/(2*a);
			if (t1 > EPSILON){
				double z1 = ray_obj.origine.z + t1*ray_obj.vectdirect.z;
				if (z1 >= -demihauteur && z1 <= demihauteur){
					nbintersectcorps++;
					if (t1 < tlimit)
						return true;				}
			}else{
				if (t2 > EPSILON && t2 < tlimit){
					double z2 = ray_obj.origine.z + t2*ray_obj.vectdirect.z;
					if (z2 >= -demihauteur && z2 <= demihauteur){
						return true;						
					}
				}
			}
		}

	}
	double tp1, tp2;
	bool intersect1, intersect2;
	if (ray_obj.vectdirect.z == 0.0){
		if (nbintersectcorps == 0)
			return false;
	}else{
		tp1 = (-demihauteur - ray_obj.origine.z)/ray_obj.vectdirect.z;
		double x1 = ray_obj.origine.x + tp1*ray_obj.vectdirect.x;
		double y1 = ray_obj.origine.y + tp1*ray_obj.vectdirect.y;
		if (tp1 < EPSILON || tp1 > tlimit || x1*x1/scax2 + y1*y1/scay2 > rayon*rayon)
			intersect1 = false;
		else
			return true;

		tp2 = (demihauteur - ray_obj.origine.z)/ray_obj.vectdirect.z;
		double x2 = ray_obj.origine.x + tp2*ray_obj.vectdirect.x;
		double y2 = ray_obj.origine.y + tp2*ray_obj.vectdirect.y;
		if (tp2 < EPSILON || tp2 > tlimit || x2*x2/scax2 + y2*y2/scay2 > rayon*rayon)
			intersect2 = false;
		else
			return true;
	}


	return false;
}



*/



bool Conerevoltronq::calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture){


	Rayon ray_obj;
	ray_obj.origine = rotation.t()*(ray_sce.origine - origine);
	ray_obj.vectdirect = rotation.t()*ray_sce.vectdirect;

	double normvecdir=1;
	if (scalex != 1 || scaley != 1 || scalez != 1){
		ray_obj.vectdirect.x /= scalex;
		ray_obj.origine.x /=scalex;
		ray_obj.vectdirect.y /= scaley;
		ray_obj.origine.y /= scaley;
		ray_obj.vectdirect.z /= scalez;
		ray_obj.origine.z /= scalez;
		normvecdir = 1/ray_obj.vectdirect.norme();
		ray_obj.vectdirect = ray_obj.vectdirect*normvecdir;
	}
	
	// ATTENTION ICI :
	ray_obj.origine.z += hauteur/2;

	double rtmoinsr = rayontronq-rayon;
	double facteur = rayon*hauteur + rtmoinsr*ray_obj.origine.z;
	double h2 = hauteur*hauteur;

	double a = h2*(ray_obj.vectdirect.x*ray_obj.vectdirect.x + ray_obj.vectdirect.y*ray_obj.vectdirect.y)
		       - ray_obj.vectdirect.z*ray_obj.vectdirect.z*rtmoinsr*rtmoinsr;

	double b = 2*(h2*(ray_obj.origine.x*ray_obj.vectdirect.x+ray_obj.origine.y*ray_obj.vectdirect.y)
		          - ray_obj.vectdirect.z*rtmoinsr*facteur);

	double c = h2*(ray_obj.origine.x*ray_obj.origine.x+ray_obj.origine.y*ray_obj.origine.y)
		       - facteur*facteur;


	int nbintersectcorps = 0;
	double t1, t2;
	if (a != 0.0){
		double delta = b*b - 4*a*c;
		if (delta > 0){
			t1 = (-b -sqrt(delta))/(2*a);
			t2 = (-b +sqrt(delta))/(2*a);
			if (t1 > EPSILON){
				double z1 = ray_obj.origine.z + t1*ray_obj.vectdirect.z;
				if (z1 >= 0 && z1 <= hauteur  &&  (!testshadow || t1 < distance)){
					nbintersectcorps++;
					resinter.t_inter = t1;

					if (!testshadow){
						resinter.normale.x = (ray_obj.origine.x + t1*ray_obj.vectdirect.x);
						resinter.normale.y = (ray_obj.origine.y + t1*ray_obj.vectdirect.y);
						resinter.normale.z = 0;
						resinter.normale.normer();
						resinter.normale.z = rayon/hauteur;
						resinter.normale.x /= scalex;
						resinter.normale.y /= scaley;
						resinter.normale.z /= scalez;
						resinter.normale.normer();
						resinter.normale = rotation*resinter.normale;
						Objet3D::copiedonnees(resinter);

						if (textures.withtexture[0] && texture){
							Point3D ptinter = Point3D(ray_obj.origine.x + resinter.t_inter*ray_obj.vectdirect.x,
														ray_obj.origine.y + resinter.t_inter*ray_obj.vectdirect.y,
														ray_obj.origine.z + resinter.t_inter*ray_obj.vectdirect.z);	

							double costheta = ptinter.x/sqrt(ptinter.x*ptinter.x + ptinter.y*ptinter.y);
							double theta = acos(costheta);
							if (ptinter.y < 0){
								theta = (2*pi) - theta;
							}
							if (textures.withtexture[0] && texture)
								textures.imtexture[0].getpixelinterpol((((double)textures.imtexture[0].largeur()-1.0)/(2*pi)*theta), 
														(((double)textures.imtexture[0].hauteur()-1.0)*(ptinter.z)/hauteur),
														resinter.couleur.R, resinter.couleur.G, resinter.couleur.B);
							if (textures.withbumpmap[0]){
								double sintheta = sin(theta);
								Point3D dpsds = Point3D(-sintheta*2*pi*rayon, costheta*2*pi*rayon,0);
								Point3D dpsdt = Point3D(-(rayon+(rayontronq-rayon)*((ptinter.z)/hauteur))*sintheta, (rayon+(rayontronq-rayon)*((ptinter.z+hauteur/2.0)/hauteur))*costheta, hauteur);
								resinter.normale = calculnormalebump(0, theta/(2*pi), (ptinter.z)/hauteur, dpsds, dpsdt);
							}
						}
						resinter.t_inter*=normvecdir;
						return true;
					}
				}
			}
			if (t2 > EPSILON && (testshadow || t1 < EPSILON)){
				double z2 = ray_obj.origine.z + t2*ray_obj.vectdirect.z;
				if (z2 >= 0 && z2 <=hauteur && (!testshadow || t2 < distance)){
					nbintersectcorps++;						
				}
			}
			
		}

	}
	double t, tp;
	double tp1, tp2;
	bool intersect1=false, intersect2=false;
	if (ray_obj.vectdirect.z == 0.0){
		if (nbintersectcorps == 0)
			return false;
		else
			t = t2;
	}else{
		tp1 = (- ray_obj.origine.z)/ray_obj.vectdirect.z;
		double x1 = ray_obj.origine.x + tp1*ray_obj.vectdirect.x;
		double y1 = ray_obj.origine.y + tp1*ray_obj.vectdirect.y;
		double z1 = ray_obj.origine.z + tp1*ray_obj.vectdirect.z;
		if (tp1 < EPSILON || (x1*x1 + y1*y1 > rayon*rayon) || (testshadow && tp1 > distance))
			intersect1 = false;
		else
			intersect1 = true;

		tp2 = (hauteur - ray_obj.origine.z)/ray_obj.vectdirect.z;
		double x2 = ray_obj.origine.x + tp2*ray_obj.vectdirect.x;
		double y2 = ray_obj.origine.y + tp2*ray_obj.vectdirect.y;
		double z2 = ray_obj.origine.z + tp2*ray_obj.vectdirect.z;
		if (tp2 < EPSILON || 
			(x2*x2 + y2*y2 > rayontronq*rayontronq) ||
			(testshadow && tp2 > distance))
			intersect2 = false;
		else
			intersect2 = true;
	}


	if (nbintersectcorps>=1){
		if (testshadow){
			int nbint = nbintersectcorps + ((intersect1 || intersect2) ? 1 : 0);
			attenuat *= attenuation();
			if (nbint >= 2)
				attenuat *= attenuation();
			if (attenuat == 0) return true;
			return false;
		}
		t = t2;
		if (intersect1)
			tp = tp1;
		else
			if (intersect2)
				tp = tp2;

		if ((!intersect1 && !intersect2) || t < tp){
					resinter.t_inter = t;

					resinter.normale.x = (ray_obj.origine.x + t*ray_obj.vectdirect.x);
					resinter.normale.y = (ray_obj.origine.y + t*ray_obj.vectdirect.y);
					resinter.normale.z = 0;
					resinter.normale.normer();
					resinter.normale.z = rayon/hauteur;
					resinter.normale.x /= scalex;
					resinter.normale.y /= scaley;
					resinter.normale.z /= scalez;
					resinter.normale.normer();
					resinter.normale = rotation*resinter.normale;
					Objet3D::copiedonnees(resinter);

					if ((textures.withtexture[0] && texture) || textures.withbumpmap[0]){
						Point3D ptinter = Point3D(ray_obj.origine.x + resinter.t_inter*ray_obj.vectdirect.x,
													ray_obj.origine.y + resinter.t_inter*ray_obj.vectdirect.y,
													ray_obj.origine.z + resinter.t_inter*ray_obj.vectdirect.z);	

						double costheta = ptinter.x/sqrt(ptinter.x*ptinter.x + ptinter.y*ptinter.y);
						double theta = acos(costheta);
						if (ptinter.y < 0){
							theta = (2*pi) - theta;
						}
						if (textures.withtexture[0] && texture)
							textures.imtexture[0].getpixelinterpol((((double)textures.imtexture[0].largeur()-1.0)/(2*pi)*theta), 
													(((double)textures.imtexture[0].hauteur()-1.0)*(ptinter.z)/hauteur),
													resinter.couleur.R, resinter.couleur.G, resinter.couleur.B);
						if (textures.withbumpmap[0]){
							double sintheta = sin(theta);
							Point3D dpsds = Point3D(-sintheta*2*pi*rayon, costheta*2*pi*rayon,0);
							Point3D dpsdt = Point3D(-(rayon+(rayontronq-rayon)*((ptinter.z)/hauteur))*sintheta, (rayontronq+(rayontronq-rayon)*((ptinter.z+hauteur/2.0)/hauteur))*costheta, hauteur);
							resinter.normale = calculnormalebump(0, theta/(2*pi), (ptinter.z)/hauteur, dpsds, dpsdt);
						}
					}
					resinter.t_inter*=normvecdir;
			return true;
		}else{
			if (intersect1 || intersect2){
				resinter.t_inter = tp*normvecdir;
				resinter.normale = Point3D(0,0,1);
				resinter.normale = rotation*resinter.normale;
				Objet3D::copiedonnees(resinter);
				return true;
			}else
				return false;
		}
	}else{
		if (testshadow){
			int nbint = ((intersect1 && intersect2) ? 2 : ((intersect1 || intersect2) ? 1 : 0));
			for (int at=0 ; at < nbint ; at++)
				attenuat *= attenuation();
			if (attenuat == 0) return true;
			return false;
		}
		if (!intersect1 && !intersect2)
			return false;

		if (intersect1 && !intersect2)
			tp = tp1;
		if (intersect2 && !intersect1)
			tp = tp2;
		if (intersect1 && intersect2)
			if (tp1 < tp2)
				tp = tp1;
			else
				tp = tp2;
		resinter.t_inter = tp*normvecdir;
		resinter.normale = Point3D(0,0,1);
		resinter.normale = rotation*resinter.normale;
		Objet3D::copiedonnees(resinter);
		return true;
	}

	return false;
}









Point3D Objet3D::calculnormalelancer(const Facette &face, Point3D p3d, bool phong){

	Point3D normale;
	
	if (!phong){
		// cas d'eclairement sans interpolation de phong
		normale.x = face.normale.x;  // vecteur normal au point x1, y1, z1
		normale.y = face.normale.y;  // vecteur normal au point x1, y1, z1
		normale.z = face.normale.z;  // vecteur normal au point x1, y1, z1
	}else{
		// cas d'un eclairement lisse par interpolation de Phong
		// le vecteur normal est calcule par interpolation
		// dans le cas d'une facette a 3 ou 4 sommets
		if (face.nbsomm == 3){
			normale = interpolenormaletriang(face, p3d);
		}else   
			if (face.nbsomm == 4){
				normale = interpolenormalecarre(face, p3d);
			}else{

				// cas d'une facette non triangulaire et non carree
				normale.x = face.normale.x; 
				normale.y = face.normale.y;
				normale.z = face.normale.z;
			}
	}
	return normale;
}








bool Objet3D::calculintersectpolyedre(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture){

	
	// le calcul de l'equation du plan de chaque facette a ete fait
	// au debut du lancer de rayons.

	Point3D tabsommetsprojetes[10000];

	Point3D p3dproche;

	bool interieur = false;
	bool intersecteobjet = false;

	double distplusproche = INFINI;
	int nofaceplusproche = -1;

	if (!boundingbox.testintersect(ray_sce))
		return false;

	for (int k = 0 ; k < nbboites ; k++){
		if (!tabboundingbox[k].testintersect(ray_sce))
			continue;
		for (int i = (k==0 ? 0 : indicesfinboites[k-1]) ; i < indicesfinboites[k] ; i++){
	
//			if (!faces[nofacesdansboites[i]].boundingbox.testintersect(ray_sce))
//				continue;

			// intersection avec le plan de la facette :

			Point3D p3d;
			double lambda;

			double axpbypcz = faces[nofacesdansboites[i]].normale.x*ray_sce.vectdirect.x + 
							  faces[nofacesdansboites[i]].normale.y*ray_sce.vectdirect.y + 
							  faces[nofacesdansboites[i]].normale.z*ray_sce.vectdirect.z;
			double aoxpboypcoz = faces[nofacesdansboites[i]].normale.x*ray_sce.origine.x + 
							  faces[nofacesdansboites[i]].normale.y*ray_sce.origine.y + 
							  faces[nofacesdansboites[i]].normale.z*ray_sce.origine.z;
			lambda = (-faces[nofacesdansboites[i]].D - aoxpboypcoz) / axpbypcz;
			if (lambda < EPSILON)
				continue;

			// intersection avec le polygone 2d :

			p3d.x = ray_sce.origine.x + lambda*ray_sce.vectdirect.x;
			p3d.y = ray_sce.origine.y + lambda*ray_sce.vectdirect.y; 
			p3d.z = ray_sce.origine.z + lambda*ray_sce.vectdirect.z;


			for (int j = 0 ; j < faces[nofacesdansboites[i]].nbsomm ; j++){
				tabsommetsprojetes[j] = tabsomm[faces[nofacesdansboites[i]].tabnosomm[j]].pos;
				tabsommetsprojetes[j].z=0;
				tabsommetsprojetes[j].x -= p3d.x;
				tabsommetsprojetes[j].y -= p3d.y;
			}

			bool intersect = false;
			for (int j = 0 ; j < faces[nofacesdansboites[i]].nbsomm ; j++){
				double x1 = tabsommetsprojetes[j].x;
				double y1 = tabsommetsprojetes[j].y;
				double x2 = (j == faces[nofacesdansboites[i]].nbsomm - 1) ? tabsommetsprojetes[0].x : tabsommetsprojetes[j+1].x;
				double y2 = (j == faces[nofacesdansboites[i]].nbsomm - 1) ? tabsommetsprojetes[0].y : tabsommetsprojetes[j+1].y;
			
				if ((y1 >= 0 && y2 >= 0) || (y1 <= 0 && y2 <= 0))
					continue;
				double xinter = (x1*y2 - x2*y1)/(y2 - y1);
				if (xinter > 0)
					intersect = !intersect;
			}

			if (!intersect)
				continue;

			interieur = !interieur;

			if (distplusproche > lambda){
				intersecteobjet = true;
				nofaceplusproche = nofacesdansboites[i];
				distplusproche = lambda;
				p3dproche = p3d;
			}
		}
	}


	if (intersecteobjet){
		resinter.t_inter = distplusproche;
		resinter.normale = calculnormalelancer(faces[nofaceplusproche], p3dproche, material.phongenable && phong);
		copiedonnees(resinter);
/*		if (avectexture && texture){
			double coordtextX;
			double coordtextY;
			if (faces[nofaceplusproche].nbsomm == 3){
				interpoletexturetriang(faces[nofaceplusproche], p3dproche, coordtextX, coordtextY,
										imtexture.largeur(), imtexture.hauteur());
				imtexture.getpixel((int)coordtextX, (int)coordtextY, resinter.couleur.R, resinter.couleur.G, resinter.couleur.B);
			}else   
				if (faces[nofaceplusproche].nbsomm == 4){
					interpoletexturecarre(faces[nofaceplusproche], p3dproche, coordtextX, coordtextY,
											imtexture.largeur(), imtexture.hauteur());
					imtexture.getpixel((int)coordtextX, (int)coordtextY, resinter.couleur.R, resinter.couleur.G, resinter.couleur.B);
				}
		}
*/
		return true;
	}
	return false;
}




/*

bool Objet3D::testintersectpolyedre(const Rayon & ray_sce, double tlimit){

	// le calcul de l'equation du plan de chaque facette a ete fait
	// au debut du lancer de rayons.

	Point3D tabsommetsprojetes[10000];


	bool intersecteobjet = false;


	if (!boundingbox.testintersect(ray_sce))
		return false;

	for (int k = 0 ; k < nbboites ; k++){
		if (!tabboundingbox[k].testintersect(ray_sce))
			continue;
		for (int i = (k==0 ? 0 : indicesfinboites[k-1]) ; i < indicesfinboites[k] ; i++){
	
//			if (!faces[nofacesdansboites[i]].boundingbox.testintersect(ray_sce))
//				continue;

			// intersection avec le plan de la facette :

			Point3D p3d;
			double lambda;

			double axpbypcz = faces[nofacesdansboites[i]].normale.x*ray_sce.vectdirect.x + 
							  faces[nofacesdansboites[i]].normale.y*ray_sce.vectdirect.y + 
							  faces[nofacesdansboites[i]].normale.z*ray_sce.vectdirect.z;
			double aoxpboypcoz = faces[nofacesdansboites[i]].normale.x*ray_sce.origine.x + 
							  faces[nofacesdansboites[i]].normale.y*ray_sce.origine.y + 
							  faces[nofacesdansboites[i]].normale.z*ray_sce.origine.z;
			lambda = (-faces[nofacesdansboites[i]].D - aoxpboypcoz) / axpbypcz;
			if (lambda < EPSILON || lambda > tlimit)
				continue;

			// intersection avec le polygone 2d :

			p3d.x = ray_sce.origine.x + lambda*ray_sce.vectdirect.x;
			p3d.y = ray_sce.origine.y + lambda*ray_sce.vectdirect.y; 
			p3d.z = ray_sce.origine.z + lambda*ray_sce.vectdirect.z;


			for (int j = 0 ; j < faces[nofacesdansboites[i]].nbsomm ; j++){
				tabsommetsprojetes[j] = tabsomm[faces[nofacesdansboites[i]].tabnosomm[j]].pos;
				tabsommetsprojetes[j].z=0;
				tabsommetsprojetes[j].x -= p3d.x;
				tabsommetsprojetes[j].y -= p3d.y;
			}

			bool intersect = false;
			for (j = 0 ; j < faces[nofacesdansboites[i]].nbsomm ; j++){
				double x1 = tabsommetsprojetes[j].x;
				double y1 = tabsommetsprojetes[j].y;
				double x2 = (j == faces[nofacesdansboites[i]].nbsomm - 1) ? tabsommetsprojetes[0].x : tabsommetsprojetes[j+1].x;
				double y2 = (j == faces[nofacesdansboites[i]].nbsomm - 1) ? tabsommetsprojetes[0].y : tabsommetsprojetes[j+1].y;
			
				if ((y1 >= 0 && y2 >= 0) || (y1 <= 0 && y2 <= 0))
					continue;
				double xinter = (x1*y2 - x2*y1)/(y2 - y1);
				if (xinter > 0)
					intersect = !intersect;
			}

			if (intersect)
				return true;

		}
	}


	return false;
}


*/

bool Cylinspline::calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture){

	return Objet3D::calculintersectpolyedre(ray_sce, resinter,
											testshadow, attenuat, distance, 
											phong, texture);
}


/*
bool Cylinspline::testintersect(const Rayon & ray_sce, double tlimit){

	return Objet3D::testintersectpolyedre(ray_sce, tlimit);
}
*/




bool Spline3Drevol::calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture){

	return Objet3D::calculintersectpolyedre(ray_sce, resinter, 
											testshadow, attenuat, distance, 
											phong, texture);
}


/*
bool Spline3Drevol::testintersect(const Rayon & ray_sce, double tlimit){

	return Objet3D::testintersectpolyedre(ray_sce, tlimit);
}
*/





bool Spline3Dextru::calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture){

	return Objet3D::calculintersectpolyedre(ray_sce, resinter, 
											testshadow, attenuat, distance, 
											phong, texture);
}


/*
bool Spline3Dextru::testintersect(const Rayon & ray_sce, double tlimit){

	return Objet3D::testintersectpolyedre(ray_sce, tlimit);
}
*/


bool Spline3DEditable::calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture){

	return Objet3D::calculintersectpolyedre(ray_sce, resinter, 
											testshadow, attenuat, distance, 
											phong, texture);
}


/*
bool Spline3DEditable::testintersect(const Rayon & ray_sce, double tlimit){

	return Objet3D::testintersectpolyedre(ray_sce, tlimit);
}

*/




bool Boiteenglobante::testintersect(const Rayon & ray_sce){


	double t_near = -INFINI;
	double t_far = INFINI;

	double t_1, t_2;



	// axe des x :

	if (ray_sce.vectdirect.x == 0)
		if (ray_sce.origine.x < xmin || ray_sce.origine.x > xmax)
			return false;

	t_1 = (xmin - ray_sce.origine.x) / ray_sce.vectdirect.x;
	t_2 = (xmax - ray_sce.origine.x) / ray_sce.vectdirect.x;

	if (t_1 > t_2){
		double temp = t_1;
		t_1 = t_2;
		t_2 = temp;
	}

	if (t_1 > t_near){
		t_near = t_1;
	}

	if (t_2 < t_far){
		t_far = t_2;
	}

	if (t_near > t_far || t_far < EPSILON)
		return false;


	// axe des y :

	
	if (ray_sce.vectdirect.y == 0)
		if (ray_sce.origine.y < ymin || ray_sce.origine.y > ymax)
			return false;

	t_1 = (ymin - ray_sce.origine.y) / ray_sce.vectdirect.y;
	t_2 = (ymax - ray_sce.origine.y) / ray_sce.vectdirect.y;

	if (t_1 > t_2){
		double temp = t_1;
		t_1 = t_2;
		t_2 = temp;
	}

	if (t_1 > t_near){
		t_near = t_1;
	}

	if (t_2 < t_far){
		t_far = t_2;
	}

	if (t_near > t_far || t_far < EPSILON)
		return false;

	
	// axe des z :

	if (ray_sce.vectdirect.z == 0)
		if (ray_sce.origine.z < zmin || ray_sce.origine.z > zmax)
			return false;

	t_1 = (zmin - ray_sce.origine.z) / ray_sce.vectdirect.z;
	t_2 = (zmax - ray_sce.origine.z) / ray_sce.vectdirect.z;

	if (t_1 > t_2){
		double temp = t_1;
		t_1 = t_2;
		t_2 = temp;
	}

	if (t_1 > t_near){
		t_near = t_1;
	}

	if (t_2 < t_far){
		t_far = t_2;
	}

	if (t_near > t_far || t_far < EPSILON)
		return false;


	
	return true;


}

