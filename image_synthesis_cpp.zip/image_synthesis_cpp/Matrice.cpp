// Matrice.cpp: implementation of the Matrice class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Synth.h"
#include "Matrice.h"
#include "Point3D.h"
#include "Spline2D.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////




// Constructeur par copie
Matrice::Matrice(Matrice& M)
{  
	nl=M.nl;
	nc=M.nc;
	mat=new double*[nl];
	*mat=new double[nl*nc];
	for(int i=1;i<nl;i++) mat[i]=*mat+nc*i;
	for(int i=0;i<nl;i++)
	  for(int j=0;j<nc;j++)
	    mat[i][j]=M[i][j];

}


Matrice::Matrice(void)
{
	nl=nc = 0;
	mat = NULL;
}

// Constructeur
Matrice::Matrice(int l, int c)
{
	nl=l; nc=c;
	if (nl > 0){
		mat=new double*[nl];
		*mat=new double[nl*nc];
	}else mat = NULL;
	for(int i=1;i<nl;i++) 
		mat[i]=*mat+nc*i;
	for (int i = 0 ; i < nl ; i++)
		for (int j = 0 ; j < nc ; j++)
			mat[i][j] = 0;
}

// Destructeur
Matrice::~Matrice()
{
	if (nl){
		if (nc)
			delete [] mat[0];
		delete [] mat;
	}
}

Matrice& Matrice::operator = (Matrice& M)
{
	if (nl > 0){
		if (nc > 0)
			delete [] mat[0];
		delete [] mat;
	}
	nl=M.nl;
	nc=M.nc;
	mat=new double*[nl];
	*mat=new double[nl*nc];
	for(int i=1;i<nl;i++) mat[i]=*mat+nc*i;
	for(int i=0;i<nl;i++)
	  for(int j=0;j<nc;j++)
	    mat[i][j]=M[i][j];

	return (*this);
}

// Operateur moins Unaire
Matrice Matrice::operator - ()
{
	Matrice M(nl, nc);
	for(int i=0;i<nl;i++)
		for(int j=0;j<nc;j++)
			M[i][j]=-mat[i][j];
	return M;
}

double* Matrice::operator [] (int i) const
{
	return *(mat+i);
}

//ostream& operator << (ostream& os,const Matrice& M)
//{for(int i=0;i<M.dim;i++)
 //{for(int j=0;j<M.dim;j++) cout<<M[i][j] <<"\t  ";
//  cout<<endl;
// }
// cout<<endl;
// return os;
//}

//istream& operator >> (istream& is,Matrice& M)
//{for(int i=0;i<M.dim;i++)
//  for(int j=0;j<M.dim;j++)
//	{
//		cout<<"\nCoef "<<i+1<<" "<<j+1<<":";
//		cin>>M[i][j];
//	}
//  return is;
//}

Matrice operator * (const Matrice& A,const Matrice& B)
{
	Matrice C(A.nl, B.nc);
	for(int i = 0; i < A.nl;i++)
		for(int j = 0; j < B.nc;j++){
			C[i][j]=0;
			for(int k=0;k<A.nc;k++)
				C[i][j]+=A[i][k]*B[k][j];
	}

	return C;
}

Matrice operator - (const Matrice& A,const Matrice& B)
{
	Matrice C(A.nl, A.nc);
	for(int i=0;i<A.nl;i++)
		for(int j=0;j<A.nc;j++)
			C[i][j]=A[i][j]-B[i][j];
	return C;
}

Matrice operator + (const Matrice& A,const Matrice& B)
{	
	Matrice C(A.nl, A.nc);
	for(int i=0;i<A.nl;i++)
		for(int j=0;j<A.nc;j++)
			C[i][j]=A[i][j]+B[i][j];
	return C;
}

Matrice Matrice::t ()
{
	Matrice T(nc, nl);
	for(int i=0;i<nc;i++)
		for(int j=0;j<nl;j++)
			T[i][j]=mat[j][i];
 return T;
}


void Matrice::normaliserotation(void){
	if (nl == 3 && nc == 3){
		Point3D ligne0(mat[0][0], mat[0][1], mat[0][2]);
		Point3D ligne1(mat[1][0], mat[1][1], mat[1][2]);
		ligne0.normer();
		ligne1.normer();
		Point3D ligne2 = ligne0^ligne1;
		mat[0][0] = ligne0.x; mat[0][1] = ligne0.y; mat[0][2] = ligne0.z;
		mat[1][0] = ligne1.x; mat[1][1] = ligne1.y; mat[1][2] = ligne1.z;
		mat[2][0] = ligne2.x; mat[2][1] = ligne2.y; mat[2][2] = ligne2.z;
	}

}


double operator*(const Quadruplet &q, const Vecteur4D &v)
{
	return (((*((Matrice*)&q)))*(*((Matrice*)&v)))[0][0];
}




Point3D operator * (const Matrice& M, const Point3D& P)
{
	double tab[3], tabres[3];
	Point3D res;
	int i;
	int j;

	if (M.nl != 3 || M.nc!=3){
		res.x = res.y = res.z = 0;
		return res;
	}


	tab[0] = P.x;
	tab[1] = P.y;
	tab[2] = P.z;

	for (i = 0 ; i < 3 ; i++){
		tabres[i] = 0;
		for (j = 0 ; j < 3 ; j++)
			tabres[i] += (double) M[i][j] * tab[j];
	}

	res.x = tabres[0];
	res.y = tabres[1];
	res.z = tabres[2];

	return res;
}




