#include <stdlib.h>

#include "stdafx.h"
#include "Synth.h"

#include "SynthDoc.h"
#include "SynthView.h"
#include "ObjetsDialog.h"
#include "SplineDialog.h"
#include "MaterialPropPage.h"

#include "Objet3D.h"
#include "Objetderiv.h"
#include "Spline2D.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif




void CSynthView::OnInsereLight() 
{
	// TODO: Add your command handler code here
	CNewLight dlg;
	dlg.m_posx = (float)scene.getmaxx();
	dlg.m_posy = (float)scene.getmaxy();
	dlg.m_posz = (float)scene.getmaxz();
	dlg.m_coulR = 1;
	dlg.m_coulG = 1;
	dlg.m_coulB = 1;
	dlg.m_directionnel=false;
	dlg.m_dirx = 0;
	dlg.m_diry = 0;
	dlg.m_dirz = 1;
	dlg.m_exposantdirect = 1;
	dlg.m_attenuation = false;
	dlg.m_c1 = 1;
	dlg.m_c2 = 1;
	dlg.m_c3 = 1;

	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
		scene.inserelum(dlg.m_posx, dlg.m_posy, dlg.m_posz,
						dlg.m_coulR, dlg.m_coulG, dlg.m_coulB,
						dlg.m_directionnel?1:0, dlg.m_dirx, dlg.m_diry, dlg.m_dirz, dlg.m_exposantdirect,
						dlg.m_attenuation?1:0, dlg.m_c1, dlg.m_c2, dlg.m_c3);

		CClientDC cdc(this);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}
}

void CSynthView::OnUpdateInsereLight(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(activinsere);

}





void CSynthView::OnInsereNouvboite() 
{
	// TODO: Add your command handler code here



	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	CMultiTextureDialog dlgText;
	dlgText.m_factorbump = 1;
	dlgText.m_textname_s="";
	dlgText.m_withtexture_s = false;
	dlgText.m_bumpname_s="";
	dlgText.m_withbump_s = false;
	dlgText.m_textname_t="";
	dlgText.m_withtexture_t = false;
	dlgText.m_bumpname_t="";
	dlgText.m_withbump_t = false;
	dlgText.m_textname_b="";
	dlgText.m_withtexture_b = false;
	dlgText.m_bumpname_b="";
	dlgText.m_withbump_b = false;

	CBoxGeomPropPage dlg;
	dlg.m_cx = 0;
	dlg.m_cy = 0;
	dlg.m_cz = 0;
	dlg.m_dimx = 50;
	dlg.m_dimy = 50;
	dlg.m_dimz = 50;
	dlg.m_rotx = 0;
	dlg.m_roty = 0;
	dlg.m_rotz = 0;
	dlg.m_nbmerid = 30;


	CPropertySheet sheet(CString("New box"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);

	


	int ret = sheet.DoModal();

	if (ret != IDCANCEL){


		TextureData text(dlgText.m_withtexture_s ? 1 : 0, dlgText.m_textname_s, 
						dlgText.m_withtexture_t ? 1 : 0, dlgText.m_textname_t, 
						dlgText.m_withtexture_b ? 1 : 0, dlgText.m_textname_b,
						dlgText.m_withbump_s ? 1 : 0, dlgText.m_bumpname_s,
						dlgText.m_withbump_t ? 1 : 0, dlgText.m_bumpname_t, 
						dlgText.m_withbump_b ? 1 : 0, dlgText.m_bumpname_b, 
						dlgText.m_factorbump);

		MaterialData mater(dlgMat1, dlgMat2);
		Cloche nouveau(dlg.m_cx, dlg.m_cy, dlg.m_cz,
						dlg.m_dimx, dlg.m_dimy, dlg.m_dimz,
						dlg.m_nbmerid,
						dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
						1,1,1,
						mater, text);


		scene.inseretete(&nouveau);

	

		CClientDC cdc(this);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}
	
}

void CSynthView::OnUpdateInsereNouvboite(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(activinsere);

}



void CSynthView::OnInsereSphere() 
{
	// TODO: Add your command handler code here

	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	CTexturePropPage dlgText;
	dlgText.m_texturename="";
	dlgText.m_withtexture = false;
	dlgText.m_bumpmapname="";
	dlgText.m_withbumpmap = false;
	dlgText.m_factorbump = 1;

	CSphereGeomPropPage dlg;
	dlg.m_cx = 0;
	dlg.m_cy = 0;
	dlg.m_cz = 0;
	dlg.m_radius = 50;
	dlg.m_nbmerid = 30;
	dlg.m_nbparal = 30;
	dlg.m_rotx = 0;
	dlg.m_roty = 0;
	dlg.m_rotz = 0;
	dlg.m_scax = 1;
	dlg.m_scay = 1;
	dlg.m_scaz = 1;


	CPropertySheet sheet(CString("New Sphere"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);



	int ret = sheet.DoModal();

	if (ret != IDCANCEL){

		TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
						false, CString(""), false, CString(""),
						dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
						false, CString(""), false, CString(""), dlgText.m_factorbump);
		MaterialData mater(dlgMat1, dlgMat2);
		Sphere nouveau(dlg.m_cx, dlg.m_cy, dlg.m_cz, 
								dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
								dlg.m_scax, dlg.m_scay, dlg.m_scaz,
								dlg.m_radius, dlg.m_nbparal, dlg.m_nbmerid,
								mater, text);


		scene.inseretete(&nouveau);



		CClientDC cdc(this);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

}

void CSynthView::OnUpdateInsereSphere(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(activinsere);
}

void CSynthView::OnInsereCylRevol() 
{
	// TODO: Add your command handler code here
	
	CMaterialBasicPropPage dlgMat1;

	CMaterialRenderPropPage dlgMat2;

	CTexturePropPage dlgText;
	dlgText.m_texturename="";
	dlgText.m_withtexture = false;
	dlgText.m_bumpmapname="";
	dlgText.m_withbumpmap = false;
	dlgText.m_factorbump = -1;

	CCylRevolGeomPropPage dlg;
	dlg.m_cx = 0;
	dlg.m_cy = 0;
	dlg.m_cz = 0;
	dlg.m_radius = 50;
	dlg.m_hauteur = 50;
	dlg.m_nbmerid = 30;
	dlg.m_rotx = 0;
	dlg.m_roty = 0;
	dlg.m_rotz = 0;
	dlg.m_scax = 1;
	dlg.m_scay = 1;
	dlg.m_scaz = 1;


	CPropertySheet sheet(CString("New Cylinder"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);

	

	int ret = sheet.DoModal();






	if (ret != IDCANCEL){
		TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
						false, CString(""), false, CString(""),
						dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
						false, CString(""), false, CString(""), dlgText.m_factorbump);
		MaterialData mater(dlgMat1, dlgMat2);
		Cylinrevol nouveau(dlg.m_cx, dlg.m_cy, dlg.m_cz, 
								dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
								dlg.m_scax, dlg.m_scay, dlg.m_scaz,
								dlg.m_radius, dlg.m_hauteur,
								dlg.m_nbmerid,
								mater, text);


		scene.inseretete(&nouveau);

	

		CClientDC cdc(this);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

}

void CSynthView::OnUpdateInsereCylRevol(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(activinsere);

}

void CSynthView::OnInsereConerevol() 
{
	// TODO: Add your command handler code here

	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	CTexturePropPage dlgText;
	dlgText.m_texturename="";
	dlgText.m_withtexture = false;
	dlgText.m_bumpmapname="";
	dlgText.m_withbumpmap = false;
	dlgText.m_factorbump = -1;

	CConeRevolPropPage dlg;
	dlg.m_cx = 0;
	dlg.m_cy = 0;
	dlg.m_cz = 0;
	dlg.m_bottomradius = 50;
	dlg.m_topradius = 25;
	dlg.m_hauttronq = 50;
	dlg.m_nbmerid = 30;
	dlg.m_nbparal=2;
	dlg.m_rotx = 0;
	dlg.m_roty = 0;
	dlg.m_rotz = 0;
	dlg.m_scax = 1;
	dlg.m_scay = 1;
	dlg.m_scaz = 1;


	CPropertySheet sheet(CString("New Cone"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);

	

	int ret = sheet.DoModal();




	if (ret != IDCANCEL){
		TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
						false, CString(""), false, CString(""),
						dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
						false, CString(""), false, CString(""), dlgText.m_factorbump);

		MaterialData mater(dlgMat1, dlgMat2);
		Conerevoltronq nouveau(dlg.m_cx, dlg.m_cy, dlg.m_cz, 
								dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
								dlg.m_scax, dlg.m_scay, dlg.m_scaz,
								dlg.m_bottomradius, dlg.m_hauttronq, dlg.m_topradius,
								dlg.m_nbmerid, dlg.m_nbparal,
								mater, text);


		scene.inseretete(&nouveau);


		CClientDC cdc(this);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}

}

void CSynthView::OnUpdateInsereConerevol(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(activinsere);

}


void CSynthView::OnInsereSpline3dCyl() 
{
	// TODO: Add your command handler code here


	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	CTexturePropPage dlgText;
	dlgText.m_texturename="";
	dlgText.m_withtexture = false;
	dlgText.m_bumpmapname="";
	dlgText.m_withbumpmap = false;
	dlgText.m_factorbump = -1;

	CCylinSplineGeomPropPage dlg;
	dlg.m_nomsp = "";
	dlg.m_cx = 0;
	dlg.m_cz = 0;
	dlg.m_cy = 0;
	dlg.m_rotx = 0;
	dlg.m_roty = 0;
	dlg.m_rotz = 0;
	dlg.m_scax = 1;
	dlg.m_scay = 1;
	dlg.m_scaz = 1;
	dlg.m_hauteur = 50;
	dlg.m_topreduction = 1;
	dlg.m_echanthauteur = 1;
	dlg.m_echantspline = 15;
	dlg.m_phongenable = true;


	CPropertySheet sheet(CString("New Cylindric surface"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);



	int ret = IDOK;
	bool correctspline = false;
	while (!correctspline && ret != IDCANCEL){
		ret = sheet.DoModal();
		if (ret != IDCANCEL){
			Spline2D *sp = NULL;
			CSynthDoc * pdoc = (CSynthDoc*)GetDocument();
			for (int i = 0 ; i < pdoc->nbSpline2D ; i++)
				if (pdoc->p_Splines2D[i]->getnom() == dlg.m_nomsp){
					sp = pdoc->p_Splines2D[i];
					break;
				}
		
			if (sp == NULL || sp->gettype() != SPLINE2D_FERMEE){
				AfxMessageBox(CString("Nom de spline 2D introuvable ou\n spline 2D de type incorrect"));
			}else{
				correctspline = true;
				TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
								false, CString(""), false, CString(""),
								dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
								false, CString(""), false, CString(""), dlgText.m_factorbump);
				MaterialData mater(dlgMat1, dlgMat2);
				Cylinspline nouveau(dlg.m_cx, dlg.m_cy, dlg.m_cz,
									dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
									dlg.m_scax, dlg.m_scay, dlg.m_scaz,
									sp, dlg.m_hauteur,
									dlg.m_topreduction,
									dlg.m_echantspline,
									dlg.m_echanthauteur,
									mater, text);

		
				scene.inseretete(&nouveau);


				CClientDC cdc(this);
				scene.zbuffer(bitmap_dib);
				OnDraw(&cdc);
			}
		}
	}
}

void CSynthView::OnUpdateInsereSpline3dCyl(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(activinsere);
	
}




void CSynthView::OnInsereSpline3dRevol() 
{
	// TODO: Add your command handler code here


	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	CTexturePropPage dlgText;
	dlgText.m_texturename="";
	dlgText.m_withtexture = false;
	dlgText.m_bumpmapname="";
	dlgText.m_withbumpmap = false;
	dlgText.m_factorbump = -1;

	CSplineRevolGeometryPropPage dlg;
	dlg.m_nomsp = "";
	dlg.m_cx = 0;
	dlg.m_cz = 0;
	dlg.m_cy = 0;
	dlg.m_rotx = 0;
	dlg.m_roty = 0;
	dlg.m_rotz = 0;
	dlg.m_scax = 1;
	dlg.m_scay = 1;
	dlg.m_scaz = 1;
	dlg.m_echantcercle = 30;
	dlg.m_echantspline = 15;
	dlg.m_phongenable = true;


	CPropertySheet sheet(CString("New revolution surface"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);



	int ret = IDOK;
	bool correctspline = false;
	while (!correctspline && ret != IDCANCEL){
		ret = sheet.DoModal();
		if (ret != IDCANCEL){
			Spline2D *sp = NULL;
			CSynthDoc * pdoc = (CSynthDoc*)GetDocument();
			for (int i = 0 ; i < pdoc->nbSpline2D ; i++)
				if (pdoc->p_Splines2D[i]->getnom() == dlg.m_nomsp){
					sp = pdoc->p_Splines2D[i];
					break;
				}
		
			if (sp == NULL || sp->gettype() != SPLINE2D_OUVERTE){
				AfxMessageBox(CString("Nom de spline 2D introuvable ou\n spline 2D de type incorrect"));
			}else{
				correctspline = true;
				TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
								false, CString(""), false, CString(""),
								dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
								false, CString(""), false, CString(""), dlgText.m_factorbump);

				MaterialData mater(dlgMat1, dlgMat2);
				Spline3Drevol nouveau(dlg.m_cx, dlg.m_cy, dlg.m_cz,
									dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
									dlg.m_scax, dlg.m_scay, dlg.m_scaz,
									sp, 
									dlg.m_echantcercle, dlg.m_echantspline,
									mater, text);

		
				scene.inseretete(&nouveau);


				CClientDC cdc(this);
				scene.zbuffer(bitmap_dib);
				OnDraw(&cdc);
			}
		}
	}

}

void CSynthView::OnUpdateInsereSpline3dRevol(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);
}





void CSynthView::OnInsereSplineExtrusion() 
{
	// TODO: Add your command handler code here

	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	CTexturePropPage dlgText;
	dlgText.m_texturename="";
	dlgText.m_withtexture = false;
	dlgText.m_bumpmapname="";
	dlgText.m_withbumpmap = false;
	dlgText.m_factorbump = -1;

	CExtrusionGeomPropPage dlg;
	dlg.m_nomame = "";
	dlg.m_nomforme = "";
	dlg.m_echantame = 5;
	dlg.m_echantforme = 5;
	dlg.m_scashape = 1;
	dlg.m_withchanfrein=false;
	dlg.m_pcba=0.05;
	dlg.m_pcbf=0.2;
	dlg.m_pcea=0.05;
	dlg.m_pcef=0.2;
	dlg.m_cx = 0;
	dlg.m_cz = 0;
	dlg.m_cy = 0;
	dlg.m_rotx = 0;
	dlg.m_roty = 0;
	dlg.m_rotz = 0;
	dlg.m_scax = 1;
	dlg.m_scay = 1;
	dlg.m_scaz = 1;


	CPropertySheet sheet(CString("New extrusion surface"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);





	int ret = IDOK;
	bool correctspline = false;
	while (!correctspline && ret != IDCANCEL){
		ret = sheet.DoModal();
		if (ret != IDCANCEL){
			Spline2D *spf = NULL;
			CSynthDoc * pdoc = (CSynthDoc*)GetDocument();
			for (int i = 0 ; i < pdoc->nbSpline2D ; i++)
				if (pdoc->p_Splines2D[i]->getnom() == dlg.m_nomforme){
					spf = pdoc->p_Splines2D[i];
					break;
				}
		
			Spline2D *spa = NULL;
			for (int i = 0 ; i < pdoc->nbSpline2D ; i++)
				if (pdoc->p_Splines2D[i]->getnom() == dlg.m_nomame){
					spa = pdoc->p_Splines2D[i];
					break;
				}
			if (spf == NULL || spf->gettype() != SPLINE2D_FERMEE ||
				spa == NULL || spa->gettype() != SPLINE2D_OUVERTE){
				AfxMessageBox(CString("Nom de spline 2D introuvable ou\n spline 2D de type incorrect"));
			}else{
				correctspline = true;
				TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
								false, CString(""), false, CString(""),
								dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
								false, CString(""), false, CString(""), dlgText.m_factorbump);
				MaterialData mater(dlgMat1, dlgMat2);
				Spline3Dextru nouveau(dlg.m_cx, dlg.m_cy, dlg.m_cz,
									dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
									dlg.m_scax, dlg.m_scay, dlg.m_scaz,
									spf, spa, dlg.m_scashape,
									dlg.m_echantforme, dlg.m_echantame, 
									dlg.m_withchanfrein ? 1 : 0, dlg.m_pcba, dlg.m_pcbf, dlg.m_pcea, dlg.m_pcef,
									mater, text);

		
				scene.inseretete(&nouveau);


				CClientDC cdc(this);
				scene.zbuffer(bitmap_dib);
				OnDraw(&cdc);
			}
		}
	}

	
}

void CSynthView::OnUpdateInsereSplineExtrusion(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here

	pCmdUI->Enable(activinsere);

}




void CSynthView::OnInsereSplinerevolEditable() 
{
	// TODO: Add your command handler code here





	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	CTexturePropPage dlgText;
	dlgText.m_texturename="";
	dlgText.m_withtexture = false;
	dlgText.m_bumpmapname="";
	dlgText.m_withbumpmap = false;
	dlgText.m_factorbump = -1;

	CDeformSplineGeom dlg;
	dlg.m_nomsp = "";
	dlg.m_cx = 0;
	dlg.m_cz = 0;
	dlg.m_cy = 0;
	dlg.m_rotx = 0;
	dlg.m_roty = 0;
	dlg.m_rotz = 0;
	dlg.m_scax = 1;
	dlg.m_scay = 1;
	dlg.m_scaz = 1;
	dlg.m_echantcercle = 30;
	dlg.m_echantspline = 15;
	dlg.m_nbctrl = 24;
	dlg.m_phongenable = true;


	CPropertySheet sheet(CString("New deformable revolution surface"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);




	int ret = IDOK;
	bool correctspline = false;
	while (!correctspline && ret != IDCANCEL){
		ret = sheet.DoModal();
		if (ret != IDCANCEL){
			Spline2D *sp = NULL;
			CSynthDoc * pdoc = (CSynthDoc*)GetDocument();
			for (int i = 0 ; i < pdoc->nbSpline2D ; i++)
				if (pdoc->p_Splines2D[i]->getnom() == dlg.m_nomsp){
					sp = pdoc->p_Splines2D[i];
					break;
				}
		
			if (sp == NULL || sp->gettype() != SPLINE2D_OUVERTE){
				AfxMessageBox(CString("Nom de spline 2D introuvable ou\n spline 2D de type incorrect"));
			}else{
				correctspline = true;
				TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
								false, CString(""), false, CString(""),
								dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
								false, CString(""), false, CString(""), dlgText.m_factorbump);

				MaterialData mater(dlgMat1, dlgMat2);

				Spline3DEditable nouveau(dlg.m_cx, dlg.m_cy, dlg.m_cz,
									dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
									dlg.m_scax, dlg.m_scay, dlg.m_scaz,
									sp, 
									dlg.m_echantcercle, dlg.m_echantspline, dlg.m_nbctrl,
									mater, text);

		
				scene.inseretete(&nouveau);


				CClientDC cdc(this);
				scene.zbuffer(bitmap_dib);
				OnDraw(&cdc);
			}
		}
	}

}

void CSynthView::OnUpdateInsereSplinerevolEditable(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);

}



void CSynthView::OnInsereCylindrevolDeformable() 
{
	// TODO: Add your command handler code here
	
	// TODO: Add your command handler code here

	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	CTexturePropPage dlgText;
	dlgText.m_texturename="";
	dlgText.m_withtexture = false;
	dlgText.m_bumpmapname="";
	dlgText.m_withbumpmap = false;
	dlgText.m_factorbump = -1;

	CDeformableCylinRevolPropPage dlg;
	dlg.m_cx = 0;
	dlg.m_cy = 0;
	dlg.m_cz = 0;
	dlg.m_bottomradius = 50;
	dlg.m_topradius = 25;
	dlg.m_hauttronq = 50;
	dlg.m_nbmerid = 30;
	dlg.m_nbparal=25;
	dlg.m_rotx = 0;
	dlg.m_roty = 0;
	dlg.m_rotz = 0;
	dlg.m_scax = 1;
	dlg.m_scay = 1;
	dlg.m_scaz = 1;
	dlg.m_nbctrlcircle = 10;
	dlg.m_nbctrlhaut = 10;
	dlg.m_nbctrldisk = 5;


	CPropertySheet sheet(CString("New Deformable cylinder"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);

	

	int ret = sheet.DoModal();



	if (ret != IDCANCEL){
		TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
						false, CString(""), false, CString(""),
						dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
						false, CString(""), false, CString(""), dlgText.m_factorbump);
		MaterialData mater(dlgMat1, dlgMat2);
		Spline3DEditable nouveau(dlg.m_cx, dlg.m_cy, dlg.m_cz,
							dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
							dlg.m_scax, dlg.m_scay, dlg.m_scaz,
							dlg.m_bottomradius, dlg.m_hauttronq, dlg.m_topradius,
							dlg.m_nbmerid, dlg.m_nbparal, dlg.m_nbmerid, dlg.m_nbctrlcircle, dlg.m_nbctrlhaut, dlg.m_nbctrldisk,
							mater, text);


		scene.inseretete(&nouveau);


		CClientDC cdc(this);
		scene.zbuffer(bitmap_dib);
		OnDraw(&cdc);
	}
}

void CSynthView::OnUpdateInsereCylindrevolDeformable(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);
}



void CSynthView::OnInsereDeformableCylExtru() 
{
	// TODO: Add your command handler code here
	
	// TODO: Add your command handler code here

	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	CTexturePropPage dlgText;
	dlgText.m_texturename="";
	dlgText.m_withtexture = false;
	dlgText.m_bumpmapname="";
	dlgText.m_withbumpmap = false;
	dlgText.m_factorbump = -1;

	CExtrusionGeomPropPage dlg;
	dlg.m_nomame = "";
	dlg.m_nomforme = "";
	dlg.m_echantame = 5;
	dlg.m_echantforme = 5;
	dlg.m_scashape = 1;
	dlg.m_withchanfrein=false;
	dlg.m_pcba=0.05;
	dlg.m_pcbf=0.2;
	dlg.m_pcea=0.05;
	dlg.m_pcef=0.2;
	dlg.m_cx = 0;
	dlg.m_cz = 0;
	dlg.m_cy = 0;
	dlg.m_rotx = 0;
	dlg.m_roty = 0;
	dlg.m_rotz = 0;
	dlg.m_scax = 1;
	dlg.m_scay = 1;
	dlg.m_scaz = 1;


	CPropertySheet sheet(CString("New extrusion surface"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);

	

	int ret = IDOK;
	bool correctspline = false;
	while (!correctspline && ret != IDCANCEL){
		ret = sheet.DoModal();
		if (ret != IDCANCEL){
			Spline2D *spf = NULL;
			CSynthDoc * pdoc = (CSynthDoc*)GetDocument();
			for (int i = 0 ; i < pdoc->nbSpline2D ; i++)
				if (pdoc->p_Splines2D[i]->getnom() == dlg.m_nomforme){
					spf = pdoc->p_Splines2D[i];
					break;
				}
		
			Spline2D *spa = NULL;
			for (int i = 0 ; i < pdoc->nbSpline2D ; i++)
				if (pdoc->p_Splines2D[i]->getnom() == dlg.m_nomame){
					spa = pdoc->p_Splines2D[i];
					break;
				}
			if (spf == NULL || spf->gettype() != SPLINE2D_FERMEE ||
				spa == NULL || spa->gettype() != SPLINE2D_OUVERTE){
				AfxMessageBox(CString("Nom de spline 2D introuvable ou\n spline 2D de type incorrect"));
			}else{
				correctspline = true;
				TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
								false, CString(""), false, CString(""),
								dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
								false, CString(""), false, CString(""), dlgText.m_factorbump);
				MaterialData mater(dlgMat1, dlgMat2);
				Spline3DEditable nouveau(dlg.m_cx, dlg.m_cy, dlg.m_cz,
									dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
									dlg.m_scax, dlg.m_scay, dlg.m_scaz,
									spf, spa, dlg.m_scashape,
									dlg.m_echantforme, dlg.m_echantame, 
									dlg.m_withchanfrein ? 1 : 0, dlg.m_pcba, dlg.m_pcbf, dlg.m_pcea, dlg.m_pcef,
									mater, text);

		
				scene.inseretete(&nouveau);


				CClientDC cdc(this);
				scene.zbuffer(bitmap_dib);
				OnDraw(&cdc);
			}
		}
	}

}

void CSynthView::OnUpdateInsereDeformableCylExtru(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);
}




void CSynthView::OnInsereExtrusionSphere() 
{
	// TODO: Add your command handler code here
	
	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	CTexturePropPage dlgText;
	dlgText.m_texturename="";
	dlgText.m_withtexture = false;
	dlgText.m_bumpmapname="";
	dlgText.m_withbumpmap = false;
	dlgText.m_factorbump = -1;

	CExtrusionGeomPropPage dlg;
	dlg.m_nomame = "";
	dlg.m_nomforme = "";
	dlg.m_echantame = 5;
	dlg.m_echantforme = 5;
	dlg.m_scashape = 1;
	dlg.m_withchanfrein=true;
	dlg.m_pcba=0.05;
	dlg.m_pcbf=1;
	dlg.m_pcea=0.05;
	dlg.m_pcef=1;
	dlg.m_cx = 0;
	dlg.m_cz = 0;
	dlg.m_cy = 0;
	dlg.m_rotx = 0;
	dlg.m_roty = 0;
	dlg.m_rotz = 0;
	dlg.m_scax = 1;
	dlg.m_scay = 1;
	dlg.m_scaz = 1;


	CPropertySheet sheet(CString("New extrusion surface"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);

	

	int ret = IDOK;
	bool correctspline = false;
	while (!correctspline && ret != IDCANCEL){
		ret = sheet.DoModal();
		if (ret != IDCANCEL){
			Spline2D *spf = NULL;
			CSynthDoc * pdoc = (CSynthDoc*)GetDocument();
			for (int i = 0 ; i < pdoc->nbSpline2D ; i++)
				if (pdoc->p_Splines2D[i]->getnom() == dlg.m_nomforme){
					spf = pdoc->p_Splines2D[i];
					break;
				}
		
			Spline2D *spa = NULL;
			for (int i = 0 ; i < pdoc->nbSpline2D ; i++)
				if (pdoc->p_Splines2D[i]->getnom() == dlg.m_nomame){
					spa = pdoc->p_Splines2D[i];
					break;
				}
			if (spf == NULL || spf->gettype() != SPLINE2D_FERMEE ||
				spa == NULL || spa->gettype() != SPLINE2D_OUVERTE){
				AfxMessageBox(CString("Nom de spline 2D introuvable ou\n spline 2D de type incorrect"));
			}else{
				correctspline = true;
				TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
								false, CString(""), false, CString(""),
								dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
								false, CString(""), false, CString(""), dlgText.m_factorbump);
				MaterialData mater(dlgMat1, dlgMat2);
				Spline3DEditable nouveau(dlg.m_cx, dlg.m_cy, dlg.m_cz,
									dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
									dlg.m_scax, dlg.m_scay, dlg.m_scaz,
									spf, spa, dlg.m_scashape,
									dlg.m_echantforme, dlg.m_echantame, 
									dlg.m_pcba, dlg.m_pcea,
									mater, text);

		
				scene.inseretete(&nouveau);


				CClientDC cdc(this);
				scene.zbuffer(bitmap_dib);
				OnDraw(&cdc);
			}
		}
	}

}

void CSynthView::OnUpdateInsereExtrusionSphere(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);
}


void CSynthView::OnInsereExtrusionTorus() 
{
	// TODO: Add your command handler code here
	
	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	CTexturePropPage dlgText;
	dlgText.m_texturename="";
	dlgText.m_withtexture = false;
	dlgText.m_bumpmapname="";
	dlgText.m_withbumpmap = false;
	dlgText.m_factorbump = -1;

	CExtrusionGeomPropPage dlg;
	dlg.m_nomame = "";
	dlg.m_nomforme = "";
	dlg.m_echantame = 5;
	dlg.m_echantforme = 5;
	dlg.m_scashape = 1;
	dlg.m_withchanfrein=true;
	dlg.m_pcba=0.05;
	dlg.m_pcbf=1;
	dlg.m_pcea=0.05;
	dlg.m_pcef=1;
	dlg.m_cx = 0;
	dlg.m_cz = 0;
	dlg.m_cy = 0;
	dlg.m_rotx = 0;
	dlg.m_roty = 0;
	dlg.m_rotz = 0;
	dlg.m_scax = 1;
	dlg.m_scay = 1;
	dlg.m_scaz = 1;


	CPropertySheet sheet(CString("New extrusion surface"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);

	

	int ret = IDOK;
	bool correctspline = false;
	while (!correctspline && ret != IDCANCEL){
		ret = sheet.DoModal();
		if (ret != IDCANCEL){
			Spline2D *spf = NULL;
			CSynthDoc * pdoc = (CSynthDoc*)GetDocument();
			for (int i = 0 ; i < pdoc->nbSpline2D ; i++)
				if (pdoc->p_Splines2D[i]->getnom() == dlg.m_nomforme){
					spf = pdoc->p_Splines2D[i];
					break;
				}
		
			Spline2D *spa = NULL;
			for (int i = 0 ; i < pdoc->nbSpline2D ; i++)
				if (pdoc->p_Splines2D[i]->getnom() == dlg.m_nomame){
					spa = pdoc->p_Splines2D[i];
					break;
				}
			if (spf == NULL || spf->gettype() != SPLINE2D_FERMEE ||
				spa == NULL || spa->gettype() != SPLINE2D_FERMEE){
				AfxMessageBox(CString("Nom de spline 2D introuvable ou\n spline 2D de type incorrect"));
			}else{
				correctspline = true;
				TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
								false, CString(""), false, CString(""),
								dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
								false, CString(""), false, CString(""), dlgText.m_factorbump);
				MaterialData mater(dlgMat1, dlgMat2);
				Spline3DEditable nouveau(dlg.m_cx, dlg.m_cy, dlg.m_cz,
									dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
									dlg.m_scax, dlg.m_scay, dlg.m_scaz,
									spf, spa, dlg.m_scashape,
									dlg.m_echantforme, dlg.m_echantame, 
									mater, text);

		
				scene.inseretete(&nouveau);


				CClientDC cdc(this);
				scene.zbuffer(bitmap_dib);
				OnDraw(&cdc);
			}
		}
	}

}

void CSynthView::OnUpdateInsereExtrusionTorus(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);
}

void CSynthView::OnInsereDeformRevolTorus() 
{
	// TODO: Add your command handler code here
	

	CMaterialBasicPropPage dlgMat1;
	CMaterialRenderPropPage dlgMat2;

	CTexturePropPage dlgText;
	dlgText.m_texturename="";
	dlgText.m_withtexture = false;
	dlgText.m_bumpmapname="";
	dlgText.m_withbumpmap = false;
	dlgText.m_factorbump = -1;

	CDeformSplineGeom dlg;
	dlg.m_nomsp = "";
	dlg.m_cx = 0;
	dlg.m_cz = 0;
	dlg.m_cy = 0;
	dlg.m_rotx = 0;
	dlg.m_roty = 0;
	dlg.m_rotz = 0;
	dlg.m_scax = 1;
	dlg.m_scay = 1;
	dlg.m_scaz = 1;
	dlg.m_echantcercle = 30;
	dlg.m_echantspline = 15;
	dlg.m_nbctrl = 24;
	dlg.m_phongenable = true;


	CPropertySheet sheet(CString("New deformable revolution surface"));

	sheet.AddPage(&dlg);
	sheet.AddPage(&dlgMat1);
	sheet.AddPage(&dlgMat2);
	sheet.AddPage(&dlgText);




	int ret = IDOK;
	bool correctspline = false;
	while (!correctspline && ret != IDCANCEL){
		ret = sheet.DoModal();
		if (ret != IDCANCEL){
			Spline2D *sp = NULL;
			CSynthDoc * pdoc = (CSynthDoc*)GetDocument();
			for (int i = 0 ; i < pdoc->nbSpline2D ; i++)
				if (pdoc->p_Splines2D[i]->getnom() == dlg.m_nomsp){
					sp = pdoc->p_Splines2D[i];
					break;
				}
		
			if (sp == NULL || sp->gettype() != SPLINE2D_FERMEE){
				AfxMessageBox(CString("Nom de spline 2D introuvable ou\n spline 2D de type incorrect"));
			}else{
				correctspline = true;
				TextureData text(dlgText.m_withtexture ? 1 : 0, dlgText.m_texturename, 
								false, CString(""), false, CString(""),
								dlgText.m_withbumpmap ? 1 : 0, dlgText.m_bumpmapname,
								false, CString(""), false, CString(""), dlgText.m_factorbump);

				MaterialData mater(dlgMat1, dlgMat2);

				Spline3DEditable nouveau(dlg.m_cx, dlg.m_cy, dlg.m_cz,
									dlg.m_rotx, dlg.m_roty, dlg.m_rotz,
									dlg.m_scax, dlg.m_scay, dlg.m_scaz,
									sp, 
									dlg.m_echantcercle, dlg.m_echantspline, dlg.m_nbctrl,
									mater, text);

		
				scene.inseretete(&nouveau);


				CClientDC cdc(this);
				scene.zbuffer(bitmap_dib);
				OnDraw(&cdc);
			}
		}
	}
}

void CSynthView::OnUpdateInsereDeformRevolTorus(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);
}
