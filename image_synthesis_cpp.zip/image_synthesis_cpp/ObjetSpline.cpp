// ObjetSpline.cpp: implementation of the Objetderiv class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Synth.h"
#include "Objetderiv.h"

#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif




// constructeur de cylindre avec pour base une courbe spline fermee 2D au lieu d'un cercle
Cylinspline::Cylinspline(double xor, double yor, double zor, // centre de l'objet
			   double rotx, double roty, double rotz, // angles de rotation suivant les differents axes
			   double scalex, double scaley, double scalez,  // parametres de changements d'echelle suivant les differents axes
			   Spline2D * sp,    // pointeur sur la courbe spline fermee 2D qui constitue la base du cylindre
			   double h,  // hauteur du cylindre
			   double factor_reduc,
			   int ech,  // nombre de points calcules pour chaque partie de la spline 2D
			   int nbparallele,
			   MaterialData mat, const TextureData &text)
			   // appel du constructeur generique d'Objet3D :
			   :Objet3D(xor, yor, zor, 
						scalex, scaley, scalez, 
						 rotx, roty, rotz,  
						mat, text)

{

	


	
}



Objet3D * Cylinspline::copie(void)
{
	Objet3D *res = new Cylinspline(hauteur, topreduction, echantillonage, nbparal, spline2d);



	res->copieObjet3D(*this);

	return res;
}


void Cylinspline::ecritfich(ostream& fich){

	fich << gettype() << "\n";
	Objet3D::ecritdonneesobjet3D(fich);

	fich << hauteur << " " << topreduction << " " << echantillonage << " "  << nbparal<< " " << spline2d->getnumero() << "\n";

}





Spline3Drevol::Spline3Drevol(double xor, double yor, double zor, 
							double rotx, double roty, double rotz,
							double scalex, double scaley, double scalez,
							Spline2D * sp,
							int nbmerid, int ech,
							MaterialData mat, const TextureData &text)
							:Objet3D(xor, yor, zor, 
						scalex, scaley, scalez, 
						 rotx, roty, rotz,  
							mat, text)

{

	echantillonage=ech;
	spline2d=sp;
    nbmeridiens=nbmerid;
	int nbparal = (sp ->nombrectrlpoints() - 3)*ech;
	
	


}



Objet3D * Spline3Drevol::copie(void)
{
	Objet3D *res = new Spline3Drevol(echantillonage, nbmeridiens,  spline2d);



	res->copieObjet3D(*this);

	return res;
}



void Spline3Drevol::ecritfich(ostream& fich){

	fich << gettype() << "\n";
	Objet3D::ecritdonneesobjet3D(fich);

	fich << echantillonage << " " << nbmeridiens << " " << spline2d->getnumero()<< "\n";

}




Spline3Dextru::Spline3Dextru(double xor, double yor, double zor, 
			   double rotx, double roty, double rotz,
			   double scalex, double scaley, double scalez,
			   Spline2D * spf, Spline2D * spa, double sca_a,
			   int echf, int echa,
			   bool chan, double pc_ba, double pc_bf, double pc_ea, double pc_ef,
			   MaterialData mat, const TextureData &text)
							:Objet3D(xor, yor, zor, 
						scalex, scaley, scalez, 
						 rotx, roty, rotz,  
							mat, text)

{
	echantforme=echf;
	echantame = echa;
	spline2dforme = spf;
	spline2dame=spa;
	scalea=sca_a;

	if (spa->gettype()==SPLINE2D_OUVERTE){
		int nbmerid = (spf ->nombrectrlpoints() - 3)*echf;
		int nbparal = (spa ->nombrectrlpoints() - 3)*echa;
		//A FAIRE
	}



}






Objet3D * Spline3Dextru::copie(void)
{
	Objet3D *res = new Spline3Dextru(echantforme, echantame,  spline2dforme, spline2dame, scalea,
										chanfrein,	propchanf_ba, propchanf_bf, propchanf_ea, propchanf_ef);



	res->copieObjet3D(*this);

	return res;
}


void Spline3Dextru::ecritfich(ostream& fich){

	fich << gettype() << "\n";
	Objet3D::ecritdonneesobjet3D(fich);

	fich << echantforme << " " << echantame << " " << spline2dforme->getnumero() << " " << spline2dame->getnumero() << "\n";
	fich << scalea << "\n";
	fich << (chanfrein ? 1:0) << " " << propchanf_ba << " " << propchanf_bf << " " << propchanf_ea << " " << propchanf_ef << "\n";
}

