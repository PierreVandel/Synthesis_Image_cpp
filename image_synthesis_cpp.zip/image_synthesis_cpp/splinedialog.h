#if !defined(AFX_SPILNEDIALOG_H__8CD29424_4CFB_11D4_B8E6_525405F505A7__INCLUDED_)
#define AFX_SPILNEDIALOG_H__8CD29424_4CFB_11D4_B8E6_525405F505A7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SpilneDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSpline2DDialog dialog

class CSpline2DDialog : public CDialog
{
// Construction
public:
	CSpline2DDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSpline2DDialog)
	enum { IDD = IDD_PARAM_SPLINE2D_FERMEE };
	CString	m_nom;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSpline2DDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSpline2DDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CRayonDeformDialog dialog

class CRayonDeformDialog : public CDialog
{
// Construction
public:
	CRayonDeformDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRayonDeformDialog)
	enum { IDD = IDD_RAYONDEFORMSPLINE };
	double	m_speeddeform;
	double	m_amplitudelissage;
	int		m_ri;
	int		m_rj;
	double	m_rayondeform_i;
	double	m_rayondeform_j;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRayonDeformDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRayonDeformDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CDegreeElevationDialog dialog

class CDegreeElevationDialog : public CDialog
{
// Construction
public:
	CDegreeElevationDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDegreeElevationDialog)
	enum { IDD = IDD_PARAM_ELEVATION };
	BOOL	m_elev_i;
	BOOL	m_elev_j;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDegreeElevationDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDegreeElevationDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPILNEDIALOG_H__8CD29424_4CFB_11D4_B8E6_525405F505A7__INCLUDED_)
