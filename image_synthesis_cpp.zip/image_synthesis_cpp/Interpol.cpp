

#include "stdafx.h"
#include "Synth.h"
#include "Objet3D.h"



#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif



#define SEUIL 0.57




Point3D interpolenormaletriang1(Point3D p1, Point3D p2, Point3D p3,
								Point3D n1, Point3D n2, Point3D n3,
								Point3D point)
{   

	return Point3D(0,0,0);
}






Point3D Objet3D::interpolenormaletriang(const Facette& face, Point3D point) const
{   


	return Point3D(0,0,0);

}




Point3D Objet3D::interpolenormalecarre(const Facette& face, Point3D point) const
{   

	return Point3D(0,0,0);
}




Sommet interpolesommettriang1(Sommet n1, Sommet n2, Sommet n3, Point3D point)
{   
	
	Point3D p1 = n1.pos; Point3D p2 = n2.pos; Point3D p3 = n3.pos;
	Point3D N1 = n1.normale; Point3D N2 = n2.normale; Point3D N3 = n3.normale;

	// on recherche le premier rep�re valide et on replace les coordonn�es en 'x/y' = 'vecteur 2D'
	for (;;) {
		if (p1.x != p1.y && p2.x != p2.y && p3.x != p3.y && point.x != point.y) { // xOy
			break; // RAS
		}
		if (p1.x != p1.z && p2.x != p2.z && p3.x != p3.z && point.x != point.z) { // xOz
			p1.y = p1.z; p2.y = p2.z; p3.y = p3.z; point.y = point.z;
			break;
		}
		if (p1.y != p1.z && p2.y != p2.z && p3.y != p3.z && point.y != point.z) { // yOz
			p1.x = p1.y; p2.x = p2.y; p3.x = p3.y; point.x = point.y;
			p1.y = p1.z; p2.y = p2.z; p3.y = p3.z; point.y = point.z;
			break;
		}
		break;
	}

	// on d�termine le point isol�, on le stocke dans p_alone d�s qu'on l'a trouv�, dans i et j les autres
	Point3D p_alone, p_i, p_j;
	Sommet S_alone, S_i, S_j;

	for (;;) {
		if (p1.y < point.y && p2.y < point.y || p1.y > point.y && p2.y > point.y) {
			p_alone = p3; p_i = p1; p_j = p2;
			S_alone = n3; S_i = n1; S_j = n2;
			break;

		}
		if (p1.y < point.y && p3.y < point.y || p1.y > point.y && p3.y > point.y) {
			p_alone = p2; p_i = p1; p_j = p3;
			S_alone = n2; S_i = n1; S_j = n3;
			break;
		}
		if (p2.y < point.y && p3.y < point.y || p2.y > point.y && p3.y > point.y) {
			p_alone = p1; p_i = p2; p_j = p3;
			S_alone = n1; S_i = n2; S_j = n3;
			break;
		}
	}


	double x_a = p_alone.x + (p_i.x - p_alone.x) * ((point.y - p_alone.y) / (p_i.y - p_alone.y));
	Sommet S_a = S_alone + (S_i - S_alone) * ((point.y - p_alone.y) / (p_i.y - p_alone.y));

	double x_b = p_alone.x + (p_j.x - p_alone.x) * ((point.y - p_alone.y) / (p_j.y - p_alone.y));
	Sommet S_b = S_alone + (S_j - S_alone) * ((point.y - p_alone.y) / (p_j.y - p_alone.y));

	Sommet S_p = S_a + (S_b - S_a) * ((point.x - x_a) / (x_b - x_a));

	S_p.normale.normer();

	Sommet P;
	P.pos = point;
	P = S_p;

	return P;		//TO DO HERE  A Modifier evidemment [DONE]
}




Sommet Objet3D::interpolesommettriang(const Facette& face, Point3D point) const
{   
	Sommet S;

//	if (face.nbsomm==3){
		
		S=interpolesommettriang1(tabsomm[face.tabnosomm[0]],tabsomm[face.tabnosomm[1]],tabsomm[face.tabnosomm[2]],point);
//	}

	return S;

}




Sommet Objet3D::interpolesommetcarre(const Facette& face, Point3D point) const
{   

	Point3D p1 = tabsomm[face.tabnosomm[0]].pos,
			p2 = tabsomm[face.tabnosomm[1]].pos,
			p3 = tabsomm[face.tabnosomm[2]].pos,
			p4 = tabsomm[face.tabnosomm[3]].pos;


	if (((p3.y-p1.y)*(point.x - p1.x) - (p3.x-p1.x)*(point.y - p1.y))*
		((p3.y-p1.y)*(p2.x - p1.x) - (p3.x-p1.x)*(p2.y - p1.y)) >= 0){
		return interpolesommettriang1( tabsomm[face.tabnosomm[0]],
									   tabsomm[face.tabnosomm[1]],
									   tabsomm[face.tabnosomm[2]],
									   point);
	}else
		return interpolesommettriang1( tabsomm[face.tabnosomm[0]],
									   tabsomm[face.tabnosomm[2]],
									   tabsomm[face.tabnosomm[3]],
									   point);

}








