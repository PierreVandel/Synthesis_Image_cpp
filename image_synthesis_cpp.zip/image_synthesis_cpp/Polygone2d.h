// CelluleTA.h: interface for the CelluleTA class.
//
//////////////////////////////////////////////////////////////////////



#if !defined(AFX_CelluleTA_H__364DFED6_469C_11D3_B1CB_8D49315C5B65__INCLUDED_)
#define AFX_CelluleTA_H__364DFED6_469C_11D3_B1CB_8D49315C5B65__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/*
class Point3D;
class Facette;
class Objet3D;
class Sourcelum;
class Scene3D;
*/

#include "Objet3D.h"



const int NBMAXTA=5000;
const int NBMAXTAA=5000;


class Arete;
class Scene3D;

class EdgeData{
	
	friend class Scene3D;
	friend class Scene3DRadio;
	friend class CelluleTA;
	friend class TableTA;
	friend class ListeTAA;
	friend class Polygone2D;

   int yhaut;
   int x;
   int numerat;
   int denomin;


};

class CelluleTA  
{	friend class CSynthView;
	friend class TableTA;
	friend class ListeTA;
	friend class ListeTAA;
	friend class Scene3D;
	friend class Scene3DRadio;

   EdgeData data;
   CelluleTA * suiv;

   static CelluleTA * memoireTA;
   static CelluleTA * tetenew;
   static int nballocglobales;

public:
	CelluleTA();
	CelluleTA(const EdgeData&);
	virtual ~CelluleTA();
    friend CelluleTA *alloueTA(void);
	friend void libereTA(CelluleTA*);
};


class ListeTA
{
	friend class Scene3D;
	friend class TableTA;
	friend class ListeTAA;
 	friend class Scene3DRadio;
	
	CelluleTA * L;

public:
	ListeTA(){L = NULL;}
	ListeTA(ListeTA&);
	~ListeTA();
	ListeTA& operator=(ListeTA &);
	void destruction(void);

};


class Arete
{   friend class TableTA;
	int xbas, ybas, xhaut, yhaut;

public:
	Arete(int, int, int, int);
	Arete(void){}
};

class TableTA
{

	friend class Scene3D;
	friend class Polygone2D;
	friend class Scene3DRadio;

   int taille;
   ListeTA *tab;

public:
	TableTA(Arete *tabaretes, int nbaretes);
	TableTA(TableTA &);
	~TableTA();
	TableTA & operator=(TableTA &);
  int calcminy(Arete *tabaretes, int nbaretes);
	int calcmaxybas(Arete *tabaretes, int nbaretes);
	int calcmaxyhaut(Arete *tabaretes, int nbaretes);
	void insertriTA(ListeTA & L, int yhaut, int xbas, int numer, int denom);

};

class CelluleTAA  
{   friend class CSynthView;
	friend class ListeTAA;
	friend class Polygone2D;
	friend class Scene3D;
	friend class Scene3DRadio;

   EdgeData data;
   int increment;
   CelluleTAA * suiv;

   static CelluleTAA * memoireTAA;
   static CelluleTAA * tetenew;

public:
	CelluleTAA();
	CelluleTAA(const EdgeData&, int);
	virtual ~CelluleTAA();
    friend CelluleTAA *alloueTAA(void);
	friend void libereTAA(CelluleTAA*);

};



class ListeTAA
{
	friend class Polygone2D;
	friend class Scene3D;
	friend class Scene3DRadio;

   CelluleTAA * L;

public:
	ListeTAA(){L = NULL;}
	ListeTAA(ListeTAA &);
	~ListeTAA(void);
	ListeTAA& operator=(ListeTAA &);
	void destruction(void);
	void interclassement(const ListeTA& liste);
	void supprimearetestraitees(int y);

	void traiteautointersections(void);

};


class Polygone2D{
	Arete *tabaretes;
	int nbaretes;

public:
	Polygone2D(){tabaretes=NULL; nbaretes=0;}
	Polygone2D(Arete *t, int n){tabaretes=t; nbaretes=n;}
	Polygone2D(Polygone2D &);
	~Polygone2D();
	Polygone2D & operator=(Polygone2D &);

	void remplissage(CDC *pDC);
};

#endif // !defined(AFX_CelluleTA_H__364DFED6_469C_11D3_B1CB_8D49315C5B65__INCLUDED_)
