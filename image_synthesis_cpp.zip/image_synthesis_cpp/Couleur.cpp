// Couleur.cpp: implementation of the Couleur class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Synth.h"
#include "Couleur.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Couleur::Couleur()
{
	R=G=B=0.0;
}

Couleur::~Couleur()
{

}

Couleur::Couleur(double RR, double GG, double BB){
	R = RR;
	G = GG;
	B = BB;
}
