#if !defined(AFX_MATERIALPROPPAGE_H__CAC03903_D4CE_480E_9612_7767888A38A3__INCLUDED_)
#define AFX_MATERIALPROPPAGE_H__CAC03903_D4CE_480E_9612_7767888A38A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MaterialPropPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMaterialRenderPropPage dialog

class CMaterialRenderPropPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CMaterialRenderPropPage)

// Construction
public:
	CMaterialRenderPropPage();
	~CMaterialRenderPropPage();

// Dialog Data
	//{{AFX_DATA(CMaterialRenderPropPage)
	enum { IDD = IDD_MATERIAL_RENDERING };
	double	m_emitance;
	double	m_coeftd;
	double	m_coefts;
	double	m_coefri;
	double	m_coefti;
	double	m_indrefr;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CMaterialRenderPropPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CMaterialRenderPropPage)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////
// CMaterialBasicPropPage dialog

class CMaterialBasicPropPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CMaterialBasicPropPage)

// Construction
public:
	CMaterialBasicPropPage();
	~CMaterialBasicPropPage();

// Dialog Data
	//{{AFX_DATA(CMaterialBasicPropPage)
	enum { IDD = IDD_MATERIAL_BASIC };
	double	m_coefamb;
	double	m_coefrd;
	double	m_coefrs;
	double	m_coulB;
	double	m_coulG;
	double	m_coulR;
	double	m_exprs;
	BOOL	m_phongenable;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CMaterialBasicPropPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CMaterialBasicPropPage)
	afx_msg void OnChoseColor();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////
// CTexturePropPage dialog

class CTexturePropPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CTexturePropPage)

// Construction
public:
	CTexturePropPage();
	~CTexturePropPage();

// Dialog Data
	//{{AFX_DATA(CTexturePropPage)
	enum { IDD = IDD_TEXTURE_BUMPMAP };
	CString	m_texturename;
	BOOL	m_withtexture;
	CString	m_bumpmapname;
	BOOL	m_withbumpmap;
	double	m_factorbump;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CTexturePropPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CTexturePropPage)
	afx_msg void OnBoutonbrowse();
	afx_msg void OnBoutonbrowse2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CMultiTextureDialog dialog

class CMultiTextureDialog : public CPropertyPage
{
	DECLARE_DYNCREATE(CMultiTextureDialog)

// Construction
public:
	CMultiTextureDialog();
	~CMultiTextureDialog();

// Dialog Data
	//{{AFX_DATA(CMultiTextureDialog)
	enum { IDD = IDD_MULTI_TEXTURE_BUMPMAP };
	BOOL	m_withbump_b;
	BOOL	m_withbump_s;
	BOOL	m_withbump_t;
	BOOL	m_withtexture_b;
	BOOL	m_withtexture_s;
	BOOL	m_withtexture_t;
	double	m_factorbump;
	CString	m_bumpname_b;
	CString	m_bumpname_s;
	CString	m_bumpname_t;
	CString	m_textname_b;
	CString	m_textname_s;
	CString	m_textname_t;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CMultiTextureDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CMultiTextureDialog)
	afx_msg void OnBoutonbrowseBb();
	afx_msg void OnBoutonbrowseBs();
	afx_msg void OnBoutonbrowseBt();
	afx_msg void OnBoutonbrowseTb();
	afx_msg void OnBoutonbrowseTs();
	afx_msg void OnBoutonbrowseTt();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MATERIALPROPPAGE_H__CAC03903_D4CE_480E_9612_7767888A38A3__INCLUDED_)
