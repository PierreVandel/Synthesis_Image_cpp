// ObjetSpline.cpp: implementation of the Objetderiv class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Synth.h"
#include "Objetderiv.h"
#include "Scene3D.h"

#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif



Spline3DEditable::Spline3DEditable(double xor, double yor, double zor, 
							double rotx, double roty, double rotz,
							double scalex, double scaley, double scalez,
							Spline2D * sp,
							int nbmerid, int ech, int nbctrlcercle,
							MaterialData mat, const TextureData &text)
							:Objet3D(xor, yor, zor, 
						scalex, scaley, scalez, 
						 rotx, roty, rotz,  
							mat, text)

{

//	nbmeridiens = nbmerid;

	int nbctrlpoints = sp->nombrectrlpoints();  // nombre de points de controle sur la spline2D fermee

	int nbparal = (nbctrlpoints-3) * ech;  // nombre de points total calcules sur la spline 2D


	int i, j;
	double teta, sinteta, costeta;
//	double x2d, xN2d;


	int nblignes=nbctrlcercle+3;
	int nbcols = sp->nombrectrlpoints();
	Point3D **ctrlpoints = allouerPoints3D(nblignes, nbcols);

	for (i = 0 ; i < nblignes ; i++)
		for (j = 0 ; j < nbcols ; j++){
			teta = 2*(double)pi*((double) i / (double) (nblignes-3));
			costeta = (double)cos(teta);
			sinteta = (double)sin(teta);
			ctrlpoints[i][j].x = costeta*sp->accesctrlpoints()[j].x;
			ctrlpoints[i][j].y = sinteta*sp->accesctrlpoints()[j].x;
			ctrlpoints[i][j].z = sp->accesctrlpoints()[j].y;


		}



	if (sp->gettype() == SPLINE2D_OUVERTE){
		surface = new SurfaceBSplineCubiqueSphere(ctrlpoints, nblignes, nbcols);
		construction_spherical(xor, yor, zor, 
					rotx, roty, rotz,
					scalex, scaley, scalez,
					nbmerid, nbparal, surface,
					mat, text);

	}
	else{
		surface = new SurfaceBSplineCubiqueTore(ctrlpoints, nblignes, nbcols);
		construction_torical(xor, yor, zor, 
					rotx, roty, rotz,
					scalex, scaley, scalez,
					nbmerid, nbparal, surface,
					mat, text);
	}
	libererPoints3D(ctrlpoints, nblignes);

}





Spline3DEditable::Spline3DEditable(double xor, double yor, double zor, 
						   double rotx, double roty, double rotz,
						   double scalex, double scaley, double scalez,
						   Spline2D * spf, Spline2D * spa, double sca_a,
						   int echf, int echa,
						   double pc_ba, double pc_ea,
						   MaterialData mat,  const TextureData &text)
							:Objet3D(xor, yor, zor, 
						scalex, scaley, scalez, 
						 rotx, roty, rotz,  
							mat, text)
{
	nbmeridiens = echf*spf->nombrectrlpoints();
	nbparalleles = echa*spa->nombrectrlpoints();

	int i, j;

	double pc_bf=1;
	double pc_ef=1;
	bool chan = true;

	int nblbody=spf->nombrectrlpoints();
	int nbcbody = spa->nombrectrlpoints();

	double longspolygame=0;
	Point3D ancien = Point3D(spa->accesctrlpoints()[0].x, spa->accesctrlpoints()[0].y,0);
	for (i=1 ; i < spa->nombrectrlpoints() ; i++){
		longspolygame += (Point3D(spa->accesctrlpoints()[i].x, spa->accesctrlpoints()[i].y,0)-ancien).norme();
		ancien = Point3D(spa->accesctrlpoints()[i].x, spa->accesctrlpoints()[i].y,0);
	}

	Point3D **ctrlbody = allouerPoints3D(nblbody, nbcbody);

	
							


	double longueurcumuleea;

	for (i = 0 ; i < nblbody-3 ; i++){
		double x2df = spf->accesctrlpoints()[spf->nombrectrlpoints()-4-i].x;
		double y2df = spf->accesctrlpoints()[spf->nombrectrlpoints()-4-i].y;
		for (j = 0 ; j < nbcbody ; j++){
			double x2da, y2da, xT2da,yT2da;
			int indj = j-2;
			if (indj < 0) indj = 0;
			if (indj >= nbcbody-5) indj = nbcbody-5;
			spa->getpoint(((double)indj)/((double)(nbcbody-5)), x2da, y2da); // calcul de la position x et y du point 2D
			spa->gettangente(((double)indj)/((double)(nbcbody-5)), xT2da, yT2da); // calcul de la tangente
			Point3D v = Point3D(xT2da, yT2da, 0)^Point3D(0,0,1);
			v.normer();
			
			if (indj <= 0){
				longueurcumuleea = 0;
			}else{
				longueurcumuleea += (Point3D(spa->accesctrlpoints()[j].x, spa->accesctrlpoints()[j].y, 0)-Point3D(spa->accesctrlpoints()[j-1].x,spa->accesctrlpoints()[j-1].y,0)).norme();
			}

			double proportion_courbe = longueurcumuleea/longspolygame;
			double facteur_forme=sca_a;
			if (proportion_courbe < pc_ba && chan){
				facteur_forme *= (1-pc_bf) + pc_bf*sqrt(abs(1-(pc_ba-proportion_courbe)/pc_ba*(pc_ba-proportion_courbe)/pc_ba));
			}
			if (proportion_courbe > 1-pc_ea && chan){
				facteur_forme *= (1-pc_ef) + pc_ef*sqrt(abs(1-(proportion_courbe-(1-pc_ea))/pc_ea*(proportion_courbe-(1-pc_ea))/pc_ea));
			}

			double xf = x2df * facteur_forme;
			double yf = y2df * facteur_forme;

			if (j >= 3 && j < nbcbody-3){
				ctrlbody[i][j].x = x2da + xf*v.x;
				ctrlbody[i][j].y = y2da + xf*v.y;
				ctrlbody[i][j].z = yf + xf*v.z;
			}else{
				ctrlbody[i][j].x = spa->accesctrlpoints()[indj+2].x;
				ctrlbody[i][j].y = spa->accesctrlpoints()[indj+2].y;
				ctrlbody[i][j].z = 0;
			}

			

		}
	}

	for (i = nblbody-3 ; i < nblbody ; i++){
		for (j = 0 ; j < nbcbody ; j++){
			ctrlbody[i][j] = ctrlbody[i-(nblbody-3)][j];
		}
	}
	surface = new SurfaceBSplineCubiqueSphere(ctrlbody, nblbody, nbcbody);

	libererPoints3D(ctrlbody, nblbody);

	construction_spherical(xor, yor, zor, 
				rotx, roty, rotz,
				scalex, scaley, scalez,
				nbmeridiens, nbparalleles, surface,
				mat, text);

}




Spline3DEditable::Spline3DEditable(double xor, double yor, double zor, 
							double rotx, double roty, double rotz,
							double scalex, double scaley, double scalez,
							int nbmerid, int nbparal, Surface *surf,
							MaterialData mat, const TextureData &text)
							:Objet3D(xor, yor, zor, 
						scalex, scaley, scalez, 
						 rotx, roty, rotz,  
							mat, text)
{

	switch (surf->gettype()){ 

	case BSPLINECUBIQUESPHERE:
		construction_spherical(xor, yor, zor, 
				rotx, roty, rotz,
				scalex, scaley, scalez,
				nbmerid, nbparal, surf,
				mat, text);
		break;
	case BSPLINECUBIQUECYLINDRE:
		construction_cylindrical(xor, yor, zor, 
				rotx, roty, rotz,
				scalex, scaley, scalez,
				nbmerid, nbparal, surf,
				mat, text);
		break;
	case BSPLINECUBIQUETORUS:
		construction_torical(xor, yor, zor, 
				rotx, roty, rotz,
				scalex, scaley, scalez,
				nbmerid, nbparal, surf,
				mat, text);
		break;

	default: AfxMessageBox(CString("mauvais type de surface !"));
		nbsomm = nbfaces =0;
	}
}


void Spline3DEditable::construction_spherical(double xor, double yor, double zor, 
							double rotx, double roty, double rotz,
							double scalex, double scaley, double scalez,
							int nbmerid, int nbparal, Surface *surf,
							MaterialData mat, const TextureData &text)
{


	nbmeridiens = nbmerid;
	nbparalleles = nbparal;
	surface = surf->copie();
	  // nombre de points total calcules sur la spline 2D
	

	int i, j, compteur;


	// calcul du nombre de sommets du polyedre
	// et allocation des sommets :
	nbsomm = (nbmerid+1) * (nbparal) + 2;
	tabsomm = new Sommet[nbsomm];

	compteur = 0;  // compteur de sommets

	// initialisation de la position des sommets, et des normales
	for (i = 0 ; i <= nbmerid ; i++){
		//double longspline = sp->calcullongueur(echantillonage);
		double longueurcumulee = 0;
		for (j = 1 ; j <= nbparal ; j++){
			// posistion du sommet (i,j) :
			surface->getpoint(((double)i)/((double)nbmerid), ((double)j)/((double) nbparal+1), tabsomm[compteur].pos.x, tabsomm[compteur].pos.y, tabsomm[compteur].pos.z); // calcul de la position x et y du sommet

			surface->getnormale(((double)i)/((double)nbmerid), ((double)j)/((double) nbparal+1), tabsomm[compteur].normale.x, tabsomm[compteur].normale.y, tabsomm[compteur].normale.z); // calcul de la normale


			tabsomm[compteur].coordtextureX = ((double)i)/((double)nbmerid);
			tabsomm[compteur].coordtextureY = ((double)j)/((double) nbparal+1);
			surface->getdsds(((double)i)/((double)nbmerid), ((double)j)/((double) nbparal+1),
								tabsomm[compteur].dpsds.x, tabsomm[compteur].dpsds.y, tabsomm[compteur].dpsds.z);
			surface->getdsdt(((double)i)/((double)nbmerid), ((double)j)/((double) nbparal+1),
									tabsomm[compteur].dpsdt.x, tabsomm[compteur].dpsdt.y, tabsomm[compteur].dpsdt.z);
			if (i == nbmerid){
				tabsomm[compteur].pos = tabsomm[j-1].pos;
				tabsomm[compteur].normale = tabsomm[j-1].normale;
			}

			compteur++; // sommet suivant
		}
	}


	// sommet correspondant au pole sud de la sphere :
	surface->getpoint(1e-4, 1e-4, tabsomm[compteur].pos.x, tabsomm[compteur].pos.y, tabsomm[compteur].pos.z); // calcul de la position x et y du sommet
	surface->getnormale(1e-4, 1e-4, tabsomm[compteur].normale.x, tabsomm[compteur].normale.y, tabsomm[compteur].normale.z); // calcul de la position x et y du sommet
	

	compteur++;

	// sommet correspondant au pole nord de la sphere :
	surface->getpoint(0.9999, 0.9999, tabsomm[compteur].pos.x, tabsomm[compteur].pos.y, tabsomm[compteur].pos.z); // calcul de la position x et y du sommet
	surface->getnormale(0.9999, 0.9999, tabsomm[compteur].normale.x, tabsomm[compteur].normale.y, tabsomm[compteur].normale.z); // calcul de la position x et y du sommet
	

	// changements d'echelle suivant les differents axes,
	// rotations, et translation
	for (i = 0 ; i < nbsomm ; i++){
		tabsomm[i].pos.x *= scalex;
		tabsomm[i].pos.y *= scaley;
		tabsomm[i].pos.z *= scalez;
		tabsomm[i].dpsds.x *= scalex;
		tabsomm[i].dpsds.y *= scaley;
		tabsomm[i].dpsds.z *= scalez;
		tabsomm[i].dpsdt.x *= scalex;
		tabsomm[i].dpsdt.y *= scaley;
		tabsomm[i].dpsdt.z *= scalez;
		tabsomm[i].normale.x /= scalex;
		tabsomm[i].normale.y /= scaley;
		tabsomm[i].normale.z /= scalez;
		tabsomm[i].normale.normer();
		tabsomm[i] = rotation*tabsomm[i];
		tabsomm[i].pos = tabsomm[i].pos + origine;
	}


	nbfaces = 2*(nbparal-1) * nbmerid + 2*nbmerid;  // nombre de facettes
	faces = new Facette[nbfaces];  // allocation des facettes



	compteur = 0;  // compteur de faces

	// allocation de chaque faccette et
	// initialisation des numeros de sommets de chaque facette
	for (i = 0 ; i < nbmerid ; i++){
		for (j = 1 ; j < nbparal ; j++){
			faces[compteur].tabnosomm = new int[3];  // facette (i,j) avec 4 sommets
			faces[compteur].nbsomm = 3;

			// numeros des sommets de la facette :
			faces[compteur].tabnosomm[0] = nbparal*i + j;
			faces[compteur].tabnosomm[1] = nbparal*(i+1) + j;
			faces[compteur].tabnosomm[2] = nbparal*(i+1) + j-1;

			compteur++;

			faces[compteur].tabnosomm = new int[3];  // facette (i,j) avec 4 sommets
			faces[compteur].nbsomm = 3;

			// numeros des sommets de la facette :
			faces[compteur].tabnosomm[0] = nbparal*(i+1) + j-1;
			faces[compteur].tabnosomm[1] = nbparal*i + j;
			faces[compteur].tabnosomm[2] = nbparal*i + j-1;

			compteur++;
		
		}
	}



	// facettes triangulaires touchant le pole sud
	for (i = 0 ; i < nbmerid ; i++){
			faces[compteur].tabnosomm = new int[3];  // facette avec 3 sommets
			faces[compteur].nbsomm = 3;

			// numeros des sommets de la facette :
			faces[compteur].tabnosomm[0] = (i+1)* nbparal;
			faces[compteur].tabnosomm[1] = (nbmerid+1)*nbparal;
			faces[compteur].tabnosomm[2] = i * nbparal;

			compteur++;
	}

	// facettes triangulaires touchant le pole nord
	for (i = 0 ; i < nbmerid ; i++){
			faces[compteur].tabnosomm = new int[3];  // facette avec 3 sommets
			faces[compteur].nbsomm = 3;

			// numeros des sommets de la facette :

			faces[compteur].tabnosomm[0] = (nbmerid+1) * nbparal + 1;
			faces[compteur].tabnosomm[1] = i * nbparal + nbparal - 1;
			faces[compteur].tabnosomm[2] = (i+1)* nbparal + nbparal - 1;

			compteur++;
	}

}


void Scene3D::updateobjetselect(Objet3D*& nouveauobjetselect){
	
	if (objetselect==NULL || objetselect->gettype() != SPLINE3DEDITABLE)
		return;
	Spline3DEditable *nouveau = new Spline3DEditable(objetselect->origine.x, objetselect->origine.y, objetselect->origine.z, 
							objetselect->rotx, objetselect->roty, objetselect->rotz,
							objetselect->scalex, objetselect->scaley, objetselect->scalez,
							((Spline3DEditable *)objetselect)->nbmeridiens, ((Spline3DEditable *)objetselect)->nbparalleles, ((Spline3DEditable *)objetselect)->surface,
							objetselect->material, objetselect->textures);

	MettreDansRepereCamera(nouveau);
	nouveau->numero = objetselect->numero;

	Celluleobj *p;
	for (p = objets.L ; p!= NULL ; p = p->suiv){
		if (p->pobjet==objetselect){
			p->pobjet = nouveau;
			delete objetselect;
			nouveauobjetselect = objetselect = nouveau;
		}
	}

}







Spline3DEditable::Spline3DEditable(double xor, double yor, double zor, 
							double rotx, double roty, double rotz,
							double scalex, double scaley, double scalez,
						    double r, double hauttronq, double rt,
						    int nbmerid, int nbparal, int nbdisk, int nbctrlcercle, int nbctrlhaut, int nbctrldisk,
							MaterialData mat,  const TextureData &text)
							:Objet3D(xor, yor, zor, 
						scalex, scaley, scalez, 
						 rotx, roty, rotz,  
							mat, text)

{

//	nbmeridiens = nbmerid;


	nbmeridiens = nbmerid,
	nbparalleles = nbparal;

	int i, j;
	double teta, sinteta, costeta;
//	double x2d, xN2d;


	int nblbody=nbctrlcercle+3;
	int nbcbody = nbctrlhaut+4;
	Point3D **ctrlbody = allouerPoints3D(nblbody, nbcbody);

	int nbltop = nbctrlcercle+3;
	int nbctop = nbctrldisk + 5;
	Point3D** ctrltop = allouerPoints3D(nbltop, nbctop);


	int nblbottom = nbctrlcercle+3;
	int nbcbottom = nbctrldisk + 5;
	Point3D** ctrlbottom = allouerPoints3D(nblbottom, nbcbottom);
	
	for (i = 0 ; i < nblbody ; i++){
		for (j = 2 ; j < nbcbody-2 ; j++){
			teta = 2*(double)pi*((double) i / (double) (nblbody-3));
			costeta = (double)cos(teta);
			sinteta = (double)sin(teta);
			double dist = r + (rt-r)*((j-2)/(double)(nbcbody-5));
			ctrlbody[i][j].x = costeta*dist;
			ctrlbody[i][j].y = sinteta*dist;
			ctrlbody[i][j].z = hauttronq*((j-2)/(double)(nbcbody-5))-hauttronq/2.0;
		}
		ctrlbody[i][0] = ctrlbody[i][1] = ctrlbody[i][2];
		ctrlbody[i][nbcbody-2] = ctrlbody[i][nbcbody-1] = ctrlbody[i][nbcbody-3];
	}

	for (i = 0 ; i < nbltop ; i++){
		for (j = 2 ; j < nbctop-2 ; j++){
			teta = 2*(double)pi*((double) i / (double) (nbltop-3));
			costeta = (double)cos(teta);
			sinteta = (double)sin(teta);
			double dist = ((j-2)/(double)(nbctop-5));
			ctrltop[i][j].x = rt*costeta*dist;
			ctrltop[i][j].y = -rt*sinteta*dist;
			ctrltop[i][j].z = hauttronq/2.0;
			ctrlbottom[i][j].x = r*costeta*dist;
			ctrlbottom[i][j].y = r*sinteta*dist;
			ctrlbottom[i][j].z = -hauttronq/2.0;
		}
		ctrltop[i][nbctop-2] = ctrltop[i][nbctop-1] = ctrltop[i][nbctop-3];
		ctrlbottom[i][nbcbottom-2] = ctrlbottom[i][nbcbottom-1] = ctrlbottom[i][nbcbottom-3];
		ctrltop[i][0] = ctrltop[i][1] = ctrltop[i][2];
		ctrlbottom[i][0] = ctrlbottom[i][1] = ctrlbottom[i][2];
	}

	surface = new SurfaceBSplineCubiqueCylindre(ctrlbody, nblbody, nbcbody,
												ctrltop, nbltop, nbctop,
												ctrlbottom, nblbottom, nbcbottom);
	libererPoints3D(ctrlbody, nblbody);
	libererPoints3D(ctrltop, nbltop);
	libererPoints3D(ctrlbottom, nblbottom);

	construction_cylindrical(xor, yor, zor, 
				rotx, roty, rotz,
				scalex, scaley, scalez,
				nbmerid, nbparal, surface,
				mat, text);

}




Spline3DEditable::Spline3DEditable(double xor, double yor, double zor, 
						   double rotx, double roty, double rotz,
						   double scalex, double scaley, double scalez,
						   Spline2D * spf, Spline2D * spa, double sca_a,
						   int echf, int echa,
						   bool chan, double pc_ba, double pc_bf, double pc_ea, double pc_ef,
						   MaterialData mat,  const TextureData &text)
							:Objet3D(xor, yor, zor, 
						scalex, scaley, scalez, 
						 rotx, roty, rotz,  
							mat, text)
{
	nbmeridiens = echf*spf->nombrectrlpoints();
	nbparalleles = echa*spa->nombrectrlpoints();

	int i, j;


	int nblbody=spf->nombrectrlpoints();
	int nbcbody = spa->nombrectrlpoints();

	double longspolygame=0;
	Point3D ancien = Point3D(spa->accesctrlpoints()[0].x, spa->accesctrlpoints()[0].y,0);
	for (i=1 ; i < spa->nombrectrlpoints() ; i++){
		longspolygame += (Point3D(spa->accesctrlpoints()[i].x, spa->accesctrlpoints()[i].y,0)-ancien).norme();
		ancien = Point3D(spa->accesctrlpoints()[i].x, spa->accesctrlpoints()[i].y,0);
	}

	Point3D **ctrlbody = allouerPoints3D(nblbody, nbcbody);

	int nbltop = spf->nombrectrlpoints();
	int nbctop = spf->nombrectrlpoints();
	Point3D** ctrltop = allouerPoints3D(nbltop, nbctop);


	int nblbottom = spf->nombrectrlpoints();
	int nbcbottom = spf->nombrectrlpoints();
	Point3D** ctrlbottom = allouerPoints3D(nblbottom, nbcbottom);
	



	double longueurcumuleea;

	for (i = 0 ; i < nblbody ; i++){
		double x2df = spf->accesctrlpoints()[spf->nombrectrlpoints()-1-i].x;
		double y2df = spf->accesctrlpoints()[spf->nombrectrlpoints()-1-i].y;
		for (j = -1 ; j <= nbcbody ; j++){
			double x2da, y2da, xT2da,yT2da;
			int indj = j-2;
			if (indj < 0) indj = 0;
			if (indj >= nbcbody-5) indj = nbcbody-5;
			spa->getpoint(((double)indj)/((double)(nbcbody-5)), x2da, y2da); // calcul de la position x et y du point 2D
			spa->gettangente(((double)indj)/((double)(nbcbody-5)), xT2da, yT2da); // calcul de la tangente
			Point3D v = Point3D(xT2da, yT2da, 0)^Point3D(0,0,1);
			v.normer();
			
			if (indj <= 0){
				longueurcumuleea = 0;
			}else{
				double xpreceda, ypreceda;
				spa->getpoint(((double)(indj-1))/((double)(nbcbody-5)), xpreceda, ypreceda);
				longueurcumuleea += (Point3D(spa->accesctrlpoints()[j].x, spa->accesctrlpoints()[j].y, 0)-Point3D(spa->accesctrlpoints()[j-1].x,spa->accesctrlpoints()[j-1].y,0)).norme();
			}

			double proportion_courbe = longueurcumuleea/longspolygame;
			double facteur_forme=sca_a;
			if (proportion_courbe < pc_ba && chan){
				facteur_forme *= (1-pc_bf) + pc_bf*sqrt(abs(1-(pc_ba-proportion_courbe)/pc_ba*(pc_ba-proportion_courbe)/pc_ba));
			}
			if (proportion_courbe > 1-pc_ea && chan){
				facteur_forme *= (1-pc_ef) + pc_ef*sqrt(abs(1-(proportion_courbe-(1-pc_ea))/pc_ea*(proportion_courbe-(1-pc_ea))/pc_ea));
			}

			if (chan && indj<=0)
				facteur_forme = (1-pc_bf)*sca_a;
			if (chan && indj>=nbcbody-5)
				facteur_forme = (1-pc_ef)*sca_a;
			double xf = x2df * facteur_forme;
			double yf = y2df * facteur_forme;

			if (j >= 3 && j <= nbcbody-3){
				ctrlbody[i][j].x = x2da + xf*v.x;
				ctrlbody[i][j].y = y2da + xf*v.y;
				ctrlbody[i][j].z = yf + xf*v.z;
			}

			if (j >= 0 && j < 3){
				ctrlbody[i][j] = ctrlbottom[i][nbcbottom-1];
			}

			if (j >= nbcbody-2 && j < nbcbody){
				ctrlbody[i][j] = ctrlbody[i][nbcbody-3];
			}

			
			if (j == -1){
				for (int k=0 ; k < nbcbottom ; k++){
					double nxf = xf*(k <= 2 ? 0 : (k>=(nbcbottom-3) ? 1 : (k-2)/(double)(nbcbottom-5)));
					double nyf = yf*(k <= 2 ? 0 : (k>=(nbcbottom-3) ? 1 : (k-2)/(double)(nbcbottom-5)));
					ctrlbottom[i][k].x = x2da + nxf*v.x;
					ctrlbottom[i][k].y = y2da + nxf*v.y;
					ctrlbottom[i][k].z = nyf + nxf*v.z;

				}
			}

			if (j == nbcbody){
				for (int k=0 ; k < nbctop ; k++){
					double fac = (k <= 2 ? 0 : (k>=(nbctop-3) ? 1 : (k-2)/(double)(nbctop-5)));
					ctrltop[nbltop-1-i][k] = Point3D(x2da,y2da,0)+fac*(ctrlbody[i][nbcbody-3]-Point3D(x2da,y2da,0));
				}
			}

		}
	}


	surface = new SurfaceBSplineCubiqueCylindre(ctrlbody, nblbody, nbcbody,
												ctrltop, nbltop, nbctop,
												ctrlbottom, nblbottom, nbcbottom);
	libererPoints3D(ctrlbody, nblbody);
	libererPoints3D(ctrltop, nbltop);
	libererPoints3D(ctrlbottom, nblbottom);

	construction_cylindrical(xor, yor, zor, 
				rotx, roty, rotz,
				scalex, scaley, scalez,
				nbmeridiens, nbparalleles, surface,
				mat, text);

}

void Spline3DEditable::construction_cylindrical(double xor, double yor, double zor, 
							double rotx, double roty, double rotz,
							double scalex, double scaley, double scalez,
							int nbmerid, int nbparal, Surface *surf,
							MaterialData mat, const TextureData &text)
{


	nbmeridiens = nbmerid;
	nbparalleles = nbparal;
	surface = surf->copie();
	  // nombre de points total calcules sur la spline 2D
	

	nbsomm = (nbmerid+1) *(nbparal + 1)+2*(nbmerid+1)*nbmerid+2;
	tabsomm = new Sommet[nbsomm];


	int compteur = 0;  // compteur de sommets

	// initialisation de la position des sommets, et des normales
	for (int i = 0 ; i <= nbmerid ; i++){
		for (int j = 0 ; j <= nbparal ; j++){
			// nbmerid premiers sommets :
			surface->getpoint((i/(double)nbmerid), (j/(double)nbparal),tabsomm[compteur].pos.x,tabsomm[compteur].pos.y,tabsomm[compteur].pos.z);
			surface->getnormale((i/(double)nbmerid), (j/(double)nbparal),tabsomm[compteur].normale.x,tabsomm[compteur].normale.y,tabsomm[compteur].normale.z);
			tabsomm[compteur].normale.normer();
			tabsomm[compteur].coordtextureX = (i/(double)nbmerid);
			tabsomm[compteur].coordtextureY = (double)(j/((double)nbparal));
			surface->getdsds((i/(double)nbmerid), (j/(double)nbparal),tabsomm[compteur].dpsds.x,tabsomm[compteur].dpsds.y,tabsomm[compteur].dpsds.z);
			surface->getdsdt((i/(double)nbmerid), (j/(double)nbparal),tabsomm[compteur].dpsdt.x,tabsomm[compteur].dpsdt.y,tabsomm[compteur].dpsdt.z);


			compteur++; // sommet suivant
		}
	}


	surface->getpoint(2, 0,tabsomm[compteur].pos.x,tabsomm[compteur].pos.y,tabsomm[compteur].pos.z);
	surface->getnormale(2, 0,tabsomm[compteur].normale.x,tabsomm[compteur].normale.y,tabsomm[compteur].normale.z);
	tabsomm[compteur].normale.normer();
	tabsomm[compteur].coordtextureX = 0;
	tabsomm[compteur].coordtextureY = 0;
	surface->getdsds(2, 0,tabsomm[compteur].dpsds.x,tabsomm[compteur].dpsds.y,tabsomm[compteur].dpsds.z);
	surface->getdsdt(2, 0,tabsomm[compteur].dpsdt.x,tabsomm[compteur].dpsdt.y,tabsomm[compteur].dpsdt.z);

	compteur++; // sommet suivant

	for (int i = 0 ; i <= nbmerid ; i++){
		for (int j = 1 ; j <= nbmerid ; j++){
		
			// nbmerid premiers sommets :
			surface->getpoint(2+(i/(double)nbmerid), (j/(double)nbmerid),tabsomm[compteur].pos.x,tabsomm[compteur].pos.y,tabsomm[compteur].pos.z);
			surface->getnormale(2+(i/(double)nbmerid), (j/(double)nbmerid),tabsomm[compteur].normale.x,tabsomm[compteur].normale.y,tabsomm[compteur].normale.z);
			tabsomm[compteur].normale.normer();
			tabsomm[compteur].coordtextureX = (i/(double)nbmerid);
			tabsomm[compteur].coordtextureY = (double)(j/((double)nbmerid));
			surface->getdsds(2+(i/(double)nbmerid), (j/(double)nbmerid),tabsomm[compteur].dpsds.x,tabsomm[compteur].dpsds.y,tabsomm[compteur].dpsds.z);
			surface->getdsdt(2+(i/(double)nbmerid), (j/(double)nbmerid),tabsomm[compteur].dpsdt.x,tabsomm[compteur].dpsdt.y,tabsomm[compteur].dpsdt.z);


			compteur++; // sommet suivant
		}
	}


	

	surface->getpoint(4, 0,tabsomm[compteur].pos.x,tabsomm[compteur].pos.y,tabsomm[compteur].pos.z);
	surface->getnormale(4, 0,tabsomm[compteur].normale.x,tabsomm[compteur].normale.y,tabsomm[compteur].normale.z);
	tabsomm[compteur].normale.normer();
	tabsomm[compteur].coordtextureX = 0;
	tabsomm[compteur].coordtextureY = 0;
	surface->getdsds(4, 0,tabsomm[compteur].dpsds.x,tabsomm[compteur].dpsds.y,tabsomm[compteur].dpsds.z);
	surface->getdsdt(4, 0,tabsomm[compteur].dpsdt.x,tabsomm[compteur].dpsdt.y,tabsomm[compteur].dpsdt.z);

	compteur++; // sommet suivant

	for (int i = 0 ; i <= nbmerid ; i++){
		for (int j = 1 ; j <= nbmerid ; j++){
		
			// nbmerid premiers sommets :
			surface->getpoint(4+(i/(double)nbmerid), (j/(double)nbmerid),tabsomm[compteur].pos.x,tabsomm[compteur].pos.y,tabsomm[compteur].pos.z);
			surface->getnormale(4+(i/(double)nbmerid), (j/(double)nbmerid),tabsomm[compteur].normale.x,tabsomm[compteur].normale.y,tabsomm[compteur].normale.z);
			tabsomm[compteur].normale.normer();
			tabsomm[compteur].coordtextureX = (i/(double)nbmerid);
			tabsomm[compteur].coordtextureY = (double)(j/((double)nbmerid));
			surface->getdsds(4+(i/(double)nbmerid), (j/(double)nbmerid),tabsomm[compteur].dpsds.x,tabsomm[compteur].dpsds.y,tabsomm[compteur].dpsds.z);
			surface->getdsdt(4+(i/(double)nbmerid), (j/(double)nbmerid),tabsomm[compteur].dpsdt.x,tabsomm[compteur].dpsdt.y,tabsomm[compteur].dpsdt.z);

			compteur++; // sommet suivant
		}
	}


	
	
	// changements d'echelle suivant les differents axes,
	// rotations, et translation
	for (int i = 0 ; i < nbsomm ; i++){
		tabsomm[i].pos.x *= scalex;
		tabsomm[i].pos.y *= scaley;
		tabsomm[i].pos.z *= scalez;
		tabsomm[i].dpsds.x *= scalex;
		tabsomm[i].dpsds.y *= scaley;
		tabsomm[i].dpsds.z *= scalez;
		tabsomm[i].dpsdt.x *= scalex;
		tabsomm[i].dpsdt.y *= scaley;
		tabsomm[i].dpsdt.z *= scalez;
		tabsomm[i].normale.x /= scalex;
		tabsomm[i].normale.y /= scaley;
		tabsomm[i].normale.z /= scalez;
		tabsomm[i].normale.normer();
		tabsomm[i] = rotation*tabsomm[i];
		tabsomm[i].pos = tabsomm[i].pos + origine;
	}



	nbfaces = (nbparal +2*(nbmerid)) * nbmerid;  // nombre de facettes
	faces = new Facette[nbfaces];  // allocation des facettes



	compteur = 0;  // compteur de faces

	// allocation de chaque faccette et
	// initialisation des numeros de sommets de chaque facette
	for (int i = 0 ; i < nbmerid ; i++){
		for (int j = 0 ; j < nbparal ; j++){
			faces[compteur].tabnosomm = new int[4];  // facette (i,j) avec 4 sommets
			faces[compteur].nbsomm = 4;

			// numeros des sommets de la facette :
			faces[compteur].tabnosomm[0] = (nbparal+1)*i + j;
			faces[compteur].tabnosomm[1] = (nbparal+1)*(i+1) + j;
			faces[compteur].tabnosomm[2] = (nbparal+1)*(i+1) + j+1;
			faces[compteur].tabnosomm[3] = (nbparal+1)*i + j+1;

			compteur++;
		}
	}

	for (int i = 0 ; i < nbmerid ; i++){
		faces[compteur].tabnosomm = new int[3];  // facette (i,j) avec 3 sommets
		faces[compteur].nbsomm = 3;

		// numeros des sommets de la facette :
		faces[compteur].tabnosomm[0] = (nbparal+1)*(nbmerid+1);
		faces[compteur].tabnosomm[1] = (nbparal+1)*(nbmerid+1)+1+(nbmerid)*i;
		faces[compteur].tabnosomm[2] = (nbparal+1)*(nbmerid+1)+1+(nbmerid)*(i+1);

		compteur++;
	}


	for (int i = 0 ; i < nbmerid ; i++){
		for (int j = 0 ; j < nbmerid-1 ; j++){
			faces[compteur].tabnosomm = new int[4];  // facette (i,j) avec 4 sommets
			faces[compteur].nbsomm = 4;

			// numeros des sommets de la facette :
			faces[compteur].tabnosomm[0] = (nbparal+1)*(nbmerid+1)+1+(nbmerid)*i + j;
			faces[compteur].tabnosomm[1] = (nbparal+1)*(nbmerid+1)+1+(nbmerid)*(i+1) + j;
			faces[compteur].tabnosomm[2] = (nbparal+1)*(nbmerid+1)+1+(nbmerid)*(i+1) + j+1;
			faces[compteur].tabnosomm[3] = (nbparal+1)*(nbmerid+1)+1+(nbmerid)*i + j+1;

			compteur++;
		}
	}


	for (int i = 0 ; i < nbmerid ; i++){
		faces[compteur].tabnosomm = new int[3];  // facette (i,j) avec 3 sommets
		faces[compteur].nbsomm = 3;

		// numeros des sommets de la facette :
		faces[compteur].tabnosomm[0] = (nbparal+1+nbmerid)*(nbmerid+1)+1;
		faces[compteur].tabnosomm[1] = (nbparal+1+nbmerid)*(nbmerid+1)+2+(nbmerid)*i;
		faces[compteur].tabnosomm[2] = (nbparal+1+nbmerid)*(nbmerid+1)+2+(nbmerid)*(i+1);

		compteur++;
	}

	for (int i = 0 ; i < nbmerid ; i++){
		for (int j = 0 ; j < nbmerid-1 ; j++){
			faces[compteur].tabnosomm = new int[4];  // facette (i,j) avec 4 sommets
			faces[compteur].nbsomm = 4;

			// numeros des sommets de la facette :
			faces[compteur].tabnosomm[0] = (nbparal+1+nbmerid)*(nbmerid+1)+2+(nbmerid)*i + j;
			faces[compteur].tabnosomm[1] = (nbparal+1+nbmerid)*(nbmerid+1)+2+(nbmerid)*(i+1) + j;
			faces[compteur].tabnosomm[2] = (nbparal+1+nbmerid)*(nbmerid+1)+2+(nbmerid)*(i+1) + j+1;
			faces[compteur].tabnosomm[3] = (nbparal+1+nbmerid)*(nbmerid+1)+2+(nbmerid)*i + j+1;

			compteur++;
		}
	}


}




Objet3D * Spline3DEditable::copie(void)
{
	Objet3D *res = new Spline3DEditable(nbmeridiens, nbparalleles, surface);



	res->copieObjet3D(*this);

	return res;
}



void Spline3DEditable::ecritfich(ostream& fich){

	fich << gettype() << "\n";
	Objet3D::ecritdonneesobjet3D(fich);

	fich << nbmeridiens << " " << nbparalleles << "\n";
	fich << surface->gettype() << "\n";


	surface->ecritctrlpoints(fich);

}







Spline3DEditable::Spline3DEditable(double xor, double yor, double zor, 
						   double rotx, double roty, double rotz,
						   double scalex, double scaley, double scalez,
						   Spline2D * spf, Spline2D * spa, double sca_a,
						   int echf, int echa,
						   MaterialData mat,  const TextureData &text)
							:Objet3D(xor, yor, zor, 
						scalex, scaley, scalez, 
						 rotx, roty, rotz,  
							mat, text)
{
	nbmeridiens = echf*spf->nombrectrlpoints();
	nbparalleles = echa*spa->nombrectrlpoints();

	int i, j;

	int nblbody=spf->nombrectrlpoints();
	int nbcbody = spa->nombrectrlpoints();


	Point3D **ctrlbody = allouerPoints3D(nblbody, nbcbody);

	

	for (i = 0 ; i < nblbody-3 ; i++){
		double x2df = spf->accesctrlpoints()[spf->nombrectrlpoints()-1-i].x;
		double y2df = spf->accesctrlpoints()[spf->nombrectrlpoints()-1-i].y;
		for (j = 0 ; j < nbcbody-3 ; j++){
			double x2da, y2da, xT2da,yT2da;
			spa->getpoint(((double)j+0.5)/((double)(nbcbody-3)), x2da, y2da); // calcul de la position x et y du point 2D
			spa->gettangente(((double)j+0.5)/((double)(nbcbody-3)), xT2da, yT2da); // calcul de la tangente
			Point3D v = Point3D(xT2da, yT2da, 0)^Point3D(0,0,1);
			v.normer();
			

			double xf = x2df * sca_a;
			double yf = y2df * sca_a;


			ctrlbody[i][j].x = x2da + xf*v.x;
			ctrlbody[i][j].y = y2da + xf*v.y;
			ctrlbody[i][j].z = yf + xf*v.z;			

		}
	}

	for (i = nblbody-3 ; i < nblbody ; i++){
		for (j = 0 ; j < nbcbody-3 ; j++){
			ctrlbody[i][j] = ctrlbody[i-(nblbody-3)][j];
		}
	}

	for (i = 0 ; i < nblbody ; i++){
		for (j = nbcbody-3 ; j < nbcbody  ; j++){
			ctrlbody[i][j] = ctrlbody[i][j-(nbcbody-3)];
		}
	}

	
	surface = new SurfaceBSplineCubiqueTore(ctrlbody, nblbody, nbcbody);

	libererPoints3D(ctrlbody, nblbody);

	construction_torical(xor, yor, zor, 
				rotx, roty, rotz,
				scalex, scaley, scalez,
				nbmeridiens, nbparalleles, surface,
				mat, text);

}





void Spline3DEditable::construction_torical(double xor, double yor, double zor, 
							double rotx, double roty, double rotz,
							double scalex, double scaley, double scalez,
							int nbmerid, int nbparal, Surface *surf,
							MaterialData mat, const TextureData &text)
{


	nbmeridiens = nbmerid;
	nbparalleles = nbparal;
	surface = surf->copie();
	  // nombre de points total calcules sur la spline 2D
	

	int i, j, compteur;


	// calcul du nombre de sommets du polyedre
	// et allocation des sommets :
	nbsomm = (nbmerid+1) * (nbparal+1);
	tabsomm = new Sommet[nbsomm];

	compteur = 0;  // compteur de sommets

	// initialisation de la position des sommets, et des normales
	for (i = 0 ; i <= nbmerid ; i++){
		//double longspline = sp->calcullongueur(echantillonage);
		double longueurcumulee = 0;
		for (j = 0 ; j <= nbparal ; j++){
			// posistion du sommet (i,j) :
			surface->getpoint(((double)i)/((double)nbmerid), ((double)j)/((double) nbparal), tabsomm[compteur].pos.x, tabsomm[compteur].pos.y, tabsomm[compteur].pos.z); // calcul de la position x et y du sommet

			surface->getnormale(((double)i)/((double)nbmerid), ((double)j)/((double) nbparal), tabsomm[compteur].normale.x, tabsomm[compteur].normale.y, tabsomm[compteur].normale.z); // calcul de la normale


			tabsomm[compteur].coordtextureX = ((double)i)/((double)nbmerid);
			tabsomm[compteur].coordtextureY = ((double)j)/((double) nbparal);
			surface->getdsds(((double)i)/((double)nbmerid), ((double)j)/((double) nbparal),
								tabsomm[compteur].dpsds.x, tabsomm[compteur].dpsds.y, tabsomm[compteur].dpsds.z);
			surface->getdsdt(((double)i)/((double)nbmerid), ((double)j)/((double) nbparal),
									tabsomm[compteur].dpsdt.x, tabsomm[compteur].dpsdt.y, tabsomm[compteur].dpsdt.z);
			if (i == nbmerid){
				tabsomm[compteur].pos = tabsomm[j].pos;
				tabsomm[compteur].normale = tabsomm[j].normale;
			}

			if (j == nbparal){
				tabsomm[compteur].pos = tabsomm[compteur-nbparal].pos;
				tabsomm[compteur].normale = tabsomm[compteur-nbparal].normale;
			}

			compteur++; // sommet suivant
		}
	}


	// changements d'echelle suivant les differents axes,
	// rotations, et translation
	for (i = 0 ; i < nbsomm ; i++){
		tabsomm[i].pos.x *= scalex;
		tabsomm[i].pos.y *= scaley;
		tabsomm[i].pos.z *= scalez;
		tabsomm[i].dpsds.x *= scalex;
		tabsomm[i].dpsds.y *= scaley;
		tabsomm[i].dpsds.z *= scalez;
		tabsomm[i].dpsdt.x *= scalex;
		tabsomm[i].dpsdt.y *= scaley;
		tabsomm[i].dpsdt.z *= scalez;
		tabsomm[i].normale.x /= scalex;
		tabsomm[i].normale.y /= scaley;
		tabsomm[i].normale.z /= scalez;
		tabsomm[i].normale.normer();
		tabsomm[i] = rotation*tabsomm[i];
		tabsomm[i].pos = tabsomm[i].pos + origine;
	}


	nbfaces = 2*nbparal * nbmerid;  // nombre de facettes
	faces = new Facette[nbfaces];  // allocation des facettes



	compteur = 0;  // compteur de faces

	// allocation de chaque faccette et
	// initialisation des numeros de sommets de chaque facette
	for (i = 0 ; i < nbmerid ; i++){
		for (j = 0 ; j < nbparal ; j++){
			faces[compteur].tabnosomm = new int[3];  // facette (i,j) avec 4 sommets
			faces[compteur].nbsomm = 3;

			// numeros des sommets de la facette :
			faces[compteur].tabnosomm[0] = (nbparal+1)*i + j+1;
			faces[compteur].tabnosomm[1] = (nbparal+1)*(i+1) + j+1;
			faces[compteur].tabnosomm[2] = (nbparal+1)*(i+1) + j;

			compteur++;

			faces[compteur].tabnosomm = new int[3];  // facette (i,j) avec 4 sommets
			faces[compteur].nbsomm = 3;

			// numeros des sommets de la facette :
			faces[compteur].tabnosomm[0] = (nbparal+1)*(i+1) + j;
			faces[compteur].tabnosomm[1] = (nbparal+1)*i + j+1;
			faces[compteur].tabnosomm[2] = (nbparal+1)*i + j;

			compteur++;
		
		}
	}


}


