/////////////////////////////////////////////////////////////////////////////
// CDisplayImageWnd



#include "stdafx.h"
#include "Synth.h"


#include "Polygone2d.h"
#include "Objetderiv.h"
#include "CDisplayImageWnd.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CDisplayImageWnd::CDisplayImageWnd()
{
}

CDisplayImageWnd::CDisplayImageWnd(imcouleur im)
{
	image=im;

	hdesktop = ::GetDesktopWindow();
	
	brosse.CreateSolidBrush(RGB(255,255,255));
	class_name=AfxRegisterWndClass(CS_HREDRAW & CS_GLOBALCLASS,0, brosse, 0);
	dimx = dimy = 0;
}


CDisplayImageWnd::~CDisplayImageWnd()
{
	DestroyMenu(hmenu);
}


BEGIN_MESSAGE_MAP(CDisplayImageWnd, CWnd)
	//{{AFX_MSG_MAP(CDisplayImageWnd)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_WM_PAINT()
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_WM_CLOSE()
	ON_WM_DESTROY()
	ON_WM_WINDOWPOSCHANGED()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDisplayImageWnd message handlers


void CDisplayImageWnd::CreateAndDisplay(){

 
	//CreateEx( DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, 
	//int x, int y, int nWidth, int nHeight, HWND hwndParent, HMENU nIDorHMenu, LPVOID lpParam = NULL );

	hmenu = LoadMenu(GetModuleHandle(NULL), MAKEINTRESOURCE(IDR_DISPLAYFRAME));

	CRect windrect(0,0, image.largeur() + 8, image.hauteur()+46);

	
	CRect bkrect;
	GetDesktopWindow()->GetClientRect(bkrect);
	if (windrect.Height() > bkrect.Height())
		windrect.bottom = bkrect.Height();
	if (windrect.Width() > bkrect.Width())
		windrect.right = bkrect.Width();

	DWORD style = WS_OVERLAPPEDWINDOW  | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL;

	if (0==AdjustWindowRectEx(
		  &windrect,    // pointer to client-rectangle structure
		  style,    // window styles
		  true,       // menu-present flag
		  WS_EX_DLGMODALFRAME   // extended style
		))
		style = style | WS_MAXIMIZE;
 
	isdestroyed=false;
	if (!CreateEx(WS_EX_DLGMODALFRAME, class_name, CString("Rendering Display"), style,
		windrect.left,windrect.top,windrect.right,windrect.bottom, hdesktop, hmenu)){
				AfxMessageBox(CString("Impossible de creer la fenetre d'affichage"));
					isdestroyed=true;
				}

	is_hroz_enabled=false;
	is_vert_enabled=false;

	EnableScrollBarCtrl(SB_HORZ, false);
	EnableScrollBarCtrl(SB_VERT, false);

	
	CenterWindow(NULL);
	ShowWindow(SW_SHOW);

	//CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, 
//	const RECT& rect, CWnd* pParentWnd, UINT nID, LPVOID lpParam = NULL);

	OnPaint();
}

void CDisplayImageWnd::OnFileSave() 
{
	// TODO: Add your command handler code here
	
		char nomfichier[150];
	

//	CExportBMP dlg;
//	dlg.m_nomfich = "noname.bmp";

	CFileDialog dlg(FALSE, CString("bmp"), CString("*.bmp"));

		int ret = dlg.DoModal();

	if (ret != IDCANCEL){
//		int longueur = dlg.m_nomfich.GetLength();
//		for (int i = 0 ; i < longueur ; i++){
//			nomfichier[i] = dlg.m_nomfich.GetAt(i);
//		}
		int longueur = dlg.GetPathName().GetLength();
    int i;
		for (i = 0 ; i < longueur ; i++){
			nomfichier[i] = dlg.GetPathName().GetAt(i);
		}
		nomfichier[i] = '\0';
		if (longueur < 4 ||
			(nomfichier[longueur-1] != 'p' && nomfichier[longueur-1] != 'P') ||
			(nomfichier[longueur-2] != 'm' && nomfichier[longueur-1] != 'M') ||
			(nomfichier[longueur-3] != 'b' && nomfichier[longueur-1] != 'B') ||
			nomfichier[longueur-4] != '.'){
			nomfichier[longueur] = '.';
			nomfichier[longueur+1] = 'b';
			nomfichier[longueur+2] = 'm';
			nomfichier[longueur+3] = 'p';
			nomfichier[longueur+4] = '\0';
		}


		image.ecritbmp(nomfichier);
	}
}

void CDisplayImageWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	
	// Do not call CWnd::OnPaint() for painting messages

	CRect clientrect;
//		GetWindowRect(windowrect);
	GetClientRect(clientrect);
	int posx = GetScrollPos(SB_HORZ);
	int posy = GetScrollPos(SB_VERT);

	CClientDC cdc(this);
	SetDIBitsToDevice(
			cdc,              // handle to device context
			0,            // x-coordinate of upper-left corner of 
							// dest. rect.
			0,            // y-coordinate of upper-left corner of 
							// dest. rect.
			clientrect.Width(),        // source rectangle width
			clientrect.Height(),       // source rectangle height
			posx,             // x-coordinate of lower-left corner of 
							// source rect.
			image.hauteur()-clientrect.Height()-posy, // y-coordinate of lower-left corner of 
							// source rect.
			0,      // first scan line in array
			image.hauteur(),      // number of scan lines
			image.bitimage,  // address of array with DIB bits
			image.pbitmapinfo,  // address of structure with bitmap info.
			DIB_RGB_COLORS       // RGB or palette indexes
			);


}




void CDisplayImageWnd::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default


	int pos = GetScrollPos(SB_HORZ);

	int tempmin, tempmax;
	UINT min, max;
	GetScrollRange(SB_HORZ, &tempmin, &tempmax);
	min = (UINT)tempmin;
	max = (UINT)tempmax;
	
	if (nSBCode==SB_LEFT)
		nPos=min;

	if (nSBCode==SB_ENDSCROLL)
		nPos=pos;

	if (nSBCode==SB_PAGELEFT){
		nPos = pos-10;
		if (nPos < min) nPos=min;
	}

	if (nSBCode==SB_PAGERIGHT){
		nPos = pos+10;
		if (nPos > max) nPos = max;
	}

	if (nSBCode==SB_LINELEFT){
		nPos = pos-1;
		if (nPos < min) nPos=min;
	}

	if (nSBCode==SB_LINERIGHT){
		nPos = pos+1;
		if (nPos > max) nPos = max;
	}

	if (nSBCode==SB_RIGHT)
		nPos = max;



	ScrollWindowEx(nPos-pos, 0, NULL, NULL, NULL, NULL, SW_INVALIDATE);

	SetScrollPos(SB_HORZ, nPos);
	CWnd::OnHScroll(nSBCode, nPos, pScrollBar);
	
	
}

void CDisplayImageWnd::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	
	int pos = GetScrollPos(SB_VERT);

	int tempmin, tempmax;
	UINT min, max;
	GetScrollRange(SB_HORZ, &tempmin, &tempmax);
	min = (UINT)tempmin;
	max = (UINT)tempmax;
	
	if (nSBCode==SB_TOP)
		nPos=min;

	if (nSBCode==SB_ENDSCROLL)
		nPos=pos;

	if (nSBCode==SB_PAGEUP){
		nPos = pos-10;
		if (nPos < min) nPos=min;
	}

	if (nSBCode==SB_PAGEDOWN){
		nPos = pos+10;
		if (nPos > max) nPos = max;
	}

	if (nSBCode==SB_LINEUP){
		nPos = pos-1;
		if (nPos < min) nPos=min;
	}

	if (nSBCode==SB_LINEDOWN){
		nPos = pos+1;
		if (nPos > max) nPos = max;
	}

	if (nSBCode==SB_BOTTOM)
		nPos = max;
	ScrollWindowEx(0, nPos-pos, NULL, NULL, NULL, NULL, SW_INVALIDATE);
	SetScrollPos(SB_VERT, nPos);
	CWnd::OnVScroll(nSBCode, nPos, pScrollBar);
}

/*void CDisplayImageWnd::OnHScrollClipboard(CWnd* pClipAppWnd, UINT nSBCode, UINT nPos) 
{
	// TODO: Add your message handler code here and/or call default
	
//	if (nSBCode==SB_ENDSCROLL)
//	CWnd::OnHScrollClipboard(pClipAppWnd, nSBCode, nPos);
}

void CDisplayImageWnd::OnVScrollClipboard(CWnd* pClipAppWnd, UINT nSBCode, UINT nPos) 
{
	// TODO: Add your message handler code here and/or call default
	
	CWnd::OnVScrollClipboard(pClipAppWnd, nSBCode, nPos);
}
*/

void CDisplayImageWnd::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	
	CWnd::OnClose();
}

void CDisplayImageWnd::OnDestroy() 
{
	CWnd::OnDestroy();
	
	// TODO: Add your message handler code here
//	GetDesktopWindow()->PostMessage(WM_SET_RENDER_DISPLAY_WND_NULL,1,1);

	isdestroyed=true;
}

void CDisplayImageWnd::OnWindowPosChanged(WINDOWPOS FAR* lpwndpos) 
{
	CWnd::OnWindowPosChanged(lpwndpos);
	
	// TODO: Add your message handler code here
	
	CRect windowrect, clientrect;
	GetWindowRect(windowrect);
	GetClientRect(clientrect);
	if (image.largeur()-windowrect.Width()+8 <= 0){
		if (is_hroz_enabled){
			is_hroz_enabled=false;
			EnableScrollBarCtrl(SB_HORZ, false);
			ShowScrollBar(SB_HORZ, false);
			OnNcPaint( );
		}
	}else{
		if (!is_hroz_enabled){
			is_hroz_enabled=true;
			EnableScrollBarCtrl(SB_HORZ, true);
			ShowScrollBar(SB_HORZ, true);
			SetScrollRange(SB_HORZ, 0, image.largeur()-clientrect.Width());
			OnNcPaint( );
		}
	}
	if (image.hauteur()-windowrect.Height()+46 <= 0){
		if (is_vert_enabled){
			is_vert_enabled=false;
			EnableScrollBarCtrl(SB_VERT, false);
			ShowScrollBar(SB_VERT, false);
			OnNcPaint( );
		}
	}else{
		if (!is_vert_enabled){
			is_vert_enabled=true;
			EnableScrollBarCtrl(SB_VERT);
			ShowScrollBar(SB_VERT, true);
			SetScrollRange(SB_VERT, 0, image.hauteur()-clientrect.Height());
			OnNcPaint( );
		}
	}
}
