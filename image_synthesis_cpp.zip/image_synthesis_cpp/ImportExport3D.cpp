#include "stdafx.h"
#include "Synth.h"
#include "Scene3DRay.h"
#include "Objetderiv.h"
#include "Polygone2d.h"
#include "SurfaceSpline.h"
#include "objetsdialog.h"



#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


#define NO_CURRENT_VERSION 7

void Objet3D::ecritdonneesobjet3D(ostream& fich){

	fich << origine.x << " " << origine.y << " " << origine.z << "\n";   // translation du repere de l'objet par rapport au repere de la scene
	fich << scalex << " " << scaley  << " "<< scalez << "\n";  // changements d'echelle sur l'objet
	fich << rotx << " " << roty << " " << rotz << " " << "\n";

	fich << (material.phongenable ? 1 : 0) << " "; // true si Phong est actif, false sinon

	fich << (textures.withtexture[0] ? 1 : 0) << " ";

	if (textures.withtexture[0])
		fich << textures.fichiertexture[0] << "\n";

	fich << (textures.withbumpmap[0] ? 1 : 0) << " ";

	if (textures.withbumpmap[0]){
		fich << textures.factorbump << "\n";
		fich << textures.fichierbumpmap[0] << "\n";
	}

	fich << (textures.withtexture[1] ? 1 : 0) << " ";

	if (textures.withtexture[1])
		fich << textures.fichiertexture[1] << "\n";

	fich << (textures.withbumpmap[1] ? 1 : 0) << " ";

	if (textures.withbumpmap[1]){
		fich << textures.factorbump << "\n";
		fich << textures.fichierbumpmap[1] << "\n";
	}

	fich << (textures.withtexture[2] ? 1 : 0) << " ";

	if (textures.withtexture[2])
		fich << textures.fichiertexture[2] << "\n";

	fich << (textures.withbumpmap[2] ? 1 : 0) << " ";

	if (textures.withbumpmap[2]){
		fich << textures.factorbump << "\n";
		fich << textures.fichierbumpmap[2] << "\n";
	}


	fich << material.couleur.R << " " << material.couleur.G << " " << material.couleur.B << "\n";  // coefficients RGB de la couleur (entre 0 et 1)
	fich << material.coef_rd << " ";       // coefficients de reflexion difuse
	fich << material.coef_ambiant << " ";  // coefficient de reflexion de la lumiere ambiante
	fich << material.coef_rs << " ";       // coefficients de reflexion speculaire
	fich << material.exp_rs << " ";
	fich << material.coef_td << " ";
	fich << material.coef_ts << " ";
	fich << material.coef_ri << " ";
	fich << material.coef_ti << " ";
	fich << material.indice_refr<< " ";
	fich << material.emitance << "\n";
}



void litdefautobjet3D(ifstream& fich,
					  Point3D& origine, 
					  double& scalex, double& scaley, double& scalez,
					  double& rotx, double& roty, double& rotz,
					  MaterialData & mater, TextureData& text, int noversion){

	bool avectexture_s; 
	CString fichiertexture_s;
	bool avecbumpmap_s; 
	CString fichierbumpmap_s;
	bool avectexture_t; 
	CString fichiertexture_t;
	bool avecbumpmap_t; 
	CString fichierbumpmap_t;
	bool avectexture_b; 
	CString fichiertexture_b;
	bool avecbumpmap_b; 
	CString fichierbumpmap_b;

	double factorbump;


	fich >> origine.x >> origine.y >> origine.z;   // translation du repere de l'objet par rapport au repere de la scene
	fich >> scalex >> scaley >> scalez;  // changements d'echelle sur l'objet
	fich >> rotx >> roty >> rotz;

	int temp;
	fich >> temp; // true si Phong est actif, false sinon
	mater.phongenable = temp ? true : false;

	fich >> temp;
	avectexture_s =  temp ? true : false;

	char nomfich[150];
	if (avectexture_s)
		fich >> nomfich;
	else
		nomfich[0]='\0';
	fichiertexture_s = CString(nomfich);

	if (noversion >= 3){
		fich >> temp;
		avecbumpmap_s = temp ? true : false;
		if (avecbumpmap_s){
			fich >> factorbump;
			fich >> nomfich;
			fichierbumpmap_s = CString(nomfich);
		}else{
			factorbump = 1;
			fichierbumpmap_s="";
		}
	}else{
		avecbumpmap_s=false;
		factorbump=1;
		fichierbumpmap_s="";

	}

	if (noversion >= 6){
		fich >> temp;
		avectexture_t =  temp ? true : false;

		char nomfich[150];
		if (avectexture_t)
			fich >> nomfich;
		else
			nomfich[0]='\0';
		fichiertexture_t = CString(nomfich);

		fich >> temp;
		avecbumpmap_t = temp ? true : false;
		if (avecbumpmap_t){
			fich >> factorbump;
			fich >> nomfich;
			fichierbumpmap_t = CString(nomfich);
		}else{
			fichierbumpmap_t="";
		}




		fich >> temp;
		avectexture_b =  temp ? true : false;

		if (avectexture_b)
			fich >> nomfich;
		else
			nomfich[0]='\0';
		fichiertexture_b = CString(nomfich);

		fich >> temp;
		avecbumpmap_b = temp ? true : false;
		if (avecbumpmap_b){
			fich >> factorbump;
			fich >> nomfich;
			fichierbumpmap_b = CString(nomfich);
		}else{
			fichierbumpmap_b="";
		}

	}else{
		avectexture_t = avectexture_b = avectexture_s; 
		fichiertexture_t = fichiertexture_b = fichiertexture_s;
		avecbumpmap_t = avecbumpmap_b = avecbumpmap_s; 
		fichierbumpmap_t = fichierbumpmap_b = fichierbumpmap_s;
		
	}

	text = TextureData(avectexture_s, fichiertexture_s, 
						avectexture_t, fichiertexture_t, 
						avectexture_b, fichiertexture_b,
						avecbumpmap_s, fichierbumpmap_s, 
						avecbumpmap_t, fichierbumpmap_t, 
						avecbumpmap_b, fichierbumpmap_b,
						factorbump);

	fich >> mater.couleur.R >> mater.couleur.G >> mater.couleur.B;  // coefficients RGB de la couleur (entre 0 et 1)
	fich >> mater.coef_rd;       // coefficients de reflexion difuse
	fich >> mater.coef_ambiant;  // coefficient de reflexion de la lumiere ambiante
	fich >> mater.coef_rs;       // coefficients de reflexion speculaire
	if (noversion < 1)
		mater.exp_rs = 10;
	else
		fich >> mater.exp_rs;
	fich >> mater.coef_td;
	fich >> mater.coef_ts;
	fich >> mater.coef_ri;
	fich >> mater.coef_ti;
	fich >> mater.indice_refr;
	fich >> mater.emitance;


}




void Scene3D::ecrit_polytext(char *nomfichier){

	ofstream fich(nomfichier);
	Celluleobj *p;

	
	MettreTousObjetsDansRepereScene();


	fich << NO_CURRENT_VERSION << "\n";
	int count = 0;
	for (p = objets.L ; p != NULL ; p = p->suiv)
		count++;
	fich << count-3 << "\n";
	int count1;
	for (p = objets.L, count1 = 0 ; p != NULL && count1 < count - 3; p = p->suiv, count1++){

		p->pobjet->ecritdonneesobjet3D(fich);
		fich << p->pobjet->nbsomm << "\n" << p->pobjet->nbfaces << "\n";
		for (int i = 0 ; i < p->pobjet->nbsomm ; i++){
			Sommet som = p->pobjet->tabsomm[i];
			fich << som.pos.x << " ";
			fich << som.pos.y << " ";
			fich << som.pos.z << "\n";
			fich << som.normale.x << " ";
			fich << som.normale.y << " ";
			fich << som.normale.z << "\n";
			fich << som.dpsds.x << " ";
			fich << som.dpsds.y << " ";
			fich << som.dpsds.z << "\n";
			fich << som.dpsdt.x << " ";
			fich << som.dpsdt.y << " ";
			fich << som.dpsdt.z << "\n";
			fich << som.coordtextureX << " " << som.coordtextureY << "\n";
		}
		for (int i = 0 ; i < p->pobjet->nbfaces ; i++){
			fich << p->pobjet->faces[i].nbsomm << " ";
			for (int j = 0 ; j < p->pobjet->faces[i].nbsomm ; j++)
				fich << p->pobjet->faces[i].tabnosomm[j] << " ";
			fich << "\n";
		}

	}
	MettreTousObjetsDansRepereCamera();

}

void Scene3D::charge_polytext(ifstream* fich){

	int noversion;
	(*fich) >> noversion;

	int nbobj;

	(*fich) >> nbobj;

	for (int i = 0 ; i < nbobj ; i++){

		Point3D origine; 
		double scalex, scaley, scalez, rotx, roty, rotz;
		
		CString fichiertexture, fichierbumpmap;
		imcouleur textu;
		MaterialData mater;
		TextureData text;

		litdefautobjet3D(*fich,
						origine,
						scalex, scaley, scalez, rotx, roty, rotz,
						mater, text, noversion);

		Polyedre nouveau(fich,
						origine,
						scalex, scaley, scalez, rotx, roty, rotz,
						mater, text);
		inseretete(&nouveau);
	}

}






void Scene3D::ecrit_scene(ofstream &fich, int nbmaxsp2d, int nbsp2d, Spline2D **ppSpline2D){

	Celluleobj *p;

	MettreTousObjetsDansRepereScene();


	fich << NO_CURRENT_VERSION << "\n";  // format version number

	fich << minix << " " << maxix << " " << miniy << " " << maxiy;
	fich << " " << miniz << " " << maxiz  << "\n";
	fich << nbcam << "\n";
	fich << nblummax << '\n';
	fich << lumambiantR << " " << lumambiantG << " " << lumambiantB << "\n";
	fich << fondR << " " << fondG << " " << fondB << "\n";

	fich << nocamselect << " ";
	for (int i = 0 ; i < nbcam ; i++){
		fich << tabcam[i]->accesanglex() << "\n";
		fich << tabcam[i]->pos.x << " " << tabcam[i]->pos.y << " " << tabcam[i]->pos.z << '\n';
		fich << tabcam[i]->centre.x << " " << tabcam[i]->centre.y << " " << tabcam[i]->centre.z << '\n';
		for (int j = 0 ; j < 3 ; j++){
			for(int k = 0 ; k < 3 ; k++)
				fich << tabcam[i]->M[j][k] << " ";
				fich << '\n';
		}
	}

	fich << nblum << '\n';
	for (int i = 0 ; i < nblum ; i++){
		fich << tablum[i].pos.x << " " << tablum[i].pos.y << " " << tablum[i].pos.z << '\n';
		fich << tablum[i].intensiteR << " " << tablum[i].intensiteG << " " << tablum[i].intensiteB << '\n';
		fich << (tablum[i].directionnel ? 1 : 0) << "\n";
		fich << tablum[i].direction.x << " ";
		fich << tablum[i].direction.y << " ";
		fich << tablum[i].direction.z << " ";
		fich << tablum[i].exponentdirect << '\n';
		fich << (tablum[i].attenuationdist?1:0) << " ";
		fich << tablum[i].c1 << " ";
		fich << tablum[i].c2 << " ";
		fich << tablum[i].c3 << "\n";

	}


	fich << (int)etatzbuffer << " ";
	fich << voiraxes << " ";
	fich << enableambiante << " ";
	fich << enablephong << " ";
	fich << enabledifuse << " ";
	fich << enablespecular << " ";
	fich << enabletexture << "\n";
	fich << enablebumpmap << "\n";

	fich << nbmaxsp2d << " " << nbsp2d << '\n';
	for (int i = 0 ; i < nbsp2d ; i++){
		fich << ppSpline2D[i]->gettype()  << '\n';
		fich << ppSpline2D[i]->getnom()  << '\n';
		fich << ppSpline2D[i]->nbctrlpoints  << '\n';
		for (int j = 0 ; j < ppSpline2D[i]->nbctrlpoints ; j++)
			fich << ppSpline2D[i]->ctrlpoints[j].x << " " << ppSpline2D[i]->ctrlpoints[j].y << " ";

		fich << '\n';
	}
	

	int count = 0;
	for (p = objets.L ; p != NULL ; p = p->suiv)
		count++;
	fich << count - 3 << "\n";

	for (int i = 0 ; i < count-3 ; i++){
		fich << nogroupe[i+4] << " ";
	}
	fich << "\n";

	int count1;
	for (p = objets.L, count1 = 0 ; p != NULL && count1 < count - 3; p = p->suiv, count1++){
		p->pobjet->ecritfich(fich);
	}

	MettreTousObjetsDansRepereCamera();
}







void Scene3D::charge_scene(ifstream& fich, Spline2D**& ppSpline2D, int& nbmaxsp2d, int& nbsp2d, int dimx, int dimy){

	int noversion;
	fich >> noversion;

	fich >> minix >> maxix >> miniy >> maxiy;
	fich >> miniz >> maxiz;
	fich >> nbcam;
	fich >> nblummax;
	fich >> lumambiantR >> lumambiantG >> lumambiantB;
	fich >> fondR >> fondG >> fondB;


	Construction(dimx, dimy, 
			minix, maxix, miniy, maxiy, miniz, maxiz,
			nbcam, 0, nblummax,
			lumambiantR, lumambiantG, lumambiantB,
			fondR, fondG, fondB);

	MettreTousObjetsDansRepereScene();


	fich >> nocamselect;
	tabcam = new Camera*[nbcam];
	for (int i = 0 ; i < nbcam ; i++){
		double anglex;
		fich >> anglex;
		tabcam[i] = new Cameraperspect(anglex);
		fich >> tabcam[i]->pos.x >> tabcam[i]->pos.y >> tabcam[i]->pos.z;
		fich >> tabcam[i]->centre.x >> tabcam[i]->centre.y >> tabcam[i]->centre.z;
		tabcam[i]->M = Matrice(3,3);
		for (int j = 0 ; j < 3 ; j++){
			for(int k = 0 ; k < 3 ; k++)
				fich >> tabcam[i]->M[j][k];
		}
		tabcam[i]->M.normaliserotation();
	}

	fich >> nblum;
	tablum = new Sourcelum[nblummax];
	for (int i = 0 ; i < nblum ; i++){
		fich >> tablum[i].pos.x >> tablum[i].pos.y >> tablum[i].pos.z;
		fich >> tablum[i].intensiteR >> tablum[i].intensiteG >> tablum[i].intensiteB;
		int dir;
		fich >> dir;
		tablum[i].directionnel = dir ? true:false;
		fich >> tablum[i].direction.x;
		fich >> tablum[i].direction.y;
		fich >> tablum[i].direction.z;
		fich >> tablum[i].exponentdirect;
		fich >> dir;
		tablum[i].attenuationdist = dir ? true:false;
		fich >> tablum[i].c1;
		fich >> tablum[i].c2;
		fich >> tablum[i].c3;
		tablum[i].allumee = true;
		
	}

	MettreTousObjetsDansRepereCamera();

	int tempint;
	fich >> tempint;
	setsamplebuffer((char)tempint);
	int temp;
	fich >> temp;
	voiraxes = temp ? true : false;
	fich >> temp;
	enableambiante = temp ? true : false;
	fich >> temp;
	enablephong = temp ? true : false;
	enablegouraud = false;
	fich >> temp;
	enabledifuse = temp ? true : false;
	fich >> temp;
	enablespecular = temp ? true : false;
	fich >> temp;
	enabletexture = temp ? true : false;
	if (noversion >= 7){
		fich >> temp;
		enablebumpmap = temp ? true : false;
	}else{
		enablebumpmap = false;
	}



	fich >> nbmaxsp2d >> nbsp2d;
	ppSpline2D = new Spline2D *[nbmaxsp2d];
	for (int i = 0 ; i < nbsp2d ; i++){
		int type;
		CString nom;
		int nbctrlpoints;
		Pixel tabctrlpoints[200];
		fich >> type;
		char nomsp[150];
		fich >> nomsp;
		nom = CString(nomsp);
		fich >>  nbctrlpoints;
		for (int j = 0 ; j < nbctrlpoints ; j++)
			fich >> tabctrlpoints[j].x >> tabctrlpoints[j].y;
		switch (type){
				case SPLINE2D_FERMEE : ppSpline2D[i] = new SplineCubiquefermee(tabctrlpoints, nbctrlpoints-3, nom, i);
									break;
				case SPLINE2D_OUVERTE : ppSpline2D[i] = new SplineCubiqueouverte(tabctrlpoints, nbctrlpoints, nom, i);
									break;
				default : Scene3D(); AfxMessageBox(CString("Erreur1 de chargement de fichier")); return;
		}
	}
	
	int nbobj;
	fich >> nbobj;

	if (noversion >= 5){
		for (int i = 0 ; i < nbobj ; i++){
			int group;
			fich >> group;
			nogroupe[nbobj-1-i+4] = nbobj-1-group+8;
		}
	}

	for (int i = 0 ; i < nbobj ; i++){
		litobj(fich, false, ppSpline2D, noversion, Point3D(0,0,0), Point3D(0,0,0), 1, Point3D(0,0,1), 0);
	}
}






void Scene3DRay::charge_scene(ifstream& fich, Spline2D**& ppSpline2D, int& nbmaxsp2d, int& nbsp2d, int dimx, int dimy){

	Scene3D::charge_scene(fich, ppSpline2D, nbmaxsp2d, nbsp2d, dimx, dimy);
	InitOptions();

}


/*
void Scene3DRadio::charge_scene(ifstream& fich, Spline2D**& ppSpline2D, int& nbmaxsp2d, int& nbsp2d, int dimx, int dimy){

	Scene3DRay::charge_scene(fich, ppSpline2D, nbmaxsp2d, nbsp2d, dimx, dimy);
	discretescene=NULL;
	enableradiosite=false;
}
*/


void Scene3D::litobj(ifstream &fich, bool translation, Spline2D** ppSpline2D, int noversion,
					 Point3D translat, Point3D orig, double sca, Point3D diraxe, double angle){

		Objet3D *nouveau;
		int typobj;
		fich >> typobj;

		Point3D origine; 
		double scalex, scaley, scalez, rotx, roty, rotz;
		MaterialData mater;
		TextureData text;

		Surface * surf;

		litdefautobjet3D(fich,
						origine,
						scalex, scaley, scalez, rotx, roty, rotz,
						mater, text, noversion);


		

		switch (typobj){
			case POLYEDRE :       nouveau = new Polyedre(&fich,
													origine,
													scalex, scaley, scalez, rotx, roty, rotz,
													mater, text);

								break;
			case BOITE :       		double xmax, ymax, zmax, xmin, ymin, zmin;
									int nbmerid;
									fich >> xmax >> ymax >> zmax >> xmin >> ymin >> zmin >> nbmerid;
									nouveau = new Cloche(origine.x, origine.y, origine.z, 
												xmax-xmin, ymax-ymin, zmax-zmin,
												nbmerid,
												rotx, roty, rotz,
   												scalex, scaley, scalez,
												mater, text);
								break;

			case SPHERE :      	double rayon; int nbmeridien, nbparallele;
								fich >> rayon >> nbmeridien >> nbparallele;


								nouveau = new Sphere(origine.x, origine.y, origine.z, 
												rotx, roty, rotz,
   												scalex, scaley, scalez,
												rayon,
												nbparallele, nbmeridien,
												mater, text);
								break;
			case CYLINREVOL :
								double hauteur;
								fich >> rayon >> hauteur >> nbmeridien;


								nouveau = new Cylinrevol(origine.x, origine.y, origine.z, 
												rotx, roty, rotz,
   												scalex, scaley, scalez,
												rayon, hauteur,
												nbmeridien,
												mater, text);
								break;
			case CONEREVOLTRONQ : 
								double raytronq;
								fich >> rayon >> hauteur >> raytronq >> nbmeridien;

								if (noversion <= 3){
											double sauve = raytronq;
											raytronq = rayon*raytronq/hauteur;
											hauteur = sauve;
											nbparallele = (int)(nbmeridien*hauteur/rayon+1);
											if (nbparallele <= 0) nbparallele=1;
								}else{
									fich >> nbparallele;
								}


								nouveau = new Conerevoltronq(origine.x, origine.y, origine.z, 
												rotx, roty, rotz,
   												scalex, scaley, scalez,
												rayon, hauteur, raytronq,
												nbmeridien, nbparallele,
												mater, text);
								break;
			case CYLINSPLINE :    
								int echantillonage, nosp1;
								double topreduction;
								int nbparal;
								fich >> hauteur; 
								if (noversion >= 3)
									fich >> topreduction;
								else
									topreduction = 1;
								fich >> echantillonage;
								if (noversion >= 3)
									fich >> nbparal;
								else
									nbparal = 1;
								fich >> nosp1;

								nouveau = new Cylinspline(origine.x, origine.y, origine.z, 
												rotx, roty, rotz,
   												scalex, scaley, scalez,
												ppSpline2D[nosp1], hauteur, 
												topreduction,
												echantillonage,
												nbparal,
												mater, text);
								break;
			case SPLINE3DREVOL :  
								fich >> echantillonage >> nbmeridien >> nosp1;

								nouveau = new Spline3Drevol(origine.x, origine.y, origine.z, 
												rotx, roty, rotz,
   												scalex, scaley, scalez,
												ppSpline2D[nosp1], nbmeridien, echantillonage,
												mater, text);
								break;
			case  SPLINE3DEXTRU : 
								int echa, echf, nospa, nospf;
								fich >> echf >> echa >> nospf >> nospa;
								double scalea;
								if (noversion >= 2)
									fich >> scalea;
								else
									scalea=1;
								int chanf;
								double pc_ba, pc_bf, pc_ea, pc_ef;
								fich >> chanf >> pc_ba >> pc_bf >> pc_ea >> pc_ef; // apres chanfrein
								//chanf=0; pc_ba = pc_bf = pc_ea = pc_ef=0.0; // a virer

								if (noversion <= 3 && !ppSpline2D[nospf]->flipped){
									ppSpline2D[nospf]->flip();
								}
								nouveau = new Spline3Dextru(origine.x, origine.y, origine.z, 
												rotx, roty, rotz,
   												scalex, scaley, scalez,
												ppSpline2D[nospf], ppSpline2D[nospa], scalea,
												echf, echa,
												chanf?true:false, pc_ba, pc_bf, pc_ea, pc_ef,
												mater, text);
								break;

			case SPLINE3DEDITABLE :
								int nbm, nbp;
								typesurface typ;
								fich >> nbm >> nbp;
								int typi;
								fich >> typi;
								typ = (typesurface) typi;
								switch (typ) {
								case BSPLINECUBIQUESPHERE :
									 surf =  new SurfaceBSplineCubiqueSphere(fich);
									break;
								case BSPLINECUBIQUECYLINDRE :
									 surf =  new SurfaceBSplineCubiqueCylindre(fich);
									 break;
								case BSPLINECUBIQUETORUS :
									 surf =  new SurfaceBSplineCubiqueTore(fich);
									break;
								default : 
									surf = NULL;
									AfxMessageBox(CString("Type de surface imprevu"));
								}

								nouveau = new Spline3DEditable(origine.x, origine.y, origine.z, 
													rotx, roty, rotz,
   													scalex, scaley, scalez,
													nbm, nbp, surf,
													mater, text);
								delete surf;
									
								break;
			default : Scene3D(); AfxMessageBox(CString("Erreur2 de chargement de fichier")); return;
		}
		inseretete(nouveau);  
		MettreDansRepereScene(objets.L->pobjet);
		objets.L->pobjet->transform(translat, orig, sca, diraxe, angle);
		MettreDansRepereCamera(objets.L->pobjet);

		delete nouveau;
}


void Scene3D::ecritobjetselect(ofstream &fich, unsigned short *numobjetselect, int nbobjetselect){
		fich << NO_CURRENT_VERSION << "\n";
		fich << nbobjetselect << "\n";


		Celluleobj *p;
		for (int i = 0 ; i < nbobjetselect ; i++){
			for (p = objets.L ; p != NULL ; p = p->suiv){
				if (p->pobjet->numero == numobjetselect[i]){
					MettreDansRepereScene(p->pobjet);
					p->pobjet->ecritfich(fich);
					MettreDansRepereCamera(p->pobjet);
				}
			}
		}
}

