// MaterialPropPage.cpp : implementation file
//

#include "stdafx.h"
#include "Synth.h"
#include "MaterialPropPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMaterialRenderPropPage property page

IMPLEMENT_DYNCREATE(CMaterialRenderPropPage, CPropertyPage)

CMaterialRenderPropPage::CMaterialRenderPropPage() : CPropertyPage(CMaterialRenderPropPage::IDD)
{
	//{{AFX_DATA_INIT(CMaterialRenderPropPage)
	m_emitance = 0.0;
	m_coeftd = 0.0;
	m_coefts = 0.0;
	m_coefri = 0.0;
	m_coefti = 0.0;
	m_indrefr = 0.0;
	//}}AFX_DATA_INIT

	m_coeftd=0;
	m_coefts=0;
	m_coefri=0;
	m_coefti=0;
	m_indrefr=1.3;
	m_emitance = 0;
}

CMaterialRenderPropPage::~CMaterialRenderPropPage()
{
}

void CMaterialRenderPropPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMaterialRenderPropPage)
	DDX_Text(pDX, IDC_EMITANCE, m_emitance);
	DDV_MinMaxDouble(pDX, m_emitance, 0., 500.);
	DDX_Text(pDX, IDC_NEWSPHE_COEF_TD, m_coeftd);
	DDV_MinMaxDouble(pDX, m_coeftd, 0., 1.);
	DDX_Text(pDX, IDC_NEWSPHE_COEF_TS, m_coefts);
	DDV_MinMaxDouble(pDX, m_coefts, 0., 1.);
	DDX_Text(pDX, IDC_REF_IDEALE, m_coefri);
	DDV_MinMaxDouble(pDX, m_coefri, 0., 1.);
	DDX_Text(pDX, IDC_TRANS_IDEALE, m_coefti);
	DDV_MinMaxDouble(pDX, m_coefti, 0., 1.);
	DDX_Text(pDX, IDC_INDICE_REFRACT, m_indrefr);
	DDV_MinMaxDouble(pDX, m_indrefr, 0., 100.);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMaterialRenderPropPage, CPropertyPage)
	//{{AFX_MSG_MAP(CMaterialRenderPropPage)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMaterialRenderPropPage message handlers
/////////////////////////////////////////////////////////////////////////////
// CMaterialBasicPropPage property page

IMPLEMENT_DYNCREATE(CMaterialBasicPropPage, CPropertyPage)

CMaterialBasicPropPage::CMaterialBasicPropPage() : CPropertyPage(CMaterialBasicPropPage::IDD)
{
	//{{AFX_DATA_INIT(CMaterialBasicPropPage)
	m_coefamb = 0.0;
	m_coefrd = 0.0;
	m_coefrs = 0.0;
	m_coulB = 0.0;
	m_coulG = 0.0;
	m_coulR = 0.0;
	m_exprs = 0.0;
	m_phongenable = FALSE;
	//}}AFX_DATA_INIT


	m_coulR = (float)0.7;
	m_coulG = (float)0.7;
	m_coulB = (float)0.7;
	m_coefrd = (float)0.9;
	m_coefrs = (float)0.2;
	m_exprs = 10;
	m_coefamb = (float)0.5;
	m_phongenable = TRUE;

}

CMaterialBasicPropPage::~CMaterialBasicPropPage()
{
}

void CMaterialBasicPropPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMaterialBasicPropPage)
	DDX_Text(pDX, IDC_NEWSPHE_COEF_AMB, m_coefamb);
	DDV_MinMaxDouble(pDX, m_coefamb, 0., 1.);
	DDX_Text(pDX, IDC_NEWSPHE_COEF_RD, m_coefrd);
	DDV_MinMaxDouble(pDX, m_coefrd, 0., 1.);
	DDX_Text(pDX, IDC_NEWSPHE_COEF_RS, m_coefrs);
	DDV_MinMaxDouble(pDX, m_coefrs, 0., 1.);
	DDX_Text(pDX, IDC_NEWSPHE_COUL_B, m_coulB);
	DDV_MinMaxDouble(pDX, m_coulB, 0., 1.);
	DDX_Text(pDX, IDC_NEWSPHE_COUL_G, m_coulG);
	DDV_MinMaxDouble(pDX, m_coulG, 0., 1.);
	DDX_Text(pDX, IDC_NEWSPHE_COUL_R, m_coulR);
	DDV_MinMaxDouble(pDX, m_coulR, 0., 1.);
	DDX_Text(pDX, IDC_NEWSPHE_EXP_RS, m_exprs);
	DDV_MinMaxDouble(pDX, m_exprs, 1., 500.);
	DDX_Check(pDX, IDC_NEWSPHE_PHONG, m_phongenable);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMaterialBasicPropPage, CPropertyPage)
	//{{AFX_MSG_MAP(CMaterialBasicPropPage)
	ON_BN_CLICKED(IDC_CHOSE_COLOR, OnChoseColor)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMaterialBasicPropPage message handlers
/////////////////////////////////////////////////////////////////////////////



void CMaterialBasicPropPage::OnChoseColor() 
{
	// TODO: Add your control notification handler code here
	CColorDialog dlg(RGB((unsigned char)(m_coulR*255), (unsigned char)(m_coulG*255), (unsigned char)(m_coulB*255)),CC_FULLOPEN);
	dlg.DoModal();

	COLORREF col = dlg.GetColor();
	m_coulR = (col & 255)/255.0;
	m_coulG = ((col & (255 << 8))>>8)/255.0;
	m_coulB = ((col & (255 << 16))>>16)/255.0;

	UpdateData(false);
}

/////////////////////////////////////////////////////////////////////////////
// CTexturePropPage property page

IMPLEMENT_DYNCREATE(CTexturePropPage, CPropertyPage)

CTexturePropPage::CTexturePropPage() : CPropertyPage(CTexturePropPage::IDD)
{
	//{{AFX_DATA_INIT(CTexturePropPage)
	m_texturename = _T("");
	m_withtexture = FALSE;
	m_bumpmapname = _T("");
	m_withbumpmap = FALSE;
	m_factorbump = 0.0;
	//}}AFX_DATA_INIT
}

CTexturePropPage::~CTexturePropPage()
{
}

void CTexturePropPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTexturePropPage)
	DDX_Text(pDX, IDC_NOMTEXTURE, m_texturename);
	DDX_Check(pDX, IDC_BOOL_TEXTURE, m_withtexture);
	DDX_Text(pDX, IDC_NOMBUMPMAP, m_bumpmapname);
	DDX_Check(pDX, IDC_BOOL_BUMPMAP, m_withbumpmap);
	DDX_Text(pDX, IDC_FACTORBUMP, m_factorbump);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTexturePropPage, CPropertyPage)
	//{{AFX_MSG_MAP(CTexturePropPage)
	ON_BN_CLICKED(IDC_BOUTONBROWSE, OnBoutonbrowse)
	ON_BN_CLICKED(IDC_BOUTONBROWSE2, OnBoutonbrowse2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTexturePropPage message handlers

void CTexturePropPage::OnBoutonbrowse() 
{
	// TODO: Add your control notification handler code here
		CFileDialog dlg(TRUE, CString("bmp"), CString("*.bmp"));

	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
			m_texturename = dlg.GetPathName();
		}
	SetDlgItemText(IDC_NOMTEXTURE, m_texturename);

}

void CTexturePropPage::OnBoutonbrowse2() 
{
	// TODO: Add your control notification handler code here
	
	CFileDialog dlg(TRUE, CString("bmp"), CString("*.bmp"));

	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
			m_bumpmapname = dlg.GetPathName();
		}
	SetDlgItemText(IDC_NOMBUMPMAP, m_bumpmapname);
}
/////////////////////////////////////////////////////////////////////////////
// CMultiTextureDialog property page

IMPLEMENT_DYNCREATE(CMultiTextureDialog, CPropertyPage)

CMultiTextureDialog::CMultiTextureDialog() : CPropertyPage(CMultiTextureDialog::IDD)
{
	//{{AFX_DATA_INIT(CMultiTextureDialog)
	m_withbump_b = FALSE;
	m_withbump_s = FALSE;
	m_withbump_t = FALSE;
	m_withtexture_b = FALSE;
	m_withtexture_s = FALSE;
	m_withtexture_t = FALSE;
	m_factorbump = 0.0;
	m_bumpname_b = _T("");
	m_bumpname_s = _T("");
	m_bumpname_t = _T("");
	m_textname_b = _T("");
	m_textname_s = _T("");
	m_textname_t = _T("");
	//}}AFX_DATA_INIT
}

CMultiTextureDialog::~CMultiTextureDialog()
{
}

void CMultiTextureDialog::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMultiTextureDialog)
	DDX_Check(pDX, IDC_BOOL_BUMPMAP_B, m_withbump_b);
	DDX_Check(pDX, IDC_BOOL_BUMPMAP_S, m_withbump_s);
	DDX_Check(pDX, IDC_BOOL_BUMPMAP_T, m_withbump_t);
	DDX_Check(pDX, IDC_BOOL_TEXTURE_B, m_withtexture_b);
	DDX_Check(pDX, IDC_BOOL_TEXTURE_S, m_withtexture_s);
	DDX_Check(pDX, IDC_BOOL_TEXTURE_T, m_withtexture_t);
	DDX_Text(pDX, IDC_FACTORBUMP, m_factorbump);
	DDX_Text(pDX, IDC_NOMBUMPMAP_B, m_bumpname_b);
	DDX_Text(pDX, IDC_NOMBUMPMAP_S, m_bumpname_s);
	DDX_Text(pDX, IDC_NOMBUMPMAP_T, m_bumpname_t);
	DDX_Text(pDX, IDC_NOMTEXTURE_B, m_textname_b);
	DDX_Text(pDX, IDC_NOMTEXTURE_S, m_textname_s);
	DDX_Text(pDX, IDC_NOMTEXTURE_T, m_textname_t);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMultiTextureDialog, CPropertyPage)
	//{{AFX_MSG_MAP(CMultiTextureDialog)
	ON_BN_CLICKED(IDC_BOUTONBROWSE_BB, OnBoutonbrowseBb)
	ON_BN_CLICKED(IDC_BOUTONBROWSE_BS, OnBoutonbrowseBs)
	ON_BN_CLICKED(IDC_BOUTONBROWSE_BT, OnBoutonbrowseBt)
	ON_BN_CLICKED(IDC_BOUTONBROWSE_TB, OnBoutonbrowseTb)
	ON_BN_CLICKED(IDC_BOUTONBROWSE_TS, OnBoutonbrowseTs)
	ON_BN_CLICKED(IDC_BOUTONBROWSE_TT, OnBoutonbrowseTt)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMultiTextureDialog message handlers

void CMultiTextureDialog::OnBoutonbrowseBb() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(TRUE, CString("bmp"), CString("*.bmp"));

	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
			m_bumpname_b = dlg.GetPathName();
		}
	SetDlgItemText(IDC_NOMBUMPMAP_B, m_bumpname_b);

}

void CMultiTextureDialog::OnBoutonbrowseBs() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(TRUE, CString("bmp"), CString("*.bmp"));

	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
			m_bumpname_s = dlg.GetPathName();
		}
	SetDlgItemText(IDC_NOMBUMPMAP_S, m_bumpname_s);

}

void CMultiTextureDialog::OnBoutonbrowseBt() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(TRUE, CString("bmp"), CString("*.bmp"));

	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
			m_bumpname_t = dlg.GetPathName();
		}
	SetDlgItemText(IDC_NOMBUMPMAP_T, m_bumpname_t);

}

void CMultiTextureDialog::OnBoutonbrowseTb() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(TRUE, CString("bmp"), CString("*.bmp"));

	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
			m_textname_b = dlg.GetPathName();
		}
	SetDlgItemText(IDC_NOMTEXTURE_B, m_textname_b);

}

void CMultiTextureDialog::OnBoutonbrowseTs() 
{
	// TODO: Add your control notification handler code here
	
	CFileDialog dlg(TRUE, CString("bmp"), CString("*.bmp"));

	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
			m_textname_s = dlg.GetPathName();
		}
	SetDlgItemText(IDC_NOMTEXTURE_S, m_textname_s);

}

void CMultiTextureDialog::OnBoutonbrowseTt() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(TRUE, CString("bmp"), CString("*.bmp"));

	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
			m_textname_t = dlg.GetPathName();
		}
	SetDlgItemText(IDC_NOMTEXTURE_T, m_textname_t);

	
}
