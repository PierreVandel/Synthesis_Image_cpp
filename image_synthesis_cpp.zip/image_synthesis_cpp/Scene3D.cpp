

#include "stdafx.h"
#include "Synth.h"
#include "Scene3D.h"
#include "Objetderiv.h"
#include "Polygone2d.h"

#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif




//////////////////////////////////////////////////////////////////////
// Fonctions des classes Celluleobj et Listeobj
//////////////////////////////////////////////////////////////////////


Celluleobj::Celluleobj(Objet3D *pobj)
{
	pobjet = pobj->copie();  // recopie de l'objet
	suiv = NULL;
}


// Destructeur


Listeobj::~Listeobj()
{
	destruction();
}

// fonction de destruction

void Listeobj::destruction()
{
	Celluleobj *p, *preced;
	p = L; 
	while (p!=NULL){
		delete p->pobjet;
		preced = p;
		p = p->suiv;
		delete preced;
	}

}

// Constructeur par copie

Listeobj::Listeobj(Listeobj& liste)
{
	Celluleobj *queue, *p;
	
	p = liste.L;

	if (p != NULL){
		L = new Celluleobj(p->pobjet);
		L->suiv = NULL;
		queue = L;
		p = p->suiv;
	}else
		L = NULL;
	while (p != NULL){
		queue->suiv = new Celluleobj(p->pobjet);
		queue = queue->suiv;
		queue->suiv = NULL;
		p = p->suiv;
	}

}


// operateur d'affectation

Listeobj& Listeobj::operator=(Listeobj& liste)
{
	Celluleobj *queue, *p;
	
	if (&liste == this)
		return (*this);

	if (L)
		destruction();

	p = liste.L;

	if (p != NULL){
		L = new Celluleobj(p->pobjet);
		L->suiv = NULL;
		queue = L;
		p = p->suiv;
	}else
		L = NULL;
	while (p != NULL){
		queue->suiv = new Celluleobj(p->pobjet);
		queue = queue->suiv;
		queue->suiv = NULL;
		p = p->suiv;
	}
	return (*this);
}


// insertion d'un objet3D en tete de liste

void Listeobj::inseretete(Objet3D * pobj)
{
	Celluleobj *p = new Celluleobj(pobj);

	p->suiv = L;
	L = p;
}


//////////////////////////////////////////////////////////////////////
// Fonctions de la classe Scene3D
//////////////////////////////////////////////////////////////////////


// allocation de matrice de float

float ** Scene3D::allouerfloats2D(int dimx, int dimy)
{
	float **t;
	if ((t = new float*[dimx]) == NULL){
		return NULL;
   }
	if (dimx)
		if ((t[0] = new float[dimx*dimy]) == NULL){
			delete [] t;
			return NULL;
		}

	for (int i = 1 ; i < dimx ; i++)
		t[i] = t[i-1] + dimy;
	return t;
}


// liberation de matrice de float

void Scene3D::liberer(float **t, int dimx)
{
	if (dimx && t != NULL){
		delete [] t[0];
		delete [] t;
	}
}


// allocation de matrice de unsigned char

unsigned char ** Scene3D::alloueruchar2D(int dimx, int dimy)
{
	unsigned char **t;
	if ((t = new unsigned char*[dimx]) == NULL){
		return NULL;
   }
	if (dimx)
		if ((t[0] = new unsigned char[dimx*dimy]) == NULL){
			delete [] t;
			return NULL;
		}


	for (int i = 1 ; i < dimx ; i++){
		t[i] = t[i-1] + dimy;
	}

	return t;
}




// liberation de matrice de unsigned char

void Scene3D::liberer(unsigned char **t, int dimx)
{
	if (dimx && t != NULL){
		delete [] t[0];
		delete [] t;
	}
}

// allocation de matrice de unsigned short

unsigned short ** Scene3D::allouerushort2D(int dimx, int dimy)
{
	unsigned short **t;
	if ((t = new unsigned short*[dimx]) == NULL){
		return NULL;
   }
	if (dimx)
		if ((t[0] = new unsigned short[dimx*dimy]) == NULL){
			delete [] t;
			return NULL;
	}

	for (int i = 1 ; i < dimx ; i++)
		t[i] = t[i-1] + dimy;

	for (int i = 0 ; i < dimx ; i++)
		for (int j = 0 ; j < dimy ; j++)
			t[i][j] = 0;

	return t;
}




// liberation de matrice de unsigned short

void Scene3D::liberer(unsigned short **t, int dimx)
{
	if (dimx && t != NULL){
		delete [] t[0];
		delete [] t;
	}
}



// Principal constructeur de Scene3D

void Scene3D::Construction(int dimx, int dimy, 
			double xmin, double xmax, double ymin, double ymax, double zmin, double zmax,
			int nbcamera, double hautcam, int nblumiere,
			double lumambR, double lumambG, double lumambB,
			double fR, double fG, double fB)
//			int nbmaxsp2D, int nbsp2D, Spline2D **psp2D)
{
	int i;

	etatzbuffer = 1;   // par defaut, affichage rapide sans antialiassage
	enableambiante=true;
	enabledifuse=true;
	enablespecular=true;
	enabletexture=true;
	enablephong=true;
	enablegouraud=false;


	objetselect = NULL;

//	pSpline2D=psp2D;

	dimfenetrex = dimx; // initialisation des dimensions de la fenetre graphique
	dimfenetrey = dimy;

	dim2Dx = etatzbuffer*dimfenetrex;  // dimensions de la matrice de l'image a calculer
	dim2Dy = etatzbuffer*dimfenetrey;  
	tabcam = new Camera*[nbcamera];  // allocation du tableau de pointeurs sur cameras
	nbcam = nbcamera;  // nombre de cameras

	objets = Listeobj(); // liste d'objets 3D vide


	minix = xmin;  // limites (approximatives) de la scene
	miniy = ymin;  // limites (approximatives) de la scene
	miniz = zmin;  // limites (approximatives) de la scene
	maxix = xmax;  // limites (approximatives) de la scene
	maxiy = ymax;  // limites (approximatives) de la scene
	maxiz = zmax;  // limites (approximatives) de la scene

	double centrex = (xmax+xmin)/(double)2;  // coordonnees du centre de la scene
	double centrey = (ymax+ymin)/(double)2;  // coordonnees du centre de la scene
	double centrez = (zmax+zmin)/(double)2;  // coordonnees du centre de la scene
	

	// initialisation des cameras autour de la scene :
	for (i = 0 ; i < nbcam ; i++){
		double px, py, pz;  // position de la camera numero i
		px = centrex + (xmax - centrex)*(double)cos(2*pi * ((double)i/(double)nbcam))*4;
		py = centrey + (ymax - centrey)*(double)sin(2*pi * ((double)i/(double)nbcam))*4;
		pz = hautcam;
		
		// construction de la camera focalisee vers le centre de la scene
		tabcam[i] = new Cameraperspect(px, py, pz, centrex, centrey, centrez, 50);
	}

	nocamselect = 0;  // camera numero zero selectionnee



	nblum = 0;  // initialement, aucune source lumineuse
	nblummax = nblumiere;  // nombre de source lumineuses allouees initialement
	tablum = new Sourcelum[nblummax];  // allocation du tableau de sources lumineuses


	lumambiantR = lumambR;  // initialisation de l'intensite de la lumiere ambiante
	lumambiantG = lumambG;  // suivant les trois composantes R, G, B
	lumambiantB = lumambB;

	fondR = fR;
	fondG = fG;
	fondB = fB;


	// allocation d'un tableau d'aretes pour remplissage de polygone utilise par le z-buffer
	nbmaxaretes = NBMAXARETES;
	tabaretes = new Arete[nbmaxaretes];


	inclipx = new double[nbmaxaretes];  // allocation de tableaux
	inclipy = new double[nbmaxaretes];  // pour utilisation de
	outclipx = new double[nbmaxaretes]; // l'algorithme de fenetrage (clipping)
	outclipy = new double[nbmaxaretes]; // (voir fonction Scene3D::clip)

	minz = allouerfloats2D(dim2Dx, dim2Dy);  // allocation du z-buffer (matrice de floats)
	bufferR = alloueruchar2D(3*dimfenetrex, 3*dimfenetrey); // allocation de matrices d'"unsigned char"
	bufferG = alloueruchar2D(3*dimfenetrex, 3*dimfenetrey); // pour stockage des couleurs des pixels
	bufferB = alloueruchar2D(3*dimfenetrex, 3*dimfenetrey); // calcules par l'algorithme du z-buffer
	numobjets=allouerushort2D(dimfenetrex, dimfenetrey);
	
	// Insertion de trois cylindres representant les axes dans la scene :

	voiraxes=true;

	imcouleur texturevide;
	// Axe des x :
	Objet3D *pobjet = new Cylinrevol(centrex, ymin, zmin, 
						0, 90, 0,
						1, 1, 1,
						(zmax - zmin)*0.005, xmax - xmin, 
		                 4, 
						 MaterialData(Couleur(1,0,0), 0.9, 0.5, 0, 2, 0, 0, 0, 0, 1, 0,true), 
						 TextureData(false, CString(""),false, CString(""),false, CString(""), 
						 false, CString(""),false, CString(""),false, CString(""),1));
	inseretete(pobjet);
	delete pobjet;

	// Axe des y :
	pobjet = new Cylinrevol(xmin, centrey, zmin, 
						-90, 0, 0,
						1, 1, 1,
						(zmax - zmin)*0.005, ymax - ymin, 
		                 4, 
						 MaterialData(Couleur(0,1,0), 0.9, 0.5, 0, 2, 0, 0, 0, 0, 1, 0,true), 
						 TextureData(false, CString(""),false, CString(""),false, CString(""),
						 false, CString(""),false, CString(""),false, CString(""), 1));
	inseretete(pobjet);
	delete pobjet;

	// Axe des z :
	pobjet = new Cylinrevol(xmin, ymin, centrez, 
						0, 0, 0,
						1, 1, 1,
						(zmax - zmin)*0.005, zmax - zmin, 
		                 4, 
						 MaterialData(Couleur(0,0,1), 0.9, 0.5, 0, 2, 0, 0, 0, 0, 1, 0,true), 
						 TextureData(false, CString(""),false, CString(""),false, CString(""),
						 false, CString(""),false, CString(""),false, CString(""), 1));
	inseretete(pobjet);
	delete pobjet;

	for (i = 0; i < 10000 ; i++){
		nogroupe[i] = i;
	}

}



// destruction de Scene3D
 
void Scene3D::destruction(void){



	liberer(numobjets, dimfenetrex);
	liberer(bufferB, 3*dimfenetrex);
	liberer(bufferG, 3*dimfenetrex);
	liberer(bufferR, 3*dimfenetrex);
	liberer(minz, dim2Dx);

	if (outclipy)
		delete [] outclipy;
	if (outclipx)
		delete [] outclipx;
	if (inclipy)
		delete [] inclipy;
	if (inclipx)
		delete [] inclipx;

	if (nbmaxaretes)
		delete [] tabaretes;

	if (nblum > 0)
		delete [] tablum;

	for (int i = 0 ; i < nbcam ; i++)
		delete tabcam[i];
	if (nbcam > 0)
		delete [] tabcam;

	dimfenetrex = dimfenetrey = dim2Dx = dim2Dy = nbcam = nblum = nbmaxaretes = 0;


}

void Scene3D::detruitmatrices(void){

	liberer(numobjets, dimfenetrex);
	liberer(bufferB, 3*dimfenetrex);
	liberer(bufferG, 3*dimfenetrex);
	liberer(bufferR, 3*dimfenetrex);
	liberer(minz, dim2Dx);


}


bool Scene3D::restorematrices(void){

	bool probleme_memoire = false;

	minz = allouerfloats2D(dim2Dx, dim2Dy);
	if (minz == NULL)
		probleme_memoire = true;

	bufferR = alloueruchar2D(3*dimfenetrex, 3*dimfenetrey);
	if (bufferR == NULL)
		probleme_memoire = true;

	bufferG = alloueruchar2D(3*dimfenetrex, 3*dimfenetrey);
	if (bufferG == NULL)
		probleme_memoire = true;

	bufferB = alloueruchar2D(3*dimfenetrex, 3*dimfenetrey);
	if (bufferB == NULL)
		probleme_memoire = true;

	numobjets = allouerushort2D(dimfenetrex, dimfenetrey);
	if (numobjets == NULL)
		probleme_memoire = true;

	return probleme_memoire;
}

// insertion d'une souce lumineuse de position et d'intensites donnees dans les composantes RGB

void Scene3D::inserelum(double posx, double posy, double posz, 
					double coulR, double coulG, double coulB,
					bool direct, double dx, double dy, double dz, int expo,
					bool att, double coefc1, double coefc2, double coefc3)
{

	// si depacement du nombre maximal de sources lumineuses, 
	// rajout de 10 elements alloues
	if (nblum >= nblummax){
		Sourcelum *p = new Sourcelum[nblummax + 10];
		for (int i = 0 ; i < nblum ; i++)
			p[i] = tablum[i];
		if (nblummax)
			delete [] tablum;
		tablum = p;
		nblummax += 10;
	}

	// creation de la nouvelle source lumineuses
	tablum[nblum].intensiteR = coulR;
	tablum[nblum].intensiteG = coulG;
	tablum[nblum].intensiteB = coulB;
	tablum[nblum].pos.x = posx;
	tablum[nblum].pos.y = posy;
	tablum[nblum].pos.z = posz;
	tablum[nblum].allumee = true;
	tablum[nblum].directionnel = direct;
	tablum[nblum].direction = Point3D(dx,dy,dz);
	tablum[nblum].exponentdirect = expo;
	tablum[nblum].attenuationdist = att;
	tablum[nblum].c1 = coefc1;
	tablum[nblum].c2 = coefc2;
	tablum[nblum].c3 = coefc3;
	tablum[nblum].directionnorme = tablum[nblum].direction;
	tablum[nblum].directionnorme.normer();
	tablum[nblum].directionnorme = tabcam[nocamselect]->M.t()*tablum[nblum].directionnorme;

	// traduction des coordonnees de la source lumineuse dans le repere de la camera :
	Matrice Minv = (tabcam[nocamselect]->M.t());  // matrice de passage
	Point3D O =  Minv * tabcam[nocamselect]->pos;  
	tablum[nblum].pos = Minv * tablum[nblum].pos;
	tablum[nblum].pos = tablum[nblum].pos - O;

	nblum++;  // incrementation du nombre de sources lumineuses
}




void Scene3D::inseretete(Objet3D * pobj)
{

	if (objets.L == NULL)
		pobj->numero = 1;
	else
		pobj->numero = objets.L->pobjet->numero+1;

	objets.inseretete(pobj);


	MettreDansRepereCamera(objets.L->pobjet);

}


void Scene3D::MettreDansRepereCamera(Objet3D * pobj)
{

	Point3D O;


	Matrice Minv = tabcam[nocamselect]->M.t();

	O =  Minv * tabcam[nocamselect]->pos;



	int i;
	for (i = 0 ; i < pobj->nbsomm ; i++){

		pobj->tabsomm[i] = Minv * pobj->tabsomm[i];
		pobj->tabsomm[i].pos = pobj->tabsomm[i].pos - O;
	}

}


void Scene3D::MettreDansRepereScene(Objet3D * pobj)
{

	Point3D O;


	Matrice Minv = tabcam[nocamselect]->M;

	O =  tabcam[nocamselect]->M.t() * tabcam[nocamselect]->pos;



	int i;
	for (i = 0 ; i < pobj->nbsomm ; i++){

		pobj->tabsomm[i].pos = pobj->tabsomm[i].pos + O;
		pobj->tabsomm[i] = Minv * pobj->tabsomm[i];
	}

}


void Scene3D::MettreTousObjetsDansRepereScene(void){

	Celluleobj *p;
	for (p=objets.L ; p != NULL ; p=p->suiv){
		MettreDansRepereScene(p->pobjet);
	}

	Matrice Minv = tabcam[nocamselect]->M;

	Point3D O =  tabcam[nocamselect]->M.t() * tabcam[nocamselect]->pos;

	for (int i = 0 ; i < nblum ; i++){
		tablum[i].pos = tablum[i].pos + O;
		tablum[i].pos = Minv * tablum[i].pos;
		tablum[i].directionnorme = tablum[i].direction;
		tablum[i].directionnorme.normer();

	}



}


void Scene3D::MettreTousObjetsDansRepereCamera(void){


	
	Celluleobj *p;
	for (p=objets.L ; p != NULL ; p=p->suiv){
		MettreDansRepereCamera(p->pobjet);
	}

	
	Point3D O;


	Matrice Minv = tabcam[nocamselect]->M.t();

	O =  Minv * tabcam[nocamselect]->pos;



	int i;
	for (i = 0 ; i < nblum ; i++){

		tablum[i].pos = Minv * tablum[i].pos;
		tablum[i].pos = tablum[i].pos - O;
		tablum[i].directionnorme = tablum[i].direction;
		tablum[i].directionnorme.normer();
		tablum[i].directionnorme = tabcam[nocamselect]->M.t()*tablum[i].directionnorme;

	}

}



bool Scene3D::setdim2D(int dimx, int dimy)
{

	int ancdimx = dim2Dx;
	int ancdimy = dim2Dy;
	int ancdimfenx = dimfenetrex;
	int ancdimfeny = dimfenetrey;
	bool probleme_memoire = false;

	dimfenetrex = dimx;
	dimfenetrey = dimy;

	dim2Dx = etatzbuffer*dimfenetrex;
	dim2Dy = etatzbuffer*dimfenetrey;

	liberer(numobjets, ancdimfenx);
	liberer(bufferB, 3*ancdimfenx);
	liberer(bufferG, 3*ancdimfenx);
	liberer(bufferR, 3*ancdimfenx);
	liberer(minz, ancdimx);

	minz = allouerfloats2D(dim2Dx, dim2Dy);
	if (minz == NULL)
		probleme_memoire = true;

	bufferR = alloueruchar2D(3*dimfenetrex, 3*dimfenetrey);
	if (bufferR == NULL)
		probleme_memoire = true;

	bufferG = alloueruchar2D(3*dimfenetrex, 3*dimfenetrey);
	if (bufferG == NULL)
		probleme_memoire = true;

	bufferB = alloueruchar2D(3*dimfenetrex, 3*dimfenetrey);
	if (bufferB == NULL)
		probleme_memoire = true;

	numobjets = allouerushort2D(dimfenetrex, dimfenetrey);
	if (numobjets == NULL)
		probleme_memoire = true;

	if (probleme_memoire){
		liberer(numobjets, dimfenetrex);
		liberer(bufferB, 3*dimfenetrex);
		liberer(bufferG, 3*dimfenetrex);
		liberer(bufferR, 3*dimfenetrex);
		liberer(minz, dim2Dx);
		dim2Dx = 0;
		dim2Dy = 0;
		dimfenetrex = 0;
		dimfenetrey = 0;
	}

	return probleme_memoire;
}



void Scene3D::setsamplebuffer(char etat){

	if (etatzbuffer != etat){
		etatzbuffer = etat;

		int ancdimx = dim2Dx;

		dim2Dx = etatzbuffer*dimfenetrex;
		dim2Dy = etatzbuffer*dimfenetrey;

//		liberer(bufferB, ancdimx);
//		liberer(bufferG, ancdimx);
//		liberer(bufferR, ancdimx);
		liberer(minz, ancdimx);
		minz = allouerfloats2D(dim2Dx, dim2Dy);
//		bufferR = alloueruchar2D(dim2Dx, dim2Dy);
//		bufferG = alloueruchar2D(dim2Dx, dim2Dy);
//		bufferB = alloueruchar2D(dim2Dx, dim2Dy);
	}
}


int Scene3D::selectcam(int nocam)
{
	Point3D O;

	if (nocam < 0 || nocam >= nbcam)
		return -1;

	Matrice Manc = tabcam[nocamselect]->M;
	Matrice Minvanc = Manc.t();

	O =  Minvanc * tabcam[nocamselect]->pos;
	
	Celluleobj * p;
	int i;
	for (p = objets.L ; p != NULL ; p = p->suiv)
		for (i = 0 ; i < p->pobjet->nbsomm ; i++){

			p->pobjet->tabsomm[i].pos = p->pobjet->tabsomm[i].pos + O;
			p->pobjet->tabsomm[i] = Manc * p->pobjet->tabsomm[i];

		}

	for (i = 0 ; i < nblum ; i++){
		tablum[i].pos = tablum[i].pos + O;
		tablum[i].pos = Manc * tablum[i].pos;
	}

	
	nocamselect = nocam;

	Matrice Minv = tabcam[nocamselect]->M.t();
	O =  Minv * tabcam[nocamselect]->pos;


	for (p = objets.L ; p != NULL ; p = p->suiv)
		for (i = 0 ; i < p->pobjet->nbsomm ; i++){
			p->pobjet->tabsomm[i] = Minv * p->pobjet->tabsomm[i];
			p->pobjet->tabsomm[i].pos = p->pobjet->tabsomm[i].pos - O;
		}

	for (i = 0 ; i < nblum ; i++){
		tablum[i].pos = Minv * tablum[i].pos;
		tablum[i].pos = tablum[i].pos - O;
	}


	return nocam;
}



