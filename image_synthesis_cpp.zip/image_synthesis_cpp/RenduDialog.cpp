// RenduDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Synth.h"
#include "RenduDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRenduGlobalDialog dialog


CRenduGlobalDialog::CRenduGlobalDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CRenduGlobalDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRenduGlobalDialog)
	m_pourcentnegl = 0.0;
	m_procrecur = 0;
	m_nbfacesmax = 0;
	m_maxdepth = 0;
	m_minsizecell = 0.0;
	m_rapportthreshold = 0.0;
	m_seuiladapt = 0.0;
	m_enableextendedlight = FALSE;
	m_nbrayslights = 0;
	m_save_calcul = FALSE;
	m_winwidth = 0;
	m_winheight = 0;
	m_use_bsp = FALSE;
	//}}AFX_DATA_INIT

	m_use_bsp=TRUE;
}


void CRenduGlobalDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRenduGlobalDialog)
	DDX_Text(pDX, IDC_POURCENT_NEGLIGE, m_pourcentnegl);
	DDV_MinMaxDouble(pDX, m_pourcentnegl, 5.e-003, 100.);
	DDX_Text(pDX, IDC_PROF_RECURS, m_procrecur);
	DDV_MinMaxInt(pDX, m_procrecur, 0, 500);
	DDX_Text(pDX, IDC_NB_FACES_CELL, m_nbfacesmax);
	DDX_Text(pDX, IDC_PROFONDEUR_ARBRE, m_maxdepth);
	DDX_Text(pDX, IDC_TAILLE_CELL, m_minsizecell);
	DDX_Text(pDX, IDC_RAPPORT_THRESHOLD, m_rapportthreshold);
	DDX_Text(pDX, IDC_ANTIALIASING_THRESHOLD, m_seuiladapt);
	DDV_MinMaxDouble(pDX, m_seuiladapt, 0., 442.);
	DDX_Check(pDX, IDC_BOOL_EXTENDED_LIGHT, m_enableextendedlight);
	DDX_Text(pDX, IDC_NB_RAYS_LIGHT, m_nbrayslights);
	DDV_MinMaxInt(pDX, m_nbrayslights, 1, 500);
	DDX_Check(pDX, IDC_SAVE_CALCUL, m_save_calcul);
	DDX_Text(pDX, IDC_WINDOW_WIDTH, m_winwidth);
	DDV_MinMaxInt(pDX, m_winwidth, 0, 50000);
	DDX_Text(pDX, IDC_WINDOW_HEIGHT, m_winheight);
	DDV_MinMaxInt(pDX, m_winheight, 0, 50000);
	DDX_Check(pDX, IDC_USE_BSP, m_use_bsp);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRenduGlobalDialog, CDialog)
	//{{AFX_MSG_MAP(CRenduGlobalDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRenduGlobalDialog message handlers
/////////////////////////////////////////////////////////////////////////////
// CMyProgresDialog dialog


CMyProgresDialog::CMyProgresDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMyProgresDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyProgresDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMyProgresDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyProgresDialog)
	DDX_Control(pDX, IDC_PROGRESSCTRL, m_progctrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyProgresDialog, CDialog)
	//{{AFX_MSG_MAP(CMyProgresDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyProgresDialog message handlers
