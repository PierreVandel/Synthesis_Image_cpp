// Spline2D.cpp: implementation of the Spline2D class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Synth.h"
#include "Spline2D.h"
#include "matrice.h"


#include <math.h>


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


#define NB_POINTS_AFFICHAGE 150




void Courbe2D::affiche(CDC& cdc, Pixel centrevue, double facteur_echelle){
	double x, y;
	getpoint(0, x, y);
	x = x/facteur_echelle + centrevue.x;
	y = -y/facteur_echelle + centrevue.y;
	cdc.MoveTo((int)x, (int)y);
	for (int i = 1 ; i <= NB_POINTS_AFFICHAGE ; i++){
		getpoint(((double)i)/((double)NB_POINTS_AFFICHAGE), x, y);
		x = x/facteur_echelle + centrevue.x;
		y = -y/facteur_echelle + centrevue.y;
		cdc.LineTo((int)x, (int)y);
		cdc.MoveTo((int)x, (int)y);

	}
}


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
SplineCubique2D::SplineCubique2D()
{
	ctrlpoints = NULL;
	nbctrlpoints = 0;
	coefs_x = NULL;
	coefs_y = NULL;

	fermee = true;

	nom = "";

}

SplineCubique2D::~SplineCubique2D()
{
	if (nbctrlpoints != 0 && ctrlpoints != NULL){
		delete [] ctrlpoints;
		if (coefs_x)
			delete [] coefs_x;
		if (coefs_y)
			delete [] coefs_y;
	}
}

SplineCubique2D::SplineCubique2D(SplineCubique2D& s){

	nbctrlpoints = s.nbctrlpoints;
	ctrlpoints = new Pixel[nbctrlpoints];
	fermee = s.fermee;
	numero = s.numero;

	if (fermee){
		for (int i = 0 ; i < nbctrlpoints +3; i++)
			ctrlpoints[i] = s.ctrlpoints[i];
		coefs_x = new Vecteur4D[nbctrlpoints];
		for (int i = 0 ; i < nbctrlpoints ; i++)
			coefs_x[i] = s.coefs_x[i];
		coefs_y = new Vecteur4D[nbctrlpoints];
		for (int i = 0 ; i < nbctrlpoints ; i++)
			coefs_y[i] = s.coefs_y[i];
	}
	else{
		for (int i = 0 ; i < nbctrlpoints; i++)
			ctrlpoints[i] = s.ctrlpoints[i];
		coefs_x = new Vecteur4D[nbctrlpoints-3];
		for (int i = 0 ; i < nbctrlpoints-3 ; i++)
			coefs_x[i] = s.coefs_x[i];
		coefs_y = new Vecteur4D[nbctrlpoints-3];
		for (int i = 0 ; i < nbctrlpoints-3 ; i++)
			coefs_y[i] = s.coefs_y[i];
	}

	nom = s.nom;
}


SplineCubique2D& SplineCubique2D::operator=(SplineCubique2D& s){

	fermee = s.fermee;
	if (nbctrlpoints != 0 && ctrlpoints != NULL){
		delete [] ctrlpoints;
		if (coefs_x)
			delete [] coefs_x;
		if (coefs_y)
			delete [] coefs_y;
	}

	nbctrlpoints = s.nbctrlpoints;
	ctrlpoints = new Pixel[nbctrlpoints];

	if (fermee){
		for (int i = 0 ; i < nbctrlpoints +3; i++)
			ctrlpoints[i] = s.ctrlpoints[i];
		coefs_x = new Vecteur4D[nbctrlpoints];
		for (int i = 0 ; i < nbctrlpoints ; i++)
			coefs_x[i] = s.coefs_x[i];
		coefs_y = new Vecteur4D[nbctrlpoints];
		for (int i = 0 ; i < nbctrlpoints ; i++)
			coefs_y[i] = s.coefs_y[i];
	}
	else{
		for (int i = 0 ; i < nbctrlpoints; i++)
			ctrlpoints[i] = s.ctrlpoints[i];
		coefs_x = new Vecteur4D[nbctrlpoints-3];
		for (int i = 0 ; i < nbctrlpoints-3 ; i++)
			coefs_x[i] = s.coefs_x[i];
		coefs_y = new Vecteur4D[nbctrlpoints-3];
		for (int i = 0 ; i < nbctrlpoints-3 ; i++)
			coefs_y[i] = s.coefs_y[i];
	}

	nom = s.nom;
	numero=s.numero;

	return (*this);
}


SplineCubiquefermee::SplineCubiquefermee(Pixel *controlpoints, int nbcontrolpoints, CString paramnom, int no){

	nom = paramnom;
	numero=no;


	fermee = true;
	flipped = false;

	nbctrlpoints = nbcontrolpoints + 3;
	ctrlpoints = new Pixel[nbctrlpoints];
	for (int i = 0 ; i < nbctrlpoints-3 ; i++)
		ctrlpoints[i] = controlpoints[i];
	ctrlpoints[nbctrlpoints-3] = ctrlpoints[0];
	ctrlpoints[nbctrlpoints -2] = ctrlpoints[1];
	ctrlpoints[nbctrlpoints -1] = ctrlpoints[2];



	coefs_x = new Vecteur4D[nbctrlpoints-3];
	coefs_y = new Vecteur4D[nbctrlpoints-3];

	precalculmatrices();
}

/*
void SplineCubiquefermee::affiche(CDC& cdc, Pixel centrevue, double facteur_echelle){

	double xpos, ypos;

	getpoint(0,xpos,ypos);
	cdc.MoveTo((int)(xpos/facteur_echelle + centrevue.x), (int)(ypos/facteur_echelle + centrevue.x));
	for (int i = 1 ; i <= NB_POINTS_AFFICHAGE  ; i++){
		getpoint(((double)i)/((double)NB_POINTS_AFFICHAGE),xpos,ypos);
		if (i == NB_POINTS_AFFICHAGE - 1)
			i=i;
		cdc.LineTo((int)(xpos/facteur_echelle + centrevue.x), (int)(ypos/facteur_echelle + centrevue.x));
		cdc.MoveTo((int)(xpos/facteur_echelle + centrevue.x), (int)(ypos/facteur_echelle + centrevue.x));


	}
}
*/



/*void SplineCubiquefermee::getpoint(double t, double & xpos, double & ypos){

	int i = (int)(t*nbctrlpoints);  // numero de la courbe

	double tvrai = (t*nbctrlpoints)-i;
	
	if (i == (nbctrlpoints)){
		i = nbctrlpoints - 1;
		tvrai=1;
	}
			
	double t2 = tvrai*tvrai;
	double t3 = t2*tvrai;
	Quadruplet vecteur_t(t3, t2, tvrai, 1);

			xpos = (vecteur_t*coefs_x[i])/6.0;
			ypos = (vecteur_t*coefs_y[i])/6.0;
}



void SplineCubiquefermee::getnormale(double t, double & vx, double & vy){

	int i = (int)(t*nbctrlpoints);  // numero de la courbe

	double tvrai = (t*nbctrlpoints)-i;
	
	if (i == (nbctrlpoints)){
		i = nbctrlpoints - 1;
		tvrai=1;
	}
			
	double t2 = tvrai*tvrai;

	Quadruplet vecteur_tprime(3*t2, 2*tvrai, 1, 0);

			vx = (vecteur_tprime*coefs_y[i])/6.0;
			vy = -(vecteur_tprime*coefs_x[i])/6.0;
}



void SplineCubiquefermee::gettangente(double t, double & vx, double & vy){

	int i = (int)(t*nbctrlpoints);  // numero de la courbe

	double tvrai = (t*nbctrlpoints)-i;
	
	if (i == (nbctrlpoints)){
		i = nbctrlpoints - 1;
		tvrai=1;
	}
			
	double t2 = tvrai*tvrai;

	Quadruplet vecteur_tprime(3*t2, 2*tvrai, 1, 0);

			vx = (vecteur_tprime*coefs_x[i])/6.0;
			vy = (vecteur_tprime*coefs_y[i])/6.0;
}



void SplineCubiquefermee::getderseconde(double t, double & vx, double & vy){

	int i = (int)(t*nbctrlpoints);  // numero de la courbe

	double tvrai = (t*nbctrlpoints)-i;
	
	if (i == (nbctrlpoints)){
		i = nbctrlpoints - 1;
		tvrai=1;
	}
			
	Quadruplet vecteur_tseconde(6*tvrai, 2, 0, 0);

			vx = (vecteur_tseconde*coefs_x[i])/6.0;
			vy = (vecteur_tseconde*coefs_y[i])/6.0;
}



double SplineCubiquefermee::calcullongueur(int echantillonage)
{
	double x1, y1, x2, y2;
	double longueur = 0;
	for (int i = 0 ; i < nbctrlpoints ; i++){

		x1 = coefs_x[i][3]/6.0; 
		y1 = coefs_y[i][3]/6.0;  // origine de la courbe numero i
		for (int j = 1 ; j <= echantillonage ; j++){
			
			double t = ((double) j) / ((double) echantillonage);
			double t2 = t*t;
			double t3 = t2*t;
			Quadruplet vecteur_t(t3, t2, t, 1);

			x2 = (vecteur_t*coefs_x[i])/6.0; 
			y2 = (vecteur_t*coefs_y[i])/6.0;
			
			longueur += sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));

			x1 = x2;
			y1 = y2;
		}
	}

	return longueur;
}




*/



SplineCubiqueouverte::SplineCubiqueouverte(Pixel *controlpoints, int nbcontrolpoints, CString paramnom, int no){

	nom = paramnom;
	numero=no;


	fermee = false;
	flipped=false;



	nbctrlpoints = nbcontrolpoints;
	ctrlpoints = new Pixel[nbctrlpoints];
	for (int i = 0 ; i < nbctrlpoints ; i++)
		ctrlpoints[i] = controlpoints[i];

	coefs_x = new Vecteur4D[nbctrlpoints-3];
	coefs_y = new Vecteur4D[nbctrlpoints-3];
	precalculmatrices();
}


void SplineCubique2D::precalculmatrices(void){

	Matrice MBS(4,4);
	MBS[0][0] = -1; MBS[0][1] = 3 ; MBS[0][2] = -3; MBS[0][3] = 1;
	MBS[1][0] = 3 ; MBS[1][1] = -6; MBS[1][2] = 3 ; MBS[1][3] = 0;
	MBS[2][0] = -3; MBS[2][1] = 0 ; MBS[2][2] = 3 ; MBS[2][3] = 0;
	MBS[3][0] = 1 ; MBS[3][1] = 4 ; MBS[3][2] = 1 ; MBS[3][3] = 0;
	for (int i = 0 ; i < nbctrlpoints-3 ; i++){
		Vecteur4D controlx(ctrlpoints[i].x, ctrlpoints[i+1].x, ctrlpoints[i+2].x, ctrlpoints[i+3].x);
		coefs_x[i] = MBS*controlx;
		Vecteur4D controly(ctrlpoints[i].y, ctrlpoints[i+1].y, ctrlpoints[i+2].y, ctrlpoints[i+3].y);
		coefs_y[i] = MBS*controly;

	}

}
/*
void SplineCubiqueouverte::affiche(CDC& cdc, Pixel centrevue, double facteur_echelle){


	double xpos, ypos;

	getpoint(0,xpos,ypos);
	cdc.MoveTo((int)(xpos/facteur_echelle + centrevue.x), (int)(ypos/facteur_echelle + centrevue.x));
	for (int i = 1 ; i <= NB_POINTS_AFFICHAGE  ; i++){

		getpoint(((double)i)/(double)NB_POINTS_AFFICHAGE,xpos,ypos);
		cdc.LineTo((int)(xpos/facteur_echelle + centrevue.x), (int)(ypos/facteur_echelle + centrevue.x));
		cdc.MoveTo((int)(xpos/facteur_echelle + centrevue.x), (int)(ypos/facteur_echelle + centrevue.x));


	}
}



*/

void SplineCubique2D::getpoint(double t, double & xpos, double & ypos){

	if (t < 0) t=0;
	if (t > 1) t=1;

	int i = (int)(t*(nbctrlpoints-3));  // numero de la courbe

	double tvrai = (t*(nbctrlpoints-3))-i;
	
//	int j = nopoint % echantillonage;  // position sur la courbe
	if (i == nbctrlpoints-3){
		i = nbctrlpoints - 4;
		tvrai=1;
	}
			
	double t2 = tvrai*tvrai;
	double t3 = t2*tvrai;
	Quadruplet vecteur_t(t3, t2, tvrai, 1);

			xpos = (vecteur_t*coefs_x[i])/6.0;
			ypos = (vecteur_t*coefs_y[i])/6.0;

}



void SplineCubique2D::getnormale(double t, double & vx, double & vy){

	if (t < 1e-6) t+=1e-3;
	if (t > 0.99999) t-= 1e-3;
	int i = (int)(t*(nbctrlpoints-3));  // numero de la courbe

	double tvrai = (t*(nbctrlpoints-3))-i;
	
//	int j = nopoint % echantillonage;  // position sur la courbe
	if (i == nbctrlpoints-3){
		i = nbctrlpoints - 4;
		tvrai=1;
	}
			
	double t2 = tvrai*tvrai;
	double t3 = t2*tvrai;
	Quadruplet vecteur_t(3*t2, 2*tvrai, 1, 0);

			vx = (vecteur_t*coefs_y[i])/6.0;
			vy = -(vecteur_t*coefs_x[i])/6.0;
}



void SplineCubique2D::gettangente(double t, double & vx, double & vy){

	if (t < 1e-6) t+=1e-3;
	if (t > 0.99999) t-= 1e-3;
	int i = (int)(t*(nbctrlpoints-3));  // numero de la courbe

	double tvrai = (t*(nbctrlpoints-3))-i;
	
//	int j = nopoint % echantillonage;  // position sur la courbe
	if (i == nbctrlpoints-3){
		i = nbctrlpoints - 4;
		tvrai=1;
	}
			
	double t2 = tvrai*tvrai;
	Quadruplet vecteur_tprime(3*t2, 2*tvrai, 1, 0);

	vx = (vecteur_tprime*coefs_x[i])/6.0;
	vy = (vecteur_tprime*coefs_y[i])/6.0;
}



void SplineCubique2D::getderseconde(double t, double & vx, double & vy){

	if (t < 1e-6) t+=1e-3;
	if (t > 0.99999) t-= 1e-3;
	int i = (int)(t*(nbctrlpoints-3));  // numero de la courbe

	double tvrai = (t*(nbctrlpoints-3))-i;
	
//	int j = nopoint % echantillonage;  // position sur la courbe
	if (i == nbctrlpoints-3){
		i = nbctrlpoints - 4;
		tvrai=1;
	}
			
	Quadruplet vecteur_tprime(6*tvrai, 2, 0, 0);


	vx = (vecteur_tprime*coefs_x[i])/6.0;
	vy = (vecteur_tprime*coefs_y[i])/6.0;
}




double SplineCubique2D::calcullongueur(int echantillonage)
{
	double x1, y1, x2, y2;
	double longueur = 0;
	for (int i = 0 ; i < nbctrlpoints-3 ; i++){

		x1 = coefs_x[i][3]/6.0; 
		y1 = coefs_y[i][3]/6.0;  // origine de la courbe numero i
		for (int j = 1 ; j <= echantillonage ; j++){
			
			double t = ((double) j) / ((double) echantillonage);
			double t2 = t*t;
			double t3 = t2*t;
			Quadruplet vecteur_t(t3, t2, t, 1);

			x2 = (vecteur_t*coefs_x[i])/6.0; 
			y2 = (vecteur_t*coefs_y[i])/6.0;
			
			longueur += sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));

			x1 = x2;
			y1 = y2;
		}
	}

	return longueur;
}
