// CelluleTA.cpp: implementation des fonctions necessaire
// au remplissage de polygone 2D
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Synth.h"
#include "Polygone2d.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif



CelluleTA *CelluleTA::memoireTA = NULL;
CelluleTA *CelluleTA::tetenew = NULL;
CelluleTAA *CelluleTAA::memoireTAA = NULL;
CelluleTAA *CelluleTAA::tetenew = NULL;
int CelluleTA::nballocglobales = 0;



//////////////////////////////////////////////////////////////////////
// Fonctions de la classe CelluleTA
//////////////////////////////////////////////////////////////////////


CelluleTA::CelluleTA()
{

}

CelluleTA::CelluleTA(const EdgeData& d)
{
   data = d;
}

CelluleTA::~CelluleTA()
{

}


CelluleTA * alloueTA(void)
{  CelluleTA* res = CelluleTA::tetenew;
   if (res == NULL)
   {
		AfxMessageBox(CString("Probl�me m�moire: memoireTA"));
   }
   CelluleTA::tetenew = CelluleTA::tetenew->suiv;
   res->suiv = NULL;
   return res;
}


void libereTA(CelluleTA* c)
{  c->suiv = CelluleTA::tetenew;
   CelluleTA::tetenew = c;
}


//////////////////////////////////////////////////////////////////////
// Fonctions de la classe CelluleTAA
//////////////////////////////////////////////////////////////////////


CelluleTAA::CelluleTAA()
{

}

CelluleTAA::CelluleTAA(const EdgeData& d, int incr)
{
   data = d;
   increment = incr;
}

CelluleTAA::~CelluleTAA()
{

}


CelluleTAA * alloueTAA(void)
{  CelluleTAA* res = CelluleTAA::tetenew;
   if (res == NULL)
   {
		AfxMessageBox(CString("Probl�me m�moire: memoireTAA"));
   }
   CelluleTAA::tetenew = CelluleTAA::tetenew->suiv;
   res->suiv = NULL;
   return res;
}


void libereTAA(CelluleTAA* c)
{  c->suiv = CelluleTAA::tetenew;
   CelluleTAA::tetenew = c;
}


//////////////////////////////////////////////////////////////////////
// Constructeur de la classe Arete
//////////////////////////////////////////////////////////////////////


Arete::Arete(int x1, int y1, int x2, int y2)
{
	if (y1 > y2){
		xbas = x2;
		ybas = y2;
		xhaut = x1;
		yhaut = y1;
	}
	else{
		xbas = x1;
		ybas = y1;
		xhaut = x2;
		yhaut = y2;
	}
}

//////////////////////////////////////////////////////////////////////
// Fonctions de la classe ListeTA
//////////////////////////////////////////////////////////////////////


// Destructeur


ListeTA::~ListeTA()
{
	destruction();
}

void ListeTA::destruction()
{
	CelluleTA *p, *preced;
	p = L; 
	while (p!=NULL){
		preced = p;
		p = p->suiv;
		libereTA(preced);
	}
}

// Constructeur par copie

ListeTA::ListeTA(ListeTA& liste)
{
	CelluleTA *queue, *p;
	
	p = liste.L;

	if (p != NULL){
		L = alloueTA();
		L->data = p->data;
		queue = L;
		p = p->suiv;
	}else
		L = NULL;
	while (p != NULL){
		queue->suiv = alloueTA();
		queue = queue->suiv;
		queue->data = p->data;
		p = p->suiv;
	}
}


// operateur d'affectation

ListeTA& ListeTA::operator=(ListeTA& liste)
{
	CelluleTA *queue, *p;
	
	if (&liste == this)
		return (*this);

	if (L)
		destruction();

	p = liste.L;

	if (p != NULL){
		L = alloueTA();
		L->data = p->data;
		queue = L;
		p = p->suiv;
	}else
		L = NULL;
	while (p != NULL){
		queue->suiv = alloueTA();
		queue = queue->suiv;
		queue->data = p->data;
		p = p->suiv;
	}
	return (*this);
}


//////////////////////////////////////////////////////////////////////
// Fonctions de la classe TableTA
//////////////////////////////////////////////////////////////////////


// Destructeur

TableTA::~TableTA()
{
	delete [] tab;
	tab = NULL;
	taille = 0;
}


// Constructeur par copie

TableTA::TableTA(TableTA & table)
{
	taille = table.taille;
	tab = new ListeTA[taille];

	for (int i = 0 ; i < taille ; i++){
		tab[i] = table.tab[i];
	}
}


// Operateur d'affectation

TableTA & TableTA::operator=(TableTA & table)
{
	if (&table == this)
		return (*this);

	if (taille)
		delete [] tab;

	taille = table.taille;
	tab = new ListeTA[taille];

	for (int i = 0 ; i < taille ; i++){
		tab[i] = table.tab[i];
	}
	return (*this);
}


// Fonctions de calcul du minimum de ybas

int TableTA::calcminy(Arete *tabaretes, int nbaretes)
{
	int i, minybas = tabaretes[0].ybas;
	for (i = 1 ; i < nbaretes ; i++){
		if (tabaretes[i].ybas < minybas)
			minybas = tabaretes[i].ybas;
	}
	return minybas;
}


// Fonctions de calcul du maximum de ybas

int TableTA::calcmaxybas(Arete *tabaretes, int nbaretes)
{
	int i, maxybas = tabaretes[0].ybas;
	for (i = 1 ; i < nbaretes ; i++){
		if (tabaretes[i].ybas > maxybas)
			maxybas = tabaretes[i].ybas;
	}
	return maxybas;
}


// Fonctions de calcul du maximum de yhaut

int TableTA::calcmaxyhaut(Arete *tabaretes, int nbaretes)
{
	int i, maxyhaut = tabaretes[0].yhaut;
	for (i = 1 ; i < nbaretes ; i++){
		if (tabaretes[i].yhaut > maxyhaut)
			maxyhaut = tabaretes[i].yhaut;
	}
	return maxyhaut;
}

// Constructeur de la table des aretes globale

TableTA::TableTA(Arete *tabaretes, int nbaretes)
{
	int i, j, numer, denom, tempo;
	Arete a;

	// calcul de la plus petite valeur de ybas:
	int minybas = calcminy(tabaretes, nbaretes);
	// calcul de la plus grande valeur de ybas:
	int maxybas = calcmaxybas(tabaretes, nbaretes);

	// Allocation et initialisation de TA:

    taille = maxybas - minybas+1;
	tab = new ListeTA[taille];
    for (j = 0 ; j < taille ; j++)
		tab[j].L = NULL;

	// Parcours des aretes du polygone et
	// insertion dans les listes de tab

	for (i = 0 ; i < nbaretes ; i++){
		a = tabaretes[i];
		numer = a.xhaut - a.xbas;
		denom = a.yhaut - a.ybas;
		if (denom){    // si arete non horizontale, insertion
			tempo = a.ybas - minybas;
			insertriTA(tab[tempo], a.yhaut, a.xbas, numer, denom);
		}
	}
}


// Insertion dans une liste triee (utilisee par le constructeur)

void TableTA::insertriTA(ListeTA & liste, int yhaut, int xbas, int numer, int denom)
{
	CelluleTA *p, *preced;
    CelluleTA *nouveau;

	preced = NULL;
	p = liste.L;
	while (p != NULL &&
		   (p->data.x < xbas ||    // determination de l'arete de gauche
		    (p->data.x == xbas && 
			 p->data.numerat * denom <= numer * p->data.denomin
			)
		   )
		  ){
		preced = p;
		p = p->suiv;
	}

	nouveau = alloueTA();
	nouveau->data.yhaut = yhaut;
	nouveau->data.x = xbas;
	nouveau->data.numerat = numer;
	nouveau->data.denomin = denom;
	if (preced == NULL){         //insertion en tete
		nouveau->suiv = liste.L;
		liste.L = nouveau;
	}else{
		nouveau->suiv = p;
		preced->suiv = nouveau;
	}
}


//////////////////////////////////////////////////////////////////////
// Fonctions de la classe ListeTAA
//////////////////////////////////////////////////////////////////////

// Destructeur

ListeTAA::~ListeTAA()
{
	destruction();
}

void ListeTAA::destruction()
{
	CelluleTAA *p, *preced;
	p = L;
	while (p!=NULL){
		preced = p;
		p = p->suiv;
		libereTAA(preced);
	}
}

// Constructeur par copie

ListeTAA::ListeTAA(ListeTAA& liste)
{
	CelluleTAA *queue, *p;
	
	p = liste.L;

	
	if (p != NULL){
		L = alloueTAA();
		L->data = p->data;
		L->increment = p->increment;
		queue = L;
		p = p->suiv;
	}else
		L = NULL;
	while (p != NULL){
		queue->suiv = alloueTAA();
		queue = queue->suiv;
		queue->data = p->data;
		queue->increment = p->increment;
		p = p->suiv;
	}
}

// Operateur d'affectation

ListeTAA & ListeTAA::operator=(ListeTAA& liste)
{
	CelluleTAA *queue, *p;
	
	if (&liste == this)
		return (*this);

	if (L)
		destruction();

	p = liste.L;

	if (p != NULL){
		L = alloueTAA();
		L->data = p->data;
		L->increment = p->increment;
		queue = L;
		p = p->suiv;
	}else
		L = NULL;
	while (p != NULL){
		queue->suiv = alloueTAA();
		queue = queue->suiv;
		queue->data = p->data;
		queue->increment = p->increment;
		p = p->suiv;
	}
	return (*this);
}

// Fonction d'interclassement de deux listes, utilisee par
// la fonction de parcours de l'interieur d'un polygone

void ListeTAA::interclassement(const ListeTA& liste)
{
   CelluleTAA *q = L, *preced = NULL;
   CelluleTA *p = liste.L;
   int compteur = 0;
   CelluleTAA * nouveau;

	while (p != NULL){
		if (q != NULL &&
			(q->data.x < p->data.x ||
			 (q->data.x == p->data.x &&
			  q->data.numerat*p->data.denomin <= p->data.numerat*q->data.denomin
			 )
			)
			){   // L'arete q->data est a gauche, on passe au suivant
			preced = q;
			q = q->suiv;
		}else{
			nouveau = alloueTAA();
			nouveau->data = p->data;

			if (compteur % 2 == 0){   // arete gauche
				if (nouveau->data.numerat >= 0)
					nouveau->increment = nouveau->data.denomin - 1;
				else
					nouveau->increment = 0;
			}else{
				if (nouveau->data.numerat >= 0)
					nouveau->increment = -1;
				else
					nouveau->increment = - nouveau->data.denomin;
			}

			if (preced == NULL){
				nouveau->suiv = L;
				L = preced = nouveau;
			}else{
				nouveau->suiv = preced->suiv;
				preced->suiv = nouveau;
				preced = nouveau;
			}

			p = p->suiv;
		}
		compteur++;
	}
}


// Fonction de suppression des aretes pour lesquelles yhaut = y

void ListeTAA::supprimearetestraitees(int y)
{
	CelluleTAA *p=L, *preced=NULL;

    while (p!=NULL){
		if (p->data.yhaut == y){
			if (preced == NULL){
				preced = p;
				p = p->suiv;
				L = p;
				libereTAA(preced);
				preced = NULL;
			}else{
				preced->suiv = p->suiv;
				libereTAA(p);
				p = preced->suiv;
			}
		}else{
			preced = p;
			p = p->suiv;
		}
	}
}


void ListeTAA::traiteautointersections(void){

		// Pour autointersections :


		char fini = 0;

		while (!fini){
			fini = 1;
			int pariteech = 0;
			CelluleTAA *preced = NULL, *p, *q;
			for (q = L ; q != NULL && q->suiv != NULL ; preced = q, q = q->suiv, pariteech++){
				if (q->data.x > q->suiv->data.x ||
					(q->suiv->data.x == q->data.x &&
					 q->suiv->data.numerat*q->data.denomin < 
					       q->data.numerat * q->suiv->data.denomin
					)
				   ){
						fini = 0;
						if (pariteech == 0){
							q->increment -= q->data.denomin;
							q->suiv->increment += q->suiv->data.denomin;
						}else{
							q->increment += q->data.denomin;
							q->suiv->increment -= q->suiv->data.denomin;
						}
						p = q->suiv;
						q->suiv = p->suiv;
						p->suiv = q;
						q = p;
						if (preced == NULL){
							L = p;
						}else{
							preced->suiv = p;
						}
				}
			}
		}

}

//////////////////////////////////////////////////////////////////////
// Fonctions de la classe Polygone2D
//////////////////////////////////////////////////////////////////////

// Destructeur

Polygone2D::~Polygone2D()
{
	delete [] tabaretes;
	tabaretes = NULL;
	nbaretes = 0;
}


// Constructeur par copie

Polygone2D::Polygone2D(Polygone2D & P)
{
	nbaretes = P.nbaretes;
	tabaretes = new Arete[nbaretes];

	for (int i = 0 ; i < nbaretes ; i++)
		tabaretes[i] = P.tabaretes[i];
}

// operateur d'affectation

Polygone2D & Polygone2D::operator=(Polygone2D & P)
{
	if (&P == this)
		return (*this);

	nbaretes = P.nbaretes;
	tabaretes = new Arete[nbaretes];

	for (int i = 0 ; i < nbaretes ; i++)
		tabaretes[i] = P.tabaretes[i];

	return (*this);
}



//////////////////////////////////////////////////////////////////////
// Fonction de parcours de l'interieur d'un polygone 2D
//////////////////////////////////////////////////////////////////////


void Polygone2D::remplissage(CDC *pDC)
{
	TableTA TA(tabaretes, nbaretes);
	ListeTAA TAA;
	CelluleTAA *q;
	int Q;
	char parite;
	int y, i;

	// calcul de la plus petite valeur de ybas:
	int minybas = TA.calcminy(tabaretes, nbaretes);
	// calcul de la plus grande valeur de ybas:
	int maxybas = TA.calcmaxybas(tabaretes, nbaretes);
	// calcul de la plus grande valeur de yhaut
	int maxyhaut = TA.calcmaxyhaut(tabaretes, nbaretes);

    TAA.L = NULL;

	for (y = minybas ; y < maxyhaut ; y++){

		TAA.supprimearetestraitees(y);
		if (y <= maxybas)
			TAA.interclassement(TA.tab[y - minybas]);
		
		parite = 0;
		for (q = TAA.L ; q!=NULL && q->suiv != NULL ; q = q->suiv){
			parite = !parite;
			if (parite)
				for (i = q->data.x ; i <= q->suiv->data.x ; i++)
					pDC->SetPixelV(i, y, RGB(0,0,0));
		}

		for (q = TAA.L ; q!=NULL ; q = q->suiv){
			q->increment += q->data.numerat;
			Q = q->increment / q->data.denomin;
			q->data.x += Q;
			q->increment -= Q * q->data.denomin;
		}

		// Pour autointersections :

		TAA.traiteautointersections();

	}
}