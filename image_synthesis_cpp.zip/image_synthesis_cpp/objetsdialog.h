#if !defined(AFX_OBJETSDIALOG_H__B1DF49A0_5951_11D3_B1CB_DDA22938F076__INCLUDED_)
#define AFX_OBJETSDIALOG_H__B1DF49A0_5951_11D3_B1CB_DDA22938F076__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ObjetsDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSphereGeomPropPage dialog

class CSphereGeomPropPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CSphereGeomPropPage)

// Construction
public:
	CSphereGeomPropPage();
	~CSphereGeomPropPage();

// Dialog Data
	//{{AFX_DATA(CSphereGeomPropPage)
	enum { IDD = IDD_SPHERE_GEOMETRY };
	double	m_cx;
	double	m_cy;
	double	m_cz;
	int		m_nbmerid;
	int		m_nbparal;
	double	m_radius;
	double	m_rotx;
	double	m_roty;
	double	m_rotz;
	double	m_scax;
	double	m_scay;
	double	m_scaz;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSphereGeomPropPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSphereGeomPropPage)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};



class CConeRevolPropPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CConeRevolPropPage)

// Construction
public:
	CConeRevolPropPage();
	~CConeRevolPropPage();

// Dialog Data
	//{{AFX_DATA(CConeRevolPropPage)
	enum { IDD = IDD_CONEREVOL_GEOMETRY };
	double	m_cx;
	double	m_cy;
	double	m_cz;
	double	m_hauttronq;
	int		m_nbmerid;
	double	m_bottomradius;
	double	m_topradius;
	double	m_rotx;
	double	m_roty;
	double	m_rotz;
	double	m_scax;
	double	m_scay;
	double	m_scaz;
	int		m_nbparal;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CConeRevolPropPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CConeRevolPropPage)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////
// CNewLight dialog

class CNewLight : public CDialog
{
// Construction
public:
	CNewLight(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNewLight)
	enum { IDD = IDD_DIALOG5 };
	float	m_coulB;
	float	m_coulG;
	float	m_coulR;
	float	m_posx;
	float	m_posy;
	float	m_posz;
	BOOL	m_attenuation;
	BOOL	m_directionnel;
	double	m_dirx;
	double	m_diry;
	double	m_dirz;
	int		m_exposantdirect;
	double	m_c1;
	double	m_c2;
	double	m_c3;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewLight)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNewLight)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CSelectCamera dialog

class CSelectCamera : public CDialog
{
// Construction
public:
	CSelectCamera(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSelectCamera)
	enum { IDD = IDD_SELECTCAM };
	int		m_nocam;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSelectCamera)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSelectCamera)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CErreurDomaineDlg dialog

class CErreurDomaineDlg : public CDialog
{
// Construction
public:
	CErreurDomaineDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CErreurDomaineDlg)
	enum { IDD = IDD_DIALOG6 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CErreurDomaineDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CErreurDomaineDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CEditCameraDialog dialog

class CEditCameraDialog : public CDialog
{
// Construction
public:
	CEditCameraDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CEditCameraDialog)
	enum { IDD = IDD_EDITER_CAMERA };
	float	m_anglex;
	float	m_cx;
	float	m_cy;
	float	m_cz;
	float	m_posx;
	float	m_posy;
	float	m_posz;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditCameraDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEditCameraDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CEditSourceLumDialog dialog

class CEditSourceLumDialog : public CDialog
{
// Construction
public:
	CEditSourceLumDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CEditSourceLumDialog)
	enum { IDD = IDD_EDITER_SOURCE };
	BOOL	m_allumee;
	double	m_ib;
	double	m_ig;
	double	m_ir;
	double	m_posx;
	double	m_posy;
	double	m_posz;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditSourceLumDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEditSourceLumDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CSelectSourceDialog dialog

class CSelectSourceDialog : public CDialog
{
// Construction
public:
	CSelectSourceDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSelectSourceDialog)
	enum { IDD = IDD_SELECTSOURCE };
	int		m_no;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSelectSourceDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSelectSourceDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CTranslationDialog dialog

class CTranslationDialog : public CDialog
{
// Construction
public:
	CTranslationDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTranslationDialog)
	enum { IDD = IDD_TRANSLATION };
	double	m_x;
	double	m_y;
	double	m_z;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTranslationDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTranslationDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CCylRevolGeomPropPage dialog

class CCylRevolGeomPropPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CCylRevolGeomPropPage)

// Construction
public:
	CCylRevolGeomPropPage();
	~CCylRevolGeomPropPage();

// Dialog Data
	//{{AFX_DATA(CCylRevolGeomPropPage)
	enum { IDD = IDD_CILINREVOL_GEOMETRY };
	double	m_cx;
	double	m_cy;
	double	m_cz;
	int		m_nbmerid;
	double	m_hauteur;
	double	m_radius;
	double	m_rotx;
	double	m_roty;
	double	m_rotz;
	double	m_scax;
	double	m_scay;
	double	m_scaz;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CCylRevolGeomPropPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CCylRevolGeomPropPage)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CBoxGeomPropPage dialog

class CBoxGeomPropPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CBoxGeomPropPage)

// Construction
public:
	CBoxGeomPropPage();
	~CBoxGeomPropPage();

// Dialog Data
	//{{AFX_DATA(CBoxGeomPropPage)
	enum { IDD = IDD_BOX_GEOMETRY };
	double	m_cx;
	double	m_cy;
	double	m_cz;
	double	m_dimx;
	double	m_dimy;
	double	m_dimz;
	double	m_rotx;
	double	m_roty;
	double	m_rotz;
	int		m_nbmerid;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CBoxGeomPropPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CBoxGeomPropPage)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CCylinSplineGeomPropPage dialog

class CCylinSplineGeomPropPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CCylinSplineGeomPropPage)

// Construction
public:
	CCylinSplineGeomPropPage();
	~CCylinSplineGeomPropPage();

// Dialog Data
	//{{AFX_DATA(CCylinSplineGeomPropPage)
	enum { IDD = IDD_CYLINSPLINE_GEOMETRY };
	double	m_cx;
	double	m_cy;
	double	m_cz;
	int		m_echantspline;
	double	m_rotx;
	double	m_roty;
	double	m_rotz;
	double	m_scax;
	double	m_scay;
	double	m_scaz;
	BOOL	m_phongenable;
	double	m_hauteur;
	CString	m_nomsp;
	double	m_topreduction;
	int		m_echanthauteur;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CCylinSplineGeomPropPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CCylinSplineGeomPropPage)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CDeformSplineGeom dialog

class CDeformSplineGeom : public CPropertyPage
{
	DECLARE_DYNCREATE(CDeformSplineGeom)

// Construction
public:
	CDeformSplineGeom();
	~CDeformSplineGeom();

// Dialog Data
	//{{AFX_DATA(CDeformSplineGeom)
	enum { IDD = IDD_DEFORMABLE_SPLINEREVOL_GEOMETRY1 };
	double	m_cx;
	double	m_cy;
	double	m_cz;
	int		m_echantspline;
	int		m_nbctrl;
	CString	m_nomsp;
	BOOL	m_phongenable;
	double	m_rotx;
	double	m_roty;
	double	m_rotz;
	double	m_scax;
	double	m_scay;
	double	m_scaz;
	int		m_echantcercle;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CDeformSplineGeom)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CDeformSplineGeom)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CExtrusionGeomPropPage dialog

class CExtrusionGeomPropPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CExtrusionGeomPropPage)

// Construction
public:
	CExtrusionGeomPropPage();
	~CExtrusionGeomPropPage();

// Dialog Data
	//{{AFX_DATA(CExtrusionGeomPropPage)
	enum { IDD = IDD_EXTRUSIONSPLINE_GEOMETRY };
	double	m_pcba;
	double	m_pcbf;
	double	m_pcea;
	double	m_pcef;
	BOOL	m_withchanfrein;
	double	m_cx;
	double	m_cy;
	double	m_cz;
	int		m_echantame;
	int		m_echantforme;
	CString	m_nomame;
	CString	m_nomforme;
	BOOL	m_phongenable;
	double	m_rotx;
	double	m_roty;
	double	m_rotz;
	double	m_scashape;
	double	m_scax;
	double	m_scay;
	double	m_scaz;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CExtrusionGeomPropPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CExtrusionGeomPropPage)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CSplineRevolGeometryPropPage dialog

class CSplineRevolGeometryPropPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CSplineRevolGeometryPropPage)

// Construction
public:
	CSplineRevolGeometryPropPage();
	~CSplineRevolGeometryPropPage();

// Dialog Data
	//{{AFX_DATA(CSplineRevolGeometryPropPage)
	enum { IDD = IDD_SPLINEREVOL_GEOMETRY1 };
	double	m_cx;
	double	m_cy;
	double	m_cz;
	BOOL	m_phongenable;
	double	m_rotx;
	double	m_roty;
	double	m_rotz;
	double	m_scax;
	double	m_scaz;
	CString	m_nomsp;
	double	m_scay;
	int		m_echantcercle;
	int		m_echantspline;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSplineRevolGeometryPropPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CSplineRevolGeometryPropPage)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CDeformableCylinRevolPropPage dialog

class CDeformableCylinRevolPropPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CDeformableCylinRevolPropPage)

// Construction
public:
	CDeformableCylinRevolPropPage();
	~CDeformableCylinRevolPropPage();

// Dialog Data
	//{{AFX_DATA(CDeformableCylinRevolPropPage)
	enum { IDD = IDD_DEFORMABLE_CYLINREVOL_GEOMETRY };
	double	m_cx;
	double	m_cy;
	double	m_cz;
	double	m_hauttronq;
	int		m_nbctrlhaut;
	int		m_nbctrlcircle;
	int		m_nbmerid;
	int		m_nbparal;
	double	m_bottomradius;
	double	m_topradius;
	double	m_rotx;
	double	m_roty;
	double	m_rotz;
	double	m_scax;
	double	m_scay;
	double	m_scaz;
	int		m_nbctrldisk;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CDeformableCylinRevolPropPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CDeformableCylinRevolPropPage)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CTransformDialog dialog

class CTransformDialog : public CDialog
{
// Construction
public:
	CTransformDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTransformDialog)
	enum { IDD = IDD_TRANSFORM };
	double	m_angle;
	double	m_axisx;
	double	m_axisy;
	double	m_axisz;
	double	m_origx;
	double	m_origy;
	double	m_origz;
	double	m_scale;
	double	m_translatx;
	double	m_translaty;
	double	m_translatz;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTransformDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTransformDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OBJETSDIALOG_H__B1DF49A0_5951_11D3_B1CB_DDA22938F076__INCLUDED_)
