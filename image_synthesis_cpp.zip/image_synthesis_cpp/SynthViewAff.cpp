#include <stdlib.h>

#include "stdafx.h"
#include "Synth.h"

#include "SynthDoc.h"
#include "SynthView.h"
#include "ObjetsDialog.h"
#include "ControlCameraDlg.h"

#include "Objet3D.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



void CSynthView::OnAffichageControlcam() 
{
	// TODO: Add your command handler code here
	if (m_pDlg->GetSafeHwnd() == 0){
		m_pDlg->m_rotstep = (float)steprot;
		m_pDlg->m_transstep = (float)steptrans;
		if (m_pDlg->Create() == 0){
		}

	}
}


void CSynthView::OnUpdateAffichageControlcam(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(activinsere);
	pCmdUI->SetCheck(m_pDlg->GetSafeHwnd() != 0);
}


void CSynthView::OnControlesNavigat() 
{
	// TODO: Add your command handler code here
	
	// TODO: Add your command handler code here
	if (m_pDlgnavigat->GetSafeHwnd() == 0){
		m_pDlgnavigat->m_rotstep = (float)steprotnavigat;
		m_pDlgnavigat->m_transstep = (float)steptransnavigat;
		if (m_pDlgnavigat->Create() == 0){
		}

	}
}

void CSynthView::OnUpdateControlesNavigat(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(activinsere);
	pCmdUI->SetCheck(m_pDlgnavigat->GetSafeHwnd() != 0);
	
}



void CSynthView::OnAffichageSelectcam() 
{
	// TODO: Add your command handler code here
	CSelectCamera dlg;

	dlg.m_nocam = scene.nocameraselect();
	int ret = dlg.DoModal();

	if (ret != IDCANCEL){
		if (dlg.m_nocam < 0 || dlg.m_nocam >= scene.nbcameras()){
			CErreurDomaineDlg dlg1;
			dlg1.DoModal();
		}else{
			scene.selectcam(dlg.m_nocam);
			scene.zbuffer(bitmap_dib);
			CClientDC cdc(this);
			OnDraw(&cdc);
		}
	}
}

void CSynthView::OnUpdateAffichageSelectcam(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(activinsere);

}

void CSynthView::OnAffichageRedresserCam() 
{
	// TODO: Add your command handler code here
	
	scene.redrescam();
	scene.zbuffer(bitmap_dib);
	CClientDC cdc(this);
	OnDraw(&cdc);
}

void CSynthView::OnUpdateAffichageRedresserCam(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->Enable(activinsere);
}



void CSynthView::OnAffichageSimplezbuffer() 
{
	// TODO: Add your command handler code here


	if (scene.getetatzbuffer() != 1){
		scene.setsamplebuffer(1);

		scene.zbuffer(bitmap_dib);
		CClientDC cdc(this);
		OnDraw(&cdc);
	}
	
}


void CSynthView::OnUpdateAffichageSimplezbuffer(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->SetCheck(scene.getetatzbuffer() == 1);
	pCmdUI->Enable(activinsere);
}

void CSynthView::OnAffichageDoublezbuffer() 
{
	// TODO: Add your command handler code here
	
	if (scene.getetatzbuffer() != 2){
		scene.setsamplebuffer(2);

		scene.zbuffer(bitmap_dib);
		CClientDC cdc(this);
		OnDraw(&cdc);

	}
}

void CSynthView::OnUpdateAffichageDoublezbuffer(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->SetCheck(scene.getetatzbuffer() == 2);
	pCmdUI->Enable(activinsere);
}

void CSynthView::OnAffichageTriplezbuffer() 
{
	// TODO: Add your command handler code here
	
	if (scene.getetatzbuffer() != 3){
		scene.setsamplebuffer(3);

		scene.zbuffer(bitmap_dib);
		CClientDC cdc(this);
		OnDraw(&cdc);
	}
}

void CSynthView::OnUpdateAffichageTriplezbuffer(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here

	pCmdUI->SetCheck(scene.getetatzbuffer() == 3);
	pCmdUI->Enable(activinsere);

}


void CSynthView::OnAffichageVoirAxes() 
{
	// TODO: Add your command handler code here

	scene.setetatvoiraxes(!scene.getetatvoiraxes());
	
	scene.zbuffer(bitmap_dib);
	CClientDC cdc(this);
	OnDraw(&cdc);
}

void CSynthView::OnUpdateAffichageVoirAxes(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->SetCheck(scene.getetatvoiraxes());
	pCmdUI->Enable(activinsere);

}







void CSynthView::OnAffichageOptionsclairementLumireambiante() 
{
	// TODO: Add your command handler code here
	
	scene.setenableambiante(!scene.getenableambiante());

	scene.zbuffer(bitmap_dib);
	CClientDC cdc(this);
	OnDraw(&cdc);
}

void CSynthView::OnUpdateAffichageOptionsclairementLumireambiante(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(scene.getenableambiante());
	pCmdUI->Enable(activinsere);

}



void CSynthView::OnAffichageOptionsclairementReflexiondifuse() 
{
	// TODO: Add your command handler code here
	scene.setenabledifuse(!scene.getenabledifuse());

	scene.zbuffer(bitmap_dib);
	CClientDC cdc(this);
	OnDraw(&cdc);
	
}

void CSynthView::OnUpdateAffichageOptionsclairementReflexiondifuse(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(scene.getenabledifuse());
	pCmdUI->Enable(activinsere);
	
}

void CSynthView::OnAffichageOptionsclairementReflexionspeculaire() 
{
	// TODO: Add your command handler code here
	
	scene.setenablespecular(!scene.getenablespecular());

	scene.zbuffer(bitmap_dib);
	CClientDC cdc(this);
	OnDraw(&cdc);
}

void CSynthView::OnUpdateAffichageOptionsclairementReflexionspeculaire(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(scene.getenablespecular());
	pCmdUI->Enable(activinsere);
	
}

void CSynthView::OnAffichageOptionsclairementTextures() 
{
	// TODO: Add your command handler code here
	scene.setenabletexture(!scene.getenabletexture());

	scene.zbuffer(bitmap_dib);
	CClientDC cdc(this);
	OnDraw(&cdc);
	
}

void CSynthView::OnUpdateAffichageOptionsclairementTextures(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(scene.getenabletexture());
	pCmdUI->Enable(activinsere);

}


void CSynthView::OnAffichageOptionsclairementBumpmaps() 
{
	// TODO: Add your command handler code here
	
	scene.setenablebumpmap(!scene.getenablebumpmap());

	scene.zbuffer(bitmap_dib);
	CClientDC cdc(this);
	OnDraw(&cdc);
}

void CSynthView::OnUpdateAffichageOptionsclairementBumpmaps(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->SetCheck(scene.getenablebumpmap());
	pCmdUI->Enable(activinsere);
}



void CSynthView::OnAffichageOptionsclairementPhong() 
{
	// TODO: Add your command handler code here

	if (scene.getenablegouraud()){
		scene.setenablegouraud(false);
	}
	scene.setenablephong(!scene.getenablephong());

	scene.zbuffer(bitmap_dib);
	CClientDC cdc(this);
	OnDraw(&cdc);
	
}

void CSynthView::OnUpdateAffichageOptionsclairementPhong(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(scene.getenablephong());
	pCmdUI->Enable(activinsere);
	
}



void CSynthView::OnAffichageOptionsclairementGouraud() 
{
	// TODO: Add your command handler code here
	if (scene.getenablephong()){
		scene.setenablephong(false);
	}
	scene.setenablegouraud(!scene.getenablegouraud());

	scene.zbuffer(bitmap_dib);
	CClientDC cdc(this);
	OnDraw(&cdc);

}

void CSynthView::OnUpdateAffichageOptionsclairementGouraud(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
	pCmdUI->SetCheck(scene.getenablegouraud());
	pCmdUI->Enable(activinsere);
}
