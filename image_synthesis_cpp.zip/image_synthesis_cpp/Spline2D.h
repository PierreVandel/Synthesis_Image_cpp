// Spline2D.h: interface for the Spline2D class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SPLINE2D_H__2E997A40_4B89_11D4_B8E6_525405F505A7__INCLUDED_)
#define AFX_SPLINE2D_H__2E997A40_4B89_11D4_B8E6_525405F505A7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_NB_CTRL_POINTS 150


#define SPLINE2D_FERMEE 1
#define SPLINE2D_OUVERTE 2




#include "Matrice.h"



class Pixel
{
public:
	int x, y;
public : 
	Pixel(void){x = y = 0;}
	Pixel(int a, int b){x = a; y = b;}
	Pixel(CPoint p){x = p.x; y=p.y;}
	int accesx(void){return x;}
	int accesy(void){return y;}
};



class Courbe2D{

protected:
	CString nom;
	int numero;

public:
	Courbe2D(){nom=CString(""); numero=-1;}

	CString getnom(){return nom;}
	int getnumero(void){return numero;}


	void affiche(CDC& cdc, Pixel centrevue, double facteur_echelle);

	virtual void getpoint(double t, double & xpos, double & ypos)=0;
	virtual void getnormale(double t, double & vx, double & vy)=0;
	virtual void gettangente(double t, double & vx, double & vy)=0;
	virtual void getderseconde(double t, double & vx, double & vy)=0;

	
	virtual int gettype(void)=0;

	virtual double calcullongueur(int echantillonage)=0;


	virtual Pixel *accesctrlpoints(void)=0;
};






class Spline2D : public Courbe2D  
{

	friend class Scene3D;
	friend class Scene3DRay;
protected:

	Pixel * ctrlpoints; // tableau des points de controle
	int nbctrlpoints; // nombre de points de controle


public:

	bool flipped;
	virtual void flip(void){flipped=true;
	                for (int i=0 ; i < nbctrlpoints ; i++)
						{int x = ctrlpoints[i].x; ctrlpoints[i].x = ctrlpoints[i].y; ctrlpoints[i].y=x;
						}
					}
	Spline2D(){ctrlpoints=NULL;nbctrlpoints=0;flipped=false;}

	CString getnom(){return nom;}
	int getnumero(void){return numero;}

	int nombrectrlpoints(void){return nbctrlpoints;}

	//virtual void affiche(CDC& cdc, Pixel centrevue, double facteur_echelle)=0;

	virtual void getpoint(double t, double & xpos, double & ypos)=0;
	virtual void getnormale(double t, double & vx, double & vy)=0;
	virtual void gettangente(double t, double & vx, double & vy)=0;
	virtual void getderseconde(double t, double & vx, double & vy)=0;

	
	virtual int gettype(void)=0;

	virtual double calcullongueur(int echantillonage)=0;

	Pixel * accesctrlpoints(void){return ctrlpoints;}
};





class SplineCubique2D : public Spline2D  
{

protected:


	Vecteur4D *coefs_x; // vecteur a multiplier pour obtenir l'abscisse du point correspondant a une valeur t
	Vecteur4D *coefs_y; // vecteur a multiplier pour obtenir l'ordonnee du point correspondant a une valeur t

	bool fermee;
	

public:

	void flip(void){Spline2D::flip();
					precalculmatrices();
					}

	SplineCubique2D();
	virtual ~SplineCubique2D();
	SplineCubique2D(SplineCubique2D& s);

	SplineCubique2D& operator=(SplineCubique2D& s);
	void precalculmatrices(void);


	CString getnom(){return nom;}
	int getnumero(void){return numero;}

//	int nombrectrlpoints(void){return nbctrlpoints;}

	//virtual void affiche(CDC& cdc, Pixel centrevue, double facteur_echelle)=0;

	void getpoint(double t, double & xpos, double & ypos);
	void getnormale(double t, double & vx, double & vy);
	void gettangente(double t, double & vx, double & vy);
	void getderseconde(double t, double & vx, double & vy);

	
	virtual int gettype(void)=0;

	double calcullongueur(int echantillonage);

	Pixel * accesctrlpoints(void){return Spline2D::accesctrlpoints();}
};

class SplineCubiquefermee:public SplineCubique2D
{

public:
	// constructeur de SplineCubique fermee a partir de points de controle
	SplineCubiquefermee(Pixel *controlpoints, int nbcontrolpoints, CString paramnom, int no);  

	//void affiche(CDC& cdc, Pixel centrevue, double facteur_echelle);
//	void getpoint(double t, double & xpos, double & ypos){SplineCubique2D::getpoint(t,xpos,ypos);}
//	void getnormale(double t, double & vx, double & vy){SplineCubique2D::getnormale(t,vx,vy);}
//	void gettangente(double t, double & vx, double & vy){SplineCubique2D::gettangente(t,vx,vy);}
//	void getderseconde(double t, double & vx, double & vy){SplineCubique2D::getderseconde(t,vx,vy);}

	int gettype(void){return SPLINE2D_FERMEE;}

//	double calcullongueur(int echantillonage);

	Pixel * accesctrlpoints(void){return Spline2D::accesctrlpoints();}
};


class SplineCubiqueouverte:public SplineCubique2D
{

public:
	// constructeur de SplineCubique fermee a partir de points de controle
	SplineCubiqueouverte(Pixel *controlpoints, int nbcontrolpoints, CString paramnom, int no);  

	//void affiche(CDC& cdc, Pixel centrevue, double facteur_echelle);
//	void getpoint(double t, double & xpos, double & ypos){SplineCubique2D::getpoint(t,xpos,ypos);}
//	void getnormale(double t, double & vx, double & vy){SplineCubique2D::getnormale(t,vx,vy);}
//	void gettangente(double t, double & vx, double & vy){SplineCubique2D::gettangente(t,vx,vy);}
//	void getderseconde(double t, double & vx, double & vy){SplineCubique2D::getderseconde(t,vx,vy);}

	int gettype(void){return SPLINE2D_OUVERTE;}

//	double calcullongueur(int echantillonage);

	Pixel * accesctrlpoints(void){return Spline2D::accesctrlpoints();}
};



#endif // !defined(AFX_SPLINE2D_H__2E997A40_4B89_11D4_B8E6_525405F505A7__INCLUDED_)
