
//////////////////////////////////////////////////////////////////////
// Classe Point3D : represente les points 3D et les vecteurs 3D :
//////////////////////////////////////////////////////////////////////

#include "Couleur.h"

#ifndef __POINT3DH

#define __POINT3DH

class Matrice;

class Point3D{
public:
	double x, y, z;  // coordonnees

	// Constructeurs :
	Point3D(double a, double b, double c){x = a; y = b; z = c;}
	Point3D(void){x = y = z = 0.0;}

	// Operations de base
	Point3D operator+(const Point3D&);  // addition
	Point3D operator-(const Point3D&) const;  // soustraction
	Point3D operator-(void);            // oppose
	double operator*(const Point3D&);   // produit scalaire
	Point3D operator^(const Point3D&);  // produit vectoriel
	friend Point3D operator*(double, const Point3D&);  // multiplication par un nombre
	friend Point3D operator*(const Point3D&, double);  // multiplication par un nombre

	// divise un vecteur par sa norme, retourne false si la norme est nulle :
	bool normer(void);

	double norme(void);  // retourne la norme d'un vecteur (ou la distance d'un point a l'origine O). 
	double normecarre(void);  // retourne le carra de la norme d'un vecteur. 
};



class Sommet{
public:
	Point3D pos;
	Point3D normale;
	Intensitesgouraud intens;
	Point3D dpsds;
	Point3D dpsdt;
	double coordtextureX, coordtextureY;


	Sommet operator+(const Sommet&);  // addition
	Sommet operator-(const Sommet&) const;  // soustraction
	friend Sommet operator*(double, const Sommet&);  // multiplication par un nombre
	friend Sommet operator*(const Sommet&, double);  // multiplication par un nombre
	Sommet operator+(const Point3D& p);  // addition

};


Sommet operator * (const Matrice&, const Sommet&);


/* D�j� d�finie dans math.h
// fonction valeur absolue de reel
inline double abs(double x)
{
	return (x >= 0) ? x : -x;
}
*/
#endif