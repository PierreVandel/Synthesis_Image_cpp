// Objet3D.h: interface for the Objet3D class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OBJET3D_H__73899100_48CC_11D3_B1CB_8EDB4ADA2F73__INCLUDED_)
#define AFX_OBJET3D_H__73899100_48CC_11D3_B1CB_8EDB4ADA2F73__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


enum typobjet {POLYEDRE=0, BOITE=1, SPHERE=2, CYLINREVOL=3, CONEREVOLTRONQ=4, CYLINSPLINE=5, SPLINE3DREVOL=6, SPLINE3DEXTRU=7, SPLINE3DEDITABLE=8};


#include "matrice.h"
#include "Point3D.h"
#include "Camera.h"
#include "imcouleur.h"
#include "Rayon.h"
#include "Couleur.h"
#include "Spline2D.h"
#include "SurfaceSpline.h"

#define NBMAXARETES 1000


class Sourcelum;
class imcouleur;


//////////////////////////////////////////////////////////////////////
// classe Facette : represente une facette d'un polyedre 3D (voir classe Objet3D)
//////////////////////////////////////////////////////////////////////

class Facette{


	friend class Objet3D;
	friend class Scene3D;
	friend class Scene3DRay;
	friend class Scene3DRadio;
	friend class Cloche;
	friend class Sphere;
	friend class Conerevol;
	friend class Cylinrevol;
	friend class Conerevoltronq;
	friend class Cylinspline;
	friend class Spline3Drevol;
	friend class Spline3Dextru;
	friend class Polyedre;
	friend class Spline3DEditable;
	friend class ObjectToIntersect;

	int nbsomm;  // number of vertices of the face
	int * tabnosomm;    // array of numbers of vertices of the face.
						// these numbers refer to indexes in the tabsomm arry of the Objet3D class
//	double couleurR, couleurG, couleurB;  // couleur individualisee pour chaque facette
//	double coef_rd;       // coefficients de reflexion difuse
//	double coef_ambiant;  // coefficient de reflexion de la lumiere ambiante
//	double coef_rs;       // coefficients de reflexion speculaire

	Point3D normale;  // vecteur normal unitaire au plan contenant la facette
					  // l'equation du plan contenant la facette est Ax + By + Cz + D = 0 
	double D;		  // A, B et C sont respectivement egaux a normale.x, normale.y et normale.z

	char notexture;

public:
	Boiteenglobante boundingbox;


public:

	// constructeur, destructeur, operateur = 
	Facette(void){nbsomm = 0; tabnosomm = NULL; notexture=0;}
	Facette(int nb);
	~Facette(){delete [] tabnosomm; tabnosomm = NULL; nbsomm = 0;}
	Facette(Facette &);
	Facette & operator=(Facette &);


	// calcul de l'equation du plan de la facette et de la normale au plan
	void calculnormaleetplan(Sommet*);


	// manipulateurs :
	int & nbresomm(void){return nbsomm;}
	int* tabnumsomm(void){return tabnosomm;}
};


//////////////////////////////////////////////////////////////////////
// Classe Objet3D : classe de base dont derivent toutes les classes sphere, cone, etc...
//////////////////////////////////////////////////////////////////////

class Objet3D  
{
friend class Scene3D;
friend class Scene3DRay;
friend class Scene3DRadio;
friend class ObjectLeave;
friend class DiscreteSceneGeometry;
friend class ObjectToIntersect;


protected:

	int numero;

	// Un objet 3D contient un polyedre necessaire a l'affichage par z-buffer

	Sommet *tabsomm;  // array of vertices
	int nbsomm;        // number of vertices
	int nbfaces;       // nombre de faces du polyedre
	Facette* faces;    // tableau des faces du polyedre

	Matrice rotation;  // matrice de passage du repere fixe de la scene au repere lie a l'objet 

	Point3D origine;   // translation du repere de l'objet par rapport au repere de la scene
	double scalex, scaley, scalez;  // changements d'echelle sur l'objet
	double rotx, roty, rotz;


//	double * coordtextureX; // array of texture coordinates
//	double * coordtextureY; // array of texture coordinates


	MaterialData material;
	TextureData textures;

	
	// boounding boxes and so on (should be improved)
public :
	Boiteenglobante boundingbox;
	Boiteenglobante *tabboundingbox;
	int * nofacesdansboites;
	int * indicesfinboites;
	int nbboites;
	int racinecubiquenbboites;


public:

	// constructeurs et destructeur, operateur =
	Objet3D();
	virtual ~Objet3D();
	Objet3D(Objet3D &);
	Objet3D(double x, double y, double z, 
		double scax, double scay, double scaz, 
		double rx, double ry, double rz, 
			MaterialData mat, const TextureData &text);
	Objet3D & operator=(Objet3D &);

	// recopies d'un objet 3D :
	virtual Objet3D * copie(void)=0;  // virtuel, permet de recopier les donnees propres aux objets derives
	void copieObjet3D(Objet3D&);

	virtual Surface *GetSurface(void)=0;

	// fonction d'�dition des propri�t�s;
	virtual Objet3D * edite(int nbsplines2D, Spline2D** pSplines2D)=0;
	void transform(Point3D translat, Point3D orig, double sca, Point3D diraxe, double angle);

	// manipulateurs :
	int & nbresomm(void){return nbsomm;}
	int & nbrefaces(void){return nbfaces;}
	int getnumero(void){return numero;}
	Point3D &getorigine(void){return origine;}
	Matrice &getrot(void){return rotation;}
	double &getscax(void){return scalex;}
	double &getscay(void){return scaley;}
	double &getscaz(void){return scalez;}
	Sommet * tableausomm(void){return tabsomm;}
	Facette* facettes(void){return faces;}

	double attenuation(void){return (material.emitance != 0) ? 1 : ((material.coef_ti + material.coef_td) > 1 ? 1 : (material.coef_ti + material.coef_td));}


	virtual typobjet gettype(void)=0;

	// export functions
	void ecritdonneesobjet3D(ostream& fich);
	virtual void ecritfich(ostream& fich)=0;


	// interpolation de tout a la fois normale, derivees, intensites, cas d'une face a 3 sommets:
	Sommet interpolesommettriang(const Facette& face, Point3D point) const;

	// interpolation de tout a la fois normale, derivees, intensites, cas d'une face a 4 sommets:
	Sommet interpolesommetcarre(const Facette& face, Point3D point) const;


	Point3D calculnormalebump(char notext, double coordX, double coordY, Point3D dpsds, Point3D dpsdt);

	// interpolation de la normale pour eclairement lisse de Phong, cas d'une face a 3 sommets:
	Point3D interpolenormaletriang(const Facette& face, Point3D point) const;

	// interpolation de la normale pour eclairement lisse de Phong, cas d'une face a 4 sommets:
	Point3D interpolenormalecarre(const Facette& face, Point3D point) const;

	// interpolation de la couleur pour eclairement lisse de Gouraud, cas d'une face a 3 sommets:
//	Intensitesgouraud interpolegouraudtriang(const Facette& face, Point3D point) const;

	// interpolation de la couleur pour eclairement lisse de Gouraud, cas d'une face a 4 sommets:
//	Intensitesgouraud interpolegouraudcarre(const Facette& face, Point3D point) const;




	// functions for ray-tracing :

	Point3D	calculnormalelancer(const Facette &face, Point3D p3d, bool phong);


	// ray-object intersection using polyhedron
	bool calculintersectpolyedre(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture);

	// ray-object intersection testing using polyhedra
//	bool testintersectpolyedre(const Rayon & ray_sce, double tlimit);

	// virtual ray-object intersection method (better for spheres, boxes, and so on...)
	virtual bool calculintersect(Rayon ray_sce,
								ResultIntersect &resinter,  // resultat de l'intersection
								bool testshadow, double& attenuat, double distance,
								bool phong, bool texture)=0;
//	virtual bool testintersect(const Rayon & ray_sce, double tlimit)=0;
	void copiedonnees(ResultIntersect & resinter);

	virtual double computesolidangle(Point3D p3d, double & costhetamax)=0;

};


//////////////////////////////////////////////////////////////////////
// classe Sourcelum : represente une source lumineuse ponctuelle non directionnelle
//////////////////////////////////////////////////////////////////////

// class for light sources

class Sourcelum{
	friend class Scene3D;
	friend class Scene3DRay;
	friend class Scene3DRadio;

	Point3D pos;  // position dans l'espace
	double intensiteR, intensiteG, intensiteB;  // intensites dans le rouge, vert et bleu
	bool allumee;
	Sourcelum(void){pos = Point3D(0,0,0); intensiteR=intensiteG=intensiteB=0; allumee=true;
					directionnel=false; attenuationdist=false;} 

	bool directionnel;
	Point3D direction;
	Point3D directionnorme;
	int exponentdirect;
	bool attenuationdist;
	double c1, c2, c3;

};


Point3D interpolenormaletriang1(Point3D p1, Point3D p2, Point3D p3,
								Point3D n1, Point3D n2, Point3D n3,
								Point3D point);

void interpoletexturetriang1(Point3D p1, Point3D p2, Point3D p3,
								double n1, double n2, double n3,
								Point3D point, double& res, int dimtexture, bool cyclique);




#endif // !defined(AFX_OBJET3D_H__73899100_48CC_11D3_B1CB_8EDB4ADA2F73__INCLUDED_)
