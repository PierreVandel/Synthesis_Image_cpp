

#include "stdafx.h"
#include "Synth.h"
#include "Scene3D.h"
#include "Polygone2d.h"
#include "imcouleur.h"




#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif





#define epsilon 0.01



void cliprectangle(double * InputX, double * InputY, int nbsommin,
				   double * OutputX, double * OutputY, int & nbsommout,
				   double xmin, double xmax, double ymin, double ymax);


	// Pour la fonction clip suivante,
	// on doit avoir : tabx[nbsomm] == tabx[0] et idem pour y


void Scene3D::clip(int nbsommets, double *tabx, double *taby,
          int* outcount, double *taboutx, double * tabouty, 
              double xmin, double ymin, double xmax, double ymax)
{
   double xIn, xOut, yIn, yOut;
   double tInX, tOutX, tInY, tOutY;
   double tOut1, tIn2, tOut2;
   double deltaX, deltaY;
   int i;

   for (i = 0 ; i <= nbsommets ; i++){
      if (tabx[i] > INFINI)
         tabx[i] = INFINI - 10;
      if (tabx[i] < -INFINI)
         tabx[i] = -INFINI + 10;
      if (taby[i] > INFINI)
         taby[i] = INFINI - 10;
      if (taby[i] < -INFINI)
         taby[i] = -INFINI + 10;

   }


   *outcount = 0;  // init du nombre d'aretes en sortie

   for (i = 0 ; i < nbsommets && *outcount < nbmaxaretes - 10 ; i++){
      deltaX = tabx[i+1] - tabx[i];
      deltaY = taby[i+1] - taby[i];

      if (deltaX > 0 || (abs(deltaX)<epsilon && tabx[i] > xmax)){
          xIn = xmin;
          xOut = xmax;
      }else{
          xIn = xmax;
          xOut = xmin;
      }
      if (deltaY > 0 || (abs(deltaY)<epsilon && taby[i] > ymax)){
          yIn = ymin;
          yOut = ymax;
      }else{
          yIn = ymax;
          yOut = ymin;
      }
      
      if (abs(deltaX) > epsilon)
         tOutX = (xOut - tabx[i])/deltaX;
      else
         if (tabx[i] <= xmax && xmin <= tabx[i])
            tOutX = INFINI;
         else
            tOutX = -INFINI;

      if (abs(deltaY)>epsilon)
         tOutY = (yOut - taby[i])/deltaY;
      else
         if (taby[i] <= ymax && ymin <= taby[i])
            tOutY = INFINI;
         else
            tOutY = -INFINI;

      if (tOutX < tOutY){
         tOut1 = tOutX; 
         tOut2 = tOutY;
      }else{
         tOut1 = tOutY;
         tOut2 = tOutX;
      }

      if (tOut2 > 0){
         if (deltaX != 0)
            tInX = (xIn - tabx[i])/deltaX;
         else
            tInX = -INFINI;
         if (deltaY != 0)
            tInY = (yIn - taby[i])/deltaY;
         else
            tInY = -INFINI;
         

         if (tInX < tInY)
            tIn2 = tInY;
         else
            tIn2 = tInX;

         if (tOut1 < tIn2){   // pas de segment visible
            if (0 < tOut1 && tOut1 <= 1){
               if (tInX < tInY){
                  taboutx[*outcount] = xOut;
                  tabouty[*outcount] = yIn;
                  (*outcount)++;
               }else{
                  taboutx[*outcount] = xIn;
                  tabouty[*outcount] = yOut;
                  (*outcount)++;
               }
            }
         }else{     // le segment traverse la fenetre
            if (0 < tOut1 && tIn2 <= 1){
               if (0 < tIn2){  // segment visible
                  if (tInX > tInY){
                     taboutx[*outcount] = xIn;
                     tabouty[*outcount] = taby[i] + tInX*deltaY;
                     (*outcount)++;
                  }else{
                     taboutx[*outcount] = tabx[i] + tInY*deltaX;
                     tabouty[*outcount] = yIn;
                     (*outcount)++;
                  }
                }

               if (1 > tOut1){
                     if (tOutX < tOutY){
                        taboutx[*outcount] = xOut;
                        tabouty[*outcount] = taby[i] + tOutX*deltaY;
                        (*outcount)++;
                     }else{
                        taboutx[*outcount] = tabx[i] + tOutY*deltaX;
                        tabouty[*outcount] = yOut;
                        (*outcount)++;
                     }
                   
               }else{
                  taboutx[*outcount] = tabx[i+1];
                  tabouty[*outcount] = taby[i+1];
                  (*outcount)++;
               }
            }

         }  // fin du else
         if (0 < tOut2 && tOut2 <= 1){
            taboutx[*outcount] = xOut;
            tabouty[*outcount] = yOut;
            (*outcount)++;
         }
      }  // fin si tOut2 > 0
   } // fin du for
}









void Scene3D::parcourspolyparal(Facette face, Objet3D& objet, float **minz)
{

	
}

void Scene3D::zbufferparal(imcouleur& bitmap_dib)
{

}







// calcul du point de la facette 3D se projetant du le pixel (x,y)

Point3D Scene3D::calculpoint3d(const Facette & face, int x, int y, double d){


	return Point3D(0,0,0);
}


// calcul de la normale en un point p3d sur une facette face
// resultant eventuellement d'une interpolation en cas d'eclairement lisse de Phong

Point3D Scene3D::calculnormale(Objet3D & objet, const Facette &face, Point3D p3d, bool phong){

	return Point3D(0,0,1);
}



Couleur Scene3D::calculcouleurgouraud(Intensitesgouraud intens, Couleur couleurobjet){


	return Couleur(0,0,0);
}



Intensitesgouraud Scene3D::calculsommetgouraud(Point3D p3d, Point3D  normale, 
											   const Objet3D & objet, 
											   bool ambiante, bool difuse, bool specular){


	return Intensitesgouraud();

}



Couleur Scene3D::calculcouleur(Couleur couleurobjet, Point3D p3d, Point3D  normale, Objet3D & objet, bool ambiante, bool difuse, bool specular){



	Couleur I;
	double costheta, cosalpha;
	Point3D L, V, R;

	if (normale * p3d > 0)				// p3d=OM alors que V=MO
		normale = -normale;
	I.R = 0;I.G = 0;I.B = 0;

	V = -p3d;
	V.normer();
	R = 2 * normale * (normale * V) - V;

	if (ambiante) {
		I.R = objet.material.coef_ambiant * lumambiantR * couleurobjet.R;
		I.G = objet.material.coef_ambiant * lumambiantG * couleurobjet.G;
		I.B = objet.material.coef_ambiant * lumambiantB * couleurobjet.B;
	}

	for (int i = 0; i < nblum; i++) {
		// Diffus 
		L = tablum[i].pos - p3d;
		L.normer();
		costheta = normale * L;

		if (costheta > 0 && difuse) {
			I.R += tablum[i].intensiteR * objet.material.coef_rd * costheta * couleurobjet.R;
			I.G += tablum[i].intensiteG * objet.material.coef_rd * costheta * couleurobjet.G;
			I.B += tablum[i].intensiteB * objet.material.coef_rd * costheta * couleurobjet.B;
		}

		//speculaire
		cosalpha = R * L;
		if (cosalpha > 0 && specular) {
			double cosalphapuis = cosalpha;
			for (int j = 1; j < objet.material.exp_rs;j++)
				cosalphapuis *= cosalpha;

			I.R += tablum[i].intensiteR * objet.material.coef_rs * cosalphapuis;
			I.G += tablum[i].intensiteG * objet.material.coef_rs * cosalphapuis;
			I.B += tablum[i].intensiteB * objet.material.coef_rs * cosalphapuis;
		}

	}



	return I;

}




Point3D Objet3D::calculnormalebump(char notext, double coordX, double coordY, Point3D dpsds, Point3D dpsdt){

	return Point3D(0,0,1);
}



Couleur Scene3D::calculcouleur(Objet3D & objet, const Facette & face, 
							Point3D p3d, Point3D normale,  
							bool ambiante, bool difuse, bool specular,
							bool phong, bool gouraud, bool texture){


	if (phong) {
		Sommet P;
		if (face.nbsomm == 3)
			P = objet.interpolesommettriang(face, p3d);
		
		else if (face.nbsomm == 4)
			P = objet.interpolesommetcarre(face, p3d);
		
		else
			P.normale = normale;

		if (objet.textures.withtexture[face.notexture])
		{
			Couleur couleurTexture;
			objet.textures.imtexture[face.notexture].getpixel(P.coordtextureX * (objet.textures.imtexture[face.notexture].largeur() - 1), P.coordtextureY * (objet.textures.imtexture[face.notexture].hauteur() - 1), couleurTexture.R, couleurTexture.G, couleurTexture.B);
			return calculcouleur(couleurTexture, p3d, P.normale, objet, ambiante, difuse, specular);
		}

		return calculcouleur(objet.material.couleur, p3d, P.normale, objet, ambiante, difuse, specular);
	}
	else
	{
		return calculcouleur(objet.material.couleur,p3d,normale,objet,ambiante,difuse,specular);
	}

}


void Scene3D::parcourspolyperspect(Facette& face, Objet3D& objet, bool phong,double d)
{
	int i;
	for(i=0;i<face.nbsomm;i++){
		double dsurz=d/objet.tabsomm[face.tabnosomm[i]].pos.z;
		inclipx[i]=objet.tabsomm[face.tabnosomm[i]].pos.x*dsurz;
		inclipy[i]=objet.tabsomm[face.tabnosomm[i]].pos.y*dsurz;
	}

	int nbsommout;
	cliprectangle(inclipx, inclipy, face.nbsomm, outclipx, outclipy, nbsommout,
				  -dim2Dx/2, dim2Dx/2-1,-dim2Dy/2, dim2Dy/2-1);




	int x1,x2,y1,y2;
	x1=(int) (outclipx[0]+0.5);
	y1=(int) (outclipy[0]+0.5);

	for(i=0;i<nbsommout-1;i++){		
		x2=(int) (outclipx[i+1]+0.5);
		y2=(int) (outclipy[i+1]+0.5);
		tabaretes[i]=Arete(x1,y1,x2,y2);
		x1=x2;
		y1=y2;
	}
	tabaretes[nbsommout-1]=Arete(x1,y1,(int) (outclipx[0]+0.5),(int) (outclipy[0]+0.5)); // la derniere





	face.calculnormaleetplan(objet.tabsomm);	// dans Objet3D : ATTENTION on passe le tableau de TOUS les sommets de l'objet
										// il faudra selectionner ceux de la facette en question
	
	int nbaretes=nbsommout;
	TableTA TA(tabaretes, nbaretes);
	ListeTAA TAA;
	CelluleTAA *q;
	int Q;
	char parite;
	int y;

	// calcul de la plus petite valeur de ybas:
	int minybas = TA.calcminy(tabaretes, nbaretes);
	// calcul de la plus grande valeur de ybas:
	int maxybas = TA.calcmaxybas(tabaretes, nbaretes);
	// calcul de la plus grande valeur de yhaut
	int maxyhaut = TA.calcmaxyhaut(tabaretes, nbaretes);

    TAA.L = NULL;

	for (y = minybas ; y < maxyhaut ; y++){

		TAA.supprimearetestraitees(y);
		if (y <= maxybas)
			TAA.interclassement(TA.tab[y - minybas]);
		
		parite = 0;
		for (q = TAA.L ; q!=NULL && q->suiv != NULL ; q = q->suiv){
			parite = !parite;
			if (parite)
				for (i = q->data.x ; i <= q->suiv->data.x ; i++){
					double t0;
					Point3D xyd(i,y,d);

					t0=-face.D/(face.normale*xyd);
					double prof=t0*d;
					Point3D M(t0*i,t0*y,prof);	//point du polyg se projetant en (i,y,d)
					int x1=i+dim2Dx/2;			// On se repositionne pour la matrice
					int y1=y+dim2Dy/2;
					if (prof>1e-10 && prof<minz[x1][y1]){
						minz[x1][y1]=(float) prof;



						Couleur coul=calculcouleur(objet,face,M,face.normale,enableambiante,enabledifuse,enablespecular,enablephong,enablegouraud,enabletexture);
						
						if (coul.R>1) coul.R=1;	//seuillage
						if (coul.G>1) coul.G=1;
						if (coul.B>1) coul.B=1;

						bufferR[x1][y1]=(unsigned char) (coul.R*255);
						bufferG[x1][y1]=(unsigned char) (coul.G*255);
						bufferB[x1][y1]=(unsigned char) (coul.B*255);


				/*		bufferR[x1][y1]=(unsigned char) (objet.material.couleur.R*255);
						bufferG[x1][y1]=(unsigned char) (objet.material.couleur.G*255);
						bufferB[x1][y1]=(unsigned char) (objet.material.couleur.B*255);
				*/	

					}
				}
					
		}

		for (q = TAA.L ; q!=NULL ; q = q->suiv){
			q->increment += q->data.numerat;
			Q = q->increment / q->data.denomin;
			q->data.x += Q;
			q->increment -= Q * q->data.denomin;
		}

		// Pour autointersections :

		TAA.traiteautointersections();

		
	}

}







void Scene3D::calculeinetnsitesommetsgouraud(void){


}

void Scene3D::zbufferperspect(imcouleur& bitmap_dib)
{

	int i,j;

	//distance de l'observateur � l'ecran
	double d=dim2Dx/(2*tan(tabcam[nocamselect]->accesanglex()/2));



	for(i=0;i<dim2Dx;i++)
		for(j=0;j<dim2Dy;j++){
			bufferR[i][j]=(unsigned char) (fondR*255);
			bufferG[i][j]=(unsigned char) (fondG*255);
			bufferB[i][j]=(unsigned char) (fondB*255);
			minz[i][j]=1000000000;
		}
	

	Celluleobj *p=objets.L;

	while (p!=NULL){
		for(i=0;i<p->pobjet->nbfaces;i++)
			parcourspolyperspect(p->pobjet->faces[i],*(p->pobjet), true,d);

		p=p->suiv;
	}



	int x,y;
	int X, Y;
	int moyenneR, moyenneG, moyenneB;
	int nbpoints = (etatzbuffer == 1) ? 1 : ((etatzbuffer == 2) ? 4 : 9);

	X=0;
	for (x = 0; x < dimfenetrex ; x++){
		Y=0; 
		for (y = 0; y < dimfenetrey ; y++){
			moyenneR = moyenneG = moyenneB = 0;

			for (i = 0 ; i < etatzbuffer ; i++)
				for (j = 0 ; j < etatzbuffer ; j++){
					moyenneR += bufferR[X+i][Y+j];
					moyenneG += bufferG[X+i][Y+j];
					moyenneB += bufferB[X+i][Y+j];
				}

			moyenneR /= nbpoints;
			moyenneG /= nbpoints;
			moyenneB /= nbpoints;

			bitmap_dib.setpixel(x, y, moyenneR, moyenneG, moyenneB);
			Y+=etatzbuffer;
		}
		X+=etatzbuffer;
	}



	

}






// Fonction ind�pendante fenetrage rectangle : recuperee ensuite pour le 3D
// Et exploitant les optimisations de la fenetre particuli�re

void cliprectangle(double * InputX, double * InputY, int nbsommin,
				   double * OutputX, double * OutputY, int & nbsommout,
				   double xmin, double xmax, double ymin, double ymax){



/*	points de la fenetre
		A0		A1

		A3		A2 
*/

	bool prem, deux;
	int i, j;

	// 1ere horizontale : /(A0,A1) 
	if (ymin < InputY[0])
		prem = true;
	else
		prem = false;
	nbsommout = 0;
	for (j=1; j <= nbsommin ; j++){
		if (ymin < InputY[j%nbsommin])
			deux = true;
		else
			deux = false;	
		if (prem && deux){
			OutputX[nbsommout]=InputX[j%nbsommin];
			OutputY[nbsommout]=InputY[j%nbsommin];
			nbsommout++;
		}
		else{
			if (prem){
				OutputY[nbsommout]=ymin;
				OutputX[nbsommout]= ((InputX[j%nbsommin] - InputX[j-1])/(InputY[j%nbsommin] - InputY[j-1]))* (ymin - InputY[j-1]) + InputX[j-1];
				nbsommout++;
			}
			else
				if (deux){
					OutputY[nbsommout]=ymin;
					OutputX[nbsommout]= ((InputX[j%nbsommin] - InputX[j-1])/(InputY[j%nbsommin] - InputY[j-1]))* (ymin - InputY[j-1]) + InputX[j-1];
					nbsommout++;
					OutputY[nbsommout]= InputY[j%nbsommin];
					OutputX[nbsommout]= InputX[j%nbsommin];
					nbsommout++;
				}
		}
		prem = deux;
	}
	for (i=0; i<nbsommout; i++){
		InputX[i] = OutputX[i];
		InputY[i] = OutputY[i];
	}
	nbsommin = nbsommout;



// 1ere verticale : /(A1,A2) 
	if (InputX[0] < xmax)
		prem = true;
	else
		prem = false;
	nbsommout = 0;
	for (j=1; j <= nbsommin ; j++){
		if (InputX[j%nbsommin] < xmax)
			deux = true;
		else
			deux = false;	
		if (prem && deux){
			OutputX[nbsommout]=InputX[j%nbsommin];
			OutputY[nbsommout]=InputY[j%nbsommin];
			nbsommout++;
		}
		else{
			if (prem){
				OutputX[nbsommout]=xmax;
				OutputY[nbsommout]= ((InputY[j%nbsommin] - InputY[j-1])/(InputX[j%nbsommin] - InputX[j-1]))* (xmax - InputX[j-1]) + InputY[j-1];
				nbsommout++;
			}
			else
				if (deux){
					OutputX[nbsommout]=xmax;
					OutputY[nbsommout]= ((InputY[j%nbsommin] - InputY[j-1])/(InputX[j%nbsommin] - InputX[j-1]))* (xmax - InputX[j-1]) + InputY[j-1];
					nbsommout++;
					OutputY[nbsommout]= InputY[j%nbsommin];
					OutputX[nbsommout]= InputX[j%nbsommin];
					nbsommout++;
				}
		}
		prem=deux;
	}
	for (i=0; i<nbsommout; i++){
		InputX[i] = OutputX[i];
		InputY[i] = OutputY[i];
	}
	nbsommin = nbsommout;

	// 2eme horizontale : /(A2,A3) 
	if (InputY[0] < ymax)
		prem = true;
	else
		prem = false;
	nbsommout = 0;
	for (j=1; j <= nbsommin ; j++){
		if (InputY[j%nbsommin] < ymax)
			deux = true;
		else
			deux = false;	
		if (prem && deux){
			OutputX[nbsommout]=InputX[j%nbsommin];
			OutputY[nbsommout]=InputY[j%nbsommin];
			nbsommout++;
		}
		else{
			if (prem){
				OutputY[nbsommout]=ymax;
				OutputX[nbsommout]= ((InputX[j%nbsommin] - InputX[j-1])/(InputY[j%nbsommin] - InputY[j-1]))* (ymax - InputY[j-1]) + InputX[j-1];
				nbsommout++;
			}
			else
				if (deux){
					OutputY[nbsommout]=ymax;
					OutputX[nbsommout]= ((InputX[j%nbsommin] - InputX[j-1])/(InputY[j%nbsommin] - InputY[j-1]))* (ymax - InputY[j-1]) + InputX[j-1];
					nbsommout++;
					OutputY[nbsommout]= InputY[j%nbsommin];
					OutputX[nbsommout]= InputX[j%nbsommin];
					nbsommout++;
				}
		}
		prem = deux;
	}
	for (i=0; i<nbsommout; i++){
		InputX[i] = OutputX[i];
		InputY[i] = OutputY[i];
	}
	nbsommin = nbsommout;


// 2eme verticale : /(A3,A0) 
	if (InputX[0] > xmin)
		prem = true;
	else
		prem = false;
	nbsommout = 0;
	for (j=1; j <= nbsommin ; j++){
		if (InputX[j%nbsommin] > xmin)
			deux = true;
		else
			deux = false;	
		if (prem && deux){
			OutputX[nbsommout]=InputX[j%nbsommin];
			OutputY[nbsommout]=InputY[j%nbsommin];
			nbsommout++;
		}
		else{
			if (prem){
				OutputX[nbsommout]=xmin;
				OutputY[nbsommout]= ((InputY[j%nbsommin] - InputY[j-1])/(InputX[j%nbsommin] - InputX[j-1]))* (xmin - InputX[j-1]) + InputY[j-1];
				nbsommout++;
			}
			else
				if (deux){
					OutputX[nbsommout]=xmin;
					OutputY[nbsommout]= ((InputY[j%nbsommin] - InputY[j-1])/(InputX[j%nbsommin] - InputX[j-1]))* (xmin - InputX[j-1]) + InputY[j-1];
					nbsommout++;
					OutputY[nbsommout]= InputY[j%nbsommin];
					OutputX[nbsommout]= InputX[j%nbsommin];
					nbsommout++;
				}
		}
		prem=deux;
	}


}


