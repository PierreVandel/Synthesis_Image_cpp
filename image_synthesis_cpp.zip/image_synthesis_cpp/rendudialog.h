#if !defined(AFX_RENDUDIALOG_H__2E9AE710_ABDC_4061_BDF7_F8B299DCF771__INCLUDED_)
#define AFX_RENDUDIALOG_H__2E9AE710_ABDC_4061_BDF7_F8B299DCF771__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RenduDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRenduGlobalDialog dialog

class CRenduGlobalDialog : public CDialog
{
// Construction
public:
	CRenduGlobalDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRenduGlobalDialog)
	enum { IDD = IDD_OPTIONS_RENDU };
	double	m_pourcentnegl;
	int		m_procrecur;
	int		m_nbfacesmax;
	int		m_maxdepth;
	double	m_minsizecell;
	double	m_rapportthreshold;
	double	m_seuiladapt;
	BOOL	m_enableextendedlight;
	int		m_nbrayslights;
	BOOL	m_save_calcul;
	int		m_winwidth;
	int		m_winheight;
	BOOL	m_use_bsp;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRenduGlobalDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRenduGlobalDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CMyProgresDialog dialog

class CMyProgresDialog : public CDialog
{
// Construction
public:
	CMyProgresDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMyProgresDialog)
	enum { IDD = IDD_PROGRESS };
	CProgressCtrl	m_progctrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyProgresDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMyProgresDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RENDUDIALOG_H__2E9AE710_ABDC_4061_BDF7_F8B299DCF771__INCLUDED_)
