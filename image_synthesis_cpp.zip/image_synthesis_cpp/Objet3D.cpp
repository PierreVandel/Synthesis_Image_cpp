// Objet3D.cpp: implementation of the Objet3D class.
//
//////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "Synth.h"
#include "Objet3D.h"
#include "Objetderiv.h"
#include "Polygone2d.h"

#include <math.h>
// #include <limits.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


#define NBMAXARETES 1000
#define INFINI 1.5e38


//////////////////////////////////////////////////////////////////////
// Fonctions de la classe Facette
//////////////////////////////////////////////////////////////////////

// allocation d'une facette avec nb sommets

Facette::Facette(int nb){
	nbsomm = nb;
	tabnosomm = new int[nbsomm];
	notexture=0;
}


// constructeur par recopie

Facette::Facette(Facette & F)
{
	nbsomm = F.nbsomm;
	normale = F.normale;
	D = F.D;
//	coef_rd = F.coef_rd;	
	tabnosomm = new int[nbsomm];
	for (int i = 0 ; i < nbsomm ; i++)
		tabnosomm[i] = F.tabnosomm[i];

//	couleurR = F.couleurR;
//	couleurG = F.couleurG;
//	couleurB = F.couleurB;
//	coef_rd = F.coef_rd;
//	coef_rs = F.coef_rs;
//	coef_ambiant = F.coef_ambiant;
	normale = F.normale; 
	D = F.D;

	notexture=F.notexture;
}

// surcharge de l'operateur d'affectation

Facette & Facette::operator=(Facette & F)
{
	if (&F == this)
		return (*this);

	if (nbsomm)
		delete [] tabnosomm;

	nbsomm = F.nbsomm;
	tabnosomm = new int[nbsomm];
	for (int i = 0 ; i < nbsomm ; i++)
		tabnosomm[i] = F.tabnosomm[i];

//	couleurR = F.couleurR;
//	couleurG = F.couleurG;
//	couleurB = F.couleurB;
//	coef_rd = F.coef_rd;
//	coef_rs = F.coef_rs;
//	coef_ambiant = F.coef_ambiant;
	normale = F.normale; 
	D = F.D;

	notexture=F.notexture;

	return (*this);
}



// calcul de l'equation du plan contenant une facette et de la normale au plan
// l'equation du plan est Ax + By + Cz + D = 0
// avec A == normale.x, B == normale.y et C == normale.z

void Facette::calculnormaleetplan(Sommet * tabsomm){

Point3D vec1,vec2, n;

	vec1=tabsomm[this->tabnosomm[1]].pos-tabsomm[this->tabnosomm[0]].pos;
	vec2=tabsomm[this->tabnosomm[2]].pos-tabsomm[this->tabnosomm[0]].pos;
	n=vec1^vec2;
	if (n.norme()>1e-10){
		n.normer();
		this->normale=n;
		this->D=-(n*tabsomm[this->tabnosomm[0]].pos);
	}
	else{
		int i=3;
		while(n.norme()<=1e-10){
			vec2=tabsomm[this->tabnosomm[i]].pos-tabsomm[this->tabnosomm[0]].pos;
			n=vec1^vec2;
			i++;
		}
		n.normer();
		this->normale=n;
		this->D=-(n*tabsomm[this->tabnosomm[0]].pos);
	}

}




//////////////////////////////////////////////////////////////////////
// Fonctions de la classe Objet3D
//////////////////////////////////////////////////////////////////////


// constructeur par defaut

Objet3D::Objet3D()
{
	tabsomm = NULL;
	nbsomm = 0;
	nbfaces = 0;
	faces = NULL;

	rotation = Matrice(3,3);



	rotation[0][0] = rotation[1][1] = rotation[2][2] = 1;
	origine = Point3D(0,0,0);
}


// partie de la construction d'un Objet3D qui est commune
// a tous les objets spheres, cones, cylindres, etc...
// notament initialisation de la matrice de passage du repere
// fixe de la scene au repere lie a l'objet lie a l'objet au repere 

Objet3D::Objet3D(double x, double y, double z, 
				double scax, double scay, double scaz, 
				double rx, double ry, double rz, 
				MaterialData mat, const TextureData &text)
{
	tabsomm = NULL;
	nbsomm = 0;
	nbfaces = 0;
	faces = NULL;

	textures = text;

	material = mat;

	scalex = scax;
	scaley = scay;
	scalez = scaz;
	rotx = rx;
	roty = ry;
	rotz = rz;

	origine.x = x;
	origine.y = y;
	origine.z = z;

	Matrice mrot(3,3);
	double teta;
	double costeta;
	double sinteta;


	// initialisation de la matrice rotation a la matrice identite
	rotation = Matrice(3,3);
	rotation[0][0] = rotation[1][1] = rotation[2][2] = 1;

	////////////////////////////////////////////////////////////
	// Rotation selon 0x

	// rotation autour de l'axe Ox d'un angle teta en radians
	teta = (rotx * pi / 180.0);  // conversion en radians
	costeta = cos(teta);
	sinteta = sin(teta);

	// matrice de la rotation d'un angle teta autour de Ox
	// remarque : la martice mrot a ete initialisee a zero par le constructeur de matrice
	mrot[0][0] = 1;
	mrot[1][1] = (double)costeta;
	mrot[2][1] = (double)sinteta;
	mrot[1][2] = (double)-sinteta;
	mrot[2][2] = (double)costeta;

	// composition des rotations

	rotation = mrot * rotation; 

	// remise a zero des coefficients non nuls de mrot
	mrot[0][0] = 0;
	mrot[1][1] = 0;
	mrot[2][1] = 0;
	mrot[1][2] = 0;
	mrot[2][2] = 0;


	////////////////////////////////////////////////////////////
	// Rotation selon 0y

	// rotation autour de l'axe Oy d'un angle teta en radians
	teta = (roty * pi / 180.0);  // conversion en radians
	costeta = cos(teta);
	sinteta = sin(teta);

	// matrice de la rotation d'un angle teta autour de Oy
	mrot[0][0] = (double)costeta;
	mrot[1][1] =  1;
	mrot[2][0] = (double)-sinteta;
	mrot[0][2] = (double)sinteta;
	mrot[2][2] = (double)costeta;

	// composition des rotations
	rotation = mrot * rotation; 

	// remise a zero des coefficients non nuls de mrot
	mrot[0][0] = 0;
	mrot[1][1] = 0;
	mrot[2][0] = 0;
	mrot[0][2] = 0;
	mrot[2][2] = 0;

	////////////////////////////////////////////////////////////
	// Rotation selon 0z

	// rotation autour de l'axe Oz d'un angle teta en radians
	teta = (rotz * pi / 180.0);  // conversion en radians
	costeta = cos(teta);
	sinteta = sin(teta);

	// matrice de la rotation d'un angle teta autour de Oz
	mrot[0][0] = (double)costeta;
	mrot[1][1] =  (double)costeta;
	mrot[1][0] = (double)sinteta;
	mrot[0][1] = (double)-sinteta;
	mrot[2][2] = 1;

	rotation = mrot * rotation; 


}



// destructeur

Objet3D::~Objet3D()
{
	if (nbsomm){
		delete [] tabsomm;
	}
	tabsomm = NULL;
	nbsomm = 0;
	if (nbfaces)
		delete [] faces;
	nbfaces = 0;

}


// constructeur par recopie

Objet3D::Objet3D(Objet3D & obj)
{

	copieObjet3D(obj);

}


// surcharge de l'operateur d'affectation

Objet3D & Objet3D::operator=(Objet3D & obj)
{
	if (&obj == this)
		return (*this);

	if (nbsomm)
		delete [] tabsomm;
	if (nbfaces)
		delete [] faces;


	copieObjet3D(obj);

	return (*this);
}


// recopie d'un objet 3D

void Objet3D::copieObjet3D(Objet3D & obj)
{

	numero=obj.numero;

	nbsomm = obj.nbsomm;
	tabsomm = new Sommet[nbsomm];


	for (int i = 0 ; i < nbsomm ; i++){
		tabsomm[i] = obj.tabsomm[i];
	}

	nbfaces = obj.nbfaces;
	faces = new Facette[nbfaces];

	for (int i = 0 ; i < nbfaces ; i++)
		faces[i] = obj.faces[i];

	rotation = obj.rotation;
	origine = obj.origine;
	scalex = obj.scalex;
	scaley = obj.scaley;
	scalez = obj.scalez;
	rotx = obj.rotx;
	roty = obj.roty;
	rotz = obj.rotz;


	material = obj.material;

	textures = obj.textures;
	


}

 





	
