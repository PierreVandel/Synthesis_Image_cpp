// imcouleur.cpp: implementation of the imcouleur class.
//
//////////////////////////////////////////////////////////////////////

#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include "stdafx.h"
#include "Synth.h"
#include "imcouleur.h"
#include "Point3D.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif




imcouleur::imcouleur(int hauteur, int largeur){
	larg = largeur;
    haut = hauteur;
	larg_scanline = ((3*larg)%4 == 0) ? 3*larg : (3*larg + 4 - (3*larg)%4);
    bitimage = new BYTE[larg_scanline*haut];
	pbitmapinfo = new BITMAPINFO;
	pbitmapinfo->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	pbitmapinfo->bmiHeader.biWidth = larg;
	pbitmapinfo->bmiHeader.biHeight = haut;
	pbitmapinfo->bmiHeader.biPlanes = 1;
	pbitmapinfo->bmiHeader.biBitCount = 24;
	pbitmapinfo->bmiHeader.biCompression = BI_RGB;
	pbitmapinfo->bmiHeader.biSizeImage = 0;
	pbitmapinfo->bmiHeader.biXPelsPerMeter = 40000;
	pbitmapinfo->bmiHeader.biYPelsPerMeter = 40000;
	pbitmapinfo->bmiHeader.biClrUsed = 0;
	pbitmapinfo->bmiHeader.biClrImportant = 0;
}


imcouleur& imcouleur::operator=(const imcouleur& im){ 
	if (&im != this){
		haut=im.haut; larg=im.larg;
		larg_scanline = im.larg_scanline;
		bitimage = new BYTE[larg_scanline*haut];
		memcpy(bitimage, im.bitimage, larg_scanline*haut*sizeof(BYTE));
		pbitmapinfo = new BITMAPINFO;
		pbitmapinfo->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		pbitmapinfo->bmiHeader.biWidth = larg;
		pbitmapinfo->bmiHeader.biHeight = haut;
		pbitmapinfo->bmiHeader.biPlanes = 1;
		pbitmapinfo->bmiHeader.biBitCount = 24;
		pbitmapinfo->bmiHeader.biCompression = BI_RGB;
		pbitmapinfo->bmiHeader.biSizeImage = 0;
		pbitmapinfo->bmiHeader.biXPelsPerMeter = 40000;
		pbitmapinfo->bmiHeader.biYPelsPerMeter = 40000;
		pbitmapinfo->bmiHeader.biClrUsed = 0;
		pbitmapinfo->bmiHeader.biClrImportant = 0;
	}
	return (*this);
}



imcouleur::imcouleur(imcouleur& im){ 
		haut=im.haut; larg=im.larg;
		larg_scanline = im.larg_scanline;
		bitimage = new BYTE[larg_scanline*haut];
		memcpy(bitimage, im.bitimage, larg_scanline*haut*sizeof(BYTE));
		pbitmapinfo = new BITMAPINFO;
		pbitmapinfo->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		pbitmapinfo->bmiHeader.biWidth = larg;
		pbitmapinfo->bmiHeader.biHeight = haut;
		pbitmapinfo->bmiHeader.biPlanes = 1;
		pbitmapinfo->bmiHeader.biBitCount = 24;
		pbitmapinfo->bmiHeader.biCompression = BI_RGB;
		pbitmapinfo->bmiHeader.biSizeImage = 0;
		pbitmapinfo->bmiHeader.biXPelsPerMeter = 40000;
		pbitmapinfo->bmiHeader.biYPelsPerMeter = 40000;
		pbitmapinfo->bmiHeader.biClrUsed = 0;
		pbitmapinfo->bmiHeader.biClrImportant = 0;
}


bool imcouleur::setdim(int l, int h){

		if (haut*larg > 0)
			delete [] bitimage;
		larg = l;
		haut = h;
		larg_scanline = ((3*larg)%4 == 0) ? 3*larg : (3*larg + 4 - (3*larg)%4);
		if (pbitmapinfo == NULL){
			pbitmapinfo = new BITMAPINFO;
			pbitmapinfo->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
			pbitmapinfo->bmiHeader.biPlanes = 1;
			pbitmapinfo->bmiHeader.biBitCount = 24;
			pbitmapinfo->bmiHeader.biCompression = BI_RGB;
			pbitmapinfo->bmiHeader.biSizeImage = 0;
			pbitmapinfo->bmiHeader.biXPelsPerMeter = 40000;
			pbitmapinfo->bmiHeader.biYPelsPerMeter = 40000;
			pbitmapinfo->bmiHeader.biClrUsed = 0;
			pbitmapinfo->bmiHeader.biClrImportant = 0;
		}
		pbitmapinfo->bmiHeader.biWidth = larg;
		pbitmapinfo->bmiHeader.biHeight = haut;

		bitimage = new BYTE[larg_scanline*haut];
		if (bitimage != NULL)
			memset(bitimage, 0, larg_scanline*haut*sizeof(BYTE));

		return (bitimage != NULL);
}



#define ecritc(c,fp)        putc(c,fp)



void ecriti(int i, FILE* fp)
{
	int b0,b1,b2,b3;
	
	b0 = (((unsigned int) i)) & 0xFF;
	b1 = (((unsigned int) i)>>8) & 0xFF;
	b2 = (((unsigned int) i)>>16) & 0xFF;
	b3 = (((unsigned int) i)>>24) & 0xFF;
	putc(b0,fp);putc(b1,fp);putc(b2,fp);putc(b3,fp);
}

void ecrits(short i, FILE* fp)
{
	int b0,b1;
	
	b0 = (((unsigned int) i)) & 0xFF;
	b1 = (((unsigned int) i)>>8) & 0xFF;
	putc(b0,fp);putc(b1,fp);
}

//
// Construit l'entete general.
//

void imcouleur::EnteteBmp(FILE * fp,int nrow,int ncol, int nbbits)
{
	int		bl, nc;
	int		ll;

	ecritc('B',fp);ecritc('M',fp);		// Magic number
	ll = larg_scanline; 	// Taille d'une ligne.
	if (nbbits == 24)
		nc=0;
	else
		nc = 256;
	bl = 14+40+(nc*4);
	ecriti(bl + (ll*nrow),fp);
	ecrits(0,fp);				// Reserved.
	ecrits(0,fp);
	ecriti(bl,fp);				// bfoffbits.
	
	ecriti(40,fp);
	ecriti(ncol,fp);
	ecriti(nrow,fp);
	ecrits(1,fp);
	ecrits(nbbits,fp);
	ecriti(0,fp);
	ecriti(ll*nrow,fp);
	ecriti(75*39,fp);
	ecriti(75*39,fp);
	ecriti(nc,fp);
	ecriti(nc,fp);
	

}




//
// Sauvegarde des donn�es 24 bits.
//
void imcouleur::DonneesBmp(FILE* df)
{
	int		i;


	int nboctets = haut*larg_scanline;

	for (i = 0 ; i < nboctets ; i++)
		ecritc(bitimage[i],df);

  
}

//
// Fichier couleur 24 bits.
//

char imcouleur::ecritbmp(char *fich)
{
	FILE*	dfd;
	int	rotation=0;

	if  (fopen_s(&dfd, fich,"wb")!=0){
			return 0;
		}
	

	EnteteBmp(dfd,haut,larg,24);
	DonneesBmp(dfd);
	fclose(dfd);
	return(1);
}
















int liti(FILE* fp)
{
	int b0,b1,b2,b3;
	
	b0 = (unsigned int) getc(fp);
	b1 = (unsigned int) getc(fp);
	b2 = (unsigned int) getc(fp);
	b3 = (unsigned int) getc(fp);
	
	int res = b0 + (b1 << 8) + (b2 << 16) + (b3 << 24);

	return res;
	
}

short lits(FILE* fp)
{
	int b0,b1;
	
	
	b0 = (unsigned int) getc(fp);
	b1 = (unsigned int) getc(fp);
	
	short res = b0 + (b1 << 8);

	return res;
}

//
// lit l'entete et alloue la memoire.
//

bool imcouleur::LitEnteteBmp(FILE * fp)
{

	if (getc(fp) != 'B' || getc(fp) != 'M')
		return false;		// Magic number
	liti(fp);
	lits(fp);
	lits(fp);
	liti(fp);
	liti(fp);

	larg=liti(fp);
	haut=liti(fp);

	lits(fp);

	if (lits(fp) != 24)
		return false;
	liti(fp);
	liti(fp);
	liti(fp);
	liti(fp);
	liti(fp);
	liti(fp);

	larg_scanline = ((3*larg)%4 == 0) ? 3*larg : (3*larg + 4 - (3*larg)%4);
    bitimage = new BYTE[larg_scanline*haut];
	pbitmapinfo = new BITMAPINFO;
	pbitmapinfo->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	pbitmapinfo->bmiHeader.biWidth = larg;
	pbitmapinfo->bmiHeader.biHeight = haut;
	pbitmapinfo->bmiHeader.biPlanes = 1;
	pbitmapinfo->bmiHeader.biBitCount = 24;
	pbitmapinfo->bmiHeader.biCompression = BI_RGB;
	pbitmapinfo->bmiHeader.biSizeImage = 0;
	pbitmapinfo->bmiHeader.biXPelsPerMeter = 40000;
	pbitmapinfo->bmiHeader.biYPelsPerMeter = 40000;
	pbitmapinfo->bmiHeader.biClrUsed = 0;
	pbitmapinfo->bmiHeader.biClrImportant = 0;

	return true;
}



//
// Lit des donn�es 24 bits.
//
void imcouleur::LitDonneesBmp(FILE* df)
{
	int		i;


	int nboctets = haut*larg_scanline;

	for (i = 0 ; i < nboctets ; i++)
		bitimage[i] = getc(df);

	
}




bool imcouleur::load_bmp(char *fich)
{
	FILE*	dfd;
	int	rotation=0;

	if  (fopen_s(&dfd, fich,"rb")!=0){
			return false;
		}
	

	if (!LitEnteteBmp(dfd))
		return false;
	LitDonneesBmp(dfd);
	fclose(dfd);
	return true;

}



Point3D interpolenormaletriang1(Point3D p1, Point3D p2, Point3D p3,
								Point3D n1, Point3D n2, Point3D n3,
								Point3D point);



void imcouleur::getpixelinterpol(double x, double y, double& r, double& g, double& b) const{
	if (x >= larg-1.0001) x = larg - 1.0001;
	if (y >= haut-1.0001) y = haut - 1.0001;
	if (x <= 0) x = 0.001;
	if (y <= 0) y = 0.001;
	int coordyb = (haut - 1 - (int)y);
	int coordyh = (haut - 1 - (int)(y+1));
	int yb = (int) y;
	int yh = (int) (y+1);
	int xb = (int) x;
	int xh = (int) (x+1);

	Point3D hh(((double)bitimage[coordyh*larg_scanline+3*xh])/255.0,
				((double)bitimage[coordyh*larg_scanline+3*xh+1])/255.0,
			   ((double)bitimage[coordyh*larg_scanline+3*xh+2])/255.0);
	Point3D hb(((double)bitimage[coordyb*larg_scanline+3*xh])/255.0,
				((double)bitimage[coordyb*larg_scanline+3*xh+1])/255.0,
				((double)bitimage[coordyb*larg_scanline+3*xh+2])/255.0);
	Point3D bh(((double)bitimage[coordyh*larg_scanline+3*xb])/255.0,
				((double)bitimage[coordyh*larg_scanline+3*xb+1])/255.0,
				((double)bitimage[coordyh*larg_scanline+3*xb+2])/255.0);
	Point3D bb(((double)bitimage[coordyb*larg_scanline+3*xb])/255.0,
				((double)bitimage[coordyb*larg_scanline+3*xb+1])/255.0,
				((double)bitimage[coordyb*larg_scanline+3*xb+2])/255.0);
	Point3D res;
	if (y-yb > x-xb){
		res=interpolenormaletriang1(Point3D(xb,yb,0), Point3D(xh,yh,0), Point3D(xb,yh,0),
									bb,hh,bh,Point3D(x,y,0));
	}else{
		res=interpolenormaletriang1(Point3D(xb,yb,0), Point3D(xh,yh,0), Point3D(xh,yb,0),
									bb,hh,hb,Point3D(x,y,0));
	}
	b=res.x; g=res.y; r=res.z;
/*		double bhh = ((double)bitimage[coordyh*larg_scanline+3*xh])/255.0;
	double ghh = ((double)bitimage[coordyh*larg_scanline+3*xh+1])/255.0;
	double rhh = ((double)bitimage[coordyh*larg_scanline+3*xh+2])/255.0;
	double bbh = ((double)bitimage[coordyb*larg_scanline+3*xh])/255.0;
	double gbh = ((double)bitimage[coordyb*larg_scanline+3*xh+1])/255.0;
	double rbh = ((double)bitimage[coordyb*larg_scanline+3*xh+2])/255.0;

	double bhb = ((double)bitimage[coordyh*larg_scanline+3*xb])/255.0;
	double ghb = ((double)bitimage[coordyh*larg_scanline+3*xb+1])/255.0;
	double rhb = ((double)bitimage[coordyh*larg_scanline+3*xb+2])/255.0;
	double bbb = ((double)bitimage[coordyb*larg_scanline+3*xb])/255.0;
	double gbb = ((double)bitimage[coordyb*larg_scanline+3*xb+1])/255.0;
	double rbb = ((double)bitimage[coordyb*larg_scanline+3*xb+2])/255.0;

	double rb = (y-(int)y)*rhb + (((int)(y+1))-y)*rbb;
	double gb = (y-(int)y)*ghb + (((int)(y+1))-y)*gbb;
	double bb = (y-(int)y)*bhb + (((int)(y+1))-y)*bbb;
	double rh = (y-(int)y)*rhh + (((int)(y+1))-y)*rbh;
	double gh = (y-(int)y)*ghh + (((int)(y+1))-y)*gbh;
	double bh = (y-(int)y)*bhh + (((int)(y+1))-y)*bbh;

	r = (x-(int)x)*rh + (((int)(x+1))-x)*rb;
	g = (x-(int)x)*gh + (((int)(x+1))-x)*gb;
	b = (x-(int)x)*bh + (((int)(x+1))-x)*bb;
*/

}


void imcouleur::getderivative(double x, double y, double& dsds, double & dsdt, bool cycliquex, bool cycliquey) const{
	

	double d1, d2;

	if (x-1 < 0 && !cycliquex)
		d1 = (getlevel(x+1,y)-getlevel(x,y))*3.0/4.0;
	else
		if (x+1 >= larg-1 && !cycliquex)
			d1 = (getlevel(x,y)-getlevel(x-1,y))*3.0/4.0;
		else{
			d1 = (getlevel(x+1,y)-getlevel(x-1,y))*3.0/8.0;
			if (d1 > 0.05)
				d1=d1;
		}

	if (x-2 < 0 && !cycliquex)
		d2 = (getlevel(x+2,y)-getlevel(x,y))/8.0;
	else
		if (x+2 >= larg-1 && !cycliquex)
			d2 = (getlevel(x,y)-getlevel(x-2,y))/8.0;
		else
			d2 = (getlevel(x+2,y)-getlevel(x-2,y))/16.0;

	dsds = (d1+d2)*larg;


	if (y-1 < 0 && !cycliquey)
		d1 = (getlevel(x,y+1)-getlevel(x,y))*3.0/4.0;
	else
		if (y+1 >= haut-1 && !cycliquey)
			d1 = (getlevel(x,y)-getlevel(x,y-1))*3.0/4.0;
		else
			d1 = (getlevel(x,y+1)-getlevel(x,y-1))*3.0/8.0;

	if (y-2 < 0 && !cycliquey)
		d2 = (getlevel(x,y+2)-getlevel(x,y))/8.0;
	else
		if (y+2 >= haut-1 && !cycliquey)
			d2 = (getlevel(x,y)-getlevel(x,y-2))/8.0;
		else
			d2 = (getlevel(x,y+2)-getlevel(x,y-2))/16.0;

	dsdt = d1+d2*haut;


}

