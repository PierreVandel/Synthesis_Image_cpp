#if !defined(AFX_CONTROLCAMERADLG_H__A58E2120_5A38_11D3_B1CB_B308B92AD376__INCLUDED_)
#define AFX_CONTROLCAMERADLG_H__A58E2120_5A38_11D3_B1CB_B308B92AD376__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ControlCameraDlg.h : header file
//

#define WM_RAFFRAICHIR WM_USER + 5
#define WM_RAFFRAICHIR_NAVIGAT WM_USER + 6

/////////////////////////////////////////////////////////////////////////////
// CControlCameraDlg dialog

class CControlCameraDlg : public CDialog
{
	CView *m_pView;
	CBitmap m_bitmapup;
	CBitmap m_bitmapdo;
	CBitmap m_bitmaple;
	CBitmap m_bitmapri;
	CBitmap m_bitmaprg;
	CBitmap m_bitmaprd;
	CBitmap m_bitmapfo;
	CBitmap m_bitmapba;

	// Construction
public:
	CControlCameraDlg(CView* pView);
	BOOL Create();
	CControlCameraDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CControlCameraDlg)
	enum { IDD = IDD_CONTROL_CAMERA };
	float	m_rotstep;
	float	m_transstep;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CControlCameraDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CControlCameraDlg)
	afx_msg void OnCcRotDown();
	afx_msg void OnCcRotLeft();
	afx_msg void OnCcRotRight();
	afx_msg void OnCcRotUp();
	afx_msg void OnCcTransBackward();
	afx_msg void OnCcTransDown();
	afx_msg void OnCcTransForward();
	afx_msg void OnCcTransLeft();
	afx_msg void OnCcTransRight();
	afx_msg void OnCcTransUp();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnCcRotRd();
	afx_msg void OnCcRotRg();
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CControlNavigatDialog dialog

class CControlNavigatDialog : public CDialog
{


	CView *m_pView;
	CBitmap m_bitmapup;
	CBitmap m_bitmapdo;
	CBitmap m_bitmaple;
	CBitmap m_bitmapri;
	CBitmap m_bitmaprg;
	CBitmap m_bitmaprd;
	CBitmap m_bitmapfo;
	CBitmap m_bitmapba;

// Construction
public:
	CControlNavigatDialog(CView* pView);
	BOOL Create();
	CControlNavigatDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CControlNavigatDialog)
	enum { IDD = IDD_CONTROL_NAVIGAT };
	double	m_rotstep;
	double	m_transstep;
	BOOL	m_backward;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CControlNavigatDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CControlNavigatDialog)
	afx_msg void OnCnRotDown();
	afx_msg void OnCnRotLeft();
	afx_msg void OnCnRotRight();
	afx_msg void OnCnRotUp();
	afx_msg void OnCnTransBackward();
	afx_msg void OnCnTransDown();
	afx_msg void OnCnTransForward();
	afx_msg void OnCnTransLeft();
	afx_msg void OnCnTransRight();
	afx_msg void OnCnTransUp();
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnCnRotRd();
	afx_msg void OnCnRotRg();
	afx_msg void OnCnRottransDown();
	afx_msg void OnCnRottransLeft();
	afx_msg void OnCnRottransRd();
	afx_msg void OnCnRottransRg();
	afx_msg void OnCnRottransRight();
	afx_msg void OnCnRottransUp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTROLCAMERADLG_H__A58E2120_5A38_11D3_B1CB_B308B92AD376__INCLUDED_)
