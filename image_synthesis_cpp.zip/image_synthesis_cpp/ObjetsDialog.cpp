// ObjetsDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Synth.h"
#include "ObjetsDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CSphereGeomPropPage property page

IMPLEMENT_DYNCREATE(CSphereGeomPropPage, CPropertyPage)

CSphereGeomPropPage::CSphereGeomPropPage() : CPropertyPage(CSphereGeomPropPage::IDD)
{
	//{{AFX_DATA_INIT(CSphereGeomPropPage)
	m_cx = 0.0;
	m_cy = 0.0;
	m_cz = 0.0;
	m_nbmerid = 0;
	m_nbparal = 0;
	m_radius = 0.0;
	m_rotx = 0.0;
	m_roty = 0.0;
	m_rotz = 0.0;
	m_scax = 0.0;
	m_scay = 0.0;
	m_scaz = 0.0;
	//}}AFX_DATA_INIT
}

CSphereGeomPropPage::~CSphereGeomPropPage()
{
}

void CSphereGeomPropPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSphereGeomPropPage)
	DDX_Text(pDX, IDC_CX, m_cx);
	DDX_Text(pDX, IDC_CY, m_cy);
	DDX_Text(pDX, IDC_CZ, m_cz);
	DDX_Text(pDX, IDC_NBMERID, m_nbmerid);
	DDV_MinMaxInt(pDX, m_nbmerid, 3, 500);
	DDX_Text(pDX, IDC_NBPARAL, m_nbparal);
	DDV_MinMaxInt(pDX, m_nbparal, 2, 500);
	DDX_Text(pDX, IDC_RAYON, m_radius);
	DDV_MinMaxDouble(pDX, m_radius, 0., 10000.);
	DDX_Text(pDX, IDC_ROT_X, m_rotx);
	DDX_Text(pDX, IDC_ROT_Y, m_roty);
	DDX_Text(pDX, IDC_ROT_Z, m_rotz);
	DDX_Text(pDX, IDC_SCA_X, m_scax);
	DDX_Text(pDX, IDC_SCA_Y, m_scay);
	DDX_Text(pDX, IDC_SCA_Z, m_scaz);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSphereGeomPropPage, CPropertyPage)
	//{{AFX_MSG_MAP(CSphereGeomPropPage)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSphereGeomPropPage message handlers

/////////////////////////////////////////////////////////////////////////////
// CConeRevolPropPage property page


IMPLEMENT_DYNCREATE(CConeRevolPropPage, CPropertyPage)

CConeRevolPropPage::CConeRevolPropPage() : CPropertyPage(CConeRevolPropPage::IDD)
{
	//{{AFX_DATA_INIT(CConeRevolPropPage)
	m_cx = 0.0;
	m_cy = 0.0;
	m_cz = 0.0;
	m_hauttronq = 0.0;
	m_nbmerid = 0;
	m_bottomradius = 0.0;
	m_topradius = 0.0;
	m_rotx = 0.0;
	m_roty = 0.0;
	m_rotz = 0.0;
	m_scax = 0.0;
	m_scay = 0.0;
	m_scaz = 0.0;
	m_nbparal = 0;
	//}}AFX_DATA_INIT
}

CConeRevolPropPage::~CConeRevolPropPage()
{
}

void CConeRevolPropPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConeRevolPropPage)
	DDX_Text(pDX, IDC_CX, m_cx);
	DDX_Text(pDX, IDC_CY, m_cy);
	DDX_Text(pDX, IDC_CZ, m_cz);
	DDX_Text(pDX, IDC_HAUTTRONQ, m_hauttronq);
	DDX_Text(pDX, IDC_NBMERID, m_nbmerid);
	DDX_Text(pDX, IDC_RAYON_BOTTOM, m_bottomradius);
	DDX_Text(pDX, IDC_RAYON_TOP, m_topradius);
	DDX_Text(pDX, IDC_ROT_X, m_rotx);
	DDX_Text(pDX, IDC_ROT_Y, m_roty);
	DDX_Text(pDX, IDC_ROT_Z, m_rotz);
	DDX_Text(pDX, IDC_SCA_X, m_scax);
	DDX_Text(pDX, IDC_SCA_Y, m_scay);
	DDX_Text(pDX, IDC_SCA_Z, m_scaz);
	DDX_Text(pDX, IDC_NBPARAL, m_nbparal);
	DDV_MinMaxInt(pDX, m_nbparal, 2, 500);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConeRevolPropPage, CPropertyPage)
	//{{AFX_MSG_MAP(CConeRevolPropPage)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConeRevolPropPage message handlers



/////////////////////////////////////////////////////////////////////////////
// CNewLight dialog


CNewLight::CNewLight(CWnd* pParent /*=NULL*/)
	: CDialog(CNewLight::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewLight)
	m_coulB = 0.0f;
	m_coulG = 0.0f;
	m_coulR = 0.0f;
	m_posx = 0.0f;
	m_posy = 0.0f;
	m_posz = 0.0f;
	m_attenuation = FALSE;
	m_directionnel = FALSE;
	m_dirx = 0.0;
	m_diry = 0.0;
	m_dirz = 0.0;
	m_exposantdirect = 0;
	m_c1 = 0.0;
	m_c2 = 0.0;
	m_c3 = 0.0;
	//}}AFX_DATA_INIT
}


void CNewLight::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewLight)
	DDX_Text(pDX, IDC_NEWLIGHT_COULB, m_coulB);
	DDV_MinMaxFloat(pDX, m_coulB, 0.f, 10.f);
	DDX_Text(pDX, IDC_NEWLIGHT_COULG, m_coulG);
	DDV_MinMaxFloat(pDX, m_coulG, 0.f, 10.f);
	DDX_Text(pDX, IDC_NEWLIGHT_COULR, m_coulR);
	DDV_MinMaxFloat(pDX, m_coulR, 0.f, 10.f);
	DDX_Text(pDX, IDC_POSX, m_posx);
	DDX_Text(pDX, IDC_POSY, m_posy);
	DDX_Text(pDX, IDC_POSZ, m_posz);
	DDX_Check(pDX, IDC_ATTENUATION, m_attenuation);
	DDX_Check(pDX, IDC_DIRECTIONNEL, m_directionnel);
	DDX_Text(pDX, IDC_DIRX, m_dirx);
	DDX_Text(pDX, IDC_DIRY, m_diry);
	DDX_Text(pDX, IDC_DIRZ, m_dirz);
	DDX_Text(pDX, IDC_EXPOSANT_DIRECT, m_exposantdirect);
	DDV_MinMaxInt(pDX, m_exposantdirect, 1, 500);
	DDX_Text(pDX, IDC_NEWLIGHT_C1, m_c1);
	DDV_MinMaxDouble(pDX, m_c1, 0., 100.);
	DDX_Text(pDX, IDC_NEWLIGHT_C2, m_c2);
	DDV_MinMaxDouble(pDX, m_c2, 0., 100.);
	DDX_Text(pDX, IDC_NEWLIGHT_C3, m_c3);
	DDV_MinMaxDouble(pDX, m_c3, 0., 100.);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNewLight, CDialog)
	//{{AFX_MSG_MAP(CNewLight)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewLight message handlers
/////////////////////////////////////////////////////////////////////////////
// CSelectCamera dialog


CSelectCamera::CSelectCamera(CWnd* pParent /*=NULL*/)
	: CDialog(CSelectCamera::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSelectCamera)
	m_nocam = 0;
	//}}AFX_DATA_INIT
}


void CSelectCamera::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSelectCamera)
	DDX_Text(pDX, IDC_SELECTCAM_NOCAM, m_nocam);
	DDV_MinMaxInt(pDX, m_nocam, 0, 100);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSelectCamera, CDialog)
	//{{AFX_MSG_MAP(CSelectCamera)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSelectCamera message handlers
/////////////////////////////////////////////////////////////////////////////
// CErreurDomaineDlg dialog


CErreurDomaineDlg::CErreurDomaineDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CErreurDomaineDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CErreurDomaineDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CErreurDomaineDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CErreurDomaineDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CErreurDomaineDlg, CDialog)
	//{{AFX_MSG_MAP(CErreurDomaineDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CErreurDomaineDlg message handlers
/////////////////////////////////////////////////////////////////////////////
// CEditCameraDialog dialog


CEditCameraDialog::CEditCameraDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CEditCameraDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEditCameraDialog)
	m_anglex = 0.0f;
	m_cx = 0.0f;
	m_cy = 0.0f;
	m_cz = 0.0f;
	m_posx = 0.0f;
	m_posy = 0.0f;
	m_posz = 0.0f;
	//}}AFX_DATA_INIT
}


void CEditCameraDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEditCameraDialog)
	DDX_Text(pDX, IDC_ANGLEX, m_anglex);
	DDV_MinMaxFloat(pDX, m_anglex, 0.f, 180.f);
	DDX_Text(pDX, IDC_EDITCAM_CX, m_cx);
	DDX_Text(pDX, IDC_EDITCAM_CY, m_cy);
	DDX_Text(pDX, IDC_EDITCAM_CZ, m_cz);
	DDX_Text(pDX, IDC_POSX, m_posx);
	DDX_Text(pDX, IDC_POSY, m_posy);
	DDX_Text(pDX, IDC_POSZ, m_posz);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEditCameraDialog, CDialog)
	//{{AFX_MSG_MAP(CEditCameraDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditCameraDialog message handlers




/////////////////////////////////////////////////////////////////////////////
// CEditSourceLumDialog dialog


CEditSourceLumDialog::CEditSourceLumDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CEditSourceLumDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEditSourceLumDialog)
	m_allumee = FALSE;
	m_ib = 0.0;
	m_ig = 0.0;
	m_ir = 0.0;
	m_posx = 0.0;
	m_posy = 0.0;
	m_posz = 0.0;
	//}}AFX_DATA_INIT
}


void CEditSourceLumDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEditSourceLumDialog)
	DDX_Check(pDX, IDC_ALLUMEE, m_allumee);
	DDX_Text(pDX, IDC_EDITLUM_IB, m_ib);
	DDV_MinMaxDouble(pDX, m_ib, 0., 1.);
	DDX_Text(pDX, IDC_EDITLUM_IG, m_ig);
	DDV_MinMaxDouble(pDX, m_ig, 0., 1.);
	DDX_Text(pDX, IDC_EDITLUM_IR, m_ir);
	DDV_MinMaxDouble(pDX, m_ir, 0., 1.);
	DDX_Text(pDX, IDC_POSX, m_posx);
	DDX_Text(pDX, IDC_POSY, m_posy);
	DDX_Text(pDX, IDC_POSZ, m_posz);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEditSourceLumDialog, CDialog)
	//{{AFX_MSG_MAP(CEditSourceLumDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditSourceLumDialog message handlers
/////////////////////////////////////////////////////////////////////////////
// CSelectSourceDialog dialog


CSelectSourceDialog::CSelectSourceDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CSelectSourceDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSelectSourceDialog)
	m_no = 0;
	//}}AFX_DATA_INIT
}


void CSelectSourceDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSelectSourceDialog)
	DDX_Text(pDX, IDC_SELECTSOURCE_NO, m_no);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSelectSourceDialog, CDialog)
	//{{AFX_MSG_MAP(CSelectSourceDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSelectSourceDialog message handlers

/////////////////////////////////////////////////////////////////////////////
// CTranslationDialog dialog


CTranslationDialog::CTranslationDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CTranslationDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTranslationDialog)
	m_x = 0.0;
	m_y = 0.0;
	m_z = 0.0;
	//}}AFX_DATA_INIT
}


void CTranslationDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTranslationDialog)
	DDX_Text(pDX, IDC_TRANSLATION_X, m_x);
	DDX_Text(pDX, IDC_TRANSLATION_Y, m_y);
	DDX_Text(pDX, IDC_TRANSLATION_Z, m_z);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTranslationDialog, CDialog)
	//{{AFX_MSG_MAP(CTranslationDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTranslationDialog message handlers
/////////////////////////////////////////////////////////////////////////////
// CCylRevolGeomPropPage property page

IMPLEMENT_DYNCREATE(CCylRevolGeomPropPage, CPropertyPage)

CCylRevolGeomPropPage::CCylRevolGeomPropPage() : CPropertyPage(CCylRevolGeomPropPage::IDD)
{
	//{{AFX_DATA_INIT(CCylRevolGeomPropPage)
	m_cx = 0.0;
	m_cy = 0.0;
	m_cz = 0.0;
	m_nbmerid = 0;
	m_hauteur = 0.0;
	m_radius = 0.0;
	m_rotx = 0.0;
	m_roty = 0.0;
	m_rotz = 0.0;
	m_scax = 0.0;
	m_scay = 0.0;
	m_scaz = 0.0;
	//}}AFX_DATA_INIT
}

CCylRevolGeomPropPage::~CCylRevolGeomPropPage()
{
}

void CCylRevolGeomPropPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCylRevolGeomPropPage)
	DDX_Text(pDX, IDC_CX, m_cx);
	DDX_Text(pDX, IDC_CY, m_cy);
	DDX_Text(pDX, IDC_CZ, m_cz);
	DDX_Text(pDX, IDC_NBMERID, m_nbmerid);
	DDX_Text(pDX, IDC_HAUTEUR, m_hauteur);
	DDX_Text(pDX, IDC_RAYON, m_radius);
	DDX_Text(pDX, IDC_ROT_X, m_rotx);
	DDX_Text(pDX, IDC_ROT_Y, m_roty);
	DDX_Text(pDX, IDC_ROT_Z, m_rotz);
	DDX_Text(pDX, IDC_SCA_X, m_scax);
	DDX_Text(pDX, IDC_SCA_Y, m_scay);
	DDX_Text(pDX, IDC_SCA_Z, m_scaz);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCylRevolGeomPropPage, CPropertyPage)
	//{{AFX_MSG_MAP(CCylRevolGeomPropPage)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCylRevolGeomPropPage message handlers
/////////////////////////////////////////////////////////////////////////////
// CBoxGeomPropPage property page

IMPLEMENT_DYNCREATE(CBoxGeomPropPage, CPropertyPage)

CBoxGeomPropPage::CBoxGeomPropPage() : CPropertyPage(CBoxGeomPropPage::IDD)
{
	//{{AFX_DATA_INIT(CBoxGeomPropPage)
	m_cx = 0.0;
	m_cy = 0.0;
	m_cz = 0.0;
	m_dimx = 0.0;
	m_dimy = 0.0;
	m_dimz = 0.0;
	m_rotx = 0.0;
	m_roty = 0.0;
	m_rotz = 0.0;
	m_nbmerid = 0;
	//}}AFX_DATA_INIT
}

CBoxGeomPropPage::~CBoxGeomPropPage()
{
}

void CBoxGeomPropPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBoxGeomPropPage)
	DDX_Text(pDX, IDC_CX, m_cx);
	DDX_Text(pDX, IDC_CY, m_cy);
	DDX_Text(pDX, IDC_CZ, m_cz);
	DDX_Text(pDX, IDC_DIMX, m_dimx);
	DDX_Text(pDX, IDC_DIMY, m_dimy);
	DDX_Text(pDX, IDC_DIMZ, m_dimz);
	DDX_Text(pDX, IDC_ROT_X, m_rotx);
	DDX_Text(pDX, IDC_ROT_Y, m_roty);
	DDX_Text(pDX, IDC_ROT_Z, m_rotz);
	DDX_Text(pDX, IDC_NBMERID, m_nbmerid);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBoxGeomPropPage, CPropertyPage)
	//{{AFX_MSG_MAP(CBoxGeomPropPage)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBoxGeomPropPage message handlers
/////////////////////////////////////////////////////////////////////////////
// CCylinSplineGeomPropPage property page

IMPLEMENT_DYNCREATE(CCylinSplineGeomPropPage, CPropertyPage)

CCylinSplineGeomPropPage::CCylinSplineGeomPropPage() : CPropertyPage(CCylinSplineGeomPropPage::IDD)
{
	//{{AFX_DATA_INIT(CCylinSplineGeomPropPage)
	m_cx = 0.0;
	m_cy = 0.0;
	m_cz = 0.0;
	m_echantspline = 0;
	m_rotx = 0.0;
	m_roty = 0.0;
	m_rotz = 0.0;
	m_scax = 0.0;
	m_scay = 0.0;
	m_scaz = 0.0;
	m_phongenable = FALSE;
	m_hauteur = 0.0;
	m_nomsp = _T("");
	m_topreduction = 0.0;
	m_echanthauteur = 0;
	//}}AFX_DATA_INIT
}

CCylinSplineGeomPropPage::~CCylinSplineGeomPropPage()
{
}

void CCylinSplineGeomPropPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCylinSplineGeomPropPage)
	DDX_Text(pDX, IDC_CX, m_cx);
	DDX_Text(pDX, IDC_CY, m_cy);
	DDX_Text(pDX, IDC_CZ, m_cz);
	DDX_Text(pDX, IDC_ECHANT_SPLINE, m_echantspline);
	DDV_MinMaxInt(pDX, m_echantspline, 1, 500);
	DDX_Text(pDX, IDC_ROT_X, m_rotx);
	DDX_Text(pDX, IDC_ROT_Y, m_roty);
	DDX_Text(pDX, IDC_ROT_Z, m_rotz);
	DDX_Text(pDX, IDC_SCA_X, m_scax);
	DDX_Text(pDX, IDC_SCA_Y, m_scay);
	DDX_Text(pDX, IDC_SCA_Z, m_scaz);
	DDX_Check(pDX, IDC_PHONG, m_phongenable);
	DDX_Text(pDX, IDC_HAUT, m_hauteur);
	DDX_Text(pDX, IDC_NOM_SPLINE2D, m_nomsp);
	DDX_Text(pDX, IDC_TOPREDUCTION, m_topreduction);
	DDX_Text(pDX, IDC_ECHANT_HAUTEUR, m_echanthauteur);
	DDV_MinMaxInt(pDX, m_echanthauteur, 1, 500);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCylinSplineGeomPropPage, CPropertyPage)
	//{{AFX_MSG_MAP(CCylinSplineGeomPropPage)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCylinSplineGeomPropPage message handlers
/////////////////////////////////////////////////////////////////////////////
// CDeformSplineGeom property page

IMPLEMENT_DYNCREATE(CDeformSplineGeom, CPropertyPage)

CDeformSplineGeom::CDeformSplineGeom() : CPropertyPage(CDeformSplineGeom::IDD)
{
	//{{AFX_DATA_INIT(CDeformSplineGeom)
	m_cx = 0.0;
	m_cy = 0.0;
	m_cz = 0.0;
	m_echantspline = 0;
	m_nbctrl = 0;
	m_nomsp = _T("");
	m_phongenable = FALSE;
	m_rotx = 0.0;
	m_roty = 0.0;
	m_rotz = 0.0;
	m_scax = 0.0;
	m_scay = 0.0;
	m_scaz = 0.0;
	m_echantcercle = 0;
	//}}AFX_DATA_INIT
}

CDeformSplineGeom::~CDeformSplineGeom()
{
}

void CDeformSplineGeom::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDeformSplineGeom)
	DDX_Text(pDX, IDC_CX, m_cx);
	DDX_Text(pDX, IDC_CY, m_cy);
	DDX_Text(pDX, IDC_CZ, m_cz);
	DDX_Text(pDX, IDC_ECHANT_SPLINE, m_echantspline);
	DDV_MinMaxInt(pDX, m_echantspline, 1, 500);
	DDX_Text(pDX, IDC_NBCTRL_CERCLE, m_nbctrl);
	DDV_MinMaxInt(pDX, m_nbctrl, 3, 500);
	DDX_Text(pDX, IDC_NOM_SPLINE2D, m_nomsp);
	DDX_Check(pDX, IDC_PHONG, m_phongenable);
	DDX_Text(pDX, IDC_ROT_X, m_rotx);
	DDX_Text(pDX, IDC_ROT_Y, m_roty);
	DDX_Text(pDX, IDC_ROT_Z, m_rotz);
	DDX_Text(pDX, IDC_SCA_X, m_scax);
	DDX_Text(pDX, IDC_SCA_Y, m_scay);
	DDX_Text(pDX, IDC_SCA_Z, m_scaz);
	DDX_Text(pDX, IDC_ECHANT_CIRCLE, m_echantcercle);
	DDV_MinMaxInt(pDX, m_echantcercle, 3, 500);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDeformSplineGeom, CPropertyPage)
	//{{AFX_MSG_MAP(CDeformSplineGeom)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDeformSplineGeom message handlers
/////////////////////////////////////////////////////////////////////////////
// CExtrusionGeomPropPage property page

IMPLEMENT_DYNCREATE(CExtrusionGeomPropPage, CPropertyPage)

CExtrusionGeomPropPage::CExtrusionGeomPropPage() : CPropertyPage(CExtrusionGeomPropPage::IDD)
{
	//{{AFX_DATA_INIT(CExtrusionGeomPropPage)
	m_pcba = 0.0;
	m_pcbf = 0.0;
	m_pcea = 0.0;
	m_pcef = 0.0;
	m_withchanfrein = FALSE;
	m_cx = 0.0;
	m_cy = 0.0;
	m_cz = 0.0;
	m_echantame = 0;
	m_echantforme = 0;
	m_nomame = _T("");
	m_nomforme = _T("");
	m_phongenable = FALSE;
	m_rotx = 0.0;
	m_roty = 0.0;
	m_rotz = 0.0;
	m_scashape = 0.0;
	m_scax = 0.0;
	m_scay = 0.0;
	m_scaz = 0.0;
	//}}AFX_DATA_INIT
}

CExtrusionGeomPropPage::~CExtrusionGeomPropPage()
{
}

void CExtrusionGeomPropPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExtrusionGeomPropPage)
	DDX_Text(pDX, IDC__PROPCH_BA, m_pcba);
	DDV_MinMaxDouble(pDX, m_pcba, 0., 1.);
	DDX_Text(pDX, IDC__PROPCH_BF, m_pcbf);
	DDV_MinMaxDouble(pDX, m_pcbf, 0., 1.);
	DDX_Text(pDX, IDC__PROPCH_EA, m_pcea);
	DDV_MinMaxDouble(pDX, m_pcea, 0., 1.);
	DDX_Text(pDX, IDC__PROPCH_EF, m_pcef);
	DDV_MinMaxDouble(pDX, m_pcef, 0., 1.);
	DDX_Check(pDX, IDC_AVEC_CHANFREIN, m_withchanfrein);
	DDX_Text(pDX, IDC_CX, m_cx);
	DDX_Text(pDX, IDC_CY, m_cy);
	DDX_Text(pDX, IDC_CZ, m_cz);
	DDX_Text(pDX, IDC_ECHANT_AME, m_echantame);
	DDV_MinMaxInt(pDX, m_echantame, 1, 500);
	DDX_Text(pDX, IDC_ECHANT_FORME, m_echantforme);
	DDV_MinMaxInt(pDX, m_echantforme, 1, 500);
	DDX_Text(pDX, IDC_NOM_SPLINE_AME, m_nomame);
	DDX_Text(pDX, IDC_NOM_SPLINE_FORME, m_nomforme);
	DDX_Check(pDX, IDC_PHONG, m_phongenable);
	DDX_Text(pDX, IDC_ROT_X, m_rotx);
	DDX_Text(pDX, IDC_ROT_Y, m_roty);
	DDX_Text(pDX, IDC_ROT_Z, m_rotz);
	DDX_Text(pDX, IDC_SCA_SHAPE, m_scashape);
	DDX_Text(pDX, IDC_SCA_X, m_scax);
	DDX_Text(pDX, IDC_SCA_Y, m_scay);
	DDX_Text(pDX, IDC_SCA_Z, m_scaz);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CExtrusionGeomPropPage, CPropertyPage)
	//{{AFX_MSG_MAP(CExtrusionGeomPropPage)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExtrusionGeomPropPage message handlers
/////////////////////////////////////////////////////////////////////////////
// CSplineRevolGeometryPropPage property page

IMPLEMENT_DYNCREATE(CSplineRevolGeometryPropPage, CPropertyPage)

CSplineRevolGeometryPropPage::CSplineRevolGeometryPropPage() : CPropertyPage(CSplineRevolGeometryPropPage::IDD)
{
	//{{AFX_DATA_INIT(CSplineRevolGeometryPropPage)
	m_cx = 0.0;
	m_cy = 0.0;
	m_cz = 0.0;
	m_phongenable = FALSE;
	m_rotx = 0.0;
	m_roty = 0.0;
	m_rotz = 0.0;
	m_scax = 0.0;
	m_scaz = 0.0;
	m_nomsp = _T("");
	m_scay = 0.0;
	m_echantcercle = 0;
	m_echantspline = 0;
	//}}AFX_DATA_INIT
}

CSplineRevolGeometryPropPage::~CSplineRevolGeometryPropPage()
{
}

void CSplineRevolGeometryPropPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSplineRevolGeometryPropPage)
	DDX_Text(pDX, IDC_CX, m_cx);
	DDX_Text(pDX, IDC_CY, m_cy);
	DDX_Text(pDX, IDC_CZ, m_cz);
	DDX_Check(pDX, IDC_PHONG, m_phongenable);
	DDX_Text(pDX, IDC_ROT_X, m_rotx);
	DDX_Text(pDX, IDC_ROT_Y, m_roty);
	DDX_Text(pDX, IDC_ROT_Z, m_rotz);
	DDX_Text(pDX, IDC_SCA_X, m_scax);
	DDX_Text(pDX, IDC_SCA_Z, m_scaz);
	DDX_Text(pDX, IDC_NOM_SPLINE2D, m_nomsp);
	DDX_Text(pDX, IDC_SCA_Y, m_scay);
	DDX_Text(pDX, IDC_ECHANT_CIRCLE, m_echantcercle);
	DDX_Text(pDX, IDC_ECHANT_SPLINE, m_echantspline);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSplineRevolGeometryPropPage, CPropertyPage)
	//{{AFX_MSG_MAP(CSplineRevolGeometryPropPage)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSplineRevolGeometryPropPage message handlers
/////////////////////////////////////////////////////////////////////////////
// CDeformableCylinRevolPropPage property page

IMPLEMENT_DYNCREATE(CDeformableCylinRevolPropPage, CPropertyPage)

CDeformableCylinRevolPropPage::CDeformableCylinRevolPropPage() : CPropertyPage(CDeformableCylinRevolPropPage::IDD)
{
	//{{AFX_DATA_INIT(CDeformableCylinRevolPropPage)
	m_cx = 0.0;
	m_cy = 0.0;
	m_cz = 0.0;
	m_hauttronq = 0.0;
	m_nbctrlhaut = 0;
	m_nbctrlcircle = 0;
	m_nbmerid = 0;
	m_nbparal = 0;
	m_bottomradius = 0.0;
	m_topradius = 0.0;
	m_rotx = 0.0;
	m_roty = 0.0;
	m_rotz = 0.0;
	m_scax = 0.0;
	m_scay = 0.0;
	m_scaz = 0.0;
	m_nbctrldisk = 0;
	//}}AFX_DATA_INIT
}

CDeformableCylinRevolPropPage::~CDeformableCylinRevolPropPage()
{
}

void CDeformableCylinRevolPropPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDeformableCylinRevolPropPage)
	DDX_Text(pDX, IDC_CX, m_cx);
	DDX_Text(pDX, IDC_CY, m_cy);
	DDX_Text(pDX, IDC_CZ, m_cz);
	DDX_Text(pDX, IDC_HAUTTRONQ, m_hauttronq);
	DDX_Text(pDX, IDC_NBCONTROHEIGHT, m_nbctrlhaut);
	DDV_MinMaxInt(pDX, m_nbctrlhaut, 2, 1000);
	DDX_Text(pDX, IDC_NBCONTROLCIRCLE, m_nbctrlcircle);
	DDV_MinMaxInt(pDX, m_nbctrlcircle, 3, 1000);
	DDX_Text(pDX, IDC_NBMERID, m_nbmerid);
	DDV_MinMaxInt(pDX, m_nbmerid, 3, 1000);
	DDX_Text(pDX, IDC_NBPARAL, m_nbparal);
	DDV_MinMaxInt(pDX, m_nbparal, 1, 1000);
	DDX_Text(pDX, IDC_RAYON_BOTTOM, m_bottomradius);
	DDX_Text(pDX, IDC_RAYON_TOP, m_topradius);
	DDX_Text(pDX, IDC_ROT_X, m_rotx);
	DDX_Text(pDX, IDC_ROT_Y, m_roty);
	DDX_Text(pDX, IDC_ROT_Z, m_rotz);
	DDX_Text(pDX, IDC_SCA_X, m_scax);
	DDX_Text(pDX, IDC_SCA_Y, m_scay);
	DDX_Text(pDX, IDC_SCA_Z, m_scaz);
	DDX_Text(pDX, IDC_NBCONTROLDISK, m_nbctrldisk);
	DDV_MinMaxInt(pDX, m_nbctrldisk, 2, 1000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDeformableCylinRevolPropPage, CPropertyPage)
	//{{AFX_MSG_MAP(CDeformableCylinRevolPropPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDeformableCylinRevolPropPage message handlers

/////////////////////////////////////////////////////////////////////////////
// CTransformDialog dialog


CTransformDialog::CTransformDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CTransformDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTransformDialog)
	m_angle = 0.0;
	m_axisx = 0.0;
	m_axisy = 0.0;
	m_axisz = 0.0;
	m_origx = 0.0;
	m_origy = 0.0;
	m_origz = 0.0;
	m_scale = 0.0;
	m_translatx = 0.0;
	m_translaty = 0.0;
	m_translatz = 0.0;
	//}}AFX_DATA_INIT
}


void CTransformDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTransformDialog)
	DDX_Text(pDX, IDC_ANGLE, m_angle);
	DDX_Text(pDX, IDC_AXIS_X, m_axisx);
	DDX_Text(pDX, IDC_AXIS_Y, m_axisy);
	DDX_Text(pDX, IDC_AXIS_Z, m_axisz);
	DDX_Text(pDX, IDC_ORIGIN_X, m_origx);
	DDX_Text(pDX, IDC_ORIGIN_Y, m_origy);
	DDX_Text(pDX, IDC_ORIGIN_Z, m_origz);
	DDX_Text(pDX, IDC_SCALE, m_scale);
	DDX_Text(pDX, IDC_TRANSLAT_X, m_translatx);
	DDX_Text(pDX, IDC_TRANSLAT_Y, m_translaty);
	DDX_Text(pDX, IDC_TRANSLAT_Z, m_translatz);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTransformDialog, CDialog)
	//{{AFX_MSG_MAP(CTransformDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTransformDialog message handlers
