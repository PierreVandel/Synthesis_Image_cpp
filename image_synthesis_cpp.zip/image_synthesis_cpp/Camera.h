
//////////////////////////////////////////////////////////////////////
// classe Camera : classe dont derivent les cameras avec projection parallele ou en perspective
// (seules les cameras en perspectives sont implementees)
//////////////////////////////////////////////////////////////////////

#include "Objet3D.h"
#include "Matrice.h"

#ifndef CAMERA_H

#define CAMERA_H

enum typ_cam {PARAL, PERSPECT};

class Camera{
	friend class Scene3D;
	friend class Scene3DRay;
	friend class Scene3DRadio;
	friend class Listeobj;
	friend class Surface;
	friend class SurfaceBSplineCubique;
	friend class SurfaceBSplineCubiqueSphere;
	friend class SurfaceBSplineCubiqueTore;
	friend class SurfaceBSplineCubiqueDisk;
	friend class SurfaceBSplineCubiqueCyl;

protected:
	Point3D pos;     // position de la camera dans l'espace
	Point3D centre;  // point de visee de la camera
	Matrice M;       // matrice de passage du repere de la scene au repere lie a la camera

	typ_cam type;   // Parallele ou perspective

public:

	// constructeurs :
	Camera(void){}
	Camera(double x, double y, double z, 
			   double dirx, double diry, double dirz);

	// accesseurs aux donnees "protected" :
	virtual 	double accesanglex(void)=0;
	Point3D accespos(void){return pos;}
	Point3D accescentre(void){return centre;}

	virtual Camera* copie(void)=0;
};


//////////////////////////////////////////////////////////////////////
// Classe Cameraperspect : camera avec projection en perspective
//////////////////////////////////////////////////////////////////////

class Cameraperspect:public Camera{
	friend class Scene3D;

	double anglex;  // angle d'ouverture de la camera

public:

	// constructeur : positionne la camera dans l'espace en initialisant la matrice M
	Cameraperspect(double angle){anglex=angle; type=PERSPECT;}
	Cameraperspect(double x, double y, double z, 
			       double cx, double cy, double cz,
				   double angx);

	// accesseur :
	double accesanglex(void){return anglex;}

	Camera* copie(void);
};

#endif