#if !defined(AFX_SPLINE3DVIEW_H__686D037B_0934_456B_AE31_535C9033128F__INCLUDED_)
#define AFX_SPLINE3DVIEW_H__686D037B_0934_456B_AE31_535C9033128F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Spline3DView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSpline3DView view

#include "Camera.h"

class CSpline3DView : public CView
{
	int dimx, dimy;

	bool ctrlpoinselect;
	CPoint noctrlpoinselect;
	bool gaucheenfonce;
	bool droiteenfonce;
	int noplan;
	CPoint anciensouris;

	double rayondeform_i;
	double rayondeform_j;
	double speeddeform;
	double amplitudelissage;
	int ri, rj;

	double steprot, steptrans;


protected:
	CSpline3DView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CSpline3DView)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSpline3DView)
	public:
	virtual void OnInitialUpdate();
	virtual void OnDragLeave();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CSpline3DView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CSpline3DView)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnSplineDeformXy();
	afx_msg void OnUpdateSplineDeformXy(CCmdUI* pCmdUI);
	afx_msg void OnSplineDeformXz();
	afx_msg void OnUpdateSplineDeformXz(CCmdUI* pCmdUI);
	afx_msg void OnSplineDeformYz();
	afx_msg void OnUpdateSplineDeformYz(CCmdUI* pCmdUI);
	afx_msg void OnDestroy();
	afx_msg void OnSplineSetrayondeform();
	afx_msg void OnSplinesLissage();
	afx_msg void OnSplineLissageLocal();
	afx_msg void OnUpdateSplineLissageLocal(CCmdUI* pCmdUI);
	afx_msg void OnSplineElevation();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPLINE3DVIEW_H__686D037B_0934_456B_AE31_535C9033128F__INCLUDED_)
